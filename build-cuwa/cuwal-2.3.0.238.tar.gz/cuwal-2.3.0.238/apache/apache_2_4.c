/*
 * apache_2_4.c -- Interface with Apache 2.4
 *
 * Copyright 2007 Cornell University.
 * All Rights Reserved.
 *
 ************************************************************************
 *  $Log: apache_2_4.c,v $
 *  Revision 1.5  2015/10/07 17:31:41  hy93
 *  merge TwoFactor treee to the head
 *
 *  Revision 1.4.4.3  2015/10/01 16:07:19  hy93
 *  add session to cuwa_permit_lookup
 *
 *  Revision 1.4.4.2  2015/06/30 12:55:49  hy93
 *  apache 2.4 support
 *
 *  Revision 1.4.2.2  2014/10/23 15:27:14  hy93
 *  Add Apache 2.4 support
 *
 *  Revision 1.3  2014/10/03 14:29:34  hy93
 *  add cuwaInquire call for noprompt
 *
 *  Revision 1.2  2014/10/03 14:26:04  hy93
 *  remove line feed
 *
 *  Revision 1.1  2014/07/25 17:27:49  hy93
 *  Apache 2.4 support
 *
 ************************************************************************/                                                                        

#ifdef APLOG_USE_MODULE
APLOG_USE_MODULE(cuwebauth);
#endif 

#include <mod_auth.h>
#include <wal.h>
#include <log.h>
#include <cuwa_err.h>

#ifdef WEBAUTH_BUILD
static int cuwa_core_authz_inquire( request_rec *r )
{
    CUWACfg_t *cfg = cuwa_wal_get_config(r);
    char *remote_user = cuwa_wal_get_env( r,"REMOTE_USER");
    char *full_user = cuwa_wal_get_env( r,"CUWA_FULL_USER");
    char *inquire = CFG_CUWAInquire(cfg);
    const char *req_word;
    int rc = CUWA_OK;

    // handle the CUWAInquire directive...
    if (inquire && remote_user)
    {
        char *memberships;

        req_word = cuwa_getword(r->pool, (const char **) &inquire,' ');

        if (!strcmp(req_word, "permit"))
        {
            rc = cuwa_permit_lookup(r, r->pool, NULL,CFG_CUWAKerberosPrincipal(cfg), CFG_CUWAKeytab(cfg),
                               full_user, inquire, &memberships);
            if (rc) return rc;

            if (memberships)
            {
                cuwa_trace("set membership:%s", memberships);
                cuwa_wal_set_header_in(r,"CUWA_GROUPS",memberships);
                cuwa_wal_set_env(r,"CUWA_GROUPS",memberships);
            }
        }
        else
        {
            char *msg = "Server configuration error."; 
            cuwa_wal_save_error(r, HTTP_SERVER_ERROR, CUWA_ERR, msg);
            cuwa_warning("Server configuration error.  Unsupported CUWAInquire type: %s", req_word);
            return CUWA_ERR;
        }
    }
    return rc; 
}

authz_status cuwa_core_authz_check_noprompt(request_rec *r,
                                         const char *require_args,
                                         const void *parsed_require_args)
{
    char *full_user = cuwa_wal_get_env( r,"CUWA_FULL_USER"); 

    if (!full_user)
    {
        char *cookies=NULL,*tgt_times=NULL;
        cookies = (char*) apr_table_get( r->headers_in,"Cookie");
        tgt_times = cuwa_core_find_cookie(r, r->pool, cookies, CUWA_WEB_LOGIN_TGT_COOKIE_NAME, NULL);
        if (!tgt_times) cuwa_trace("noprompt: %s not set",CUWA_WEB_LOGIN_TGT_COOKIE_NAME);

        if (!tgt_times || (tgt_times && (atoi(tgt_times) < apr_time_sec( apr_time_now()))))
        {
            if (tgt_times) cuwa_trace("noprompt: %s=%s(%d) < now=%d",CUWA_WEB_LOGIN_TGT_COOKIE_NAME,tgt_times,atoi(tgt_times),apr_time_sec( apr_time_now()) );
            cuwa_wal_set_cookie(r,CUWA_SITE_COOKIE_NAME,NULL);
            cuwa_info("Authorization granted to anonymous user (noprompt)"); 
            return AUTHZ_GRANTED;
         }
         else {
             //user has single sign on cookie, return denied_no_user so our authenticaiton funciton will be triggered
             cuwa_trace("nopromt found. User has single sign on cookie. Let authentication handle it");
             return AUTHZ_DENIED_NO_USER;
         }
    } 
    else
    {
        int rc = CUWA_OK;
        rc = cuwa_core_authz_inquire( r );
        if ( rc )
           return AUTHZ_GENERAL_ERROR;
    }

    cuwa_info("Authorization granted to %s (noprompt)", full_user?full_user:"anonymous user");
   
   return AUTHZ_GRANTED;
}
    
authz_status cuwa_core_authz_check_user(request_rec *r,
                                         const char *require_args,
                                         const void *parsed_require_args)
{
    char *remote_user = cuwa_wal_get_env( r,"REMOTE_USER");
    char *full_user = cuwa_wal_get_env( r,"CUWA_FULL_USER");
    int rc = CUWA_OK;
    const char *t, *req_word;

    if (!remote_user) 
        return AUTHZ_DENIED_NO_USER;
    

    rc = cuwa_core_authz_inquire( r );
    if ( rc )  
       return AUTHZ_GENERAL_ERROR;

    t = require_args;                                                                                                              
    req_word = ap_getword_conf(r->pool, &t);

    if (req_word[0])                                                                            
    {
        char *realm;                                                                                                               
        cuwa_trace("check %s", req_word);                                                                                          
        realm = req_word;                                                                                             
                                                                                                                                                  
        //require valid-user realm is defined. Check if remote_user is in the same realm as defined                            
        char *remote_user_realm = strchr(full_user,'@');                                                                       
        cuwa_trace("user in realm %s, check realm %s", remote_user_realm,realm);
        if (!strcmp( remote_user_realm+1, realm ) )                                                                              
        {
            cuwa_info("Authorization granted to %s (valid-user)", full_user);                                                  
            return AUTHZ_GRANTED;                                                                                                
         }                                                                                                                      
    }            
    else 
    {
        //require valid-user is defined which only allows user in local realm                                                                               
        //if remote_user doesn't contain realm that means it is in local realm                                                                              
        if ( !strchr( remote_user, '@' ) )                                                                                                                  
        {                                                                                                                                                   
            cuwa_info("Authorization granted to %s (valid-user)", full_user);                                                                               
            return AUTHZ_GRANTED;                                                                                                                           
        }          
    }
    char *msg = apr_psprintf(r->pool,"User %s is not authorized to access %s", full_user, cuwa_wal_get_uri(r,CUWA_URI_UNPARSED));

    cuwa_wal_save_error(r, HTTP_AUTHZ_DENY, CUWA_ERR_AUTHZ_DENY, msg);

    return AUTHZ_DENIED;
}

authz_status cuwa_core_authz_check_netid(request_rec *r,
                                         const char *require_args,
                                         const void *parsed_require_args)
{
    const char *t, *w;
    char *remote_user = cuwa_wal_get_env( r,"REMOTE_USER");
    char *full_user = cuwa_wal_get_env( r,"CUWA_FULL_USER");
    int rc = CUWA_OK;

    if (!remote_user) 
        return AUTHZ_DENIED_NO_USER;
    
    rc = cuwa_core_authz_inquire( r );
    if ( rc )    return AUTHZ_GENERAL_ERROR;

    t = require_args;
    while ((w = ap_getword_conf(r->pool, &t)) && w[0]) {
        if (!strcmp(remote_user, w)) {
            cuwa_info("Authorization granted to %s",remote_user);
            return AUTHZ_GRANTED;
        }
        if (!strcmp(full_user, w)) {
            cuwa_info("Authorization granted to %s",full_user);
            return AUTHZ_GRANTED;
        }
    }
    char *msg = apr_psprintf(r->pool,"User %s is not authorized to access %s", remote_user, cuwa_wal_get_uri(r,CUWA_URI_UNPARSED));

    cuwa_wal_save_error(r, HTTP_AUTHZ_DENY, CUWA_ERR_AUTHZ_DENY, msg);

    return AUTHZ_DENIED;
}

authz_status cuwa_core_authz_check_permit(request_rec *r,
                                          const char *require_args,
                                          const void *parsed_require_args)
{
    char *full_user = cuwa_wal_get_env( r,"CUWA_FULL_USER");
    CUWACfg_t *cfg = cuwa_wal_get_config(r);
    char *memberships;
    int rc; 

    cuwa_trace("in core_authz_check_permit");

    if (!full_user) 
        return AUTHZ_DENIED_NO_USER;
    
    rc = cuwa_core_authz_inquire( r );
    if ( rc )    return AUTHZ_GENERAL_ERROR;

    rc = cuwa_permit_lookup(r, r->pool, NULL, CFG_CUWAKerberosPrincipal(cfg), CFG_CUWAKeytab(cfg),    
                            full_user, (char*)require_args, &memberships); 
    if ( rc )  
        return AUTHZ_GENERAL_ERROR;

    if (memberships)                                                                                                    
    {                                                                                                                   
        cuwa_info("Authorization granted to %s (permits=%s)", full_user,memberships);                                   
        const char *anyMember = cuwa_wal_get_header_in(r, "CUWA_GROUPS");
        if ( !anyMember )                                                                                           
        {                                                                                                               
            cuwa_trace("set memberships:%s", memberships);
            cuwa_wal_set_header_in(r,"CUWA_GROUPS",memberships);                                                        
            cuwa_wal_set_env(r,"CUWA_GROUPS",memberships);                                                              
        }                                                                                                               
        return AUTHZ_GRANTED;                                                                                                 
    }
    char *msg = apr_psprintf(r->pool,"User %s is not authorized to access %s", full_user, cuwa_wal_get_uri(r,CUWA_URI_UNPARSED));

    cuwa_wal_save_error(r, HTTP_AUTHZ_DENY, CUWA_ERR_AUTHZ_DENY, msg);
    return AUTHZ_DENIED;
}

#endif

char *cuwa_wal_get_remote_IP(void *req)
{
    request_rec *r = (request_rec *)req;

   return r->connection->client_ip;
}


void cuwa_wal_log_rerror(void *rec,int logLevel,char *file,int line,int severity,char *logdomain, char *msg,char *cuwaTest,char *sidStr)
{

    ap_log_rerror(NULL,line, APLOG_MODULE_INDEX, logLevel, 0,(request_rec *)rec,"%s,%s,%s(%d)|%d|%s %s",cuwaTest?cuwaTest:"-",sidStr?sidStr:"-",file,line,severity,logdomain, msg);
}

void cuwa_wal_log_error(void *rec,int logLevel, char *file, int line, int severity, char *logdomain, char *msg )
{
    ap_log_error(NULL,line, APLOG_MODULE_INDEX,logLevel,0,(server_rec *)rec,"%s(%d)|%d|%s %s",file,line,severity,logdomain,msg);
}

void cuwa_wal_log_cerror(void *rec,int logLevel, char *file, int line, int severity, char *logdomain, char *msg )                      
{                                                                                                                                                
    ap_log_cerror(NULL,line, APLOG_MODULE_INDEX, logLevel,0,(conn_rec *)rec,"%s(%d)|%d|%s %s",file,line,severity,logdomain,msg);                              
}                                                                                                                                                
void cuwa_wal_log_perror(apr_pool_t *p,int logLevel, char *file, int line, int severity, char *logdomain, char *msg )                             
{                                                                                                                                                
    ap_log_perror(NULL,line, APLOG_MODULE_INDEX,logLevel,0,p,"%s(%d)|%d|%s %s",file,line,severity,logdomain,msg);
}                 

const apr_array_header_t *cuwa_wal_get_requires(void *req)
{
    return NULL;
}

