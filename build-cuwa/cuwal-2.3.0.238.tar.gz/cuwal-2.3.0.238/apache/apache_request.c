/************************************************************************
 * apache_request.c -- Apache filter that performs a session restore
 * post CUWL login traversal.  Also exposes a session save function
 * to be called by the cuwa core when there is no valid session and
 * the requested resource is restricted.
 *
 * The filter restores the session, but adds a new cookie which is
 * the wac0 credential to be used by downstream handlers to access
 * the session data.
 *
 *
 * Copyright 2007 Cornell University.
 * All Rights Reserved.
 *
 ************************************************************************
 *  $Log: apache_request.c,v $
 *  Revision 1.65  2015/10/07 17:32:57  hy93
 *  merge TwoFactor treee to the head
 *
 *  Revision 1.62.2.3  2015/06/04 14:23:07  hy93
 *  fix error page doesn't display properly when root is protected by authentication
 *
 *  Revision 1.62.2.2  2015/01/29 18:26:44  hy93
 *  remove loginurl from request_save function
 *
 *  Revision 1.62.2.1  2014/10/22 19:25:30  hy93
 *  add two factor support
 *
 *  Revision 1.62  2014/10/22 15:53:32  hy93
 *  remove two factor support(v 1.61)
 *
 *  Revision 1.61  2014/07/25 17:03:19  hy93
 *  save weblogin server url to the request
 *
 *  Revision 1.60  2012/03/19 14:17:12  hy93
 *  remove previous check in
 *
 *  Revision 1.59  2012/03/19 14:09:50  hy93
 *  chage log message
 *
 *  Revision 1.58  2009/10/09 20:49:32  pb10
 *  Fix problem with large POST data.
 *
 *  Revision 1.57  2009/10/06 16:39:43  pb10
 *  Added support for webauth accepting a WA credential via POST in addition to URL based cred.
 *  This is to support large credentials that exceed 2K browser limit of IE.
 *
 *  Revision 1.56  2009/09/22 19:23:09  pb10
 *  Resolves multiple site cookies present in cookie header due to
 *  overlapping cookie domains (IE).
 *
 *  Revision 1.55  2009/04/20 16:59:26  hy93
 *  encrypt post data support
 *
 *  Revision 1.54  2009/02/12 19:28:23  pb10
 *  Check from cuwal2sid cookie on return from cuwl.  If present, generates 400
 *  error and includes User-agent in message and log.  This improves error message
 *  in case where old webauth is trying to act as mid-tier using the old
 *  cookie.
 *
 *  Revision 1.53  2009/02/11 06:26:02  pb10
 *  Removal of cuwal2sid cookie.
 *
 *  Revision 1.52  2008/09/08 01:55:19  pb10
 *  Fix possible unterminated string.
 *
 *  Revision 1.51  2008/08/27 18:49:52  hy93
 *  fix compiler warning on windows
 *
 *  Revision 1.50  2008/08/25 20:00:32  hy93
 *  move portal proxy code to a new file
 *
 *  Revision 1.49  2008/08/20 14:08:58  gbr4
 *  change all occurances of %llx and %qx to $llX and %qX respectively.
 *
 *  Revision 1.48  2008/08/16 11:47:37  hy93
 *  allow HEAD request
 *
 *  Revision 1.47  2008/08/11 04:14:20  hy93
 *  move code to auth.c
 *
 *  Revision 1.46  2008/07/30 00:01:07  hy93
 *  Moved core code to auth.c
 *
 *  Revision 1.2  2008/07/29 02:44:54  pb10
 *  Fix naming for core functions.
 *
 *  Revision 1.1  2008/07/29 01:55:29  pb10
 *  Incomplete mod_cuwebauth surgery.
 *
 *  Revision 1.44  2008/07/01 14:38:46  pb10
 *  Fix Greg's compiler warning :-)
 *
 *  Revision 1.43  2008/06/30 19:40:44  gbr4
 *  read wa= correctly when other arguments are present. add some comments
 *
 *  Revision 1.42  2008/06/30 19:13:24  gbr4
 *  truncate off &continue
 *
 *  Revision 1.41  2008/06/30 19:11:31  gbr4
 *  fix decode in filter
 *
 *  Revision 1.40  2008/06/30 17:01:03  gbr4
 *  accept POST requests from weblogin in the filter. URL decode the WA credential in the filter.
 *
 *  Revision 1.39  2008/06/25 23:54:53  pb10
 *  Fix error message for missing cookie.
 *
 *  Revision 1.38  2008/06/19 14:21:07  pb10
 *  Message field not initialized.
 *
 *  Revision 1.37  2008/06/19 00:56:31  pb10
 *  Implement 3-phase filter...
 *    1) redir to weblogin
 *    2) process cred and redir to orig url
 *    3) process request
 *
 *  Revision 1.36  2008/06/17 21:07:33  pb10
 *  Display message properly when session is garbage collected.
 *
 *  Revision 1.35  2008/06/12 19:59:53  pb10
 *  More fixes for subrequest.
 *
 *  Revision 1.34  2008/06/12 06:45:22  pb10
 *  Subrequests and internal redirects:
 *    - Make sure to search main and prev for notes table entries.
 *    - Allow subrequests to call cuwa_request_save.
 *
 *  Revision 1.33  2008/06/10 18:30:33  pb10
 *  Remove SID from return URL.
 *
 *  Revision 1.32  2008/06/04 16:01:37  pb10
 *  Add comparison of URL based SID to SID aquired from credential.
 *
 *  Revision 1.31  2008/06/03 06:12:33  pb10
 *  Fix keepalive was causing delay on first page GET after return from weblogin.
 *
 *  Revision 1.30  2008/06/02 01:44:20  pb10
 *  Add starttime and endtime to fields being hacked out of GSS credential with
 *  KRB5 calls.  The starttime is being used by session manager to support
 *  cred age test... too old = starttime-authtime > CUWACredentialAge
 *
 *  Revision 1.29  2008/05/30 20:04:01  pb10
 *  Put back in code that remembers current cookies even thought he rest of the request
 *  is being replaced by the original request (from session file).  This gets around
 *  issue where expired WA cred is sent in a refresh.  Now the session will be restored
 *  from the session file based on sid/key in cookie.
 *
 *  Revision 1.28  2008/05/30 17:09:44  pb10
 *  Fixed filter problem (POST test failing).
 *  Pointing the test suite at the new DEV KDC.
 *
 *  Revision 1.27  2008/05/06 03:13:23  gbr4
 *  more cleanup of missing checks
 *
 *  Revision 1.26  2008/05/01 18:31:47  pb10
 *  Removed extra redirect to orig URL.  To get same functionality put entire
 *  orig. path into returnURL given to weblogin. Filter now searches for the
 *  following in the URI to detect CUWL return: .cuweblogin?wa=
 *  The return URL format is http://host/path/sid.cuweblogin?wa=cred
 *
 *  Revision 1.25  2008/04/29 13:30:01  hy93
 *  fix warning regarding assignment differ in signedness
 *
 *  Revision 1.24  2008/04/19 14:21:27  pb10
 *  Convert malloc's to APR allocations.
 *
 *  Revision 1.23  2008/04/19 05:16:28  pb10
 *  Redirect to original URL, feature added.  This is being done so that
 *  path relative objects such as images will be displayed properly after
 *  login.
 *
 *  Revision 1.22  2008/04/14 04:12:36  pb10
 *  Fix CUWACredentialAge to only check age on initial website page hit.  CUWACrentialDefaultAge obsolete.
 *
 *  Revision 1.21  2008/03/29 16:14:10  pb10
 *  Filter was reading beyond end of HTTP message in apache 2.2.  Changed filter "type" which
 *  put the filter at lower priority in the chain.  Not sure why this fixes it except that
 *  when the problem occurs, the HTTP_IN filter is not in the chain, and that
 *  filter is responsible for detecting the end of the HTTP message.
 *
 *  Revision 1.20  2008/03/24 21:30:28  pb10
 *  Better error page support.
 *
 *  Revision 1.19  2008/03/19 20:30:12  pb10
 *  Moved weblogin credential parsing from the filter to mod_cuwebauth.c so that
 *  kerberos directives could be based on virtual host.
 *
 *  Revision 1.18  2008/03/13 20:11:17  pb10
 *  Changed pools from connection based to request based.
 *  Improved message passing between filter and mod_cuwebauth (Using notes field).
 *
 *  Revision 1.17  2008/03/12 14:42:53  hy93
 *  need to set keys in restore filter
 *
 *  Revision 1.16  2008/03/06 18:27:41  pb10
 *  fixed filter segfault.
 *
 *  Revision 1.15  2008/03/02 06:29:51  gbr4
 *  change versioning scheme to take advantage of hudson -- and still work otherwise
 *
 *  Revision 1.14  2008/02/29 06:42:12  pb10
 *  Put back in the first line detection (filter_ignore).  Changed the hook so as to restart the filter
 *  for each request (so that first line detection works correctly).
 *
 *  Revision 1.13  2008/02/05 18:35:25  hy93
 *  fix cuweblogin not detected when there is more than one requests in one connection
 *
 *  Revision 1.12  2008/01/25 03:18:30  hy93
 *  fix segmentation fault in log
 *
 *  Revision 1.11  2008/01/25 01:43:47  gbr4
 *  Added an ID string to every file
 *
 *  Revision 1.10  2008/01/16 06:59:28  pb10
 *  Fixed strip code to not depend on null terminated strings.  To do...
 *  check the rest of this code or such dependencies.
 *
 *  Revision 1.9  2008/01/15 16:39:15  pb10
 *  Initialize log targets.
 *
 *  Revision 1.8  2008/01/14 16:12:42  pb10
 *  Fix issue with module struct naming conflict.  For some reason it worked OK on one version of apache but not another.  Now the module name coincides with the struct name.
 *
 *  Revision 1.7  2008/01/14 09:35:07  pb10
 *  Integrated logging and config into webauth.  authz working.  authn for valid-user working, or netid also, but not tested.
 *
 *  Revision 1.6  2008/01/11 04:18:47  pb10
 *  Integrate with logging and config.  Compiles, but isn't tested yet.
 *
 *  Revision 1.5  2008/01/02 04:33:23  pb10
 *  Changes for integration with session manager, cred manager, apache mod.
 *
 *  Revision 1.4  2007/12/28 18:12:56  pb10
 *  remove linefeeds.
 *
 *  Revision 1.3  2007/12/21 19:56:02  hy93
 *  modify a call to cuwa_session_write_request because of interface change.
 *
 *  Revision 1.2  2007/12/21 00:13:04  pb10
 *  Integrate with session mgr.
 *
 *  Revision 1.1  2007/12/12 18:27:07  pb10
 *  Initial
 *
 ************************************************************************
 */

#include <cuwa_request.h>
#include <session.h>
#include <httpd.h>
#include <http_config.h>
#include <http_connection.h>
#include <apr_buckets.h>
#include <apr_general.h>
#include <apr_lib.h>
#include <util_filter.h>
#include <http_request.h>
#include <http_protocol.h>
#include <http_config.h>
#include <session_bucket.h>
#include <session.h>
#include <apr_strings.h>
#include <ap_compat.h>    /* in case we decide we need to support 1.3 */
#include <log.h>
#include <log_apache.h>
#include <cfg.h>
#include <cuwa_malloc.h>
#include <assert.h>
#include <wal.h>
extern module AP_MODULE_DECLARE_DATA *cuwa_module;

#define CUWA2_LOG_DOMAIN cuwa.apache.filter

#define CUWA_MAGIC_ARG "CUWACRED="
#define CUWA_SID_COOKIE_NAME "cuwal2sid="
#define LIMIT_REQUEST_LINE 8190
#define CUWL_REDIR_SIGNATURE(u)  (strstr((u),CUWA_MAGIC_FILE)?1:0)
#define CUWA_REDIR_SIGNATURE(u)  (strstr((u),CUWA_MAGIC_ARG)?1:0)

static char * cuwa_request_strip(request_rec *r, ap_filter_t *f, apr_bucket_brigade *b, apr_read_type_e block, apr_off_t readbytes, char **saved, const char **postCred);
static int cuwa_get_session_from_req(request_rec *r, char **reqLine, ap_filter_t *f, apr_bucket_brigade *b,
                                          apr_read_type_e block, apr_off_t readbytes);
static ap_filter_rec_t *cuwa_filter_handle = NULL;

/* This address is a placeholder, so we know to ignore the request */
static char filter_ignore[] = "Ignore";
static char filter_empty[]  = "Empty";
static char filter_eos[]    = "eos";


typedef struct cuwa_filter_context
{
    apr_bucket_brigade *bb;
    int linecnt;
} cuwa_filter_context;


static cuwa_err_t write_request( cuwa_session_t *session, char *buf, int count ,int encryption)
{

    return cuwa_session_write_request( session, buf, count, encryption );
}

// Handle deferred errors from the filter
static void cuwa_request_defer_error(request_rec *r, int status, int code, char *msg)
{
    char *codeStr, *statusStr;

    cuwa_trace("cuwa_request_defer_error: status %d code %d %s",status,code,msg);
    r->handler = "cuwa-error-handler";
    codeStr = apr_psprintf( r->pool,"%d",code );
    statusStr = apr_psprintf( r->pool,"%d",status );
    apr_table_set(r->notes,"CUWL-error-status",statusStr);
    apr_table_set(r->notes,"CUWL-error-code",codeStr);
    apr_table_set(r->notes,"CUWL-error-msg",msg);
}


/* This function handles stuffing replacement request into bucket brigade
   Once all of the data has been read, we return to the state of waiting for a new request. */
static apr_status_t cuwa_get_brigade(ap_filter_t *f, apr_bucket_brigade *b, ap_input_mode_t mode,
                                           apr_read_type_e block, apr_off_t readbytes)
{
    apr_bucket *e;
    apr_status_t rc = APR_SUCCESS;
    const char *str;
    apr_size_t len = 0;
    const char *pos;
    apr_off_t ofs;
    request_rec *r = f->r;

    cuwa_filter_context *ctx = (cuwa_filter_context *) f->ctx;

    cuwa_assert(ctx);

    cuwa_trace("cuwa_get_brigade f->ctx: %p, f->r: %p",f->ctx,r);
    e = APR_BRIGADE_FIRST(ctx->bb);

    if (!APR_BRIGADE_EMPTY(ctx->bb))
    {
        if (mode == AP_MODE_GETLINE)
        {
            cuwa_trace("cuwa_get_brigade AP_MODE_GETLINE linecnt: %d len: %d",ctx->linecnt,len);

            rc = apr_bucket_read(e, &str, &len, block);
            if (rc != APR_SUCCESS) return rc;

            pos = memchr(str, APR_ASCII_LF, len);

            // Check that ofs is not gt readBytes???
            ofs = pos ? (pos - str + 1) : e->length;

            cuwa_trace("cuwa_get_brigade AP_MODE_GETLINE: ofs: %d",ofs);
            cuwa_trace("cuwa_get_brigade AP_MODE_GETLINE: buck: %p, start: %d, len: %d, data: %p list: %p",e,e->start,e->length,e->data,e->list);
            cuwa_trace("cuwa_get_brigade EMPTY: %s",APR_BRIGADE_EMPTY(ctx->bb)?"YES":"NO");

            ctx->linecnt++;
        }
        else
        {
            len = (apr_size_t)readbytes;
            rc = apr_bucket_read(e, &str, &len, block);
            if (rc != APR_SUCCESS) return rc;

            ofs = readbytes;

            cuwa_trace("cuwa_get_brigade mode: %d ofs: %d, start: %d len: %d",mode,ofs,e->start,e->length);
        }

        /* We found a match. */

        cuwa_trace("cuwa_get_brigade before split: %p",e);
        if (ofs < e->length) {

            cuwa_trace("split: %d %d",ofs, e->length);
            apr_bucket_split(e, (apr_size_t)ofs);
        }

        cuwa_trace("cuwa_get_brigade after split: %p, len: %d, start: %d",e,e->length,e->start);

        APR_BUCKET_REMOVE(e);
        APR_BRIGADE_INSERT_TAIL(b, e);
    }
    else
    {
        cuwa_trace("cuwa_get_brigade sent eos");
        e = apr_bucket_eos_create(f->c->bucket_alloc);
        APR_BRIGADE_INSERT_TAIL(b,e);
        f->ctx = filter_eos;
    }

    if (APR_BRIGADE_EMPTY(ctx->bb))
    {
        cuwa_trace("cuwa_get_brigade CLEANUP (brigade empty)");
        apr_brigade_destroy(ctx->bb);
        if (f->ctx != filter_eos) f->ctx = filter_empty;
    }

    return APR_SUCCESS;
}

/* the filter detects when a request comes in for /cuweblogin, before the request
   has been processed at all.  When it triggers, it flushes the inbound request
   and then sets things up for cuwa_get_brigade to drop in a new request. */
static apr_status_t cuwa_request_restore_filter(ap_filter_t *f, apr_bucket_brigade *b, ap_input_mode_t mode,
                                                apr_read_type_e block, apr_off_t readbytes)
{
    apr_status_t rc = APR_SUCCESS;
    char *str = NULL;
    apr_size_t len;
    apr_bucket *e;
    request_rec *r = f->r;
    conn_rec *c = f->c;
    assert(r); //native assert since cuwa_assert needs cuwa_log_apache_set_keys
    cuwa_log_apache_set_keys(r,r->server,r->connection);
    cuwa_malloc_set_pool(r->pool);
    cuwa_trace("filter_in...f=%p next=%p ctx=%p req=%p main=%p prev=%p",f,f->next,f->ctx,f->r,f->r->main,f->r->prev);

    cuwa_assert(c);
    cuwa_assert(r);
    cuwa_assert(f!=f->next);

    if (f->ctx == filter_eos)
    {
        cuwa_trace("Call to filter, sent APR_EOF");
        return APR_EOF;
    }

    if (f->ctx == filter_empty)
    {
        cuwa_trace("Call to filter, BB already empty, sent eos, len %d chunk %d remaining %d", r->read_length, r->read_chunked, r->remaining);
        e = apr_bucket_eos_create(f->c->bucket_alloc);
        APR_BRIGADE_INSERT_TAIL(b,e);
        f->ctx = filter_eos;
        return APR_SUCCESS;
    }

    /* Let the next filter handle, if we're ignoring this request, or if we're waiting
       for the first getline in the next request */
    if (r->main || r->prev || (f->ctx == filter_ignore) || (!f->ctx && mode!=AP_MODE_GETLINE))
    {
        rc = ap_get_brigade(f->next, b, mode, block, readbytes);
        cuwa_trace("Filter bypass, ap_get_brigade: %d",rc);
        return rc;
    }

    if (!f->ctx)
    {
        char *str2;
        len = 0;
        rc = ap_get_brigade(f->next, b, AP_MODE_GETLINE, block, readbytes);
        if (rc == APR_SUCCESS)
        {
            rc = apr_brigade_pflatten(b, (char**)&str2, &len, r->pool);
        }
        apr_brigade_cleanup(b);

        if ( rc )
        {

            cuwa_trace("apr_brigade_pflatten error: %d",rc);
            return rc;
        }

        str = apr_pcalloc(r->pool,len+1); 	
        memcpy(str,str2,len);

        cuwa_trace("REQUEST: len %d %s",len,str);

        if (cuwa_get_session_from_req(r,&str,f,b,block,readbytes))
        {
            // Start inserting the original request
            rc = cuwa_get_brigade(f,b,mode,block,readbytes);
            cuwa_trace("Filter insert, cuwa_get_brigade: %d (request line)",rc);
        }
        else
        {
            /* We need to let the request go through */
            /* so stuff the part we already read into a bucket and return to caller */
            cuwa_trace("Not from CUWL!");
            cuwa_trace("Filter passthrough start");
            cuwa_trace("Request bucket %d bytes: %s",len, DENULL(str));
            e = apr_bucket_pool_create(str, len, r->pool, c->bucket_alloc);
            APR_BRIGADE_INSERT_TAIL(b,e);

            // FIXME: we might be able to remove this filter from the request, instead of going into pass-through mode.
            f->ctx = filter_ignore;
        }
    }
    else
    {
        // Continue inserting the original request
        rc = cuwa_get_brigade(f,b,mode,block,readbytes);
    }

    return rc;
}


static int cuwa_create_request(request_rec *r)
{
    cuwa_log_apache_set_keys(r,r->server,r->connection);
    cuwa_malloc_set_pool(r->pool);
    cuwa_trace("cuwa_create_request_hook");

    if (!r->main && !r->prev)
    {
        cuwa_trace("cuwa_create_request_hook no main or prev");
        ap_add_input_filter_handle(cuwa_filter_handle, NULL, r, r->connection);
    }

    return OK;
}


/* to be called when registering hooks */
void cuwa_request_apache_init(char *serviceid, char *keytab)
{
    // The serviceid and keytab are ignored (should be removed)
    ap_hook_create_request(cuwa_create_request, NULL, NULL, APR_HOOK_MIDDLE);
    cuwa_filter_handle = ap_register_input_filter("cuwa_request_restore_filter",
                                                  cuwa_request_restore_filter, NULL, AP_FTYPE_PROTOCOL);
}


static int write_header(void *p, const char *key, const char *value)
{
    if (write_request( (cuwa_session_t*)p, (char*) key, strlen(key) , 0)) return 0;
    if (write_request( (cuwa_session_t*)p, ": ", 2 , 0) ) return 0;
    if (write_request( (cuwa_session_t*)p, (char*) value, strlen(value), 0)) return 0;
    if (write_request( (cuwa_session_t*)p, "\r\n", 2 , 0)) return 0;

    return 1;
}


/**
 * cuwa_get_session_from_req detects if this request is a redirect from weblogin.
 * If it is, extract the credential from the request, and return the associated session.
 * If the request has already been replayed, adjust the reqLine, but don't return the session.
 *
 * Upon successful completion the filter context will be created and prepared for processing
 * bucket brigade.
 *
 * On failure, the caller goes into filter bypass mode -- just returning response from ap_get_brigade.
 *
 * @param[in] r - the request
 * @param[in] reqLine - first line of request, already read from the bucket brigade
 * @param[in] f - the filter record
 * @param[in] b - the bucket brigade (pulls data from the socket)
 * @param[in] block - block type
 * @param[in] readbytes - maximum number of bytes to be read
 *
 * @return 1=success, 0=failure
 */
int cuwa_get_session_from_req(request_rec *r, char **reqLine, ap_filter_t *f, apr_bucket_brigade *b,
                                          apr_read_type_e block, apr_off_t readbytes)
{
    char *sidstr;
    const char *cred = NULL;
    char *saved = NULL;
    uint64 sid;
    cuwa_session_t *session = NULL;
    int code = 0;
    CUWACfg_t *cfg;
    cuwa_filter_context *ctx;
    apr_bucket *e;
    apr_off_t blen;
    conn_rec *c = f->c;
    int from_cuwl,from_cuwa;
    char *msg = NULL;
    char *oldua;
    int defer_status = 403;

    cuwa_assert(reqLine);
    cuwa_assert(*reqLine);

    // Look for weblogin signature
    if (strncmp((*reqLine),"GET ",4) && strncmp((*reqLine),"POST ",5) && strncmp((*reqLine),"HEAD ",5)) return 0;
    from_cuwl = CUWL_REDIR_SIGNATURE(*reqLine);
    from_cuwa = CUWA_REDIR_SIGNATURE(*reqLine);
    if (!from_cuwl && !from_cuwa) return 0;

    // Extract cred if this is from CUWL.
    // Note that if it's redirect from CUWA, the site cookie must be present for authn to work
    if (from_cuwl)
    {
        cred = cuwa_get_cred_from_uri( r->pool, *reqLine);
        if ( !cred && strncmp((*reqLine),"POST ",5) ) return 0;

        sidstr = cuwa_get_sid_from_uri( r->pool, *reqLine);
        if (!sidstr) return 0;
    }
    else
    {
        cuwa_trace("Filter: inbound redirect from CUWA");
        sidstr = cuwa_get_sid_from_arg(r->pool, *reqLine);
        if (!sidstr) return 0;
        saved = apr_pstrdup(r->pool, *reqLine);
    }

    // Create context for restoring original request
    ctx = apr_palloc(r->pool,sizeof(cuwa_filter_context));
    cuwa_assert(ctx);
    f->ctx  = ctx;
    ctx->bb = apr_brigade_create(r->pool, c->bucket_alloc);
    ctx->linecnt = 0;

    // Strip request, extract cookies and sid cookie
    oldua = cuwa_request_strip(r, f, b, block, readbytes, (saved ? &saved : NULL), (from_cuwl && !cred) ? &cred : NULL );
    
    if (cred)
    {
        apr_table_set(r->notes,"CUWL-Credential",cred);
        cuwa_trace("Cred: %s",cred);        
    }
        
    if (!sidstr)
    {
        if (oldua)
        {
            cuwa_notice("Old cookie cuwal2sid detected, probably from incompatable webauth UA (%s).",oldua);
            msg = apr_psprintf(r->pool, "Old cookie cuwal2sid detected, probably from incompatable webauth UA (%s).",oldua);
            defer_status = 400;            
        }
        else {
            cuwa_notice("Missing session ID in URI - redirect from %s.",from_cuwl?"weblogin":"webauth");
            msg = apr_psprintf(r->pool, "Missing session ID in URI - redirect from %s.",from_cuwl?"weblogin":"webauth");
        }
    }
    else
    {
        sscanf( sidstr, "%llX", &sid);
        cuwa_trace("SessionID: %s",sidstr);

        // Get the session
        cfg = (CUWACfg_t *) ap_get_module_config(r->server->module_config, cuwa_module);
        cuwa_assert(cfg);
        code = cuwa_session_from_sessionid( r, r->pool, cfg, sid, &session);
        if (code)
        {
            cuwa_notice("cuwa_session_from_sessionid failed with status %d",code);
        }
        else
        {
            cuwa_trace("This is from CUWL! %x sessionid=%llX...",session, session->sessionID);
        }

        // Get session request size, open it, then bucketize
        if (!code) code = cuwa_session_get_req_size(session, &blen);
        if (!code) code = cuwa_session_open_request(session, 0 );
        if (!code)
        {
            e = session_bucket_create(session,0,(apr_size_t)blen, r->pool, c->bucket_alloc);
            if (!e) code = APR_EOF;
        }

        if (!code)
        {
            // Hand request bucket off to the brigade
            APR_BRIGADE_INSERT_TAIL(ctx->bb, e);

            cuwa_trace("cuwa_get_brigade created brigade");

            // Pass credential to cuwa_authn()
            apr_table_set(r->notes,"CUWA-SID",sidstr);
        }

        if (code) session = NULL;
    }

    if (!session)
    {
        // We've already destroyed the original request.  Create a substitute so that BB doesn't stall...
        char *req;
        if (saved)
        {
            cuwa_trace("Session was lost, let authn handle redirect to weblogin");
            req = saved;
        }
        else
        {
            cfg = (CUWACfg_t *) ap_get_module_config(r->server->module_config, cuwa_module);
            char *errLocation = "/cuwa-error";

            if ( cfg && CFG_CUWAErrorLocation(cfg) ) errLocation = CFG_CUWAErrorLocation(cfg);

            // Error handler will catch this request and display an error page
            cuwa_trace("Cannot restore session %d",code);
            req = apr_psprintf( r->pool,"GET %s HTTP/1.0\r\nHost: %s\r\n\r\n",errLocation, r->server->server_hostname );

            if (!msg) msg = apr_psprintf( r->pool,"Credential was received from the web login server, but the session expired (code=%d). "
                             " It could be caused by waiting a really long time to type in your password.  Try logging in again.",
                             code );
            cuwa_request_defer_error(r, defer_status, code, msg);
        }

        cuwa_trace("New request... %s",req);
        e = apr_bucket_pool_create(req, strlen(req), r->pool, c->bucket_alloc);
        assert(e);
        APR_BRIGADE_INSERT_TAIL(ctx->bb, e);
    }

    return 1;
}

// cuwa_request_strip: strip the request from the inbound bucket brigade
char * cuwa_request_strip(request_rec *r, ap_filter_t *f, apr_bucket_brigade *b, apr_read_type_e block, apr_off_t readbytes, char **saved, const char **postCred)
{
    apr_status_t rc = APR_SUCCESS;
    const char *str,*str2,*p;
    apr_size_t len;
    char *sidstr = NULL;
    char *ua = "UA unknown";
    int postLen = 0;

    // Read and discard to the end of the incoming request, assume simple GET, no body
    while (1)
    {
        rc = ap_get_brigade(f->next, b, AP_MODE_GETLINE, block, readbytes);
        if (rc != APR_SUCCESS) break;

        rc = apr_brigade_pflatten(b, (char**)&str, &len, r->pool);
        if (rc != APR_SUCCESS) break;

        apr_brigade_cleanup(b);

        // Make a terminated string copy for display purposes...
        str2 = apr_pcalloc(r->pool, len+1);
        memcpy((char*) str2,str,len);
        cuwa_trace("STRIP: %d <%s>",len,str2);

        if (saved) *saved = apr_pstrcat(r->pool,*saved,str2,NULL);

        if (len==2 && strncmp(str2,"\r\n",2)==0) break;

        if (strncasecmp("cookie:",str2,7)==0)
        {
            // This cookie gets wiped out by orig. request.
            // Save it internally...
            apr_table_set(r->notes,"CUWA-Cookies",str2);
            cuwa_trace("Set CUWA-Cookies");
            sidstr = cuwa_core_find_cookie(r, r->pool, (char*) str2, CUWA_SID_COOKIE_NAME, NULL);
        }

        if (strncasecmp("User-Agent:",str2,11)==0)
        {
            ua = apr_pstrdup(r->pool,str2);
            ua += 12;
        }
        
        if (strncasecmp("content-length:",str2,15)==0)
        {
            postLen = atoi(&str2[16]);
            cuwa_trace("POST is %d bytes",postLen);
        }
    }
    
    if (postCred && postLen && postLen < 0x100000) // make sure POST < 1M
    {
        // read the POST here...
        str2 = apr_pcalloc(r->pool, postLen+1);
        p = str2;

        do {
            rc = ap_get_brigade(f->next, b, AP_MODE_READBYTES, APR_BLOCK_READ, postLen);
            if (rc == APR_SUCCESS) 
            {
                rc = apr_brigade_pflatten(b, (char**)&str, &len, r->pool);
                if (rc == APR_SUCCESS)
                {
                    apr_brigade_cleanup(b);
                    cuwa_trace("POST read %d bytes",len);
                    postLen -= len;
                    memcpy((char*) p,str,len);
                    p += len;
                }
                else break;
            }
            else break;
        } while (postLen);
        
        if (rc) 
        {
            cuwa_trace("POST can't read POST bytes, ap_get_brigade: %d",rc);
        }
        else
        {
            cuwa_trace("Entire POST %d bytes",strlen(str2));
            *postCred = cuwa_get_cred_from_args(r->pool, (char*) str2);
            cuwa_trace("base64 cred is %d bytes",strlen(*postCred));
            cuwa_trace("Using POST data to find credential");
        }
    }
    
    cuwa_trace("STRIP: COMPLETE");
    return sidstr?ua:NULL;
}

/////////////////////////////////////////////////////
// serialize method, target, headers+cookie, body
// need to use opaque mask of the request_rec
/////////////////////////////////////////////////////
int cuwa_wal_request_save(uint64 *sessionid, void *request)
{
    apr_status_t code = CUWA_OK;
    request_rec *r = (request_rec *) request;
    cuwa_session_t *session = NULL;
    CUWACfg_t *cfg = cuwa_wal_get_config(r);
    char *st,*st2;
    char *req = r->the_request;
    int cnt;

    cuwa_trace("cuwa_request_save...");

    // Avoid circular craziness
    // FIXME: need to look for weblogin URI
    if (CUWL_REDIR_SIGNATURE(r->unparsed_uri))
    {
        cuwa_trace("cuwa_request_save can't save request=cuwl_restore");
        return CUWA_OK;
    }

    // Remove the magic arg if it's in the request
    cuwa_trace("cuwa_request_save %s",req);
    req = apr_pstrdup(r->pool, req);
    st = strstr(req,CUWA_MAGIC_ARG);
    if (st && st!=req)
    {
        st--;
        if (*st=='?' || *st=='&')
        {
            cnt = strlen(CUWA_MAGIC_ARG)+1;
            st2 = st + cnt;
            while(*st2 && *st2!='&') st2++; // search for end of SID
            cuwa_trace("cuwa_request_save rmv magic <%s> <%s> %d",st2,st,cnt);
            while (*st2) *st++ = *st2++;
            *st = 0;
        }
    }

    code = cuwa_session_new( r, r->pool, cfg, &session);
    if (code) goto cleanup;

    code = cuwa_session_get_sessionid( session, sessionid );
    if (code) goto cleanup;

    if ( !strncmp( req, "POST", 4 ) )
    {
        code = cuwa_session_encryption_set( session );
        if (code) goto cleanup;
    }

    code = cuwa_session_open_request( session, 1 );
    if (code) goto cleanup;

    code = write_request( session, req, strlen(req),0 );
    if (code) goto cleanup;;

    code = write_request( session, "\r\n", 2,0 );
    if (code) goto cleanup;

    // write the headers
    apr_table_do( write_header, session, r->headers_in, NULL);

    code = write_request( session, "\r\n", 2,0 );
    if (code) goto cleanup;

    // write the POST data
    code = ap_setup_client_block(r, REQUEST_CHUNKED_ERROR);
    if (code) goto cleanup;

    if (ap_should_client_block(r))
    {
        char buf[512];
        int len_read;

        cuwa_trace("write post: %d bytes",r->remaining);

        while ((len_read = ap_get_client_block(r, buf, sizeof(buf))) > 0)
        {
            code = write_request( session, buf, len_read,1 );
            if (code) goto cleanup;
            cuwa_trace("write bytes: %d",len_read);
/* HACK */  if (len_read==r->remaining) break;
        }

        code = cuwa_session_encryption_done( session );
        if (code) goto cleanup;
    }

cleanup:

    cuwa_trace("cuwa_request_save done: %d",code);

    if (session)
    {
        cuwa_session_close_request( session );
        cuwa_session_release( session );
    }

    return code;
}
const char id_apache_apache_request_c[] = "$Id: apache_request.c,v 1.65 2015/10/07 17:32:57 hy93 Exp $";
