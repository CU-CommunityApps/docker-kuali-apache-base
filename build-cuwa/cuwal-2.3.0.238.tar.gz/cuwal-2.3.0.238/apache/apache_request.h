/************************************************************************
 * apache_request.h -- Apache implementation of request save and restore
 *                     functions.
 *
 * Copyright 2007 Cornell University.
 * All Rights Reserved.
 *
 ************************************************************************
 *
 *  Revision 1.3  2008/04/10 16:57:10  gbr4
 *  Line endings only. This set of files had mixed line endings which breaks visual studio (and looks ugly in vim). Each file was converted to the format that resulted in the fewest line changes (i.e. whichever format it was mostly in).
 *
 *  Revision 1.2  2008/01/02 04:33:23  pb10
 *  Changes for integration with session manager, cred manager, apache mod.
 *
 *  Revision 1.1  2007/12/12 18:27:07  pb10
 *  Initial
 *
 *
 *
 ************************************************************************
 */

#ifndef _APACHE_REQUEST_H
#define _APACHE_REQUEST_H

#include <http_config.h>

// Apache specific function to be called during register_hooks
void cuwa_request_apache_init(char *serviceid, char *keytab);

#endif
