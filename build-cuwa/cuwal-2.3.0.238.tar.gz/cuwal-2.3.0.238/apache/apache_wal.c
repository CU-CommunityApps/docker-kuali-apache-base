//////////////////////////////////////////////
// Support functions
//////////////////////////////////////////////

#if AP_SERVER_MINORVERSION_NUMBER > 2
#include <apache_2_4.c>
#else
#include <apache_2_2.c>
#endif

const char *cuwa_table_get(request_rec *r, char *name)
{
    // Get table entry from notes.  Support subrequests and internal redirects by looking at main and prev.
    const char *returns = NULL;
    if(!r) return(NULL);
    if(r->notes)   returns = apr_table_get( r->notes,name);

    if (!returns && r->main)
    {
        returns = cuwa_table_get( r->main,name);
    }
    if (!returns && r->prev)
    {
        returns = cuwa_table_get( r->prev,name);
    }
    return returns;
}

apr_pool_t *cuwa_wal_get_pool( void *req )
{
    request_rec *r = (request_rec *)req;

    return (r->pool);
}

char *cuwa_wal_note_get(void *request, char *name)
{
    request_rec *r = (request_rec *)request;

    if ( r->notes )
        return (char *) cuwa_table_get( r, name );
    else
        return NULL;
}

void cuwa_wal_note_set( void *request, char *name, char *value)
{
    request_rec *r = (request_rec *)request;

    apr_table_set( r->notes, name, value);
}

int cuwa_wal_send_page(void * request, int status, char *html)
{
    request_rec *r = (request_rec *) request;
    r->status = status;
    r->content_type = "text/html;charset=ISO-8859-1";
    r->no_cache = 1;
    r->no_local_copy = 1;
    ap_set_content_length(r, strlen(html));
    ap_send_http_header(r);
    ap_rprintf(r,"%s",html);

    return DONE;
}

const char *cuwa_wal_get_log_error(void * request)
{
    request_rec *r = (request_rec *) request;
    return cuwa_table_get( r,"CUWA-LogError");
}

CUWACfg_t *cuwa_wal_get_config(void * request)
{
    request_rec *r = (request_rec *) request;
    return ap_get_module_config(r->per_dir_config, cuwa_module);
}

void cuwa_wal_save_error(void *request, int status, int code, char *msg)
{
    char *codeStr, *statusStr;
    request_rec *r = (request_rec *)request;

    cuwa_trace("cuwa_request_save_error: status %d code %d %s",status,code,msg);
    codeStr = apr_psprintf( r->pool,"%d",code );
    statusStr = apr_psprintf( r->pool,"%d",status );
    apr_table_set(r->notes,"CUWL-error-status",statusStr);
    apr_table_set(r->notes,"CUWL-error-code",codeStr);
    apr_table_set(r->notes,"CUWL-error-msg",msg);
}
