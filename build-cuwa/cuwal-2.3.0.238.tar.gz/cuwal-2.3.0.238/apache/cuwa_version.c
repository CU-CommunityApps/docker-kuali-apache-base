/************************************************************************
 * cuwa_version.c -- Get the module's version number
 *
 * Copyright 2008 Cornell University.
 * All Rights Reserved.
 *
 ************************************************************************
 *  $Log: cuwa_version.c,v $
 *  Revision 1.25  2013/02/26 15:45:07  hy93
 *  fix weblogin server can not recognize IIS from url VerS parameter because & was converted to &amp; in IIS
 *
 *  Revision 1.24  2013/02/25 19:45:01  hy93
 *  remove previous check in
 *
 *  Revision 1.23  2013/02/25 19:32:59  hy93
 *  should not escape uri in version string.Otherwise it adds extra amp; in the query string that weblogin server received
 *
 *  Revision 1.22  2011/06/02 17:15:09  pb10
 *  add reset of version string.
 *
 *  Revision 1.21  2011/06/02 15:17:37  pb10
 *  Fix diagnostic for version string issue.  Add more diagnostics
 *
 *  Revision 1.20  2010/11/01 16:15:42  pb10
 *  Make cuwa_permit_add_to_buf copy safe.
 *  Reduced potential for improper use of recycled buffer in cuwa_perit_add_to_buf.
 *  Added comments to explain buffer reuse.
 *  Added comments to explain cuwa_version string changes.
 *
 *  Revision 1.19  2010/07/20 18:14:42  hy93
 *  improve the code that builds client version string.
 *
 *  Revision 1.18  2008/10/07 19:38:40  hy93
 *  add header file
 *
 *  Revision 1.17  2008/09/13 15:50:36  pb10
 *  Fix up version stuff
 *
 *  Revision 1.16  2008/09/13 13:23:53  pb10
 *  Add IIS code and cleanup apache dependency in cuwa_version.c.
 *  Fix naming and positioning of DAV functions in wal.h.
 *
 *  Revision 1.15  2008/09/11 15:46:25  gbr4
 *  Add the (stringsable) text CUWA_CVS_TAG to mod_cuwebauth.so. This allows recovering the exact source tree used to build any experimental build even after we delete the hudson records.
 *
 *  Revision 1.14  2008/08/19 19:53:57  hy93
 *  fix compiler warning
 *
 *  Revision 1.13  2008/08/19 05:18:21  gbr4
 *  Make the version numbering more reasonable. configure.ac now contains the build  version number in the call to AC_INIT. hudson_build.sh uses sed to insert hudson's build number into that call. (i.e. sed -e "s/\.UnknownCUWA/\.$BUILD_NUMBER/") before re-running autoreconf and then configure.
 *
 *  All the old variables that were in cuwa_build and mod_weblogin/version/... are now exposed via autoconf in autoconfig.h and are available in depend.rules. A future cleanup pass could probably delete most of these.
 *
 *  The version stamping of unofficial builds is now based on CONFIGURE time rather than make time. To compensate for this a CUWA_BUILT_AT has been added
 *
 *  The only user-visible change from all of this should be that the apache version was added to the end of the product string. (i.e. 2.0.0.158/idmbuild@pine/RHEL4-Linux/2.2.8)
 *
 *  Revision 1.12  2008/08/14 20:00:13  gbr4
 *  include the apache version from ap_release.h
 *
 *  Revision 1.11  2008/07/30 18:49:06  hy93
 *  add server startup time to client version
 *
 *  Revision 1.10  2008/05/08 16:21:30  hy93
 *  add include to see if it resolve window's build error
 *
 *  Revision 1.9  2008/05/08 14:00:29  hy93
 *  fix previous ci broke window's build
 *
 *  Revision 1.8  2008/05/06 13:17:05  hy93
 *  add code to provide os version and apache version
 *
 *  Revision 1.7  2008/05/06 03:13:23  gbr4
 *  more cleanup of missing checks
 *
 *  Revision 1.6  2008/05/03 03:39:41  gbr4
 *  fix some unambiguous memory leaks. these were in config1 and in code that runs once per child so no serious harm but...
 *
 *  Revision 1.5  2008/04/24 20:06:18  gbr4
 *  win32 warning cleanup pass.
 *
 *  Revision 1.4  2008/03/02 06:29:51  gbr4
 *  change versioning scheme to take advantage of hudson -- and still work otherwise
 *
 *  Revision 1.3  2008/01/25 01:43:47  gbr4
 *  Added an ID string to every file
 *
 *  Revision 1.2  2008/01/14 09:35:07  pb10
 *  Integrated logging and config into webauth.  authz working.  authn for valid-user working, or netid also, but not tested.
 *
 *  Revision 1.1  2008/01/11 04:19:48  pb10
 *  Initial code.  Not compiled into the module yet.
 *
 *
 ************************************************************************
 */
#include <cuwa_version.h>
//#include <ap_release.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <autoconfig.h>
#include <log.h>
#include <util.h>
#include <apr_time.h>
#include <apr_strings.h>
#include <wal.h>
#include <apr_file_io.h>

#ifdef HAVE_UNISTD_H
#include <unistd.h>
#endif

#ifndef AP_SERVER_VERSION
// Must be IIS, this tag is just used for strings command
#define AP_SERVER_VERSION "IIS"
#endif

static char *short_version = NULL;
static char *detail_version = NULL;
static char *cuwa_client_version = NULL;
char cuwa_apache_version[] = "CUWA_BUILT_FOR: " AP_SERVER_VERSION;
char cuwa_build_stamp[] = "CUWA_BUILT_ON: " __DATE__ " " __TIME__;

#define CUWA_STRX(x) #x
#define CUWA_STRX2(x) CUWA_STRX(x) // black magic http://everything2.com/index.pl?node_id=885916
char cuwa_cvs_tag[] = "CUWA_CVS_TAG: " CUWA_STRX2(CUWA_CVS_TAG) " (UTC)";
#undef CUWA_STRX
#undef CUWA_STRX2

char cuwa_version_string[] = CUWA_PROD;
char cuwa_build[] = CUWA_PROD;
#define CUWA2_LOG_DOMAIN cuwa.version

int cuwa_version_reset()
{
    cuwa_client_version = NULL;
    return 0;
}

void cuwa_version_init()
{
    char *tmp;
    detail_version=strdup(cuwa_build);
    short_version=strdup(cuwa_build);
    tmp=strchr(short_version,' ');
    if(tmp) *tmp='\0';
    cuwa_crit("cuwa_version_init: %s",detail_version);

}

char *cuwa_version_get()
{
    if (!short_version) cuwa_version_init();
    return short_version;
}

char *cuwa_version_get_full()
{
    if (!detail_version) cuwa_version_init();
    return detail_version;
}


#ifdef WIN32
char *cuwa_get_window_version()
{
   char *version = "unknown";
   //for Greg to fill in

   return version;
}
#endif

#ifdef LINUX
char *cuwa_get_linux_distro( apr_pool_t *pool, char *hardwareV)
{
    apr_file_t *pFile;
    apr_status_t rv;
    char *os = hardwareV;
    char distro[2500];
    apr_size_t len = sizeof(distro);
    char *p;

    rv = apr_file_open(&pFile, "/etc/issue", APR_READ, APR_UREAD|APR_UWRITE, pool );
    if (!rv)
    {
        rv = apr_file_read( pFile, distro, &len);
        if (!rv)
        {
            cuwa_trace("/etc/issue file:%s",distro);

            p = strchr(&distro[2],'\n');
            if ( p )
                *p = '\0';

            cuwa_util_replace_char( distro, '(');
            cuwa_util_replace_char( distro, ')');
            cuwa_util_replace_char( distro, '\n');

            if ( strstr( distro, "Welcome to ") )
                os = apr_psprintf( pool, "%s %s",hardwareV, &distro[11] );
            else
                os = apr_psprintf( pool, "%s %s",hardwareV, distro );
        }
        apr_file_close( pFile );
    }
    cuwa_trace("OSVersion=%s",os);
    return os;
}
#endif

char *cuwa_get_OS_version(apr_pool_t *pool)
{
#ifdef WIN32
    return cuwa_get_window_version();
#else
    pid_t pid;
    int commpipe[2];
    int rv;
    char *os;
    char hardware[250];

    if (pipe(commpipe))
    {
        return "none";
    }
    if ( (pid=fork()) == -1 )
    {
        return "none";
    }
    if (pid)
    {
        //parent process
        dup2(commpipe[0],0);     //replace stdin with the in side of the pipe
        close(commpipe[1]);
        fflush(stdout);

        if (!fgets(hardware,sizeof(hardware),stdin))
            strcpy(hardware,"unknown");

        if ( hardware[strlen(hardware)-1] == '\n' )
            hardware[strlen(hardware)-1] = '\0';

        os = apr_pstrdup( pool, hardware );
        cuwa_trace("os is %s", os);
       return os;
    }
   else
    {
        //child process
        dup2(commpipe[1],1);       //replace stdout with the out side of the pipe
        close(commpipe[0]);   //close unused side of pipe
        setvbuf(stdout,(char *)NULL, _IONBF, 0);  //set non-buffered output on stdout

        if ( system("/bin/uname -a") )
           system("/usr/bin/uname -a");

        wait(&rv);
        exit(1);
   }
#endif
}

void cuwa_build_client_version( apr_pool_t *pool )
{
    if ( !cuwa_client_version )
    {
        char *cuwa_version = cuwa_version_get_full();
        char *webServer = (char *)cuwa_wal_get_server_version();
        char *os = cuwa_get_OS_version( pool);
        apr_time_exp_t xt;
        char *timeStr,*verS;
        char *verStr = NULL;

        apr_time_exp_lt(&xt, apr_time_now());
        timeStr = apr_psprintf( pool, "%04d%02d%02d-%02d%02d",
                                       xt.tm_year+1900,
                                       xt.tm_mon+1,
                                       xt.tm_mday,
                                       xt.tm_hour,
                                       xt.tm_min );

        cuwa_trace("start up time %s", timeStr);
#ifdef LINUX
        os = cuwa_get_linux_distro(pool, os);
#endif

        // NOTE: The following bit of superstitious code is attempting to..
        //   1) prevent odd condition in windows where version string is being truncated
        //   2) if the condition recurs, get some tracing that might shed some light on why

        //escape the uri before we build verStr. Otherwise & is converted to &amp; in IIS that 
       //causes webLogin server can not recognize IIS from the url agrument it receives.
        cuwa_version = cuwa_wal_escape_uri(pool, cuwa_version);
        verS = apr_psprintf(pool,"%s %s",webServer, timeStr);
        verS = cuwa_wal_escape_uri(pool,verS);
        os = cuwa_wal_escape_uri(pool, os);

        verStr = apr_psprintf(pool, "VerC=%s&VerS=%s&VerO=%s", cuwa_version, verS, os);
        cuwa_trace("verStr: %s", verStr);

      //  verStr = cuwa_wal_escape_uri(pool, verStr );
      //  cuwa_trace("verStr: %s", verStr);

        if ( !cuwa_client_version )
        {
            cuwa_client_version = verStr;
            cuwa_crit("cuwa_build_client_version: %x: %s",cuwa_client_version,cuwa_client_version);
        }
        cuwa_trace("cuwa_client_version:%x", cuwa_client_version);
    }
}

char *cuwa_get_client_version()
{
    char *version = "VerC=unknown&VerS=unknown&VerO=unknown";

    if ( cuwa_client_version )
        return cuwa_client_version;
    else
        return version;
}

const char id_apache_cuwa_version_c[] = "$Id: cuwa_version.c,v 1.25 2013/02/26 15:45:07 hy93 Exp $";
