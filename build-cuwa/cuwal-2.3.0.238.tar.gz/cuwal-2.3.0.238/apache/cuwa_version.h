/************************************************************************
 * cuwa_version.h -- Get the module's version number
 *
 * Copyright 2008 Cornell University.
 * All Rights Reserved.
 *
 ************************************************************************
 *  $Log: cuwa_version.h,v $
 *  Revision 1.3  2008/05/06 13:17:52  hy93
 *  add prototype
 *
 *  Revision 1.2  2008/02/28 20:49:50  hy93
 *  fix compiler warning
 *
 *  Revision 1.1  2008/01/11 04:19:48  pb10
 *  Initial code.  Not compiled into the module yet.
 *
 *
 ************************************************************************
 */

#ifndef _CUWA_VERSION_H_
#define _CUWA_VERSION_H_

#include <apr_pools.h>

char *cuwa_version_get();
char *cuwa_version_get_full();
char *cuwa_get_client_version();
void cuwa_build_client_version(apr_pool_t *);

#endif
