/************************************************************************
 * session_bucket.h -- Bucket for moving request data out of session and
 *                     into bucket brigade.
 *
 * Copyright 2007 Cornell University.
 * All Rights Reserved.
 *
 ************************************************************************
 *
 *  Revision 1.2  2008/04/10 16:57:10  gbr4
 *  Line endings only. This set of files had mixed line endings which breaks visual studio (and looks ugly in vim). Each file was converted to the format that resulted in the fewest line changes (i.e. whichever format it was mostly in).
 *
 *  Revision 1.1  2007/12/21 00:14:00  pb10
 *  Integrate with session mgr.
 *
 *
 ************************************************************************
 */

#ifndef _SESSION_BUCKET_H
#define _SESSION_BUCKET_H

#include "apr.h"
#include "apr_general.h"
#include "apr_buckets.h"
#include "session.h"


extern const apr_bucket_type_t cuwa_session_bucket_type;

#define BUCKET_IS_SESSION(e) ((e)->type == &cuwa_session_bucket_type)

apr_bucket * session_bucket_make(apr_bucket *b, cuwa_session_t *sess,
                                               apr_off_t offset,
                                               apr_size_t len, apr_pool_t *p);

apr_bucket * session_bucket_create(cuwa_session_t *sess,
                                                 apr_off_t offset,
                                                 apr_size_t len, apr_pool_t *p,
                                                 apr_bucket_alloc_t *list);



#endif
