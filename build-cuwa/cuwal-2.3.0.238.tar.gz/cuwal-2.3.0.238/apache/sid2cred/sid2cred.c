#include <stdlib.h>
#include <stdio.h>
#include <kutil.h>
#include <cuwa_types.h>
#include <cred_krb.h>
#include <cred_base64.h>
#include <log.h>

#include <netinet/in.h>

#define CUWA2_LOG_DOMAIN cuwa.apache

#define syntax_check(c) do {if(argc<c){ printf("syntax: sid2cred host|0 sessionid netid password serviceid\n  NOTE: host=0 converts to host=NULL\n"); return 0;}} while (0)

int login(char *host, char *sid, char *netid, char *password, char *serviceid, char **wa);

int main(int argc, char* argv[])
{
    char *wa;
    int rc;

    syntax_check(6);

    rc = login(argv[1],argv[2],argv[3],argv[4],argv[5], &wa);
    if (rc)
    {
        fprintf(stderr,"ERROR: %d\n",rc);
    }
    else
    {
        printf("%s",wa);
    }

    return 0;
}

int login(char *host, char *sid, char *netid, char *password, char *serviceid, char **wa_ret)
{
    cuwa_err_t err, rc = 0;
    kutil_session_t ksess = NULL;
    char *k2=NULL, *wa=NULL;
    int k2len, waLen;
    uint64 sessionid;

    sscanf( sid,"%llX", &sessionid );
    fprintf(stderr,"SID: %llX (%s) \n",sessionid,sid);
    sessionid = ntohll(sessionid);
    fprintf(stderr,"SID2: %llX (%s) \n",sessionid,sid);
    sessionid = htonll(sessionid);
    fprintf(stderr,"SID3: %llX (%s) \n",sessionid,sid);

    if (host[0] == '0')
    {
        host = ""; //fixme ... NULL would crash
    }

    err = kutil_login(&ksess, netid, password);
    FAIL_IF(err,err);

    // for now just do local host
    err = cuwa_krb_make_k2( NULL, host, serviceid, &sessionid, 1, &k2, &k2len, NULL );
    FAIL_IF(err,err);

    err = cuwa_base64_make_wa(&wa, &waLen, k2len, 1, k2, k2len);
    FAIL_IF(err,err);
    wa[waLen]='\0';

    *wa_ret = wa;

cleanup:

    if (ksess) kutil_end_session(ksess);

    return rc;
}
const char id_apache_sid2cred_sid2cred_c[] = "$Id: sid2cred.c,v 1.9 2008/07/14 14:47:44 pb10 Exp $";
