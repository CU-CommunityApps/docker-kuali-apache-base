#!/usr/bin/perl -w

use IO::Handle;
use Net::LDAPS;
use Socket;


$confFile = "/app/bridge/conf/permit.conf";

open(CONFFILE,$confFile) or die ("Can't open file $confFile");
foreach $line (<CONFFILE>) {
    chomp($line);    #remove caritage return
    chop($line);     #remove "
    if ( length($line)>0 && index($line,"#") == -1 ) {
        if ( index($line, "LdapURL") >= 0 ) {
            $LdapURL = substr($line, index($line,"\"")+1);
        }
        if  ( index($line, "LdapBindID") >= 0 ) {
            $LdapBindID = substr($line, index($line,"\"")+1);
        }
        if  ( index($line, "LdapPasswd") >= 0 ) {
            $LdapPasswd = substr($line, index($line,"\"")+1);
        }
        if  ( index($line, "LdapIgnoreDC") >= 0 ) {
            $ignoreAD = substr($line, index($line,"\"")+1);
        }
        if  ( index($line, "LdapBaseDn") >= 0 ) {
            $LdapBaseDn = substr($line, index($line,"\"")+1);
        }
        if  ( index($line, "LiveADFileName") >= 0 ) {
            $ADFile = substr($line, index($line,"\"")+1);
        }

    }
}

close(CONFFILE);

($sec,$min,$hour,$mday,$mon,$year) = localtime(time);
$current_timestamp = sprintf("%4d-%02d-%02d %02d:%02d:%02d", $year+1900,$mon+1,$mday,$hour,$min,$sec);

$hint = "has SRV record 0 100 389 ";

$base = "ou=HoldingIDs,".$LdapBaseDn;

$filter = "CN=oit idm-permitmgr";

$caPath = "/app/bridge/conf/certs/";
$timeout = 10;

@allAD=`host -t SRV _ldap._tcp.ithaca._sites.$LdapURL`;
$newADFile = $ADFile.".latest";

$availableAD = "";

foreach $ad (@allAD) {
    chomp($ad);
    $index = index($ad, $hint);

    if ($index <= 0 )  {  print "host cmd failed\n"; exit;}

    $adUrl = substr($ad, $index+length($hint));
    chop($adUrl);

    if ( $adUrl eq $ignoreAD ) { next;}

    pipe(FROM_CHILD,TO_PARENT) or die "pipe: $!";

    TO_PARENT->autoflush(1);

    if ($child = fork )        #parent
    {
        close TO_PARENT;
 
        $done = 0;
        $rfd = '';
        while (!$done ) {
            vec($rfd, fileno(FROM_CHILD),1) = 1;
            if (select( $rfd, undef, undef, $timeout) >= 0 &&
                vec($rfd, fileno(FROM_CHILD),1) )
            {
                chomp ($result = <FROM_CHILD>);
                if ($result eq "OK" ) { 
                     $availableAD = $availableAD.$adUrl." ";
                }
                close FROM_CHILD;
                waitpid($child,0);
                $done = 1; 
            }
            else {
                kill( 15,$child );
                print "$adUrl not responding\n";
                $done = 1;
            }
        }
    }
    else
    {
        close FROM_CHILD;
        print "$current_timestamp check the health of $adUrl\n";
        $ldap = Net::LDAPS->new($adUrl,port=>'636',verify=>'require',capath=>$caPath) or exit print TO_PARENT "BAD";
        my($junk,$CN) = split('CN=', $ldap->certificate->subject_name);
        if ($CN !~m/$adUrl/) { 
           print "$current_timestamp host name verification failed:$adUrl\n";                                  
           print TO_PARENT "BAD"; 
           close TO_PARENT;
           exit;                                                                            
        }                                                                                    
        $result = $ldap->bind($LdapBindID,                                                   
                              password=>$LdapPasswd);                                           
        if ($result->code)
        {
            print "$current_timestamp bind failed, $result->code\n";
            print TO_PARENT "BAD";
        }
        else
        {
            $mesg = $ldap->search(
                    base => $base,
                    filter => $filter,
                    attrs => ['distinguishedname']);
            if ($mesg->code )  { 
                print "$current_timestamp ldapsearch failed:$adUrl\n";
                print TO_PARENT "BAD";
            }
            else {
                $entry = $mesg->entry(0);
                $result = $entry->get_value("distinguishedname");
                if ( $result =~ m/$filter/) { $result = "OK"; }
                else { 
                    print "$current_timestamp search result is not correct: $result\n";
                    $result = "BAD";
                } 
                print TO_PARENT $result;
            }
         }
         $ldap->unbind;
         close TO_PARENT;
         exit;
     }
}

if ( length($availableAD) > 0 ) {
    @liveAD = split(' ', $availableAD);
    @liveAD = sort(@liveAD);

    open ADFILE,">",$newADFile or die "Can't open file $newADFile";
    foreach $ad (@liveAD) { 
        print "$current_timestamp Live AD: $ad\n";
        print ADFILE "$ad\n";
    }
    close ADFILE;
    if (-e $ADFile) {
        @diff = `diff $newADFile $ADFile`;
        if (@diff > 0 ) {
            `mv $newADFile $ADFile`;
            print "$current_timestamp new live AD file generated\n";
        }
        else {
            `rm $newADFile`;
        }
   }
   else {
       `mv $newADFile $ADFile`;
       print "$current_timestamp new live AD file generated\n";
  }
}

print "------------------------------\n";
