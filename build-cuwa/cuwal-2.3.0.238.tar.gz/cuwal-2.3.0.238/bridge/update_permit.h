/************************************************************************
 * update_permit.h -- Handle add/delete member from group and create new group
 *                    using ARS
 * Copyright 2010 Cornell University.
 * All Rights Reserved.
 *
 ************************************************************************
 *  $Log: update_permit.h,v $
 *  Revision 1.4  2010/07/26 18:00:30  hy93
 *  Fix add/delete member faild for the group which has space in the DN
 *
 *  Revision 1.3  2010/05/21 20:59:25  hy93
 *  permit create support
 *
 *  Revision 1.2  2010/05/19 20:16:49  hy93
 *  modify function interface
 *
 *  Revision 1.1  2010/05/19 16:59:57  hy93
 *  header for permit add/delete/create
 *
 *
 ************************************************************************
 */

#ifndef _UPDATE_PERMIT_H
#define _UPDATE_PERMIT_H

int cuwa_bridge_qars_add_member(apr_pool_t *pool,char * arsserver, char * client, char * group, char * newMember);
int cuwa_bridge_qars_del_member(apr_pool_t *pool,char * arsserver, char * client, char * group, char * exMember);
int cuwa_bridge_qars_create_group(apr_pool_t *pool,char * arsserver, char * client, char *groupSam, char *groupCN, char *groupOU, char *adminOU, char *clientDN);
int cuwa_bridge_qars_force_passwd(apr_pool_t *pool,char * arsserver, char *bridgeCredential, char *clientNewPassword, char *clientDN);
#endif
