/************************************************************************
 * update_permit_questars.c -- permit bridge that searches AD for group info
 *
 * Copyright 2010 Cornell University.
 * All Rights Reserved.
 *
 ************************************************************************
 *  $Log: update_permit_questars.c,v $
 *  Revision 1.18  2016/04/19 18:41:13  hy93
 *  modify group membership update using a new aspx page
 *
 *  Revision 1.17  2014/04/23 19:55:19  hy93
 *  *** empty log message ***
 *
 *  Revision 1.16  2010/07/26 18:00:20  hy93
 *  Fix add/delete member faild for the group which has space in the DN
 *
 *  Revision 1.15  2010/06/28 14:09:00  hy93
 *  remove create update and admin groups for delegation groups
 *
 *  Revision 1.14  2010/05/23 01:56:28  hy93
 *  fix compiler warning
 *
 *  Revision 1.13  2010/05/21 20:59:02  hy93
 *  permit create support
 *
 *  Revision 1.12  2010/05/21 17:16:36  gbr4
 *  add group create -- untested
 *
 *  Revision 1.11  2010/05/21 16:35:42  hy93
 *  use aspx for updating permit
 *
 *  Revision 1.10  2010/05/20 18:52:12  hy93
 *  permit update support
 *
 *  Revision 1.9  2010/05/19 20:17:41  hy93
 *  fix underfined variable error
 *
 *  Revision 1.8  2010/05/19 20:12:34  gbr4
 *  change interface to cuwa_bridge_qars_create_group
 *
 *  Revision 1.7  2010/05/19 19:24:18  gbr4
 *  fix set_password_action
 *
 *  Revision 1.6  2010/05/19 19:10:55  gbr4
 *  add error code capture and password reset
 *
 *  Revision 1.5  2010/05/19 18:58:39  gbr4
 *  interim change
 *
 *  Revision 1.4  2010/05/19 16:58:20  hy93
 *  remove code that are no longer needed
 *
 *  Revision 1.3  2010/05/19 14:13:38  hy93
 *  add interface for force password
 *
 *  Revision 1.2  2010/05/18 19:35:17  gbr4
 *  update_permit junk
 *
 *  Revision 1.1  2010/05/18 19:20:05  gbr4
 *  initial commit
 *
 ************************************************************************                                       
 */


#define CUWA2_LOG_DOMAIN cuwa.bridge.update


#include <curl/curl.h>
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <log.h>
#include <unistd.h>
#include <apr_pools.h>
#include <httpd.h>  

#define CUWA_SPML_BUFFER_SIZE 40000
/*
static const char * spml_add = "<?xml version=\"1.0\"?><soap:Envelope xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\" xmlns:soap=\"http://schemas.xmlsoap.org/soap/envelope/\"> <soap:Body> <addRequest xmlns=\"urn:oasis:names:tc:SPML:2:0\" returnData=\"everything\">      <psoID ID=\"CN=%s," PERMIT_OU "\"/> <data> <attr name=\"objectClass\" xmlns=\"urn:oasis:names:tc:DSML:2:0:core\"> <value>group</value> </attr> <attr name=\"description\" xmlns=\"urn:oasis:names:tc:DSML:2:0:core\"> <value>My test group</value> </attr> </data> </addRequest> </soap:Body> </soap:Envelope>";

*/
//(groupDN, add|delete, memberDN)
/*static const char * g_cuwa_spml_modify_member = \
               "<?xml version=\"1.0\"?> \
                <soap:Envelope xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\" xmlns:soap=\"http://schemas.xmlsoap.org/soap/envelope/\"> \
                  <soap:Body> \
                    <spml:modifyRequest xmlns:spml=\"urn:oasis:names:tc:SPML:2:0\" returnData=\"\"> \
                      <spml:psoID ID=\"%s\"/> \
                      <spml:modification> \
                        <modification name=\"member\" operation=\"%s\" xmlns=\"urn:oasis:names:tc:DSML:2:0:core\"> \
                          <value>%s</value> \
                        </modification> \
                      </spml:modification> \
                    </spml:modifyRequest> \
                  </soap:Body> \
                </soap:Envelope>";

static const char * g_cuwa_spml_modify_member_action = \
	"SOAPAction: \"urn:oasis:names:tc:SPML:2:0/modify\"";
*/


//(DN,sAMAccountName)
static const char * g_cuwa_spml_create_group = \
               "<?xml version=\"1.0\" encoding=\"utf-8\"?> \
                <soap:Envelope xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\" xmlns:soap=\"http://schemas.xmlsoap.org/soap/envelope/\"> \
                  <soap:Body> \
                    <addRequest xmlns=\"urn:oasis:names:tc:SPML:2:0\"> \
                      <psoID ID=\"%s\" /> \
                      <data> \
			<attr name=\"objectClass\" xmlns=\"urn:oasis:names:tc:DSML:2:0:core\"> <value>group</value> </attr> \
			<attr name=\"description\" xmlns=\"urn:oasis:names:tc:DSML:2:0:core\"> <value>created by bridge</value> </attr> \
                        <attr name=\"sAMAccountName\" xmlns=\"urn:oasis:names:tc:DSML:2:0:core\"> \
                          <value>%s</value> \
			</attr> \
                        <attr name=\"member\" xmlns=\"urn:oasis:names:tc:DSML:2:0:core\"> <value>%s</value> </attr> \
                      </data> \
                    </addRequest> \
                  </soap:Body> \
                </soap:Envelope>";

static const char * g_cuwa_spml_create_group_action = \
	"SOAPAction: \"urn:oasis:names:tc:SPML:2:0/add\"";
/*
static const char * g_cuwa_spml_reset_password = \
               "<?xml version=\"1.0\" encoding=\"utf-8\"?> \
               <soap:Envelope xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\" xmlns:soap=\"http://schemas.xmlsoap.org/soap/envelope/\"> \
                 <soap:Body> \
                   <resetPasswordRequest xmlns=\"urn:oasis:names:tc:SPML:2:0:password\" /> \
                 </soap:Body> \
               </soap:Envelope>";
static const char * g_cuwa_spml_reset_password_action = "urn:oasis:names:tc:SPML:2:0:password/resetPassword";
*/


//(targetDN,newPassword)
static const char * g_spml_set_password = \
              "<?xml version=\"1.0\"?> \
               <soap:Envelope xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\" xmlns:soap=\"http://schemas.xmlsoap.org/soap/envelope/\"> \
                 <soap:Body> \
                   <setPasswordRequest xmlns=\"urn:oasis:names:tc:SPML:2:0:password\"> \
                     <psoID ID=\"%s\"/> \
                     <password>%s</password> \
                   </setPasswordRequest> \
                 </soap:Body> \
               </soap:Envelope>";
static const char * g_spml_set_password_action = "urn:oasis:names:tc:SPML:2:0:password/setPassword";


/*********************************************************************
 *  issues a specified SPML command to the specified server
 *  arsserver: the server to use
 *  client: the identity to use to issue the command
 *  spml: the SPML to issue
 *  action: the SOAPAction header to use ("SOAPAction: \"urn:oasis:names:tc:SPML:2:0/listTargets\"");
 */
static int cuwa_bridge_qars_issue_spml(apr_pool_t *pool,const char *arsserver, const char * client, const char * spml, const char * action){
	long ret=-1;
	CURL *curl;
	CURLcode res;
        
	curl=curl_easy_init();
	if(curl){
		struct curl_slist *hlist=NULL;
                char *escapedURL = ap_escape_uri(pool,arsserver);

		hlist=curl_slist_append(hlist, "Content-Type: text/xml");
		hlist=curl_slist_append(hlist, action);

                cuwa_trace("connect to %s", escapedURL);
		curl_easy_setopt(curl, CURLOPT_URL, escapedURL);
		curl_easy_setopt(curl, CURLOPT_HTTPHEADER, hlist);
		curl_easy_setopt(curl, CURLOPT_USERPWD, client);
		curl_easy_setopt(curl, CURLOPT_HTTPAUTH, CURLAUTH_NTLM);
		curl_easy_setopt(curl, CURLOPT_POST,1);
		curl_easy_setopt(curl, CURLOPT_VERBOSE,0);
		curl_easy_setopt(curl, CURLOPT_POSTFIELDS, spml);

		//curl_easy_setopt(curl, CURLOPT_POSTFIELDSIZE, -1);
		res = curl_easy_perform(curl);
                if (!res)
                {
		    curl_easy_getinfo(curl, CURLINFO_RESPONSE_CODE, &ret);
                    cuwa_trace("http response code is:%d", ret);
                }
		curl_slist_free_all(hlist); hlist=NULL;
		curl_easy_cleanup(curl); curl=NULL;
	}
        if (ret==200) ret= CUWA_OK;
        else if (ret == 401) ret = CUWA_ERR_ARS_LOGIN;

	return ret;
}

static int cuwa_bridge_qars_issue_aspx(apr_pool_t *pool,const char *arsserver, const char * client ){
        long ret=-1;
        CURL *curl;
        CURLcode res;

        curl=curl_easy_init();
        if(curl){

                cuwa_trace("connect to %s", arsserver);
                curl_easy_setopt(curl, CURLOPT_URL, arsserver);
                curl_easy_setopt(curl, CURLOPT_USERPWD, client);
                curl_easy_setopt(curl, CURLOPT_HTTPAUTH, CURLAUTH_NTLM);
                curl_easy_setopt(curl, CURLOPT_VERBOSE,0);

                res = curl_easy_perform(curl);
                if (!res)
                {
                    curl_easy_getinfo(curl, CURLINFO_RESPONSE_CODE, &ret);
                    cuwa_trace("http response code is:%d", ret);
                }
                curl_easy_cleanup(curl); curl=NULL;
        }
        if (ret==200) ret= CUWA_OK;
        else if (ret == 401) ret = CUWA_ERR_ARS_LOGIN;

        return ret;
}

//Build and execute an SPML query allocating a buffer as necessary
//this could be a function if I rememberd the syntax for ... functions
//ret [OUT] return value ... pass an int
//server ... passed as arsserver to cuwa_bridge_ars_issue_spml
//client ... passed as client to cuwa_bridge_ars_issue_spml
//action  ... passed as action to cuwa_bridge_ars_issue_spml 
//fmtstring ... SPML with %s's to be replaced with the ...
#define CUWA_BRIDGE_SPML_INVOKE(pool,ret,server,client,action,fmtstring,...) do { \
									char spml[CUWA_SPML_BUFFER_SIZE]; \
									int realsize; \
									realsize=snprintf(spml, CUWA_SPML_BUFFER_SIZE, fmtstring,  ##__VA_ARGS__); \
									if(realsize >= CUWA_SPML_BUFFER_SIZE){ \
										char * bigger = malloc(realsize +1); \
										realsize=snprintf(bigger, realsize, fmtstring,  ##__VA_ARGS__); \
										bigger[realsize]='\0'; \
										ret = cuwa_bridge_qars_issue_spml(pool,arsserver,client,bigger,action); \
										free(bigger); \
									} \
									else{ \
										ret = cuwa_bridge_qars_issue_spml(pool,arsserver,client,spml,action); \
									} \
									}while(0)


int cuwa_bridge_qars_force_passwd(apr_pool_t *pool,char * arsserver, char *bridgeCredential, char *clientNewPassword, char *clientDN){  
	int ret;
	CUWA_BRIDGE_SPML_INVOKE(pool,ret,arsserver,bridgeCredential,g_spml_set_password_action,g_spml_set_password,clientDN,clientNewPassword);
	return ret;
}

#define CUWA_BRIDGE_ASPX_INVOKE(pool, ret,server,client,action,group,member) do { \
           char spml[CUWA_SPML_BUFFER_SIZE]; \
           int realsize; \
           realsize=snprintf(spml,CUWA_SPML_BUFFER_SIZE,"%s?action=%s&group=%s&member=%s", server,action,group,member); \
           if(realsize >= CUWA_SPML_BUFFER_SIZE){ \
               char * bigger = malloc(realsize +1); \
               realsize=snprintf(bigger,realsize,"%s?action=%s&group=%s&member=%s", server,action,group,member); \
               bigger[realsize]='\0'; \
               ret = cuwa_bridge_qars_issue_aspx(pool,bigger,client); \
               free(bigger); \
             } \
             else{ \
                ret = cuwa_bridge_qars_issue_aspx(pool,spml,client); \
             } \
       }while(0)    

/*********************************************************************
 *  adds a member to a group
 *  arsserver: the server to use
 *  client: the identity to use to issue the command
 *  group: the DN of the group to modify
 *  newMember: the DN of the member to add
 */
int cuwa_bridge_qars_add_member(apr_pool_t *pool, char * arsserver, char * client, char * group, char * newMember){
	int ret;
       //CUWA_BRIDGE_SPML_INVOKE(ret,arsserver,client,g_cuwa_spml_modify_member_action,g_cuwa_spml_modify_member,group,"add",newMember);
       CUWA_BRIDGE_ASPX_INVOKE(pool, ret,arsserver,client,"add",ap_escape_uri(pool,group),ap_escape_uri(pool,newMember));
	return ret;
}

/*********************************************************************
 *  removes a member from a group
 *  arsserver: the server to use
 *  client: the identity to use to issue the command
 *  group: the DN of the group to modify
 *  exMember: the DN of the member to remove
 */
int cuwa_bridge_qars_del_member(apr_pool_t *pool, char * arsserver, char * client, char * group, char * exMember){
	int ret;
	//CUWA_BRIDGE_SPML_INVOKE(,ret,arsserver,client,g_cuwa_spml_modify_member_action,g_cuwa_spml_modify_member,group,"delete",exMember);
        CUWA_BRIDGE_ASPX_INVOKE(pool,ret,arsserver,client,"delete",ap_escape_uri(pool,group),ap_escape_uri(pool,exMember));
	return ret;
}


// create a single group. no security checks.
int cuwa_bridge_qars_create_one_group(apr_pool_t *pool, char *arsserver, char *bridgeCred, char * groupSAM, char * groupCN, char * groupOU, char *newMember){
        int ret;
        char groupDN[CUWA_SPML_BUFFER_SIZE+1];
	snprintf(groupDN, CUWA_SPML_BUFFER_SIZE, "CN=%s,%s",groupCN,groupOU);
	groupDN[CUWA_SPML_BUFFER_SIZE]='\0';
	CUWA_BRIDGE_SPML_INVOKE(pool,ret,arsserver,bridgeCred,g_cuwa_spml_create_group_action,g_cuwa_spml_create_group,groupDN, groupSAM,newMember);

        return ret;
}
	

/*********************************************************************
 *  creates a group
 *  arsserver: the server to use
 *  client: the identity to use to issue the command
 *  group: the DN of the group to modify
 *  exMember: the DN of the member to remove
 * PRE: FIXME: CALLER MUST VERIFY PERMISSIONS
 * PRE: FIXME: CALLER MUST CALCULATE CN TO BE LESS THAN 60 characters
 */
int cuwa_bridge_qars_create_group(apr_pool_t *pool,char * arsserver, char * bridgeCred, char * groupSAM, char * groupCN, char * groupOU, char * adminOU, 
                                  char *clientDN) {
	int ret;
         
	/*calculate _adm and _upd names
        char groupAdm[CUWA_SPML_BUFFER_SIZE+1];
        char groupUpd[CUWA_SPML_BUFFER_SIZE+1];
        char groupAdmSAM[CUWA_SPML_BUFFER_SIZE+1];
        char groupUpdSAM[CUWA_SPML_BUFFER_SIZE+1];

	snprintf(groupAdm, CUWA_SPML_BUFFER_SIZE, "%s_adm",groupCN);
	snprintf(groupUpd, CUWA_SPML_BUFFER_SIZE, "%s_upd",groupCN);
	snprintf(groupAdmSAM, CUWA_SPML_BUFFER_SIZE, "%s_adm",groupSAM);
	snprintf(groupUpdSAM, CUWA_SPML_BUFFER_SIZE, "%s_upd",groupSAM);
        groupAdm[CUWA_SPML_BUFFER_SIZE]='\0';
        groupUpd[CUWA_SPML_BUFFER_SIZE]='\0';
        groupAdmSAM[CUWA_SPML_BUFFER_SIZE]='\0';
        groupUpdSAM[CUWA_SPML_BUFFER_SIZE]='\0';
*/	

	//make the groups
	ret = cuwa_bridge_qars_create_one_group(pool,arsserver, bridgeCred, groupSAM, groupCN, groupOU,clientDN);

/*      usleep(1000000);
	if (!ret) ret= cuwa_bridge_qars_create_one_group(arsserver, bridgeCred, groupAdmSAM, groupAdm, adminOU,clientDN);
        usleep(1000000);
	if (!ret) ret= cuwa_bridge_qars_create_one_group(arsserver, bridgeCred, groupUpdSAM, groupUpd, adminOU,clientDN);
*/
        usleep(1000000);

         //add client to newGroup's adm group and update group
        // snprintf(groupAdmDN, CUWA_SPML_BUFFER_SIZE,"CN=%s,%s",groupAdm, adminOU);
       // if (!ret) ret= cuwa_bridge_qars_add_member( arsserver, bridgeCred, groupAdmDN, clientDN );

	//TODO: assign client rights in the _upd group
	//TODO: setup AccessTemplateLinks (x4)
	return ret;
}

