
$error=1;
$warning=2;
$message=4;
my $last_status=0;
my $line;
while(<STDIN>){
	s/\s*$//g;
	$line=$_;
	my $status=0;
	my $prefix="";
	my $postfix="";
	if(m/[Ww]arning:/){
		$status = $status | $warning;
	}
	if(m/[Ee]rror:/){
		$status = $status | $error;
	}
	if(m/\*\*\*/){
		$status = $status | $message;
		if($last_status){
			$status=$last_status;
		}
	}
	
	if($status & $error){
		$line="<span style=\"background:pink;\">$line</span>";
	}
	elsif($status & $warning){
		$line="<span style=\"background:yellow;\">$line</span>";
	}
	elsif($status & $message){
		$line="<b>$line</b>";
	}
	print $line . "\n";
	$last_status=$status
}


	


