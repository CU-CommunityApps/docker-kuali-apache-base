#!/bin/sh

#script to find stuff on the build servers

SRC_ROOT=$HOME/src
BIN_ROOT=$HOME/local
CUWA_TOP=$SRC_ROOT/cuwal2

#ok the build servers got a bit messy
#right now 2.2 is the only series with multiple installs
#try looking in the set of places apache might be installed
[ -z "$AP22VER" ] && AP22VER=2.2.10
LOOK_IN2="$BIN_ROOT /idm/local /idm/local2 /idm/stack-$AP22VER $HOME/local $HOME/local2 $HOME/stack-$AP22VER"
if [ "$APVer" = "2.2.8" ]; then
	for place in $LOOK_IN2; do echo checking $place; [ -x "$place/httpd-$AP22VER/bin/apxs" ] && BIN_ROOT=$place && APACHE22=$place/httpd-$AP22VER && echo found; done
fi

[ -z "$APACHE" ] && APACHE=$APACHE22


#now that we have adjusted BIN_ROOT set the locations relative to that
[ -z "$KRBPATH" ] && KRBPATH=`ls -d $BIN_ROOT/krb5-* | sort | tail -1`
[ -z "$APACHE" ] && APACHE=`ls -d $BIN_ROOT/httpd-$APVer | sort | tail -1`
[ -z "$APACHE" ] && APACHE=`ls -d $BIN_ROOT/apache-$APVer | sort | tail -1`
[ -z "$APACHE" ] && APACHE=`ls -d $BIN_ROOT/httpd-$APVer* | sort | tail -1`
[ -z "$APACHE" ] && APACHE=`ls -d $BIN_ROOT/apache-$APVer* | sort | tail -1`
[ -z "$APACHE" ] && APACHE=`ls -d $BIN_ROOT/httpd-* | sort | tail -1`
[ -z "$APACHE" ] && APACHE=`ls -d $BIN_ROOT/apache-* | sort | tail -1`
[ -z "$OPENSSL" ] && OPENSSL=`ls -d $BIN_ROOT/openssl-* | sort | tail -1`
APACHEPATH=$APACHE
APR_PATH=$APACHE

RELEASEDIR=$HOME/www
if [ -z "$NOW" ] ; then
NOW=`date +%Y%m%d-%H%M`
fi
APXS=$APACHEPATH/bin/apxs
[ -z "$MAKE" ] && MAKE=make
makeisgnu=`$MAKE --version 2>&1 | grep GNU`
[ -z "$makeisgnu" ] && MAKE=gmake

gdb="`which gdb`"
[ -z "$GDB" ] && [ -x "$gdb" ] && GDB="$gdb";
gdb="/opt/TWWfsw/bin/gdb"
[ -z "$GDB" ] && [ -x "$gdb" ] && GDB="$gdb";
gdb="/usr/local/bin/gdb"
[ -z "$GDB" ] && [ -x "$gdb" ] && GDB="$gdb";
gdb="/opt/fsw/bin/gdb"
[ -z "$GDB" ] && [ -x "$gdb" ] && GDB="$gdb";

export GDB
export MAKE
export APACHE
export OPENSSL
export KRBPATH
