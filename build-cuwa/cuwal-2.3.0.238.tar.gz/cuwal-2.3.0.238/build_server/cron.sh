#!/bin/sh
DIR=`dirname $0`
PATH=$PATH:/usr/bin:/usr/sbin:/opt/common/bin:/usr/sfw/bin:/users/idmbuild/bin:/usr/ucb:/usr/openwin/bin:/usr/ccs/bin:/opt/bin
export PATH
. $DIR/config.sh

cd $CUWA_TOP
$DIR/update_tree.sh
$DIR/do_builds.sh
