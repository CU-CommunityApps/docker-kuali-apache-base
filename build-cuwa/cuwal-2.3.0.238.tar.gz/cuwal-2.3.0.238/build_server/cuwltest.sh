#!/bin/sh
echo > servers
#pull the WLR from a prod test and dev server
for i in web1.login.cornell.edu web1.login.test.idm.cit.cornell.edu web1.login.dev.idm.cit.cornell.edu; do curl -sS https://$i/HA/servers >> servers; done

sort servers > servers2
echo > servers3
for i in `cat servers2`; do curl -sS $i/HA/servers >> servers3; done

sort servers3 | uniq > servers4

diff servers2 servers4 || echo ERROR some server missing from roots

for i in `cat servers4`; do echo $i `curl -sS $i/HA/status` `curl -sS $i/build | grep 2.0.0 | cut -d \- -f 1`; done
