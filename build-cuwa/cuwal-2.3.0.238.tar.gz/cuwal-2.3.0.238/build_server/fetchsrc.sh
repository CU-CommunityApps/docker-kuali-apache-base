cvs -Q -z3 -d cvsrepo.cit.cornell.edu:/cvs co -P -d cuwal2 -D "Thursday, August 25, 2016 4:10:40 PM UTC" IdentityManagement/cuwal2
