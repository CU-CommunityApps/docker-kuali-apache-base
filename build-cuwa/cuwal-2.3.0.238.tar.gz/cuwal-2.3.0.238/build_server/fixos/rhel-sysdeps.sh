yum install httpd-devel.x86_64 openssl-devel krb5-devel mod_perl perl-Crypt-SSLeay
