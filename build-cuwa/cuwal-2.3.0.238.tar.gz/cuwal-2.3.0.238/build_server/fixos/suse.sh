#!/bin/sh

# last tested on OpenSUSE 11
sudo zypper install gcc make bison python-ply autoconf automake ncurses-devel cvs
