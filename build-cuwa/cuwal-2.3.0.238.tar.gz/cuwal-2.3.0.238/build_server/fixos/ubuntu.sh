#!/bin/sh

# last tested on Ubuntu 8.04 Server
# it is assumed that you have done these 4 lines first
#sudo apt-get update
#sudo apt-get dist-upgrade
#sudo apt-get install openssh-server
#sudo shutdown -r now

sudo apt-get install gcc gdb make byacc autoconf automake ncurses-dev curl ca-certificates cvs 

