#!/bin/sh
DIR=`dirname $0`
CC=gcc
export CC
echo --- Determining build ID ---
JOB_BASENAME=`echo $JOB_NAME | cut -d / -f 1`
CUWALBUILD="unknown-UNOFFICIAL"
if [ "$JOB_BASENAME" = "cuwal2" ]; then
	CUWALBUILD=$BUILD_NUMBER
fi
if [ "$JOB_BASENAME" = "cuwal2-source" ]; then
	CUWALBUILD=$HBUILD
fi

if [ "$JOB_BASENAME" = "cuwal2-experimental-source" ]; then
	CUWALBUILD="e$HBUILD"
elif [[ "$JOB_BASENAME" == cuwal2-experimental ]]; then
        CUWALBUILD="e$BUILD_NUMBER"
elif [[ "$JOB_BASENAME" == cuwal2-experimental-* ]]; then
        CUWALBUILD="e$BUILD_NUMBER"
fi
if [ -n "$CUWALBUILD" ]; then
	echo $CUWALBUILD > build_server/build-id
fi
echo --- Build ID is $CUWALBUILD ---
echo 'sed -e "s/\.UnknownCUWA/\.$CUWALBUILD/" configure.ac > configure.ac.ver'
sed -e "s/\.UnknownCUWA/\.$CUWALBUILD/" configure.ac > configure.ac.ver
CUWALVER=`grep AC_INIT configure.ac.ver | cut -d , -f 2 | cut -d \[ -f 2 | cut -d \] -f 1`
echo $CUWALVER > build_server/build-ver
mv configure.ac.ver configure.ac
env AUTOCONF_VERSION=2.61 env AUTOMAKE_VERSION=1.9 autoreconf -f
[ "$1" = "-nobuild" ] && exit 0

. $DIR/config.sh
LD_LIBRARY_PATH="$KRBPATH/lib:$OPENSSL/lib:$APACHE/lib:$LD_LIBRARY_PATH"
export LD_LIBRARY_PATH

psflags="-ef"
if [ "`uname`" = "OpenBSD" ]; then
psflags="-auxwww"
fi
ps $psflags | grep httpd | grep idmbuild | grep -v local/www
X=`ps $psflags | grep httpd | grep idmbuild | awk '{print $2}'`
if [ -n "$X" ]; then
         for i in $X; do kill -9 $i || true; done
fi

	CURLP=`ls -d $HOME/local/curl* | sort | tail -1` 2> /dev/null
		PATH=$CURLP/bin:$PATH;
		export PATH

echo --- Build Server Information ---
. $DIR/build_info.sh 2>&1 | tee build/info.log

echo --- Apache information --- 
$APACHE/bin/httpd -V 2>&1  | sed -e 's/^/APACHE: /' | tee build/apache.log

echo --- Configure output ---
./configure --with-apxs=$APACHE/bin/apxs --with-krb5=$KRBPATH --with-ssl=$OPENSSL 2>&1 | tee build/configure.log
touch test.cfg

echo --- Make output ---
echo $MAKE
($MAKE 2>&1 || touch build/fail) | tee build/make.log

(ldd apache/.libs/mod_cuwebauth.so 2>&1 || true) | tee build/ldd.log

if [ "$ENABLE_TESTS" = "yes" ]; then
echo --- Make check ---
cd tests
	if [ -z "$TEST_ARGS" ]; then
     		#(./runtests.sh || ./runtests.sh -v  ||  touch ../build/fail) 2>&1 | tee ../build/make_check.log
		
     		(./runtests.sh ||  touch ../build/fail-tests) 2>&1 | tee ../build/make_check.log
		#if tests failed, go ahead and parse out the important parts of the error_log
		if [ -f ../build/fail-tests ]; then
			touch ../build/fail
			csplit ../build/make_check.log "%-------------------------------------------------------------------------------%1"
			mv xx00 summary
			rm xx*
			FAILED=`cat summary | awk '{print $1}' | grep "^t/[a-zA-Z0-9_-]*.t" | sed -e 's/^t\///'`
			echo "appear to have failed $FAILED"
			cd t/logs/
			for tname in $FAILED; do
				echo working on $tname
				csplit error_log "%####CUWAT start test $tname####%" '/####CUWAT start test/' '%caught SIGTERM, shutting down%'
				ls
				mv xx00 error_log.$tname.log
				rm xx*
			done
			cd ../..
			#remove empty files
			for i in `ls t/logs/*.log`; do test -s $i || rm $i; done
		fi
		find ./t/sessions -name '*.req' -exec rm {} \;
		find ./t/sessions -name '*.use' -exec rm {} \;
		find ./t/sessions -name '*.pri' -exec rm {} \;
		rm t/logs/error_log
		
	else
     		(./runtests.sh $TEST_ARGS  ||  touch ../build/fail) 2>&1 | tee ../build/make_check.log
	fi
cd ..
fi

if [ -x "$GDB" ]; then
echo --- Looking for cores ---
	pwd
	echo '#!/bin/sh' > genbt.sh
	echo ". $APACHE/bin/envvars" >> genbt.sh
	echo "GDB=$GDB" >>genbt.sh
	chmod 755 genbt.sh
	cat tests/summary | grep 'for stacktrace, run: gdb' | sed -e 's/^.*run: gdb/\$GDB/' | sed -e "s/$/ -batch -x .\/build_server\/gdb.in/" >> genbt.sh
	#Apache::Test doesn't find the core on OpenBSD
	[ -f tests/t/httpd.core ] && echo '$GDB -c tests/t/httpd.core $APACHE/bin/httpd -batch -x ./build_server/gdb.in' >> genbt.sh
	cat genbt.sh
	./genbt.sh 2>&1 | tee tests/t/logs/backtrace.log
	test -s tests/t/logs/backtrace.log || rm tests/t/logs/backtrace.log
	cat tests/t/logs/backtrace.log | head -100
else
	echo "--- could not find gdb, not looking for cores ---"
	echo "$GDB not executable"
fi

echo
echo Generating HTML of the logs
echo
echo "<html><body><h1>Build Info $BUILD_NUMBER $APVer (`whoami`@`uname`) </h1><pre>" > build/buildlog.html
echo '</pre><h1>Make output</h1><pre>' >> build/buildlog.html
cat build/make.log | perl $DIR/colorize.pl >> build/buildlog.html
echo '</pre><h1>Make check output</h1><pre>' >> build/buildlog.html
cat build/make_check.log | perl $DIR/colorize.pl >> build/buildlog.html
echo '</pre><h1>Software Info</h1><pre>' >> build/buildlog.html
cat build/info.log | perl $DIR/colorize.pl >> build/buildlog.html
echo '</pre><h2>Apache Info</h2><pre>' >> build/buildlog.html
cat build/apache.log | perl $DIR/colorize.pl >> build/buildlog.html
echo '</pre><h1>Configure output</h1><pre>' >> build/buildlog.html
cat build/configure.log | perl $DIR/colorize.pl >> build/buildlog.html
echo '</pre><h2>depend.rules output</h2><pre>' >> build/buildlog.html
cat depend.rules | perl $DIR/colorize.pl >> build/buildlog.html
echo '</pre><h1>Ldd output</h1><pre>' >> build/buildlog.html
cat build/ldd.log | perl $DIR/colorize.pl >> build/buildlog.html
echo '</pre></body></html>' >> build/buildlog.html

echo Looking for warnings...
for i in build/*.log; do
	grep -i 'error:' $i | sed -e 's/^/BUILD_ERROR:/' >> build/hudson-err.log
	grep -i ': syntax error' $i | sed -e 's/^/BUILD_ERROR:/' >> build/hudson-err.log
	egrep -i '^make.* Error[0-9 ]*$' $i | sed -e 's/^/BUILD_ERROR:/' >> build/hudson-err.log
	grep -i 'warning:' $i | sed -e 's/^/BUILD_WARNING:/' >> build/hudson-warn.log
done

[ -f build/fail ] && exit 1
if test -s build/hudson-err.log ; then exit 1; fi
true
