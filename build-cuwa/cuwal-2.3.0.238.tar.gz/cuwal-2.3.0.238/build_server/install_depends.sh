#!/bin/sh
SRC_BASE=$HOME/src
BIN_BASE=$HOME/local
CVS=cvsrepo.cit.cornell.edu
CVS_RSH=`which ssh`
TAR=`which tar`
export CVS_RSH

echo Checking for a ssh key pair in $HOME/.ssh/id_rsa...
if [ ! -f $HOME/.ssh/id_rsa ]; then
	echo Generating a ssh key pair...
	ssh-keygen -t rsa -b 4096
fi

echo Checking to ensure that login works to $CVS
if ssh -oPasswordAuthentication=no $CVS hostname; then
	echo Ok
else
	echo -n please enter a userid with access to $CVS: 
	read cvs_user
	scp $HOME/.ssh/id_rsa.pub $cvs_user@$CVS:`whoami`@`hostname`.pub
	echo I copied this key to $CVS:\~$cvs_user/`whoami`@`hostname`.pub
	echo Please manually install the authorized key on cvsrepo and then re-run this script
	exit
fi
mkdir -p $SRC_BASE
mkdir -p $BIN_BASE
cd $SRC_BASE
mkdir tars
cd tars
echo Fetching dependancies
VAPACHE20="2.0.63"
VAPACHE22="2.2.8"
VOPENSSL="0.9.8g"
VK5="1.6.3"


test -f httpd-$VAPACHE22.tar.gz || wget http://apache.oregonstate.edu/httpd/httpd-$VAPACHE22.tar.gz
test -f httpd-$VAPACHE20.tar.gz || wget http://apache.oregonstate.edu/httpd/httpd-$VAPACHE20.tar.gz
test -f openssl-$VOPENSSL.tar.gz || wget http://www.openssl.org/source/openssl-$VOPENSSL.tar.gz
test -f krb5-$VK5-signed.tar || wget http://web.mit.edu/kerberos/dist/krb5/1.6/krb5-$VK5-signed.tar
$TAR xf krb5-$VK5-signed.tar
echo Extracting dependancies 
cd ..
$TAR xzf tars/openssl-$VOPENSSL.tar.gz 
$TAR xzf tars/krb5-$VK5.tar.gz
$TAR xzf tars/httpd-$VAPACHE20.tar.gz 
$TAR xzf tars/httpd-$VAPACHE22.tar.gz 

cd openssl-$VOPENSSL/
echo Configuring `pwd`
./config --prefix=$BIN_BASE/openssl-$VOPENSSL/ shared || exit 1
echo Making `pwd`
make || exit 1
echo Installing `pwd`
make install || exit 1

cd $SRC_BASE
cd krb5-$VK5/
cd src
./configure --without-tcl --prefix=$BIN_BASE/krb5-$VK5
make
make install


cd $SRC_BASE
cd httpd-$VAPACHE20/
./configure --with-ssl=$BIN_BASE/openssl-$VOPENSSL/ --enable-ssl --enable-so --prefix=$BIN_BASE/apache-$VAPACHE20
make
make install


cd $SRC_BASE
cd httpd-$VAPACHE22/
./configure --with-ssl=$BIN_BASE/openssl-$VOPENSSL/ --enable-ssl --enable-so --prefix=$BIN_BASE/apache-$VAPACHE22
make
make install

