#! /usr/bin/env bash
# solaris sh sucks but bash location is unreliable

###############################################################################
# $Id: install_stack.sh,v 1.39 2015/12/10 18:58:51 hy93 Exp $ 
#
# install_stack.sh builds and installs an autoconf-based software stack
# usage: install_stack.sh [config_file]
#
# config_file is an optional shell script that is included
# this can set any of the variables below:
#
# Reads the following environment variables 
# SRC_BASE	directory to unpack source into [$HOME/src]
# BIN_BASE	base of prefixes for components. [$HOME/local]
# TAR_BASE	where to put downloaded source tars [$SRC_BASE/tars]
#
# STACK		the stack to install. An ordered list of the above components
#		[OPENSSL KRB5 APACHE22]
#
# INSTALL	if install is "small" the apache manual icons and other junk
#		is dumped ["small"] -- this default is for environments with
#		many copies of apache that don't like a manual in each of them
#
# OPENSSL
# KRB5		kerberos 5 LIBRARIES only by default.
# APACHE22	
#
# The following can be customized but the defaults are recommended
# for each item ($X) in stack:
# X_MIRROR	http://some.mirror.org/path/to -- REQUIRED
# X_NAME	somesoftware-a.b.c -- REQUIRED
# X_FETCH	name of tar.gz on mirror [$X_NAME.tar.gz]
# X_EXTRACT	how to extract X_FETCH [gunzip -c $X_FETCH | tar xf -]
# X_PREFIX	--prefix for X [$BIN_BASE/$X_NAME]
# X_CHECK	test whether X is present [test -d $X_PREFIX]
# X_CFGOPTS	extra arguments to --configure [""]
# X_CFG_WITHME	name of this package used only in X_CFG_OTHERS by default 
#		[Prefix of $X_NAME before -]
# X_CFG_OTHERS	arguments for configuring later packages in the stack
#		[--with-$X_CFG_OTHERS=$X_PREFIX]. This is appended to
#		$GLOBAL_CFG *after* this package is installed
# X_PRECONFIGURE	Command run before X_CONFIGURE [:] 		
#		expected use is something like 'cd src'
# X_CONFIGURE	[./configure --prefix=$X_PREFIX --CFGOPTS]
#		$GLOBAL_CFG is appended to $X_CONFIGURE which is then run
# X_MAKE	[$MAKE]
# X_INSTALL	[$MAKE install]
#
# if an argument is specified it will be
# included in this file
# that can be used to use a configuration
# file instead of the environment
#
# fixme: not everything can be overridden. need to guard more stuff with
# test -z "$X" &&
#
##############################################################################


# note to maintainer: the X_Y above are run under a variety of eval $X_Y, eval eval $X_Y, sh -c "$X_Y". Be very careful with variable escaping. For example, you seldom want to read $X_PREFIX, you will usually want \$X_PREFIX so that it is read after \$X_PREFIX has been built. At some point I would like to go through this and make the number of eval's constant.

if [ -n "$1" ]; then
	test "$1" = "-?" -o "$1" = "--help" && cat $0 | head -54 | tail -52 | grep '^#' && exit 1
	test "$1" = "-v" -o "$1" = "--version" && echo '$Id: install_stack.sh,v 1.39 2015/12/10 18:58:51 hy93 Exp $' && exit 1
	test -f "$1" && . $1
fi
set -x

#########################################
# Paths where stuff will be installed
#########################################
test -z "$SRC_BASE" && SRC_BASE=/app/src
test -z "$BIN_BASE" && BIN_BASE=/app/share
test -z "$TAR_BASE" && TAR_BASE=$SRC_BASE/tars

for i in $SRC_BASE $BIN_BASE $TAR_BASE; do test -d $i || mkdir -p $i; done

#########################################
# Dependancies
#########################################
if [ -z "$MAKE" ]; then
	gmake -v && MAKE=gmake
	#kerberos makefile likes gmake
fi
test -z "$TAR" && TAR=tar
test -z "$WGET" && WGET="wget --no-check-certificate"
test -z "$MAKE" && MAKE=make
test -z "$GUNZIP" && GUNZIP=gunzip
test -z "$LOCALMIRROR" && LOCALMIRROR='http://cuwabuild.cit.cornell.edu/download'

#########################################
# Components & Order of installation
#########################################
test -z "$STACK" && STACK='OPENSSL KRB5 APACHE22 PERL MODPERL P5SSLEAY P5URI P5HTMLTAGSET P5HTMLPARSER P5LWP P5WWWMECHANIZE'
#test -z "$STACK" && STACK='OPENSSL KRB5 APR APRUTIL PCRE APACHE24 PERL MODPERL P5SSLEAY P5URI P5HTMLTAGSET P5HTMLPARSER P5LWP P5WWWMECHANIZE'
test -z "$INSTALL" && INSTALL="small"

#########################################
# Component definitions
#########################################
[ -z "$OPENSSL_NAME" ]          && OPENSSL_NAME='openssl-1.0.1q'
[ -z "$CURL_NAME" ]		&& CURL_NAME='curl-7.18.1'
[ -z "$PERL_NAME" ]		&& PERL_NAME='perl-5.20.1'
[ -z "$MODPERL_NAME" ]		&& MODPERL_NAME="mod_perl-2.0.9"
[ -z "$P5SSLEAY_NAME" ]		&& P5SSLEAY_NAME='Crypt-SSLeay-0.57'
[ -z "$P5HTMLTAGSET_NAME" ]	&& P5HTMLTAGSET_NAME='HTML-Tagset-3.20'
[ -z "$P5HTMLPARSER_NAME" ]	&& P5HTMLPARSER_NAME='HTML-Parser-3.71'
[ -z "$P5URI_NAME" ]		&& P5URI_NAME='URI-1.69'
[ -z "$P5LWP_NAME" ]		&& P5LWP_NAME='libwww-perl-5.820'
[ -z "$P5WWWMECHANIZE_NAME" ]	&& P5WWWMECHANIZE_NAME='WWW-Mechanize-1.34'
[ -z "$KRB5_NAME" ]		&& KRB5_NAME='krb5-1.13.2'
[ -z "$APR_NAME" ]              && APR_NAME='apr-1.5.2'
[ -z "$APRUTIL_NAME" ]          && APRUTIL_NAME='apr-util-1.5.4'
[ -z "$APACHE22_NAME" ]		&& APACHE22_NAME='httpd-2.2.31'
[ -z "$APACHE24_NAME" ]         && APACHE24_NAME='httpd-2.4.17'
[ -z "$PCRE_NAME" ]             && PCRE_NAME='pcre-8.37'

[ "$OPENSSL_NAME" = "openssl-0.9.7" ]	&& OPENSSL_NAME='openssl-0.9.7m'

OPENSSL_MIRROR='http://www.openssl.org/source'

OPENSSL_CONFIGURE="./config --prefix=\$OPENSSL_PREFIX shared"
if [ "`uname -sr`" = "SunOS 5.9" ]; then
	if [ "OPENSSL_NAME" = "openssl-0.9.7m" ]; then
	#work around OpenSSL 0.9.7 bug on solaris 9
		OPENSSL_CONFIGURE="./Configure --prefix=\$OPENSSL097_PREFIX shared solaris-sparcv9-gcc27"
	fi
fi

OPENSSL_CFG_OTHERS="--with-ssl=\$OPENSSL_PREFIX --enable-ssl"
OPENSSL_POSTINSTALL='test -d "$OPENSSL_PREFIX/lib" && for i in $OPENSSL_PREFIX/lib/*.so*; do ln -s $i $HOME/lib/`basename $i`; done'

CURL_MIRROR='http://curl.haxx.se/download/'
WGET_MIRROR='http://ftp.gnu.org/gnu/wget/'
WGET_POSTINSTALL="ln -s \$WGET_PREFIX/bin/wget $HOME/bin/wget"

PERL_MIRROR='http://www.cpan.org/src/'
PERL_CONFIGURE="env CC=gcc env CFLAGS=-fPIC ./configure.gnu --prefix=\$PERL_PREFIX -Duseithreads #"
PERL_POSTINSTALL="ln -s \$PERL_PREFIX/bin/perl $HOME/bin/perl"

MODPERL_MIRROR="http://perl.apache.org/dist/"
MODPERL_PRECONFIGURE="$FIND_PERL"
MODPERL_CONFIGURE='\$PERL_PREFIX/bin/perl Makefile.PL MP_APXS=\$APACHE22_PREFIX\$APACHE24_PREFIX/bin/apxs INSTALL_BASE=\$APACHE22_PREFIX\$APACHE24_PREFIX #'
MODPERL_POSTINSTALL="mkdir \$MODPERL_PREFIX; echo PERL5LIB=\$APACHE22_PREFIX\$APACHE24_PREFIX/lib/perl5 >>  \$APACHE22_PREFIX\$APACHE24_PREFIX/bin/envvars; echo export PERL5LIB >>  \$APACHE22_PREFIX\$APACHE24_PREFIX/bin/envvars"
MODPERL_CHECK="\$PERL_PREFIX/bin/perl -I\$APACHE22_PREFIX\$APACHE24_PREFIX/lib/perl5 -MApache2::URI -e 1 2>/dev/null"

P5SSLEAY_MIRROR='http://search.cpan.org/CPAN/authors/id/D/DL/DLAND/'
P5SSLEAY_CONFIGURE='env PERL_MM_USE_DEFAULT=1 env LD_LIBRARY_PATH="\$OPENSSL_PREFIX/lib:$LD_LIBRARY_PATH" \$PERL_PREFIX/bin/perl Makefile.PL --lib=\$OPENSSL_PREFIX INC=-I\$OPENSSL_PREFIX/include #'
P5SSLEAY_CHECK="env LD_LIBRARY_PATH=$LD_LIBRARY_PATH:\$OPENSSL_PREFIX/lib \$PERL_PREFIX/bin/perl -MCrypt::SSLeay -e 1"


P5HTMLTAGSET_MIRROR='http://search.cpan.org/CPAN/authors/id/P/PE/PETDANCE/'
P5HTMLTAGSET_CONFIGURE='\$PERL_PREFIX/bin/perl Makefile.PL #'
P5HTMLTAGSET_CHECK="\$PERL_PREFIX/bin/perl -MHTML::Tagset -e 1"

P5HTMLPARSER_MIRROR='http://search.cpan.org/CPAN/authors/id/G/GA/GAAS/'
P5HTMLPARSER_CONFIGURE='\$PERL_PREFIX/bin/perl Makefile.PL #'
P5HTMLPARSER_CHECK="\$PERL_PREFIX/bin/perl -MHTML::Parser -e 1"

P5URI_MIRROR='http://search.cpan.org/CPAN/authors/id/G/GA/GAAS/'
P5URI_CONFIGURE='\$PERL_PREFIX/bin/perl Makefile.PL #'
P5URI_CHECK="\$PERL_PREFIX/bin/perl -MURI -e 1"

P5LWP_MIRROR='http://search.cpan.org/CPAN/authors/id/G/GA/GAAS/'
P5LWP_CONFIGURE='env PERL_MM_USE_DEFAULT=1 \$PERL_PREFIX/bin/perl Makefile.PL -n #'
P5LWP_CHECK="\$PERL_PREFIX/bin/perl -MLWP::Simple -e 1"


P5WWWMECHANIZE_MIRROR='http://search.cpan.org/CPAN/authors/id/P/PE/PETDANCE/'
P5WWWMECHANIZE_CONFIGURE='env PERL_MM_USE_DEFAULT=1 \$PERL_PREFIX/bin/perl Makefile.PL -n #'
P5WWWMECHANIZE_CHECK="\$PERL_PREFIX/bin/perl -MWWW::Mechanize -e 1"

KRB5_MIRROR='http://web.mit.edu/kerberos/dist/krb5/1.6'
KRB5_FETCH="$KRB5_NAME-signed.tar"
#MIT provides signed tars which need to be unwrapped
KRB5_EXTRACT="(cd $TAR_BASE; $TAR xf $KRB5_FETCH; cd $SRC_BASE; $GUNZIP -c $TAR_BASE/$KRB5_NAME.tar.gz | tar xf -)"
KRB5_CFGOPTS="--without-tcl"
KRB5_PRECONFIGURE='cd src'
#Don't install the whole package (which needs sudo) just install the libs
#KRB5_INSTALL="mkdir -p \$KRB5_PREFIX/lib; mkdir -p \$KRB5_PREFIX/include/gssrpc; mkdir -p \$KRB5_PREFIX/include/gssapi; mkdir -p \$KRB5_PREFIX/lib; mkdir -p \$KRB5_PREFIX/bin; cd lib; make install; cd ../util; make install; cd ..; cp krb5-config \$KRB5_PREFIX/bin/"

PCRE_MIRROR='ftp://ftp.csx.cam.ac.uk/pub/software/programming/pcre/'

APR_MIRROR='http://archive.apache.org/dist/apr/'
APRUTIL_MIRROR='http://archive.apache.org/dist/apr/'

APACHE_MIRROR='http://archive.apache.org/dist/httpd/'
APACHE_CFGOPTS="--enable-so --enable-headers --enable-cgi --enable-rewrite --enable-mods-shared=\"headers cgi rewrite\""

APACHE24_MIRROR=$APACHE_MIRROR
APACHE24_CFG_OTHERS="--with-apxs=\$APACHE24_PREFIX/bin/apxs"
test -z "$APACHE24_CFGOPTS" && APACHE24_CFGOPTS="$APACHE_CFGOPTS --with-included-apr"
APACHE24_MAKE="$MAKE SHELL=`which bash`"

APACHE22_MIRROR=$APACHE_MIRROR
APACHE22_CFG_OTHERS="--with-apxs=\$APACHE22_PREFIX/bin/apxs"
test -z "$APACHE22_CFGOPTS" && APACHE22_CFGOPTS="$APACHE_CFGOPTS --with-included-apr"
APACHE22_MAKE="$MAKE SHELL=`which bash`"


if [ "$INSTALL" = "small" ]; then
        APACHE24_INSTALL="$MAKE install SHELL=`which bash` && rm -rf \$APACHE24_PREFIX/manual && rm -rf \$APACHE24_PREFIX/icons && rm -rf \$APACHE24_PREFIX/htdocs/apache*"
	APACHE22_INSTALL="$MAKE install SHELL=`which bash` && rm -rf \$APACHE22_PREFIX/manual && rm -rf \$APACHE22_PREFIX/icons && rm -rf \$APACHE22_PREFIX/htdocs/apache*"
else
	APACHE22_INSTALL="$MAKE install SHELL=`which bash`"
        APACHE24_INSTALL="$MAKE install SHELL=`which bash`"
fi

#apache 2.2.9 ships with an included apr that doesn't build 
#on solaris without tweaking the makefile.
test "$APACHE22_NAME" = "httpd-2.2.9" &&  APACHE22_PRECONFIGURE="cd srclib/apr-util; test -f Makefile.in.buggy || mv Makefile.in Makefile.in.buggy; sed -e 's/@for m in/-@for m in/' Makefile.in.buggy > Makefile.in; cd ../.."


APACHE22_POSTINSTALL='test -d "$OPENSSL_PREFIX/lib" && cd $APACHE22_PREFIX/lib && for i in $OPENSSL_PREFIX/lib/*.so* $KRB5_PREFIX/lib/*.so*; do ln -s \$i .; done'
APACHE24_POSTINSTALL='test -d "$OPENSSL_PREFIX/lib" && cd $APACHE24_PREFIX/lib && for i in $OPENSSL_PREFIX/lib/*.so* $KRB5_PREFIX/lib/*.so*; do ln -s \$i .; done'

CUWA_MIRROR='https://cuwabuild.cit.cornell.edu/hudson/job/cuwal2-source/lastSuccessfulBuild/artifact/'
CUWA_INSTALL='cd tests; ./runtests.sh; echo not installing automatically'


###############################################################################
# Build default values for unspecified options
# recommend trying to make the defaults usable rather than overriding all 
# 12+ for each package
###############################################################################
for X in $STACK; do
	#check the required stuff
	# X_MIRROR should be http://somesite/some/path
	# X_NAME is the top-level directory in $S_FETCH
	for Y in NAME MIRROR; do
		eval X_REQUIRED="\$${X}_${Y}"
		if [ -z "$X_REQUIRED" ]; then
			echo "${X} is defined in \$STACK and ${X}_${Y} is required but not defined"
			exit 1
		else
			echo ${X}_${Y}=$X_REQUIRED
		fi
		export ${X}_${Y}
	done


	#set default values for optional settings
	#the default settings are usually fine.
	#override them elsewhere if needed, don't edit this section
	
	# X_FETCH
	# The file to be downloaded and extracted 
	# set unless it is X_NAME.tar.gz
	eval X_FETCH="\$${X}_FETCH"
	if [ -z "$X_FETCH" ]; then
		eval "${X}_FETCH=\"\$${X}_NAME.tar.gz\""
		eval echo "${X}_FETCH_=\$${X}_FETCH"
	else
		eval echo "${X}_FETCH=\$${X}_FETCH"
	fi
	export ${X}_FETCH


	# X_EXTRACT
	# COMMAND run from $TAR_BASE to produce $SRC_BASE/NAME
	# CWD is $TAR_BASE
	eval X_EXTRACT="\$${X}_EXTRACT"
	if [ -z "$X_EXTRACT" ]; then
		eval "${X}_EXTRACT=\"$GUNZIP -c $TAR_BASE/\$${X}_FETCH | $TAR xf -\""
		eval echo "${X}_EXTRACT_=\$${X}_EXTRACT"
	else
		eval echo "${X}_EXTRACT=\$${X}_EXTRACT"
	fi
	export ${X}_EXTRACT

	# X_PREFIX
	# DIRECTORY into which X should be installed
	eval X_PREFIX="\$${X}_PREFIX"
	if [ -z "$X_PREFIX" ]; then
		eval "${X}_PREFIX=\"${BIN_BASE}/\$${X}_NAME\""
		eval echo ${X}_PREFIX_=\$${X}_PREFIX
	else
		eval echo ${X}_PREFIX=\$${X}_PREFIX
	fi
	export ${X}_PREFIX

	# X_CHECK
	# COMMAND used to determine whether X is already installed
	# CWD is $SRC_BASE
	# default does a weak test for the existance of X_PREFIX
	# this might be worth changing
	eval X_CHECK="\$${X}_CHECK"
	if [ -z "$X_CHECK" ]; then
		eval "${X}_CHECK=\"test -d \$${X}_PREFIX\""
		eval echo ${X}_CHECK_=\$${X}_CHECK
	else
		eval echo ${X}_CHECK=\$${X}_CHECK
	fi
	export ${X}_CHECK

	# X_CFGOPTS
	# ARGUMENTS to X_CONFIGURE
	# prefix doesn't need to be specified here, it is specified as part of X_CONFIGURE
	eval X_CFGOPTS="\$${X}_CFGOPTS"
	if [ -z "$X_CFGOPTS" ]; then
		eval "${X}_CFGOPTS=\"\""
		eval echo ${X}_CFGOPTS_=\$${X}_CFGOPTS
	else
		eval echo ${X}_CFGOPTS=\$${X}_CFGOPTS
	fi
	export ${X}_CFGOPTS
	

	# X_CFG_WITHME
	# This is used to tell LATER packages in the stack how to take advantage of X
	# it is used in X_CFG_OTHERS by default as --with-$X_CFG_WITHME=$X_PREFIX
	# The default is to use the prefix of X_NAME before the first -
	# ARGUMENTS to Y_CONFIGURE of the form --with-${X_CFG_WITHME}=${X_PREFIX}
	eval X_CFG_WITHME="\$${X}_CFG_WITHME"
	if [ -z "$X_CFG_WITHME" ]; then
		eval "${X}_CFG_WITHME=\`echo \$${X}_NAME | cut -d \- -f 1\`"
		eval echo ${X}_CFG_WITHME_=\$${X}_CFG_WITHME
	else
		eval echo ${X}_CFG_WITHME=\$${X}_CFG_WITHME
	fi
	export ${X}_WITHME
	

	# X_CFG_OTHERS
	# ARGUMENTS to Y_CONFIGURE for each Y configured after X
	eval X_CFG_OTHERS="\$${X}_CFG_OTHERS"
	if [ -z "$X_CFG_OTHERS" ]; then
		eval "${X}_CFG_OTHERS=\"--with-\$${X}_CFG_WITHME=\$${X}_PREFIX\""
		eval echo ${X}_CFG_OTHERS_=\$${X}_CFG_OTHERS
	else
		#it was set, do an extra interpolation to expand things like the prefix
		eval "${X}_CFG_OTHERS=\"$X_CFG_OTHERS\""
		eval echo ${X}_CFG_OTHERS=\$${X}_CFG_OTHERS
	fi
	export ${X}_CFG_OTHERS
	
	# X_PRECONFIGURE
	# COMMAND run before configure.
	# the usual use of this is to change into a source directory
	eval X_PRECONFIGURE="\$${X}_PRECONFIGURE"
	if [ -z "$X_PRECONFIGURE" ]; then
		eval "${X}_PRECONFIGURE=\":\""
		eval echo ${X}_PRECONFIGURE_=\$${X}_PRECONFIGURE
	else
		eval echo ${X}_PRECONFIGURE=\$${X}_PRECONFIGURE
	fi
	export ${X}_PRECONFIGURE
	

	# X_CONFIGURE
	# COMMAND used to configure. for autoconf driven packages the default is fine
	# ./configure --prefix=$X_PREFIX $GLOBAL_CFG
	# if you override this you won't get $GLOBAL_CFG
	eval X_CONFIGURE="\$${X}_CONFIGURE"
	if [ -z "$X_CONFIGURE" ]; then
		eval "${X}_CONFIGURE=\"./configure --prefix=\$${X}_PREFIX \$${X}_CFGOPTS\""
		eval echo ${X}_CONFIGURE_=\$${X}_CONFIGURE
	else
		eval "${X}_CONFIGURE=\"$X_CONFIGURE\""
		eval echo ${X}_CONFIGURE=\$${X}_CONFIGURE
	fi
	export ${X}_CONFIGURE

	# X_MAKE
	# COMMAND used to build the source
	eval X_MAKE="\$${X}_MAKE"
	if [ -z "$X_MAKE" ]; then
		eval "${X}_MAKE=\"$MAKE\""
		eval echo ${X}_MAKE_=\$${X}_MAKE
	else
		eval echo ${X}_MAKE=\$${X}_MAKE
	fi
	export ${X}_MAKE

	# X_INSTALL
	# COMMAND used to install the source
	# run immediately after $X_MAKE
	eval X_INSTALL="\$${X}_INSTALL"
	if [ -z "$X_INSTALL" ]; then
		eval "${X}_INSTALL=\"$MAKE install\""
		eval echo ${X}_INSTALL_=\$${X}_INSTALL
	else
		eval "${X}_INSTALL=\"$X_INSTALL\""
		eval echo ${X}_INSTALL=\$${X}_INSTALL
	fi
	export ${X}_INSTALL

	# X_POSTINSTALL
	# COMMAND used to postinstall
	# run immediately after $X_POSTINSTALL
	eval X_POSTINSTALL="\$${X}_POSTINSTALL"
	if [ -z "$X_POSTINSTALL" ]; then
		eval "${X}_POSTINSTALL=\"echo no post-install\""
		eval echo ${X}_POSTINSTALL_=\$${X}_POSTINSTALL
	else
		eval "${X}_POSTINSTALL=\"$X_POSTINSTALL\""
		eval echo ${X}_POSTINSTALL=\$${X}_POSTINSTALL
	fi
	export ${X}_POSTINSTALL

	echo ""
	echo ""

done

###############################################################################
# Fetch stage -- download distfiles for each package
###############################################################################
echo "Grabbing distfiles for $STACK"
for X in $STACK; do
	cd $TAR_BASE
	eval DISTFILE=\$${X}_FETCH
	echo Checking for $DISTFILE
	if test -f "$DISTFILE"; then
		echo "Have $DISTFILE, not downloading again"
		echo ""
	else
		eval $WGET $LOCALMIRROR/$DISTFILE -O$DISTFILE
		grep 'The file you have requested is not found' $DISTFILE && rm $DISTFILE
		if [ -f "$DISTFILE" ]; then
			:
		else
		
		if eval $WGET \$${X}_MIRROR/$DISTFILE -O$DISTFILE; then
			echo Got $DISTFILE
		else
			echo Could not get $DISTFILE
			echo check that \$${X}_FETCH and \$${X}_MIRROR are correct
			exit 1
		fi
		fi
	fi
done

###############################################################################
# Install stage -- install each package if needed
###############################################################################
echo "Starting to build and install"
for X in $STACK; do
	
	cd $SRC_BASE

	echo "************************************************************************"
	echo  "***          Installing $X"
	echo "************************************************************************"
	
	#make sure this needs to be installed
	eval "X_CONFIGURE=\"\$${X}_CONFIGURE $GLOBAL_CFG\""
	eval "X_CHECK=\"\$${X}_CHECK\""
	if eval $X_CHECK; then
		echo ${X} appears to be already installed
		eval echo "\$${X}_CHECK passed"
		eval echo "to force installation, you probably need to remove \$${X}_PREFIX"
		eval PREVARGS="\$${X}_PREFIX/configure.args"
		if test -f "$PREVARGS"; then
			PREVARGS=`cat $PREVARGS`
			eval "MYARGS=\"$X_CONFIGURE\""
			if [ "$MYARGS" != "$PREVARGS" ]; then
				echo "WARNING: installed configured with:  $PREVARGS"
				echo "WARNING: my configure arguments are: $MYARGS"
			fi
		fi
		echo skipping
	else	
		#unpack the source if necessary
		cd $SRC_BASE
		if eval "test -d \$${X}_NAME"; then
			eval echo "${X} $SRC_BASE/\$${X}_NAME exists, not unpacking"
			echo "WARNING: you might have wanted to make clean this"
		else
			eval "echo \"\$${X}_EXTRACT\""
			if eval "sh -c \"\$${X}_EXTRACT\""; then
				echo success
                                if [ ${X} == "APACHE24" ]; then
                                      eval "cp -r $APR_NAME \$${X}_NAME/srclib/apr"
                                      eval "cp -r $APRUTIL_NAME \$${X}_NAME/srclib/apr-util"
                                fi
			else
				echo "Error unpacking $X"
				eval "rm -rf \$${X}_NAME"
				eval "rm -rf $TAR_BASE/\$${X}_FETCH"
				eval "$WGET \$${X}_MIRROR/\$${X}_FETCH -O$TAR_BASE/\$${X}_FETCH" || exit 1
				eval "sh -c \"\$${X}_EXTRACT\"" || exit 1				
			fi
		fi
                
                if [ ${X} == "APR" ]; then continue; fi
                if [ ${X} == "APRUTIL" ]; then continue; fi
                
		#configure it
		eval cd $SRC_BASE/\$${X}_NAME || exit 1
		
		eval eval \$${X}_PRECONFIGURE

		eval $X_CONFIGURE || exit 1

		#build it
		eval "\$${X}_MAKE" || exit 1

		#install it
		eval "sh -c \"\$${X}_INSTALL\"" || exit 1
		eval "sh -c \"test -d \$${X}_PREFIX\" || mkdir \$${X}_PREFIX"
		
		#do any post-install
		eval "sh -c \"\$${X}_POSTINSTALL\"" 

		#write some information about the install into
		#X_PREFIX/configure.args, config.log, and build.environment
		eval "echo $X_CONFIGURE > \$${X}_PREFIX/configure.args"
		if test -f config.log; then
			eval "cp config.log \$${X}_PREFIX/config.log"
		else
			eval "echo \"$X_CONFIGURE\" > \$${X}_PREFIX/config.log"
		fi

                #for apache24 load mod_ssl
                if [ ${X} == "APACHE24" ]; then
                    eval "sed -i 's!#LoadModule ssl_module modules/mod_ssl.so!LoadModule ssl_module modules/mod_ssl.so!g' \$${X}_PREFIX/conf/httpd.conf"
                fi
		eval "set > \$${X}_PREFIX/build.enviornment"
	fi
	
	#now that this is installed, update the global configuration
	#so that other packages in this STACK know it exists
	eval "GLOBAL_CFG=\"$GLOBAL_CFG \$${X}_CFG_OTHERS\""
	eval "echo $GLOBAL_CFG > \$${X}_PREFIX/config-args-out"
	
done
echo $GLOBAL_CFG > $BIN_BASE/config-args

