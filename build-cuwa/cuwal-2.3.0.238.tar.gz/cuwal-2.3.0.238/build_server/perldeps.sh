#!/bin/sh
[ -x $HOME/local/perl*/bin/perl ] && PERL=$HOME/local/perl*/bin/perl
[ -x $HOME/bin/perl ] && PERL=$HOME/bin/perl
[ -z "$PERL" ] && PERL=`which perl`

$PERL -MCPAN -e"install Crypt::SSLeay"
$PERL -MCPAN -e"install Bundle::LWP"
$PERL -MCPAN -e"install WWW::Mechanize"
$PERL -MCPAN -e"install HTTP::Recorder"
$PERL -MCPAN -e"install HTTP::Proxy"
