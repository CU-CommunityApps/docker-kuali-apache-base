#!/bin/sh
DIR=`dirname $0`
cd $DIR/..
CVS_RSH=`which ssh`
export CVS_RSH
cvs up -APd
