/**
 * CUWAL2 Configuration Subsystem.
 * Copyright (c) 2007 Cornell University
 */

#include "config.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdarg.h>
#include <assert.h>
#include "../log/log.h"
#include "../pal/pal.h"
#include "../util/util.h"

/** Longest line expected in a conf file */
#define CUWA2_CONF_LINE_LEN 1024

/** Logging domain */
#define CUWA2_LOG_DOMAIN cuwa.config

/**
 * Prints out the passed attribute.
 * @param[in] s1 Attribute to be printed
 */
static void cuwa_printattrib(cuwa_attrib * s1){
	cuwa_trace("node (%s) (%s)",s1->name,s1->value);
}

/**
 * Compares a string to an attribute's name (case insensative).
 * @param[in] s input string for comparison
 * @param[in] a input attribute for comparison
 * @return 0 if they match, nonzero otherwise
 * @see stricmp
 */
static int cuwa_attribcmp(void * s, void * a){
	cuwa_atrace("comparing (%s) (%s)",s,((cuwa_attrib*)a)->name);
	return(_stricmp(s,((cuwa_attrib*)a)->name));
}

#undef CUWA2_LOG_DOMAIN
#define CUWA2_LOG_DOMAIN cuwa.config.parse
/**
 * Takes an input string and removes all unquoted comments, trims leading and trailing whitespace, turns unquoted tabs into spaces and multiple contiguous unquoted spaces into a single space
 * @param[in,out] s The string to be modified
 * @return a pointer to the beginning of the processed string. this pointer will always be within the buffer passed as input. It is returned so that leading whitespace can be trimmed
 * @see stricmp
 */
static char* cuwa_conf_line_cleanup(char *s){
	char *ret=s;
	char *iterator;
	char quotetype=0;
	while(' '==*ret || '\t'==*ret) ret++; // strip leading whitespace
	iterator=ret;
	while(*iterator){
		if(!quotetype && ('"' == *iterator || '\'' == *iterator )){
			quotetype=*iterator;
		}
		if(!quotetype){
			if('#' == *iterator){
				cuwa_trace("Stripping comment (%s) from line: %s",(iterator+1),s);
				*iterator='\0';
				break;
			}
			else if('\t' == *iterator){
				*iterator=' ';
			}
			while(' ' == *iterator &&( ' ' == *(iterator+1) || '\t' ==  *(iterator+1) )){ //delete repeated whitespaceexpo
				char *i2=iterator+1;

				*i2=' '; //spaceify a tab
				while(*i2){
					*i2=*(i2+1);
					i2++;
				}
			}
		}
		if(quotetype && *iterator == quotetype)	quotetype=0; //found end of quote
		iterator++;
	}
	if (quotetype){
		cuwa_crit("unmatched quote in: %s",s);
		return iterator; //iterator points to an empty string
	}

	while(strlen(ret) && ' ' == ret[strlen(ret)-1] ) ret[strlen(ret)-1]='\0'; //trim trailing whitespace
	return ret;
}


/**
 * Parses line and adds it into the attribute list passed.
 * Parses lines of the form 'n1 (d2 n2)* d1 value' into the list.
 * n1 will be inserted into the list with n2 as a child and n3 as a child of that ... value will be assigned only to the final leaf.
 * @param[in,out] l The list of attributes into which the attribute will be inserted
 * @param[in,out] line The line to be parsed. setattr can write to line during the parsing. The contents of line after parsing are undefined
 * @param[in] d1 The delimiter used to seperate the name from the value. Use " \t"
 * @param[in] d2 The delimiter used to seperate parts of the name from each other. Use "."
 * @param[in] linenum the config file line number at which the paramater was found to enhance error messages.
 * @param[in] meta a cuwa_config containing the metaconfiguration or NULL. If this paramater is non-null then line will be looked up in the meta configuration and warnings will be issued if line is not recognized.
 * @note the paramater value will be stripped of one level of either " or ' quoting IFF the entire paramater is quoted
 * @note comment lines starting with # will be ignored
 * @note whitespace will be trimmed from the name and value
 * */

void cuwa_config_setattr(cuwa_config * cfg, char* line, char* d1, char* d2, int linenum, cuwa_config *meta){
	char* name;
	char* value;
	char* delim;
	char *vdata; //value data
	cuwa_list **l;
	l=&(cfg->attribs);

	if(!line || !*line){
		cuwa_info("Line %d is empty after preprocessing and is being ignored", linenum);
		return;
	}
	cuwa_assert(l);
	cuwa_assert(line);	
	name = line;
	
	//find a name/value delimiter
	delim = strpbrk(line,d1);
	if(!delim){
		cuwa_warning("Ignoring malformed configuration line: %s",line);
		return;
	}
	*delim='\0';
	value=delim+1;
	
	//extra whitespace should have been cleaned up already
	cuwa_assert(' '  != name[strlen(name)-1]);
	cuwa_assert('\t'  != name[strlen(name)-1]);
	//vdata=_strdup(name); //this memory will be owned by the list  // fixme this was a pointless memory leak. Was something else intended?

	//strip leading/trailing whitespace from value
	cuwa_assert(value);
	cuwa_assert(value[0] != ' ' && value[0] != '\t'); //should have already stripped these
	cuwa_assert(!(' ' == value[strlen(value)-1] || '\t'==value[strlen(value)-1]));

	//check for and remove exactly one layer of ' or " quoting
	if('"' == value[0] || '\'' == value[0]){
		if(value[0]==value[strlen(value)-1] ){ //matching quote at the end
			value[strlen(value)-1]='\0';
			value++;
		}
		else{
			cuwa_warning("Paramater %s starts with an unmatched %c. Parsing as %s.",name,value[0],value);
		}
	}
	vdata=_strdup(value);

	//check for bad characters in the name
	{
		unsigned int i;
		for(i=0; i<strlen(name); i++){
			cuwa_assert(( '.'==name[i] || '-'==name[i] || '_'==name[i]) || (name[i]>='A' && name[i]<='Z') || (name[i]>='a' && name[i]<='z') || (name[i]>='0' && name[i]<='9') || ('$'==name[i]) || ('\\'==name[i]) || ('/'==name[i]));
		}
	}

	if(meta){ //metaconf defined, validate paramater
		char *mn, *tmp;
		cuwa_attrib *ma;
		int found=0;
		
		//Is this paramater defined as a string in the metaconf?
		mn=cuwa_sprintf("%s.$string",name);
		ma=cuwa_config_read(meta,mn);
		if(ma){
			if (strlen(vdata) > (unsigned int)atoi(ma->value)){
				cuwa_warning("Validation error parsing conf file at line %d. Paramater %s is limited to %d characters but was set to %s.",linenum,name,atoi(ma->value),vdata);
				free(mn);
				free(vdata);
				return;
			}
			cuwa_trace("Validated string %s=%s",name,vdata);
			found++;
		}
		free(mn);

		//Is this paramater defined as an int in the metaconf?
		mn=cuwa_sprintf("%s.$int.min",name);
		ma=cuwa_config_read(meta,mn);
		if(ma){
			long low, high, val;
			low=atol(ma->value);
			free(mn);
			mn=cuwa_sprintf("%s.$int.max",name);
			ma=cuwa_config_read(meta,mn);
			cuwa_assert(ma);
			high=atol(ma->value);
			val=atol(vdata);
			free(mn);
			mn=cuwa_sprintf("%d",val);
			if(strcmp(mn,vdata)){
				cuwa_warning("Validation error parsing conf file at line %d. Paramater %s is required to be an integer between %d and %d but is %s and was interpreted as %d.",linenum,name,low,high,vdata,val);
				free(vdata);
				return;
			}
			cuwa_trace("Validated integer %s=%s",name,vdata);
			found++;
		}
		free(mn);

		//Is this paramater defined as an enum in the metaconf?
		mn=cuwa_sprintf("%s.$enum.%s",name,vdata);
		ma=cuwa_config_read(meta,mn);
		if(ma){
			if(_stricmp("deprecated",ma->value)){
				cuwa_warning("Warning, paramater %s set to a deprecated value (%s)",name,vdata);
			}
			cuwa_trace("Validated integer %s=%s",name,vdata);
			found++;
		}
		free(mn);

		//Is this paramater defined as a block in the metaconf?
		tmp=_strdup(name);
		{
		char *t2;
		t2=strchr(tmp,'.');
		if(t2){
			*t2='\0';
			mn=cuwa_sprintf("%s.$block",tmp);
			ma=cuwa_config_read(meta,mn);
			if(ma){
				cuwa_trace("Validated block %s=%s",name,vdata);
				found++;
			}
			free(mn);	
		}
		}
		free(tmp);
		if(!found){
			cuwa_warning("Warning, paramater %s not recognized",name);
		}
		cuwa_assert(found<=1);
		//fixme add support for obsolite detection etc
	}


	//vdata has the final value
	//now parse the name out and create any hierarchy needed in the list
	{
		char *n2;
		cuwa_attrib *a;
		cuwa_list **ll=l;
		while((n2=strstr(name,d2))){
			cuwa_node *node;
			*n2='\0';
			n2++;
			cuwa_trace("looking for %s (%s)", name,n2);
			//have name delim n2
			//attempt to find the name node in the conf
			node=cuwa_list_find(*ll,name,cuwa_attribcmp);
			if(node){
				//found the node
				cuwa_trace("found node %s",name);
				name=n2;
				ll=&(((cuwa_attrib*)(node->data))->kids);
				a=node->data;
				if(a->value){
					//adding a child of a node with data
					//invalidate all cache entries pointing to the existing node
					int i;
					for(i=0;i<CUWA2_CONFIG_CACHE && cfg->cache_names[i]; i++){
						if(cfg->cache_attribs[i] == a){
							cuwa_warning("Invalidating cache[%d] %s=%s due to addition of %s",i,cfg->cache_names[i],cfg->cache_attribs[i]->value,n2);
							cfg->cache_attribs[i]=NULL;
						}
					}
				}
				continue;
			}
			else{
				cuwa_trace("adding node %s",name);
				a=malloc(sizeof(cuwa_attrib));
				cuwa_assert(a);
				memset(a,0,sizeof(cuwa_attrib));
				a->kids=NULL;
				a->name=_strdup(name);
				a->value=NULL;
				cuwa_list_append(ll,a);
				ll=&(a->kids);
				name=n2;
			}
		}


		{
			cuwa_node *node;
			//ok now add name/value to ll and we are done
		node =cuwa_list_find(*ll,name,cuwa_attribcmp);
		if(!node || !(node->data)){
			cuwa_trace("adding node %s",name);
			a=malloc(sizeof(cuwa_attrib));
			cuwa_assert(a);
			memset(a,0,sizeof(cuwa_attrib));
			a->kids=NULL;
			a->name=_strdup(name);
			a->value=vdata;
			cuwa_list_append(ll,a);	
		}
		else{
			a=node->data;
			cuwa_warning("replacing node %s",name);
			if(a->value) free(a->value);
			a->value=vdata;
		}
		}
	}
}


/**
 * If the line is the start of a block then returns a processed version that can be handed to cuwa_config_setattr. This pointer points into the line buffer.
 * If the line is the end of a block then returns the string "/BlockType" This pointer points into the line buffer.
 * Otherwise NULL is returned and the line buffer is not modified
 * @param[in/out] line the line to be preprocessed. Can be modified
 * @param[in] linenum the current line number, used to improve warnings
 * @return a pointer into line if this is a block otherwise null
 */

char * cuwa_config_preprocess_block(char* line, int linenum){
	cuwa_assert(line);
	if(strlen(line) < 3) return NULL;
	if('<' == line[0]){
		char *term=line;
		cuwa_trace("Treating line as a block: %s", line);
		while(*term){
			*term=*(term+1); //shift the whole line over by one to make room at the end;
			term++;
		}
		term=strchr(line,'>');
		if(!term){
			cuwa_crit("Configuration line starts with </ but is missing >: %s",line);
			return NULL;
		}
		else if(*(term+1)){
			cuwa_warning("Ignoring unexpected text after >:%s",term+1);
		}
		if('/'==line[0]){
			*term='\0';
			return(cuwa_conf_line_cleanup(line)); //for a good measure strip any trailing garbage
		}
		else if ((line[0] >= 'A' && line[0] <='Z')||(line[0] >='a' && line[0] <='z')){
			char *delim;
			delim=strpbrk(line," \t");
			if(!delim){
				cuwa_crit("Configuration line is a block but is missing data (<foo> instead of <foo bar>): %s",line);
				return NULL;
			}
			term[0]=' '; //line was left shifted one and term points to a > therefore the line contains at least three characters including null term;
			term[1]='b';
			term[2]='\0';
			*delim='.';
			delim++;
			if('"' == delim[0] || '\'' == delim[0]){
				if(delim[0]==delim[strlen(delim)-1] ){ //matching quote at the end
					delim[strlen(delim)-1]='\0';
					delim++;
				}
				else{
					cuwa_crit("Block %s has an unmatched %c",line,delim[0]);
					return NULL;
				}
			}
			return line;
		}
		else{
			cuwa_crit("Configuration line malformed < should be followed by a directive type: %s",line);
			*line='\0';
			return NULL;
		}
	}
	return NULL;

}



/**
 * Imports a configuration context into the basecfg.
 *
 * @param[in,out] basecfg the configuration into which to import the config (may be null)
 * @param[in] filename the filename containing a configuration file
 * @return the new config
 */
cuwa_config* cuwa_config_import(cuwa_config* basecfg, char * filename, cuwa_config* meta){
	FILE *cfile;
	int linenum=0;
	cuwa_list* stack=NULL;
	char line[CUWA2_CONF_LINE_LEN+1];
	cuwa_trace("importing configuration from %s into %ux",DENULL(filename),basecfg);
	
	if(!basecfg){
		cuwa_trace("basecfg null, building root config", NULL);
		basecfg=malloc(sizeof(cuwa_config));
		cuwa_assert(basecfg);
		memset(basecfg,0,sizeof(cuwa_config));
	}
	if(!filename) return basecfg;
		


#pragma warning(push)
#pragma warning(disable:4996)
	cfile=fopen(filename,"r");
#pragma warning(pop)
	cuwa_assert(cfile);



	
	//read each line in
	while(fgets(line,CUWA2_CONF_LINE_LEN,cfile)){
		char * cleanline=line;
		char * procline;
		linenum++;
		while(strlen(cleanline) && ('\n'==cleanline[strlen(cleanline)-1] || '\r'==cleanline[strlen(cleanline)-1])) cleanline[strlen(cleanline)-1]='\0';
		cuwa_info("processing configuration line %d: %s",linenum,cleanline);
		cleanline=cuwa_conf_line_cleanup(cleanline);
		cuwa_trace("line %d after cleanup: %s",linenum,cleanline);
		procline=cuwa_config_preprocess_block(cleanline,linenum);
		if(!procline){
			cuwa_trace("line %d isn't a block start or end",linenum);
			cuwa_config_setattr(basecfg,cleanline,"= \t",".",linenum,meta);
		}
		else if('/'==procline[0]){ //end of block
			cuwa_trace("line %d looks like a block end and was processed into: %s",linenum,procline);
			if(!stack || !stack->tail) cuwa_crit("Block closed when no block was open",linenum);
			else if(_strnicmp(procline+1,stack->tail->data,strlen(procline+1))){ //wrong block
				cuwa_crit("Line %i: Close of block type %s in block type %s",linenum,procline,stack->tail->data);
			}
			else{
				basecfg=basecfg->parent;
				free(cuwa_list_del(stack,stack->tail));
			}
		}
		else{ //start of block
			cuwa_attrib * nattrib;
			cuwa_config *nrec;
			char * attribname;
			char *t3;

			cuwa_trace("line %d looks like a block start and was processed into: %s",linenum,procline);
			//create a new config record
			nrec=malloc(sizeof(cuwa_config));
			cuwa_assert(nrec);
			memset(nrec,0,sizeof(cuwa_config));
			nrec->parent=basecfg;
			
			attribname=_strdup(procline);
			t3=strchr(attribname,' ');
			cuwa_assert(t3); //fixme should use better validation
			*t3='\0';

			//update the local context stack
			cuwa_list_append(&stack,_strdup(procline));
			t3=strchr(stack->tail->data,'.');
			cuwa_assert(t3);
			*t3='\0';

			nrec->type=_strdup(stack->tail->data);

			//insert an attribute into the base context to point to the new record
			cuwa_config_setattr(basecfg,procline,"= \t",".",linenum,meta);
			
			//point the new attribute at the newly created context block
			line[strlen(line)-1]='\0'; //line is now the attribute name
			nattrib=cuwa_config_read(basecfg,attribname);
			cuwa_assert(nattrib);
			nattrib->block = nrec;
			free(attribname);
			basecfg=nrec;
			
		}
	}
	fclose(cfile); cfile=NULL;
	cuwa_assert(basecfg);
	return(basecfg);
}

#undef CUWA2_LOG_DOMAIN
#define CUWA2_LOG_DOMAIN cuwa.config

/**
* Deallocates all storage used by the input config.
*
* @param[in,out] c Configuration context handle.
* @bug unimplimented
*/
void cuwa_config_destroy(cuwa_config *c){
	//cuwa_fixme(NULL,NULL);
}



/**
 * Read a configuration value.
 *
 * @param[in] cfg Configuration context handle.
 * @param[in] attrib The attribute to read.
 *
 * @returns A pointer to the configuration attribute node
 * that most closely matches. Callers outside of this file
 * shall treat this as
 * read-only.
 *
 * For the following sample config:
 * Log=15
 * Log.CUWA.CredMgr=10
 * Log.CUWA.CredMgr.Krb=5
 * the following will be read:
 * CUWA.CredMgr.Krb(5), CUWA.CredMgr.LDAP(10),CUWA.Test(10).
 *
 * @remarks Approximate matches generate log entries at the info level.
 *
 * @see cuwa_attrib
 */
cuwa_attrib* cuwa_config_read2(cuwa_config* cfg, const char *attrib, int nullok){
	char *lan; //local attribute name copy
	size_t lanlen;	
	cuwa_list *l;
	char *n1,*n2, *pbest,*p;
	cuwa_attrib *best; //most specific attribute with a non-null value
	cuwa_node *node;
	cuwa_attrib *a;
	int cacheindx=-1;
	//int cacheidx;
	if(!cfg) return NULL; //FIXME should not be silent but not sure how to avoid infinite loop

	for(cacheindx=0; cacheindx<CUWA2_CONFIG_CACHE && cfg->cache_names[cacheindx]; cacheindx++){
		if(cfg->cache_names[cacheindx]==attrib){
			break;
		}
	}
	if(cacheindx >= CUWA2_CONFIG_CACHE || cfg->cache_names[cacheindx]!=attrib) cacheindx=-1;


	l=cfg->attribs;
	lan=_strdup(attrib);
	lanlen=strlen(lan); //keep track of the length so the \0's can be restored to .'s
	best=NULL;
	//if a and a.b.c have been set then a.b will have no value therefore a is the most specific.
	n1=lan;
	pbest=lan;
	cuwa_trace("Searching for %s",attrib);

	do{
		//truncate n1 to the first delimiter, n2 is the remainder
		n2=strstr(n1,".");
		if(n2){
			*n2='\0';
			n2++;
		}
		//find the attribute for n1
		node=cuwa_list_find(l,n1,cuwa_attribcmp);
		if(node){
			a=node->data;
			cuwa_trace("found %s",a->name);
			if(nullok || a->value){ //if this node has a value set update the best pointers
				best=a;
				if(n2) pbest=n2-1; //pbest is the end of the string for the matched paramater
				else{ //n2=NULL therefore
					//this is fully specific paramater (no remainder). We are done.
					free(lan);
					if(-1!=cacheindx){
						if(cfg->cache_attribs[cacheindx]!=best){
							cfg->cache_attribs[cacheindx]=best;
							cuwa_warning("Replaced cache entry for %s",attrib);
						}
					}
					return best;
				}
			}
			if(!a->kids) break; //childless node, exact match impossible
			l=a->kids; //look at the children of the matching node
			continue;
		}
		else{ //couldn't find the node, search over return the best match
			break;
		}
	}while(n2 && (n1=n2)); //yes assign is intended

	//can't resolve name exactly

	//patch the string back together (remove null's added during parsing), print an info, and return
	for(p=lan; p<pbest && p<(lan+lanlen); p++){
		if(!*p) *p='.';
	}
	if(best){
		if(!nullok) cuwa_assert(best->value);
		cuwa_info("attribute %s mapped to %s=%s",attrib,lan,DENULL(best->value));
		free(lan);
		if(-1!=cacheindx){
				if(cfg->cache_attribs[cacheindx]!=best){
					cfg->cache_attribs[cacheindx]=best;
					cuwa_warning("Replaced cache entry for %s",attrib);
				}
		}

		return(best);
	}
	else if(cfg->parent){
		cuwa_trace("Performing parent lookup on %s",attrib);
		free(lan);
		best=cuwa_config_read(cfg->parent,attrib);
		if(-1!=cacheindx){
				if(cfg->cache_attribs[cacheindx]!=best){
					cfg->cache_attribs[cacheindx]=best;
					cuwa_warning("Replaced cache entry for %s",attrib);
				}
		}
		return(cuwa_config_read(cfg->parent,attrib));
	}
	free(lan);
	cuwa_info("attribute %s not found",attrib);
	return(NULL);
}

cuwa_attrib* cuwa_config_read(cuwa_config* cfg, const char *attrib){
     return (cuwa_config_read2(cfg,attrib,0));
}

/**
 * Read the string value from an attribute
 * @param[in] a the attribute
 * @return a pointer to the string in the attribute. Do not free.
 */
char * cuwa_config_str(cuwa_attrib *a){
	cuwa_assert(a);
	return(a->value);
}

/**
 * Read the int value from an attribute
 * @param[in] a the attribute
 * @return an int
 */
int cuwa_config_int(cuwa_attrib *a){
	cuwa_assert(a);
	//fixme do sanity checking
	return(atoi(a->value));
}

/**
 * Retreive the active configuration.
 * This is currently implimented as a per-thread global
 */
cuwa_config * cuwa_config_get_active(){
	return cuwa_pal_get_thread_conf();
}

/**
 * Release a cuwa_config handle.
 * Not currently implimented and, come to think of it, probably pointless
 */
cuwa_config * cuwa_config_release(cuwa_config* c){
	return 0;
}

/**
 * Set the active configuration
 * This is currently implimented as a per-thread global
 * In general the WAL is responsible for setting an active
 * configuration before calling into other modules
 *@param[in] c the new active configuration
 */
void cuwa_config_set_active(cuwa_config *c){
	cuwa_pal_set_thread_conf(c);
}


/**
 * Fast cache-based read -- SEE CAVEATS. The attribute name POINTER is compared against the cache (and possibly saved in the cache).
 * reuse of this memory for a different attribute name WILL CAUSE incorrect operation.
 * The attribute name MUST be a string literal for proper operation. Telling the compiler to pool string literals will improve performance.
 * Lookup will be done by searching the cache for a mapping between the attrib_literal pointer and a pointer to an attribute.
 * If such a mapping is not found and allowslow is nonzero a normal cuwa_read_attrib will be invoked and the result cached.
 @param[in,out] cfg the config to use. Changes are made only to the cache.
 @param[in] attrib_literal the paramater to use **WARNING** this MUST be a string literal (or must never be changed)
 @param[in] allowslow allow a non-cached lookup. If the literal is not cached and this is nonzero NULL will be returned. If this paramater is nonzero there will be no logging output (thus the log write function can call this safely)
 @note For correctness, the char * passed in MUST be a string LITERAL. This does a pointer comparison instead of a string comparison.
 */

cuwa_attrib* cuwa_config_read_literal(cuwa_config* cfg, const char *attrib_literal, int allowslow){
	int i; cuwa_attrib *a;
	for(i=0; i<CUWA2_CONFIG_CACHE && cfg->cache_names[i]; i++){
		if(cfg->cache_names[i]==attrib_literal){
			if(cfg->cache_attribs[i]) return cfg->cache_attribs[i];	
			break;
		}
	}
	if(!allowslow) return NULL;
	a=cuwa_config_read(cfg,attrib_literal);
	if(a && i<CUWA2_CONFIG_CACHE){
		cfg->cache_names[i]=(char*)attrib_literal;
		cfg->cache_attribs[i]=a;
		cuwa_info("Cache miss, store[%d] %s %s\n",i, attrib_literal,a->value);
	}
	return a;
}


/**
 * Utility routine for cuwa_config_walk. Applies f to each of the cuwa_attrib*'s in the given list and the children (if any) of each of those.
 * @param[in] l the list of cuwa_attrib*'s to walk
 * @param[in,out] name the list of cuwa_attrib*'s to walk. Modified as an intermediate step and then restored.
 * @param[in] name_size the size of the buffer pointed to by name.
 * @param[in] accum, a pointer passed along to each invocation of f. This can be used by f to accumulate information about the traversal
 * @param[in] f, the function to be invoked on each list attribute. The first paramater is the full (. seperated) name of the parent node of the cuwa_attrib. The second paramater is a cuwa_attrib. The third paramater is accum, above for f's internal use.
 */

static void walklist(cuwa_list *l, char *name, int name_size, void * accum, void (*f)(char*,cuwa_attrib*,void*)){
		char* name_end;
		int name_len;
        cuwa_node *n;
        cuwa_attrib *a;
		cuwa_assert(l);
		cuwa_assert(name);
		cuwa_assert(f);
        	n=l->head;
		name_len=strlen(name);
		name_end=name + name_len; //save name_end so we can restore name;
        while(n){
                a=n->data;
                if(a->block){
						(*f)(name,a,accum);	 //invoke f for the block's node
						cuwa_assert(name_len + strlen(a->name) + 3 < name_size);
						snprintf(name_end,name_size-name_len,".<%s>", a->name);
                        cuwa_config_walk(a->block,name,name_size,accum,f); //walk that config
                }
				else{
					(*f)(name,a,accum);
					cuwa_assert(name_len + strlen(a->name) + 1 < name_size);
					snprintf(name_end,name_size-name_len,(name_len?".%s":"%s"), a->name);
				}
                if(a->kids) walklist(a->kids,name,name_size,accum,f);
                n=n->next;
				*name_end='\0'; // truncate off anything added to process this node before moving to the next
        }
}

/**
 * walks a cuwa config structure, invokes f for each node in the structure passing along a full name of the node's parent. Warning, node names in excess of 2000 will trigger an assert
 * @param[in] l the list of cuwa_attrib*'s to walk
 * @param[in,out] name the list of cuwa_attrib*'s to walk. Modified as an intermediate step and then restored. Pass NULL.
 * @param[in] name_size the size of the buffer pointed to by name. Initial caller should pass zero.
 * @param[in] accum, a pointer passed along to each invocation of f. This can be used by f to accumulate information about the traversal
 * @param[in] f, the function to be invoked on each list attribute. The first paramater is the name of the parent node of the cuwa_attrib. The second paramater is a cuwa_attrib. The third paramater is accum, above for f's internal use.
 */
void cuwa_config_walk(cuwa_config *c,char * name, int name_size, void * accum, void (*f)(char*,cuwa_attrib*,void*)){
		int our_memory=0;
		if(!name){
			name_size=2048;
			name=malloc(name_size);
			our_memory=-1;
			cuwa_assert(name);
			*name='\0'; // name=""
		}
        walklist(c->attribs,name,name_size,accum,f);
		if(our_memory) free(name);
}
const char id_config_config_c[] = "$Id: config.c,v 1.30 2008/05/06 03:13:23 gbr4 Exp $";
