#ifdef NEVER_DEFINED

/*
 * meta conf:
 * directive <type expr>
 * <type expr> is one of:
 * string <length>
 * enum v1 v2 v3
 * int <min max>
 *
 * what happens for:
 * d1.enum string
 *
 */





/*
 * d1.string len
 * d1.enum.v1
 * d1.enum.v2
 * d1.enum.v3
 * d1.int.min
 * d1.int.max
 * meta conf tree:
 *


typedef struct cuwa_metaconf_t{
	int a;
}*/
#endifconst char id_config_metaconf_c[] = "$Id: metaconf.c,v 1.4 2008/01/25 01:43:47 gbr4 Exp $";
