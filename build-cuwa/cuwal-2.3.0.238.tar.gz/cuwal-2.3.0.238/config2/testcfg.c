#include <stdlib.h>
#include <stdio.h>
#include "cfg.h"


int main()
{
    printf("cfg.h compiled!\n");
    return 0;
}
const char id_config2_testcfg_c[] = "$Id: testcfg.c,v 1.4 2008/04/10 19:51:36 gbr4 Exp $";
