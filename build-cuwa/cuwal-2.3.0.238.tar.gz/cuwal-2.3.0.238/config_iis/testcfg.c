#include <stdlib.h>
#include <stdio.h>
#include "cfg.h"


int main()
{
    printf("cfg.h compiled!\n");
    return 0;
}
const char id_config2_testcfg_c[] = "$Id: testcfg.c,v 1.1 2008/09/16 18:47:22 hy93 Exp $";
