/************************************************************************
 * cred.c -- credential manager for CUWebAuth
 *
 * Copyright 2007 Cornell University.
 * All Rights Reserved.
 *
 ************************************************************************
 *  $Log: cred.c,v $
 *  Revision 1.27  2015/10/07 17:36:23  hy93
 *  merge TwoFactor treee to the head
 *
 *  Revision 1.26.2.3  2015/03/13 18:16:48  hy93
 *  add 2FA credential token support
 *
 *  Revision 1.26.2.2  2015/01/29 18:31:40  hy93
 *  modify 2F cred handling(not complete)
 *
 *  Revision 1.26.2.1  2014/10/22 19:31:01  hy93
 *  add two factor support
 *
 *  Revision 1.26  2014/10/22 16:05:59  hy93
 *  Remove two factor support
 *
 *  Revision 1.25  2014/07/25 17:34:31  hy93
 *  d1 signature
 *
 *  Revision 1.24  2013/11/12 19:06:32  hy93
 *  remove dual start time in d1 credential
 *
 *  Revision 1.23  2013/08/06 18:29:19  hy93
 *  add the vendor that user authenticated with in credential
 *
 *  Revision 1.22  2013/07/30 19:13:43  hy93
 *  Two factor authentication support
 *
 *  Revision 1.21  2008/08/19 19:57:23  hy93
 *  replace FAIL_IF_SESSION
 *
 *  Revision 1.20  2008/08/17 14:18:03  pb10
 *  Remove unused code from session manager and cred manager.
 *
 *  Revision 1.19  2008/08/15 04:49:26  pb10
 *  Added table based attribute support to session code.
 *  Still need to put support into auth.c and lastly need to remove old code from everywhere.
 *
 *  Revision 1.18  2008/08/12 20:34:40  pb10
 *  Convert cred manager interface to use apr_table to transfer credential attributes.
 *  Also supporting the old interface to keep things working while I update  session
 *  manager and auth code.
 *
 *  Revision 1.17  2008/08/10 01:52:29  pb10
 *  Add function cuwa_cred_make_proxy and support functions in cred_base64.
 *
 *  Revision 1.16  2008/07/16 14:12:58  hy93
 *  add function to get k3
 *
 *  Revision 1.15  2008/07/14 14:47:44  pb10
 *  Modified cred mgr to allow access to f1 and k3 from k2 authenticator.
 *  Modified make_k2 to allow caller to insert arbitrary keyword/value pairs
 *  into authenticator.
 *
 *  Revision 1.14  2008/04/19 14:21:27  pb10
 *  Convert malloc's to APR allocations.
 *
 *  Revision 1.13  2008/03/24 21:32:22  pb10
 *  Better error page support.
 *
 *  Revision 1.12  2008/02/27 19:11:48  hy93
 *  fix compiler warning
 *
 *  Revision 1.11  2008/02/12 17:09:55  hy93
 *  remove \n when call cuwa_trace
 *
 *  Revision 1.10  2008/01/25 01:43:47  gbr4
 *  Added an ID string to every file
 *
 *  Revision 1.9  2008/01/13 21:20:31  pb10
 *  Lowercase CUWA2_LOG_DOMAIN setting.
 *
 *  Revision 1.8  2008/01/11 03:53:39  pb10
 *  Integration with logging.
 *
 *  Revision 1.7  2008/01/02 04:40:19  pb10
 *  Added host URL to K2 token.
 *  Minor bugs fix.
 *  Makefile mods to adapt to webauth.
 *
 *  Revision 1.6  2007/12/28 16:18:14  pb10
 *  linefeed removal
 *
 *  Revision 1.5  2007/12/21 19:52:25  hy93
 *  Modified function get_netid, get_realm, get_fullid
 *
 *  Revision 1.4  2007/12/20 02:48:24  pb10
 *  Integration with session manager.
 *
 *  Revision 1.3  2007/11/07 03:47:53  pb10
 *  Minor fixes to get creds working.
 *
 *  Revision 1.2  2007/10/23 21:28:57  pb10
 *  Add support for cred manager.
 *
 *  Revision 1.1  2007/10/22 16:48:14  pb10
 *  Initial commit, to publish API.
 *
 *
 ************************************************************************
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <cred.h>
#include <cuwa_err.h>
#include <cuwa_types.h>
#include <cred_getput.h>
#include <cred_krb.h>
#include <cred_base64.h>
#include <log.h>
#include <cuwa_malloc.h>
#include <cred_session.h>
#include <apr_strings.h>
#include <session_file.h>


#define CUWA2_LOG_DOMAIN cuwa.cred

//#define CUWA_CRED_MAX_STACK 1    /* max depth of credentials embedding */

int cuwa_cred_init(apr_pool_t *pool, cuwa_cred_t **credout)
{
    cuwa_cred_t *cred;

    cred = (cuwa_cred_t *) cuwa_calloc(1,sizeof(cuwa_cred_t));
    if (!cred) return CUWA_ERR_MEM;

    cred->pool = pool;
    cred->attributes = apr_table_make(pool, 25);
    cred->contexts = apr_array_make(pool, 25, sizeof(cuwa_cred_context_t));
    *credout = cred;
    return 0;
}

/**
 * cuwa_cred_parse parses sequence of bytes as a credential.
 * Who calls cuwa_cred_parse...
 * - webauth core
 * - weblogin module
 * - mid-tier, likely using java version of cuwa_cred_parse
 *
 * @param[out] cred credential object returned from parse operation.  Caller must call cuwa_cred_release to free.
 * @param[in] credBytes the bytes to be parsed
 * @param[in] credByteLen the length of the credential in bytes
 * @param[in] serviceName the application name as identified by the authentication service (Kerberos ServiceID)
 * @param[in] keytabName path to the keytab file
 * @param[in] host the URL of this virtual host (used in K2)
 * @param[in] reserved must be NULL.  Future versions of this function may add parameters, but existing code will
 *            still work as long as this parameter is NULL.
 */
int cuwa_cred_parse( apr_pool_t *pool, cuwa_cred_t **credout, char *credBytes, int credByteLen, char *serviceName, char *keytabName, char *host, void *reserved )
{
    int code;
    cuwa_err_t rc = CUWA_OK;
    cuwa_base64_t *base64 = NULL;
    cuwa_cred_t *cred = NULL;
    char *kcred;
    int klen = 0;
    int numCreds = -1; /* NumCreds is set after reading the number of creds in a WA credential */
    char tokenType;

    cuwa_assert(credout);
    cuwa_assert(credBytes);
    cuwa_assert(reserved==NULL);

    FAIL_IF(credByteLen<6,CUWA_ERR_CRED_INVALID);
    code = cuwa_cred_init(pool, &cred);
    FAIL_IF(code,code);

    while(credByteLen && numCreds!=0)
    {
        cuwa_trace("cred_parse, bytesLeft=%d, numCreds=%d",credByteLen,numCreds);
        FAIL_IF(credByteLen<4,CUWA_ERR_CRED_INVALID);
        switch (*credBytes)
        {
            case 'K':
                credBytes++; credByteLen--;
                tokenType = *credBytes;
                credBytes++; credByteLen--;
                PEEK_BUFFER(kcred, klen, credBytes,credByteLen);

                switch (tokenType)
                {
                    case '1':
                        code = cuwa_krb_parse_k1(cred, kcred, klen );
                        FAIL_IF(code,code);
                        break;
                    case '2':
                        cuwa_assert(serviceName);
                        cuwa_assert(keytabName);
                        code = cuwa_krb_parse_service_token("K2",cred, kcred, klen, serviceName, keytabName, host );
                        FAIL_IF(code,code);
                        break;
                    default:
                        /* Ignore unknown type */
                        break;
                }

                numCreds--;
                break;
            case 'C':
                credBytes++; credByteLen--;
                tokenType = *credBytes;
                credBytes++; credByteLen--;
                PEEK_BUFFER(kcred, klen, credBytes,credByteLen);

                switch (tokenType)
                {
                    case '0':
                        code = cuwa_cred_session_parse(cred, kcred, klen );
                        FAIL_IF(code,code);
                        break;
                    default:
                        /* Ignore unknown type */
                        break;
                }

                numCreds--;
                break;


            case 'W':
                credBytes++; credByteLen--;

                /* Can't make assumptions about the length of a W type credential, so if unknown type, we fail. */
                FAIL_IF(*credBytes!='A',CUWA_ERR_CRED_NOT_SUPPORTED);

                credBytes++; credByteLen--;

                code = cuwa_base64_parse( cred, credBytes, credByteLen );
                FAIL_IF(code,code);

                base64 = (cuwa_base64_t *) cuwa_cred_last(cred);
                FAIL_IF(!base64,CUWA_ERR_CRED_INVALID);

                /* Get the de-base64'd bytes... */
                credBytes   = base64->data;
                credByteLen = base64->length;

                /* How many creds are there? */
                GET_16(numCreds,credBytes,credByteLen);

                cuwa_trace("WA cred count: %d",numCreds);

                break;

            case '2':
                credBytes++; credByteLen--;
                FAIL_IF(*credBytes!='F',CUWA_ERR_CRED_NOT_SUPPORTED);
                credBytes++; credByteLen--;
                PEEK_BUFFER(kcred, klen, credBytes,credByteLen);

                cuwa_assert(serviceName);
                cuwa_assert(keytabName);
                code = cuwa_krb_parse_service_token("2F",cred, kcred, klen, serviceName, keytabName, host );
                FAIL_IF(code,code);

                numCreds--;
                break;

            default:
                /* Ignore unknown credential type */
                credBytes+=2; credByteLen-=2;
                PEEK_BUFFER(kcred, klen, credBytes,credByteLen);
                break;
        }
    }


    cuwa_trace("cred_parse complete: credByteLen=%d, numCreds=%d",credByteLen, numCreds);

    FAIL_IF((credByteLen || numCreds>0),CUWA_ERR_CRED_INVALID);

    *credout = cred;

cleanup:

    if (rc)
    {
        if (cred)
        {
            cuwa_cred_release(cred);
        }
    }

    return rc;
}

/**
 * cuwa_cred_get_context...
 * Count a contexts of a give type. Not sure if we'll need this function.
 * @param[in] cred credential object retrieved from parse operation.
 * @param[in] ctxType the context type
 */
void * cuwa_cred_get_context( cuwa_cred_t *cred, cuwa_cred_ctx_t ctxType, int index )
{
    cuwa_cred_context_t *contexts;
    int cnt,i,current=0;

    cuwa_assert(cred);
    cuwa_assert(cred->contexts);

    contexts = (cuwa_cred_context_t *)cred->contexts->elts;
    cnt      = cred->contexts->nelts;
    for (i=0;i<cnt;i++,contexts++)
    {
        if (contexts->type == ctxType)
        {
            if (current==index) return contexts->ctx;
            current++;
        }
    }
    return NULL;
}

/**
 * cuwa_cred_set_attribute...
 * Set a credential attribute.
 * @param[in] cred credential object retrieved from parse operation.
 * @param[in] ctxType the context type
 */
void cuwa_cred_set_attribute( cuwa_cred_t *cred, const char *key, const char *val)
{
    const char *newKey;

    cuwa_assert(cred);
    cuwa_assert(key);
    cuwa_assert(val);

    if (!cred->attrSetCnt)
    {
        newKey = key;
    }
    else
    {
        newKey = apr_psprintf(cred->pool,"%s_%d",key,cred->attrSetCnt);
    }
    apr_table_set(cred->attributes,newKey,val);
}


/**
 * cuwa_cred_get_attribute...
 * Get a credential attribute.
 * @param[in] cred credential object retrieved from parse operation.
 * @param[in] instance which credential instance
 */
char *cuwa_cred_get_attribute( cuwa_cred_t *cred, const char *key, int instance)
{
    const char *newKey;

    cuwa_assert(cred);
    cuwa_assert(key);

    if (!instance)
    {
        newKey = key;
    }
    else
    {
        newKey = apr_psprintf(cred->pool,"%s_%d",key,instance);
    }

    return (char*) apr_table_get( cred->attributes,newKey);
}

/**
 * cuwa_cred_set_context...
 * Adds a session context of the specified context type.
 * @param[in] cred credential object retrieved from parse operation.
 * @param[in] ctxType the context type
 * @param[in] ctx the context
 */
void cuwa_cred_set_context( cuwa_cred_t *cred, cuwa_cred_ctx_t ctxType, void *ctx )
{
    cuwa_cred_context_t *context;

    cuwa_assert(ctxType>=0 && ctxType<CUWA_CRED_CTX_MAX);

    context = (cuwa_cred_context_t *) apr_array_push( cred->contexts );
    cuwa_assert(context);

    context->ctx   = ctx;
    context->type  = ctxType;
    cred->lastCred = context;
}

/**
 * cuwa_cred_release...
 * Release all of the resources associated with the cred.
 * @param[in] cred credential object retrieved from parse operation.
 */
void cuwa_cred_release( cuwa_cred_t *cred )
{
    cuwa_cred_context_t *context;

    cuwa_assert(cred);

    context = apr_array_pop(cred->contexts);
    while (context)
    {
        switch (context->type)
        {
            case CUWA_CRED_CTX_GSS:
            case CUWA_CRED_CTX_KERBEROS:
                cuwa_krb_release(cred,context);
                break;
            case CUWA_CRED_CTX_BASE64:
                cuwa_base64_release(cred,context);
                break;
            default:
                cuwa_trace("cred_release Unexpected type: %d",context->type);
                break;
        }
        context = apr_array_pop(cred->contexts);
    }

    cuwa_free(cred);
}

int cuwa_cred_make_proxy( char *serviceid, char *keytab, char *remoteHost, char *remoteService, uint64 *sessionID,
                         char *inCred, int inCredLen, char **outCred, int *outCredLen)
{
    cuwa_err_t code;
    cuwa_err_t rc = CUWA_OK;
    char *preCreds;
    int preLen, preCnt, k2Len;
    kutil_session_t ksess = NULL;
    char *k2;

    code = cuwa_base64_extract_wa( inCred, inCredLen, &preCreds, &preLen, &preCnt );
    FAIL_IF(code,code);

    code = kutil_login_key(&ksess, serviceid, keytab);
    FAIL_IF(code,code);

    code = cuwa_krb_make_k2( NULL, remoteHost, remoteService, sessionID, 0, &k2, &k2Len, NULL );
    FAIL_IF(code,code);

    code = cuwa_base64_rebuild_wa(outCred, outCredLen, preCreds, preLen, preCnt, k2Len, 1, k2, k2Len, NULL);

cleanup:

    if (ksess) kutil_end_session(ksess);

    return rc;
}

#ifdef CUWA_SERIALIZE_CRED
int cuwa_cred_serialize( cuwa_cred_t *cred, apr_file_t *file )
{
    cuwa_err_t rc = CUWA_OK;

    cuwa_assert(cred);
    cuwa_assert(cred->attributes);

    cuwa_trace("cuwa_cred_serialize, attrSetCnt: %d",cred->attrSetCnt);

    // write attrSetCnt
    CUWA_SESSION_WRITE_NUM(file, cred->attrSetCnt);

    // write attributes
    rc = cuwa_session_write_table( file, cred->attributes );

cleanup:
    return rc;
}

int cuwa_cred_deserialize( apr_pool_t *pool, cuwa_cred_t **outcred, apr_file_t *file )
{
    cuwa_cred_t *cred = *outcred;
    cuwa_err_t rc = CUWA_OK;

    if (!cred)
    {
        rc = cuwa_cred_init(pool, &cred);
        FAIL_IF(rc,rc);
    }

    // read attrSetCnt
    CUWA_SESSION_READ_NUM(file, cred->attrSetCnt);

    cuwa_trace("cuwa_cred_deserialize, attrSetCnt: %d",cred->attrSetCnt);

    rc = cuwa_session_read_table( pool, file, &cred->attributes );
    FAIL_IF( rc, rc );

    cuwa_trace("cuwa_cred_deserialize, done %d", cred);

    *outcred = cred;

cleanup:
    if (rc && cred)
    {
        cuwa_cred_release(cred);
        *outcred = NULL;
    }

    return rc;
}
#endif


///////////////////////////////////////////////////////////////////////////////////////////////
// Functions to simplify access to some critical non-text attributes
///////////////////////////////////////////////////////////////////////////////////////////////
int cuwa_cred_get_auth_time(cuwa_cred_t *cred)
{
    char *str;

    str = cuwa_cred_get_attribute( cred, "CUWA_AUTH_TIME", 0);
    return str?atoi(str):0;
}

int cuwa_cred_get_end_time(cuwa_cred_t *cred)
{
    char *str;

    str = cuwa_cred_get_attribute( cred, "CUWA_END_TIME", 0);
    return str?atoi(str):0;
}

int cuwa_cred_get_start_time(cuwa_cred_t *cred)
{
    char *str;

    str = cuwa_cred_get_attribute( cred, "CUWA_START_TIME", 0);
    return str?atoi(str):0;
}

int cuwa_cred_get_mechanism(cuwa_cred_t *cred)
{
    char *str;
    str = cuwa_cred_get_attribute( cred, "CUWA_MECHANISM", 0);
    if (!strcmp("kerberos",str)) return CUWA_CRED_MECH_KERBEROS;
    if (!strcmp("session",str)) return CUWA_CRED_MECH_SESSION_KEY;
    return CUWA_CRED_MECH_NONE;
}

int cuwa_cred_get_sessionkey(cuwa_cred_t *cred, uint64 *sessionKey)
{
    char *str;

    str = cuwa_cred_get_attribute( cred, "CUWA_SESSIONKEY", 0);
    if (!str) return CUWA_ERR_CRED_MISSING;

    sscanf( str, "%llX", sessionKey);
    return CUWA_OK;
}

int cuwa_cred_get_sessionid(cuwa_cred_t *cred, uint64 *sessionid)
{
    char *str;

    str = cuwa_cred_get_attribute( cred, "CUWA_SESSIONID", 0);
    if (!str) return CUWA_ERR_CRED_MISSING;

    sscanf( str, "%llX", sessionid);
    return CUWA_OK;
}

/**
 * cuwa_cred_set_attribute_at...
 * Set a credential attribute at instance i
 * @param[in] cred credential object retrieved from parse operation.
 * @param[in] ctxType the context type
 */
void cuwa_cred_set_attribute_at( cuwa_cred_t *cred, const char *key, const char *val,int i)
{
    const char *newKey;

    cuwa_assert(cred);
    cuwa_assert(key);
    cuwa_assert(val);
         
    if ( i == 0 )
    { 
        newKey = key;
    }
    else
    {
        newKey = apr_psprintf(cred->pool,"%s_%d",key, i );
    }
    apr_table_set(cred->attributes,newKey,val);
}

void cuwa_cred_get_dual_auth(cuwa_cred_t *cred, char **dualUser, char **dualMethod, int *authTime)
{

   char *user=NULL, *method=NULL, *dualTime=NULL;

   user = cuwa_cred_get_attribute( cred, "CUWA_2FA_USER", 0);
   method = cuwa_cred_get_attribute( cred, "CUWA_2FA_METHOD", 0);
   dualTime = cuwa_cred_get_attribute( cred, "CUWA_2FA_TIME", 0);

   *dualUser = user;
   *dualMethod = method;
   *authTime = dualTime? atoi(dualTime):0; 
}


const char id_cred_cred_c[] = "$Id: cred.c,v 1.27 2015/10/07 17:36:23 hy93 Exp $";
