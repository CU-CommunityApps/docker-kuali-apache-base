/************************************************************************
 * cred.h -- Credential library for cuwebauth
 *
 * Copyright 2007 Cornell University.
 * All Rights Reserved.
 *
 ************************************************************************
 *  $Log: cred.h,v $
 *  Revision 1.23  2015/10/07 17:36:33  hy93
 *  merge TwoFactor treee to the head
 *
 *  Revision 1.22.2.3  2015/03/13 18:18:02  hy93
 *  add 2FA credential token support
 *
 *  Revision 1.22.2.2  2015/01/29 18:32:32  hy93
 *  modify 2F cred handling(not complete)
 *
 *  Revision 1.22.2.1  2014/10/22 19:32:46  hy93
 *  add two factor support
 *
 *  Revision 1.7  2008/04/10 16:57:11  gbr4
 *  Line endings only. This set of files had mixed line endings which breaks visual studio (and looks ugly in vim). Each file was converted to the format that resulted in the fewest line changes (i.e. whichever format it was mostly in).
 *
 *  Revision 1.6  2008/04/02 06:22:09  pb10
 *  New code to support delegation.  Some new functions have been added that
 *  support serializing the delegated TGT as a K1 token.
 *
 *  Revision 1.5  2008/01/11 03:53:39  pb10
 *  Integration with logging.
 *
 *  Revision 1.4  2008/01/02 04:40:19  pb10
 *  Added host URL to K2 token.
 *  Minor bugs fix.
 *  Makefile mods to adapt to webauth.
 *
 *  Revision 1.3  2007/12/20 02:48:24  pb10
 *  Integration with session manager.
 *
 *  Revision 1.2  2007/10/23 21:28:57  pb10
 *  Add support for cred manager.
 *
 *  Revision 1.1  2007/10/22 16:48:14  pb10
 *  Initial commit, to publish API.
 *
 *
 ************************************************************************
 */

#ifndef _CRED_H
#define _CRED_H

#include <cuwa_types.h>
#include <apr_tables.h>
#include <apr_pools.h>
#include <apr_file_io.h>

typedef enum
{
    CUWA_CRED_CTX_NONE,        /** 0 == no context established */
    CUWA_CRED_CTX_GSS,         /** kutil_sec_ctx_t - GSSAPI security context (from K2) */
    CUWA_CRED_CTX_KERBEROS,    /** kutil_session_t - kerberos login (from K1 - and K2 if delegated) */
    CUWA_CRED_CTX_BASE64,      /** cuwa_base64_t   - binary conversion from base64 */
    CUWA_CRED_CTX_SESSION_KEY, /** Cookie based sessionid/sessionKey pair */
    CUWA_CRED_CTX_PUBLIC_KEY,  /** Not supported */
    CUWA_CRED_CTX_TOKEN,       /** Not supported */
    CUWA_CRED_CTX_MAX
} cuwa_cred_ctx_t;


/* Bit flags for mechanism */
#define CUWA_CRED_MECH_NONE          0
#define CUWA_CRED_MECH_KERBEROS      1
#define CUWA_CRED_MECH_TOKEN         2   /** Not supported */
#define CUWA_CRED_MECH_PUBLIC_KEY    4   /** Not supported */
#define CUWA_CRED_MECH_SESSION_KEY   8

/* Bit flags for CUWAwak2Flags */
#define CUWA_WAK2FLAG_DELEGATE       1

typedef struct cuwa_cred_context
{
    cuwa_cred_ctx_t type;
    void *ctx;

} cuwa_cred_context_t;

typedef struct cuwa_cred
{
    apr_pool_t *pool;                  /** Memory pool */
    apr_table_t *attributes;           /** Table of credential attributes */
    apr_array_header_t *contexts;      /** Array of credential contexts */
    cuwa_cred_context_t *lastCred;     /** Most recently processed credential */
    int attrSetCnt;                    /** Number of credentials with attributes */
} cuwa_cred_t;


void cuwa_cred_set_context( cuwa_cred_t *cred, cuwa_cred_ctx_t ctxType, void *context );

int cuwa_cred_parse( apr_pool_t *pool, cuwa_cred_t **cred, char *credBytes, int credByteLen, char *serviceName, char *keytabName,
                     char *host, void *reserved );

void cuwa_cred_release( cuwa_cred_t *cred );

void * cuwa_cred_get_context( cuwa_cred_t *cred, cuwa_cred_ctx_t ctxType, int index );

void cuwa_cred_set_attribute( cuwa_cred_t *cred, const char *key, const char *val);
void cuwa_cred_set_attribute_at( cuwa_cred_t *cred, const char *key, const char *val,int i);
char *cuwa_cred_get_attribute( cuwa_cred_t *cred, const char *key, int instance);

int cuwa_cred_make_proxy( char *serviceid, char *keytab, char *remoteHost, char *remoteService, uint64 *sessionID,
                         char *inCred, int inCredLen, char **outCred, int *outCredLen);

int cuwa_cred_serialize( cuwa_cred_t *cred, apr_file_t *file );

int cuwa_cred_deserialize( apr_pool_t *pool, cuwa_cred_t **outcred, apr_file_t *file );

#define cuwa_cred_get_attributes(cred) (cred)->attributes

#define cuwa_cred_attributes_complete( cred )  cred->attrSetCnt++

#define cuwa_cred_last(cred) (cred)->lastCred?(cred)->lastCred->ctx:NULL;

#define cuwa_get_pool(cred) (cred)->pool;

// Functions to simplify access to some critical non-text attributes //
int cuwa_cred_get_auth_time(cuwa_cred_t *cred);
int cuwa_cred_get_end_time(cuwa_cred_t *cred);
int cuwa_cred_get_start_time(cuwa_cred_t *cred);
int cuwa_cred_get_mechanism(cuwa_cred_t *cred);
int cuwa_cred_get_sessionkey(cuwa_cred_t *cred, uint64 *sessionKey);
int cuwa_cred_get_sessionid(cuwa_cred_t *cred, uint64 *sessionKey);
void cuwa_cred_get_dual_auth(cuwa_cred_t *cred, char **dualUser, char **dualMethod, int *authTime);
#endif /* _CRED_H */








