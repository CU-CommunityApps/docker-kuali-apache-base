/************************************************************************
 * cred_base64.c -- Support for base64 wrapping of credentials.  This
 *                  implementation does not pad with trailing zeroes.
 *
 * Copyright 2007 Cornell University.
 * All Rights Reserved.
 *
 ************************************************************************
 *  $Log: cred_base64.c,v $
 *  Revision 1.13  2008/08/20 04:12:44  pb10
 *   Some fixes for portal proxy.
 *
 *  Revision 1.12  2008/08/14 17:21:05  pb10
 *  Fixed credential count param in cuwa_bas64_extract_wa
 *
 *  Revision 1.11  2008/08/12 20:34:40  pb10
 *  Convert cred manager interface to use apr_table to transfer credential attributes.
 *  Also supporting the old interface to keep things working while I update  session
 *  manager and auth code.
 *
 *  Revision 1.10  2008/08/10 01:52:29  pb10
 *  Add function cuwa_cred_make_proxy and support functions in cred_base64.
 *
 *  Revision 1.9  2008/04/19 14:21:27  pb10
 *  Convert malloc's to APR allocations.
 *
 *  Revision 1.8  2008/02/12 17:10:27  hy93
 *  remove \n when call cuwa_trace
 *
 *  Revision 1.7  2008/01/25 01:43:47  gbr4
 *  Added an ID string to every file
 *
 *  Revision 1.6  2008/01/13 21:20:31  pb10
 *  Lowercase CUWA2_LOG_DOMAIN setting.
 *
 *  Revision 1.5  2008/01/11 04:02:10  pb10
 *  Integrate with logging.
 *
 *  Revision 1.4  2008/01/06 05:57:01  gbr4
 *  Fix three signed/unsigned warnings
 *
 *  Revision 1.3  2007/11/07 03:51:02  pb10
 *  Fixes to get it working :-)
 *
 *  Revision 1.2  2007/10/23 21:28:57  pb10
 *  Add support for cred manager.
 *
 *  Revision 1.1  2007/10/22 16:48:14  pb10
 *  Initial commit, to publish API.
 *
 *
 ************************************************************************
 */
#include <stdlib.h>
#include <string.h>
#include <stdarg.h>
#include <log.h>
#include <cuwa_err.h>
#include <cred.h>
#include <cred_getput.h>
#include <cred_base64.h>
#include <cuwa_malloc.h>

#define CUWA2_LOG_DOMAIN cuwa.cred

static const char cb64[]="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";

static const unsigned char cd64[] =
{
    64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64,
    64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64,
    64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 62, 64, 64, 64, 63,
    52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 64, 64, 64, 64, 64, 64,
    64,  0,  1,  2,  3,  4,  5,  6,  7,  8,  9, 10, 11, 12, 13, 14,
    15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 64, 64, 64, 64, 64,
    64, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40,
    41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 64, 64, 64, 64, 64,
    64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64,
    64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64,
    64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64,
    64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64,
    64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64,
    64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64,
    64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64,
    64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64
};

/**
 * cuwa_base64_parse parses a base64 encoded credential.  The resulting
 * binary credential is stored in the cred structure (cuwa_cred_t), and
 * is retrieved by cuwa_cred_parse for further parsing.  This function
 * is called by cuwa_cred_parse and never needs to be called directly.
 * cuwa_base64_release is called to by cuwa_cred_release to free memory.
 *
 * @param[in] cred credential object passed from cuwa_cred_parse.
 * @param[in] credBytes the bytes to be parsed
 * @param[in] credByteLen the length of the credential in bytes
 */
int cuwa_base64_parse( cuwa_cred_t *cred, char *credBytes, int credByteLen )
{
    cuwa_err_t rc = CUWA_OK;
    char *decode_cred = NULL;
    int len;
    cuwa_base64_t *base64 = NULL;

    cuwa_assert(cred);
    cuwa_assert(credBytes);
    cuwa_assert(credByteLen);

    /* calculate size of decoded version, note we aren't using credByteLen in calculation */
    len = cuwa_base64_decode_bytes(credBytes);

    /* Allocate space for the decoded... */
    decode_cred = cuwa_malloc(len);
    FAIL_IF(!decode_cred,CUWA_ERR_MEM);

    /* Unwrap...*/
    len = cuwa_base64_decode(credBytes,decode_cred);

    base64 = (cuwa_base64_t *) cuwa_malloc(sizeof(cuwa_base64_t));
    FAIL_IF(!base64,CUWA_ERR_MEM);

    base64->data   = decode_cred;
    base64->length = len;

    cuwa_cred_set_context( cred, CUWA_CRED_CTX_BASE64, base64 );

cleanup:

    if (rc)
    {
        if (decode_cred) cuwa_free(decode_cred);
        if (base64)
        {
            cuwa_free(base64->data);
            cuwa_free(base64);
        }
    }

    return rc;
}

/**
 * cuwa_base64_release releases memory allocated by cuwa_base64_parse.
 *
 * @param[in] cred credential object passed from cuwa_cred_release.
 */
void cuwa_base64_release(cuwa_cred_t *cred, cuwa_cred_context_t *context)
{
    cuwa_base64_t *base64;

    cuwa_assert(cred);

    base64 = (cuwa_base64_t *) context->ctx;
    if (base64)
    {
        cuwa_free(base64->data);
        cuwa_free(base64);
    }
}

/**
 * cuwa_base64_make_wa creates a base64 encoded credential, given one or more
 * binary credentials.
 *
 * @param[out] retCred newly allocated memory containing base64 encoded cred.
 * @param[out] retLen length of the base64 cred.
 * @param[in] totLen total length of all binary credentials.
 * @param[in] numCreds number of credentials.
 * @param[in] cred1 (char *) pointer to first credential.
 * @param[in] cred1Len (int) length of first credential.
 */
int cuwa_base64_make_wa(char **retCred, int *retLen, int totLen, int numCreds, ...)
{
    cuwa_err_t rc = CUWA_OK;
    char *encode_cred = NULL;
    char *decode_cred = NULL, *dcred;
    int len = 0, olen = 0;
    char *cred;
    int credLen = 0;
    va_list	args;
    int i;

    credLen = totLen + 2; /* leave room for 16-bit credCount */

    cuwa_trace("base64_make_wa numCreds=%d, decode len=%d",numCreds,credLen);

    decode_cred = cuwa_malloc(credLen);
    FAIL_IF(!decode_cred,CUWA_ERR_MEM);

    cuwa_trace("base64_make_wa cred=%p",decode_cred);

    /* Put together unwrapped creds... */
    dcred = decode_cred;
    PUT_16(numCreds, dcred, olen);
    va_start(args, numCreds);
    for(i=0 ; i<numCreds; i++)
    {
        cred = va_arg(args, char *);
        len  = va_arg(args, int);
        cuwa_trace("base64_make_wa cred=%p, cred_length=%d",cred,len);
        PUT_BYTES(cred, len, dcred, olen);
    }
    va_end( args );

    cuwa_trace("base64_make_wa ready for base64 if %d==%d",credLen,olen);
    cuwa_assert(olen==credLen);

    /* calclulate size of base64 encoded cred */
    len = cuwa_base64_encode_bytes(credLen)+2;  /* add 2 for "WA" */

    cuwa_trace("base64_make_wa credLen=%d len=%d",credLen,len);

    encode_cred = cuwa_malloc(len);
    FAIL_IF(!encode_cred,CUWA_ERR_MEM);

    memcpy(encode_cred,"WA",2);
    cuwa_base64_encode(decode_cred,credLen,&encode_cred[2]);

    *retCred = encode_cred;
    *retLen  = len - 1; /* Don't include the string term. char in the length */

cleanup:

    if (decode_cred) cuwa_free(decode_cred);

    if (rc && encode_cred)
    {
        cuwa_free(encode_cred);
    }

    return rc;
}

/**
 * cuwa_base64_encode given a string of bytes, encodes bytes in base64.
 *
 * @param[in] in pointer to bytes to be converted to base64.
 * @param[in] inLen length of "in" bytes..
 * @param[in] pointer to where the encoded bytes will be copied.  not caller
 * needs to allocate sufficient space for encoded string.  Call
 * cuwa_base64_encode_bytes for size calculation.
 */
void cuwa_base64_encode( char *in, int inLen, char *encodedBytes)
{
    char *out = encodedBytes;

    for ( ;inLen>2; inLen-=3, in+=3)
    {
        *out++ = cb64[ (in[0] >> 2) & 0x3F];
        *out++ = cb64[ ((in[0] & 0x03) << 4) | ((in[1] & 0xf0) >> 4) ];
        *out++ = cb64[ ((in[1] & 0x0f) << 2) | ((in[2] & 0xc0) >> 6) ];
        *out++ = cb64[ in[2] & 0x3f ];
    }

    if (inLen)
    {
        *out++ = cb64[ (in[0] >> 2) & 0x3F ];
        if (inLen==1)
        {
            *out++ = cb64[ ((in[0] & 0x03) << 4)];
            *out++ = '=';
        }
        else
        {
            *out++ = cb64[ ((in[0] & 0x03) << 4) | ((in[1] & 0xf0) >> 4) ];
            *out++ = cb64[ ((in[1] & 0x0f) << 2) ];
        }
        *out++ = '=';
    }

    *out++ = 0; /* NULL terminate string */
}

/**
 * cuwa_base64_encode_bytes calculate size of base64 encoding.
 *
 * @param[in] inLen length in bytes of binary to be encoded.
 */
int cuwa_base64_encode_bytes( int inLen )
{
    return ((inLen + 2) / 3 * 4) + 1;
}

/**
 * cuwa_base64_decode_bytes calculate size of binary after base64 decoding.
 *
 * @param[in] inBytes pointer to base64 encoded string.
 */
int cuwa_base64_decode_bytes( char *inBytes )
{
    unsigned char *in = (unsigned char *)inBytes;

    // search for end of base64 string
    while (cd64[*(in++)] <= 63);

    return ((((((char*)in - inBytes) + 2) / 4) * 3) + 1);
}

/**
 * cuwa_base64_decode decodes a base64 string.
 *
 * @param[in] inBytes pointer to base64 encoded string.
 * @param[in] outBytes pointer to where decoded bytes are to be copied.  Note that
 * caller must allocate appropriately sized memory for outBytes by calling
 * cuwa_base64_decode_bytes first.
 */
int cuwa_base64_decode(char *inBytes, char *outBytes)
{
    int outLen = 0;
    unsigned char *in = (unsigned char *)inBytes;
    unsigned char *out;
    int inLen;

    // search for end of base64 string
    while (cd64[*(in++)] <= 63);
    inLen = (in - (unsigned char *) inBytes) - 1;

    out = (unsigned char *) outBytes;
    in  = (unsigned char *) inBytes;

    for ( ;inLen>4; in+=4, inLen-=4, outLen+=3)
    {
        *(out++) = (unsigned char) (cd64[in[0]] << 2 | cd64[in[1]] >> 4);
        *(out++) = (unsigned char) (cd64[in[1]] << 4 | cd64[in[2]] >> 2);
        *(out++) = (unsigned char) (cd64[in[2]] << 6 | cd64[in[3]]);
    }

    if (inLen > 1)
    {
        *(out++) = (unsigned char) (cd64[in[0]] << 2 | cd64[in[1]] >> 4);
        outLen++;
    }
    if (inLen > 2)
    {
        *(out++) = (unsigned char) (cd64[in[1]] << 4 | cd64[in[2]] >> 2);
        outLen++;
    }
    if (inLen > 3)
    {
        *(out++) = (unsigned char) (cd64[in[2]] << 6 | cd64[in[3]]);
        outLen++;
    }

    return outLen;
}


int cuwa_base64_extract_wa( char *wa, int walen, char **creds, int *credsLen, int *credsCnt )
{

    cuwa_err_t rc = CUWA_OK;
    char *decode_cred = NULL;
    int len, numCreds;

    cuwa_assert(wa);
    cuwa_assert(walen);
    cuwa_assert(creds);
    cuwa_assert(credsLen);
    cuwa_assert(credsCnt);

    FAIL_IF(*wa!='W',CUWA_ERR_CRED_NOT_SUPPORTED);
    wa++; walen--;
    FAIL_IF(*wa!='A',CUWA_ERR_CRED_NOT_SUPPORTED);
    wa++; walen--;

    /* calculate size of decoded version, note we aren't using credByteLen in calculation */
    len = cuwa_base64_decode_bytes(wa);

    /* Allocate space for the decoded... */
    decode_cred = cuwa_malloc(len);
    FAIL_IF(!decode_cred,CUWA_ERR_MEM);

    /* Unwrap...*/
    len = cuwa_base64_decode(wa,decode_cred);

    /* Get the cred count... */
    GET_16(numCreds,decode_cred,len);

    *creds    = decode_cred;
    *credsLen = len;
    *credsCnt = numCreds;

cleanup:

    if (rc)
    {
        if (decode_cred) cuwa_free(decode_cred);
    }

    return rc;
}

int cuwa_base64_rebuild_wa(char **retCred, int *retLen, char *creds, int credsLen, int credsCnt, int totLen, int numCreds, ...)
{

    cuwa_err_t rc = CUWA_OK;
    char *encode_cred = NULL;
    char *decode_cred = NULL, *dcred;
    int len = 0, olen = 0;
    char *cred;
    int credLen = 0;
    va_list	args;
    int i;

    credLen = credsLen + totLen + 2; /* leave room for 16-bit credCount */

    cuwa_trace("base64_make_wa numCreds=%d, decode len=%d",numCreds,credLen);

    decode_cred = cuwa_malloc(credLen);
    FAIL_IF(!decode_cred,CUWA_ERR_MEM);

    cuwa_trace("base64_make_wa cred=%p",decode_cred);
    cuwa_trace("base64_make_wa total cred cnt=%d",numCreds+credsCnt);

    /* Put together unwrapped creds... */
    dcred = decode_cred;
    PUT_16(numCreds+credsCnt, dcred, olen);

    /* Drop in the pre-existing cred bundle */
    if (creds) PUT_BYTES(creds, credsLen, dcred, olen);

    /* Drop in the new creds */
    va_start(args, numCreds);
    for(i=0 ; i<numCreds; i++)
    {
        cred = va_arg(args, char *);
        len  = va_arg(args, int);
        cuwa_trace("base64_make_wa cred=%p, cred_length=%d",cred,len);
        PUT_BYTES(cred, len, dcred, olen);
    }
    va_end( args );

    cuwa_trace("base64_make_wa ready for base64 if %d==%d",credLen,olen);
    cuwa_assert(olen==credLen);

    /* calclulate size of base64 encoded cred */
    len = cuwa_base64_encode_bytes(credLen)+2;  /* add 2 for "WA" */

    cuwa_trace("base64_make_wa credLen=%d len=%d",credLen,len);

    encode_cred = cuwa_malloc(len);
    FAIL_IF(!encode_cred,CUWA_ERR_MEM);

    memcpy(encode_cred,"WA",2);
    cuwa_base64_encode(decode_cred,credLen,&encode_cred[2]);

    *retCred = encode_cred;
    *retLen  = len - 1; /* Don't include the string term. char in the length */

cleanup:

    if (decode_cred) cuwa_free(decode_cred);

    if (rc && encode_cred)
    {
        cuwa_free(encode_cred);
    }

    return rc;
}



const char id_cred_cred_base64_c[] = "$Id: cred_base64.c,v 1.13 2008/08/20 04:12:44 pb10 Exp $";
