/************************************************************************
 * cred_session.c -- Session credential (C0)
 *
 * Copyright 2007 Cornell University.
 * All Rights Reserved.
 *
 ************************************************************************
 *  $Log: cred_session.c,v $
 *  Revision 1.14  2009/06/12 16:54:28  pb10
 *  Commit IIS / AD integration.  This is not yet complete, but the
 *  code shouldn't affect AD-less configuration.
 *
 *  Revision 1.13  2009/04/29 06:12:12  pb10
 *  Initial.
 *
 *  Revision 1.12  2009/04/01 21:02:11  pb10
 *  experimental code from interop for exchange.
 *
 *  Revision 1.11  2008/08/20 14:08:58  gbr4
 *  change all occurances of %llx and %qx to $llX and %qX respectively.
 *
 *  Revision 1.10  2008/08/12 20:34:40  pb10
 *  Convert cred manager interface to use apr_table to transfer credential attributes.
 *  Also supporting the old interface to keep things working while I update  session
 *  manager and auth code.
 *
 *  Revision 1.9  2008/04/19 14:21:27  pb10
 *  Convert malloc's to APR allocations.
 *
 *  Revision 1.8  2008/02/12 17:11:54  hy93
 *  remove \n when call cuwa_trace
 *
 *  Revision 1.7  2008/01/25 01:43:47  gbr4
 *  Added an ID string to every file
 *
 *  Revision 1.6  2008/01/13 21:20:31  pb10
 *  Lowercase CUWA2_LOG_DOMAIN setting.
 *
 *  Revision 1.5  2008/01/11 03:53:39  pb10
 *  Integration with logging.
 *
 *  Revision 1.4  2008/01/02 04:40:19  pb10
 *  Added host URL to K2 token.
 *  Minor bugs fix.
 *  Makefile mods to adapt to webauth.
 *
 *  Revision 1.3  2007/12/28 16:18:14  pb10
 *  linefeed removal
 *
 *  Revision 1.2  2007/12/21 19:48:51  hy93
 *  Modify make_c0 function.
 *
 *  Revision 1.1  2007/12/20 02:37:00  pb10
 *  Initial code.
 *
 *
 ************************************************************************
 */

#include <stdlib.h>
#include <apr_strings.h>
#include <cred_session.h>
#include <string.h>
#include <cred_getput.h>
#include <log.h>
#include <cuwa_err.h>
#include <cuwa_malloc.h>

#define CUWA2_LOG_DOMAIN cuwa.cred

/**
 * cuwa_cred_make_c0 makes a C0 (cookie) token.
 *
 * @param[in] sessionID.
 * @param[in] sessionKey.
 * @param[out] c0 pointer to newly allocated memory containing the c0.  Caller must free.
 * @param[out] c0len length of the c0 (in bytes).
 */
int cuwa_cred_make_c0( uint64 sessionID, uint64 sessionKey, char **c0, int *c0Len )
{
    int rc=0;
    char label[2] = {'C','0'};
    char *token = NULL, *tok;
    int olen = 0;
    int tokenLen = sizeof(sessionKey)+sizeof(sessionID);

    cuwa_trace("cuwa_cred_make_c0, sid:  %llX",sessionID);
    cuwa_trace("cuwa_cred_make_c0, skey: %llX",sessionKey);

    token = cuwa_malloc(tokenLen+sizeof(label)+sizeof(int16));
    FAIL_IF( !token, CUWA_ERR_MEM );

    tok = token;
    PUT_BYTES(label, 2, tok, olen);
    PUT_16(tokenLen, tok, olen);
    PUT_64( sessionID, tok, olen );
    PUT_64( sessionKey, tok, olen );

    *c0 = token;
    *c0Len = olen;

cleanup:

    if (rc && token) cuwa_free(token);

    return rc;
}

int cuwa_cred_session_parse(cuwa_cred_t *cred, char *token, int tokenLen  )
{
    int rc=0;
    uint64 sessionKey, sessionID;

    cuwa_trace("cuwa_cred_session_parse, tokLen:  %d",tokenLen);

    GET_64(sessionID,token,tokenLen);
    GET_64(sessionKey,token,tokenLen);

    cuwa_trace("cuwa_cred_session_parse, sid:  %llX",sessionID);
    cuwa_trace("cuwa_cred_session_parse, skey: %llX",sessionKey);

    cuwa_cred_set_attribute( cred, "CUWA_MECHANISM", "session");
    cuwa_cred_set_attribute( cred, "CUWA_SESSIONKEY", apr_psprintf(cred->pool,"%qX",sessionKey));
    cuwa_cred_set_attribute( cred, "CUWA_SESSIONID", apr_psprintf(cred->pool,"%qX",sessionID));

    cuwa_cred_attributes_complete(cred);

cleanup:

    return rc;

}



const char id_cred_cred_session_c[] = "$Id: cred_session.c,v 1.14 2009/06/12 16:54:28 pb10 Exp $";
