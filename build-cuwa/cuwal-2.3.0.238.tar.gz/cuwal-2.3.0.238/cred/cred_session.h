/************************************************************************
 * cred_session.h -- Session key credential (C0)
 *
 * Copyright 2007 Cornell University.
 * All Rights Reserved.
 *
 ************************************************************************
 *  $Log: cred_session.h,v $
 *  Revision 1.4  2007/12/28 16:18:14  pb10
 *  linefeed removal
 *
 *  Revision 1.3  2007/12/21 19:47:38  hy93
 *  change function name
 *
 *  Revision 1.2  2007/12/21 19:34:36  hy93
 *  change interface
 *
 *  Revision 1.1  2007/12/20 02:37:14  pb10
 *  Initial code.
 *
 *
 ************************************************************************
 */

#ifndef _CRED_SESSION_H
#define _CRED_SESSION_H

#include "cred.h"


int cuwa_cred_make_c0( uint64 sessionID, uint64 sessionKey, char **c0, int *c0Len );

int cuwa_cred_session_parse(cuwa_cred_t *cred, char *credBytes, int credByteLen  );



#endif


