/************************************************************************
 * kutil.c -- Kerberos utilities for cuwebauth
 *
 * Copyright 2007 Cornell University.
 * All Rights Reserved.
 *
 ************************************************************************
 *  $Log: kutil.c,v $
 *  Revision 1.52  2015/10/07 17:37:10  hy93
 *  merge TwoFactor treee to the head
 *
 *  Revision 1.51.2.2  2015/05/01 17:24:13  hy93
 *  add error checking after storing credential cache
 *
 *  Revision 1.51.2.1  2015/02/25 20:09:19  hy93
 *  replace deprecated krb5 calls
 *
 *  Revision 1.51  2009/07/06 21:39:08  pb10
 *  Add warning for out-of-date KFW.
 *
 *  Revision 1.50  2009/04/29 06:17:29  pb10
 *  Fix build issue.
 *
 *  Revision 1.49  2009/04/29 06:12:12  pb10
 *  Initial.
 *
 *  Revision 1.48  2009/04/22 15:20:07  pb10
 *  Add threadid to credential cache name to fix crash in IIS.
 *  Note that this fix should eventually be done in *nix code so that it is thread safe.
 *  (see fixme).
 *
 *  Revision 1.47  2008/10/30 15:56:01  hy93
 *  remove the hack to work around win32 replay cache issue
 *
 *  Revision 1.46  2008/10/22 19:15:41  pb10
 *  add sleep back in until we fix mutex issue
 *
 *  Revision 1.45  2008/10/21 14:46:25  pb10
 *  modified disable rcache
 *
 *  Revision 1.43  2008/10/16 14:38:15  hy93
 *  remove previous check in that try to fix permission deny in replay cache error on Windows
 *
 *  Revision 1.42  2008/10/14 16:10:04  hy93
 *  try to fix permission deny in replay cache error on Windows
 *
 *  Revision 1.41  2008/10/14 16:00:46  hy93
 *  try to fix permission deny in replay cache error on Windows
 *
 *  Revision 1.40  2008/09/11 17:08:30  pb10
 *  Fix user for weblogin.
 *
 *  Revision 1.39  2008/08/22 17:11:44  pb10
 *  Replace calls to KRB_FREE with something better.
 *
 *  Revision 1.38  2008/08/20 16:05:19  hy93
 *  fix segfault in kutil_end_session
 *
 *  Revision 1.37  2008/08/17 15:08:07  pb10
 *  Add CUWA_LOGIN_USER attribute when parsing K1.
 *
 *  Revision 1.36  2008/07/14 14:47:44  pb10
 *  Modified cred mgr to allow access to f1 and k3 from k2 authenticator.
 *  Modified make_k2 to allow caller to insert arbitrary keyword/value pairs
 *  into authenticator.
 *
 *  Revision 1.35  2008/06/30 22:02:56  gbr4
 *  windows is really tired
 *
 *  Revision 1.34  2008/06/30 21:53:02  gbr4
 *  windows is tired
 *
 *  Revision 1.33  2008/06/30 21:24:34  gbr4
 *  temporary hack to fix windows replay cache issue
 *
 *  Revision 1.32  2008/06/30 18:07:38  gbr4
 *  improve error messages when keytab is bad or missing
 *
 *  Revision 1.31  2008/06/02 01:44:20  pb10
 *  Add starttime and endtime to fields being hacked out of GSS credential with
 *  KRB5 calls.  The starttime is being used by session manager to support
 *  cred age test... too old = starttime-authtime > CUWACredentialAge
 *
 *  Revision 1.30  2008/05/19 19:34:45  pb10
 *  Change creation of K1 (restore SSO cookie) to use malloc instead of cuwa_malloc.
 *  This is because krb_ functions are used to cleanup and those functions will
 *  call free.
 *
 *  Revision 1.29  2008/05/09 15:59:46  gbr4
 *  added some more tracing to kutil.h
 *
 *  Revision 1.28  2008/05/09 15:46:04  gbr4
 *  added some more tracing to kutil.h
 *
 *  Revision 1.27  2008/05/06 04:06:43  gbr4
 *  krb5_gss_register_acceptor_identity present in kfw3.2, remove conditional compile
 *
 *  Revision 1.26  2008/04/29 13:35:25  hy93
 *  fix warning regarding assignment differ in signedness
 *
 *  Revision 1.25  2008/04/19 14:21:27  pb10
 *  Convert malloc's to APR allocations.
 *
 *  Revision 1.24  2008/04/14 04:12:36  pb10
 *  Fix CUWACredentialAge to only check age on initial website page hit.  CUWACrentialDefaultAge obsolete.
 *
 *  Revision 1.23  2008/04/13 18:29:27  pb10
 *  Hacked the GSS ICT so that we can get real authtime when accepting tokens.
 *
 *  Revision 1.22  2008/04/07 14:40:07  pb10
 *  Add function kutil_get_times.
 *
 *  Revision 1.21  2008/04/03 19:31:30  pb10
 *  Remove conditional around disabling ticket cache.
 *
 *  Revision 1.20  2008/04/02 14:30:57  gbr4
 *  changed setenv to putenv for solaris. have not tested yet, want to see how it does on solaris
 *
 *  Revision 1.19  2008/04/02 14:19:37  pb10
 *  Change the setting of environment variable to only happen when building the
 *  test harness.  Apparantly setenv isn't standard on solaris.  I'll have to
 *  revisit using appropriate APR function instead, which requires a pool (yuk).
 *
 *  Revision 1.18  2008/04/02 06:22:09  pb10
 *  New code to support delegation.  Some new functions have been added that
 *  support serializing the delegated TGT as a K1 token.
 *
 *  Revision 1.17  2008/03/26 21:06:34  pb10
 *  Enable host checking in webauth. Fix minor log sanitizing glitch.
 *
 *  Revision 1.16  2008/03/25 16:31:50  pb10
 *  Improve the error message for keytab problems.
 *
 *  Revision 1.15  2008/02/28 20:48:14  hy93
 *  fix compiler warning
 *
 *  Revision 1.14  2008/02/22 16:23:43  pb10
 *  Added authtime and endtime to K1 parse so that weblogin can examine.
 *
 *  Revision 1.13  2008/02/12 17:14:46  hy93
 *  remove \n when call cuwa_trace.Change some error message to use cuwa_warnning instead of cuwa_trace
 *
 *  Revision 1.12  2008/01/25 01:43:47  gbr4
 *  Added an ID string to every file
 *
 *  Revision 1.11  2008/01/13 21:20:31  pb10
 *  Lowercase CUWA2_LOG_DOMAIN setting.
 *
 *  Revision 1.10  2008/01/11 03:57:21  pb10
 *  Integration with logging.
 *
 *  Revision 1.9  2008/01/06 05:57:01  gbr4
 *  Fix three signed/unsigned warnings
 *
 *  Revision 1.8  2008/01/02 04:40:19  pb10
 *  Added host URL to K2 token.
 *  Minor bugs fix.
 *  Makefile mods to adapt to webauth.
 *
 *  Revision 1.7  2007/12/20 02:48:24  pb10
 *  Integration with session manager.
 *
 *  Revision 1.6  2007/11/08 12:58:13  pb10
 *  Fixed call to accept_sec_context, undocumented GSS "feature" bug.
 *
 *  Revision 1.5  2007/11/07 03:41:19  pb10
 *  Changes to support delegated creds, and Win32.
 *
 *  Revision 1.4  2007/10/23 21:28:57  pb10
 *  Add support for cred manager.
 *
 *  Revision 1.3  2007/10/18 20:12:16  pb10
 *  Added Kerberos API support.
 *
 *  Revision 1.2  2007/09/07 11:42:34  pb10
 *  Imposed rothfix reverse comparison.
 *
 *  Revision 1.1  2007/09/07 11:24:42  pb10
 *  Initial
 *
 ************************************************************************
 */

#include <kutil.h>
#include <stdlib.h>
#include <string.h>
#include <krb5.h>
#include <gssapi/gssapi_generic.h>
#include <gssapi/gssapi_krb5.h>
#include <log.h>
#include <time.h>
#include <cuwa_types.h>
#include <cred_getput.h>
#include <cuwa_malloc.h>
#include <apr_portable.h>

#ifndef WIN32
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#else
#include <windows.h> //for sleep -- fixme
#endif


/* MAXLIFE is site dependent, it is the default tkt lifetime setting for the KDC */
#define MAXLIFE 10*60*60

/** Logging domain */
#define CUWA2_LOG_DOMAIN cuwa.cred

/** Ticket cache is stored as a thread global */
#define CACHE_NAME "MEMORY:CUWAkutil"
#define CACHE_NAME_SIZE 64

// Use these macros to allocate memory that might be freed by kerberos.  This is used in kutil_restore_session when
// recreating internal kerberos structures.
// IMPORTANT!!: don't change these to cuwa_malloc because APR memory cannot be freed by kerberos.
#define KRB_MALLOC malloc
#define KRB_CALLOC calloc

/**
 * Internal structure in support of kerberos login session state.
 */
typedef struct _kutil_session_priv
{
    krb5_context ctx;
    krb5_ccache cache;
    char cachename[CACHE_NAME_SIZE];
    char *user;
    char *save;
} kutil_session_priv_t;

/**
 * Internal structure in support of gss context (client/server connection).
 */
typedef struct _kutil_context_priv
{
    gss_ctx_id_t ctx;
    gss_cred_id_t delegated_cred;
    gss_buffer_desc buf;
    gss_buffer_desc netid;
    gss_buffer_desc target;
    gss_buffer_desc initiator;
    int authtime;                  // need to hold onto this, GSS doesn't support it
    int starttime;                 // need to hold onto this, GSS doesn't support it
    int endtime;                   // need to hold onto this, GSS doesn't support it
} kutil_context_priv_t;

/**
 * Internal structure in support of krb5 context (client/server connection).
 */
typedef struct _kutil_krb_ctx_priv
{
    krb5_auth_context auth_ctx;
    kutil_session_priv_t *session;
    int free_session;
    int authtime;                 // need to hold onto this, help GSS out
    int starttime;                // need to hold onto this, help GSS out
    int endtime;                  // need to hold onto this, help GSS out
} kutil_krb_ctx_priv_t;

// Set environment variable for disabling the replay cache
// Note: this only works for the test harness, not apache-module
#ifdef WIN32
#define KUTIL_INIT do {if (!kutil_init) {kutil_init=1;_putenv_s("KRB5RCACHETYPE","none");}} while (0)
#else
#define KUTIL_INIT do {if (!kutil_init) {kutil_init=1;putenv("KRB5RCACHETYPE=none");}} while (0)
#endif
static int kutil_init = 0;

/* Local routines */
static void kutil_krb_error(char *func, int line, int rc);
static void kutil_gss_error(char *func, int line, OM_uint32 code, int type);
static cuwa_err_t kutil_server_acquire_creds(char *service_name, gss_cred_id_t *server_creds, int wantDelegated);
static cuwa_err_t kutil_get_initial_tkt(kutil_session_t ksess, char *netid, char *password, char *serviceid);
static cuwa_err_t kutil_get_initial_tkt_key(kutil_session_t ksess, char *keytab, char *serviceid);
static cuwa_err_t kutil_serialize_cred(kutil_session_t ksess, krb5_creds *creds, char *output, int *length);
static cuwa_err_t kutil_init_session(kutil_session_t *ksess);
static cuwa_err_t kutil_mk_addr( krb5_address **addr_ret, struct in_addr *addr );
static cuwa_err_t kutil_ict_to_ap_req(char *buf, int blen, char **buf_out, int *blen_out);
static cuwa_err_t kutil_peek_sec_context(kutil_sec_ctx_t ctx, char *bits, int bitLen, char *serviceName, char *keytabName);
static char * kutil_get_cache_name(char *buffer);
cuwa_err_t kutil_dump_cache(kutil_session_t ksess);
/**
 * Creates a kutil session.  Call at the beginning of security transaction.
 * @param[out] ksess the session
 * @return success==CUWA_OK, possible errors... CUWA_ERR_MEM, CUWA_ERR_KRB, CUWA_ERR_GSS
 */
cuwa_err_t kutil_init_session(kutil_session_t *ksess)
{
    kutil_session_priv_t *priv;
    int code;
    cuwa_err_t rc = CUWA_OK;
    OM_uint32 minor_status;
    char *cache_name;

    KUTIL_INIT;

    cuwa_assert( ksess );

    priv = (kutil_session_priv_t*) cuwa_calloc(1,sizeof(kutil_session_priv_t));
    FAIL_IF(!priv,CUWA_ERR_MEM);

    code = krb5_init_context(&priv->ctx);
    FAIL_IF_KRB_ERR(code);

    cache_name = kutil_get_cache_name(priv->cachename);
    cuwa_assert(cache_name);
    cuwa_trace("Using cred cache name: %s",cache_name);
    code = krb5_cc_resolve(priv->ctx, cache_name, &priv->cache);
    FAIL_IF_KRB_ERR(code);

    /* Set up thread to use this ticket cache */
    code = gss_krb5_ccache_name(&minor_status, cache_name, NULL);
    FAIL_IF_GSS_ERR(code,minor_status);

    priv->save = NULL;

    *ksess = (kutil_session_t) priv;

cleanup:

    if (rc && priv)
    {
        if (priv->cache) 
            krb5_cc_close(priv->ctx, priv->cache);

        if (priv->ctx)
            krb5_free_context(priv->ctx);

        cuwa_free(priv);
    }

    return rc;
}

/**
 * Cleans up a kutil session.  Call when you're done processing security trasaction.
 * @param[in] ksess the session
 */
void kutil_end_session(kutil_session_t ksess)
{
    kutil_session_priv_t *priv = (kutil_session_priv_t *) ksess;

    cuwa_assert( ksess );

    if (priv->user)
    {
        cuwa_trace("kutil_end_session priv->user: %p",priv->user);
        cuwa_free(priv->user);
        priv->user = NULL;
    }

    if (priv->save)
    {
        cuwa_trace("kutil_end_session priv->save: %p",priv->save);
        cuwa_free(priv->save);
        priv->save = NULL;
    }

    if (priv->cache)
    {
        cuwa_trace("kutil_end_session CacheName: %s",priv->cachename);
        krb5_cc_destroy(priv->ctx, priv->cache);
        priv->cache = NULL;
    }

    if ( priv->ctx)
    {
        cuwa_trace("kutil_end_session priv->ctx: %p",priv->ctx);
        krb5_free_context(priv->ctx);
        priv->ctx = NULL;
    }
    cuwa_free(priv);
    cuwa_trace("kutil_end_session done");
}

/**
 * Gets TGT into cache, given netid and password.
 * @param[out] ksess the newly created session
 * @param[in] netid the netid
 * @param[in] password the password
 * @return success==CUWA_OK, possible errors... CUWA_ERR_KRB, CUWA_ERR_GSS
 */
cuwa_err_t kutil_login(kutil_session_t *ksess, char *netid, char *password)
{
    kutil_session_priv_t *priv;
    cuwa_err_t rc = CUWA_OK;
    int code;

    KUTIL_INIT;

    cuwa_assert( ksess );
    cuwa_assert( netid );
    cuwa_assert( password );
    cuwa_assert( *netid );
    cuwa_assert( *password );

    *ksess = NULL;

    code = kutil_init_session(ksess);
    FAIL_IF(code,code);

    priv = (kutil_session_priv_t *) *ksess;

    code = kutil_get_initial_tkt(*ksess, netid, password, NULL);
    FAIL_IF(code,code);

cleanup:

    if (rc && *ksess)
    {
        kutil_end_session(*ksess);
        *ksess = NULL;
    }

    return rc;
}

/**
 * Gets TGT into cache, given netid and password.
 * @param[out] ksess the newly created session
 * @param[in] serviceid the kerberos id whose key is in the keytab
 * @param[in] keytab the path to the key file
 * @return success==CUWA_OK, possible errors... CUWA_ERR_KRB, CUWA_ERR_GSS
 */
cuwa_err_t kutil_login_key(kutil_session_t *ksess, char *serviceid, char *keytab)
{
    kutil_session_priv_t *priv;
    cuwa_err_t rc = CUWA_OK;
    int code;

    KUTIL_INIT;

    cuwa_assert( ksess );
    cuwa_assert( serviceid );
    cuwa_assert( keytab );
    cuwa_assert( *serviceid );
    cuwa_assert( *keytab );

    *ksess = NULL;

    code = kutil_init_session(ksess);
    FAIL_IF(code,code);

    priv = (kutil_session_priv_t *) *ksess;

    code = kutil_get_initial_tkt_key(*ksess,keytab,serviceid);
    FAIL_IF(code,code);

    cuwa_trace("#### Got initial ticket use keytab");
    kutil_dump_cache(*ksess);

cleanup:

    if (rc && *ksess)
    {
        kutil_end_session(*ksess);
    }

    return rc;
}

/**
 * Returns a bit stream representation of the TGT.
 * @param[in] ksess the session
 * @param[out] bits, allocated, must call end_session to free
 * @param[out] length in bytes
 * @return success==CUWA_OK, possible errors... CUWA_ERR_MEM, CUWA_ERR_KRB, CUWA_ERR_GSS
 */
cuwa_err_t kutil_save_session( kutil_session_t ksess, char **bits, int *length)
{
    int code;
    cuwa_err_t rc = CUWA_OK;
    krb5_data *realm;
    krb5_creds creds, tgtq;
    kutil_session_priv_t *priv = (kutil_session_priv_t *) ksess;

    cuwa_assert( priv );
    cuwa_assert( bits );
    cuwa_assert( length );

    memset(&tgtq, 0, sizeof(tgtq));
    memset(&creds, 0, sizeof(creds));

    /* Get login principal name */
    code = krb5_cc_get_principal(priv->ctx, priv->cache, &tgtq.client);
    FAIL_IF_KRB_ERR(code);

    /* Get login realm */
    realm = krb5_princ_realm(priv->ctx, tgtq.client);


    /* Get TGS name */
    code = krb5_build_principal_ext(priv->ctx,
                                    &tgtq.server,
                                    realm->length,
                                    realm->data,
                                    KRB5_TGS_NAME_SIZE,
                                    KRB5_TGS_NAME,
                                    realm->length,
                                    realm->data,
                                    0);
    FAIL_IF_KRB_ERR(code);

    /* Get TGT Cred... */
    code = krb5_cc_retrieve_cred(priv->ctx, priv->cache,
                                 KRB5_TC_MATCH_SRV_NAMEONLY,
                                 &tgtq, &creds);
    FAIL_IF_KRB_ERR(code);

    /* Estimate length of serialized cred... */
    code = kutil_serialize_cred(ksess, &creds, NULL, length);
    FAIL_IF(code,code);

    *bits = cuwa_malloc(*length);
    FAIL_IF(!*bits,CUWA_ERR_MEM);

    /* Serialize the cred */
    code = kutil_serialize_cred(ksess, &creds, *bits, length);
    FAIL_IF(code,code);

cleanup:

    if (rc && *bits)
    {
        cuwa_free(*bits);
        *bits = NULL;
    }
    else
    {
        priv->save = *bits;
    }

    krb5_free_cred_contents(priv->ctx, &creds);
    krb5_free_cred_contents(priv->ctx, &tgtq);

    return rc;
}

/**
 * Get an initial ticket.  If serviceid is NULL, gets a TGT.
 * @param[in] ksess the kerberos session state
 * @param[in] netid the user's netid
 * @param[in] password the user's password
 * @param[in] serviceid the name of the service for which an initial ticket is obtained
 * @return success==CUWA_OK, otherwise CUWA_ERR_KRB
 */
cuwa_err_t kutil_get_initial_tkt(kutil_session_t ksess, char *netid, char *password, char *serviceid)
{
    kutil_session_priv_t *priv = (kutil_session_priv_t *) ksess;
    krb5_creds creds;
    int code = 0;
    cuwa_err_t rc = CUWA_OK;
    char *tgtsrv;
    krb5_get_init_creds_opt *opts = NULL;

    memset((char *)&creds, 0, sizeof(creds));

    code = krb5_parse_name(priv->ctx, netid, &creds.client);
    FAIL_IF_KRB_ERR(code);

    code = krb5_cc_initialize(priv->ctx, priv->cache, creds.client);
    FAIL_IF_KRB_ERR(code);

    if (serviceid)
    {
        /* Parse the caller supplied service, for use with "force" relogin mechanism */
        code = krb5_parse_name(priv->ctx, serviceid, &creds.server);
        FAIL_IF_KRB_ERR(code);
    }
    else
    {
        /* Build the name of the TGS */
        code = krb5_build_principal_ext(priv->ctx, &creds.server,
                                        creds.client->realm.length,
                                        creds.client->realm.data,
                                        KRB5_TGS_NAME_SIZE,
                                        KRB5_TGS_NAME,
                                        creds.client->realm.length,
                                        creds.client->realm.data,
                                        0);
        FAIL_IF_KRB_ERR(code);

        tgtsrv = NULL;
        (void) krb5_unparse_name(priv->ctx, creds.server, &tgtsrv);
        if (tgtsrv)
        {
            cuwa_trace("TGS: %s",tgtsrv);
            krb5_free_unparsed_name(priv->ctx,tgtsrv);
        }
        (void) krb5_unparse_name(priv->ctx, creds.client, &priv->user);
    }

    code = krb5_get_init_creds_opt_alloc(priv->ctx, &opts);
    FAIL_IF_KRB_ERR(code);
 
    krb5_get_init_creds_opt_set_forwardable(opts, 1);
    krb5_get_init_creds_opt_set_proxiable(opts, 1);

    code = krb5_get_init_creds_password(priv->ctx, &creds, creds.client,password,NULL, NULL,0, NULL, opts); 
    FAIL_IF_KRB_ERR(code);

    code = krb5_cc_store_cred( priv->ctx, priv->cache, &creds);
    FAIL_IF_KRB_ERR(code);

cleanup:

    if (opts)
        krb5_get_init_creds_opt_free(priv->ctx, opts);

    krb5_free_cred_contents(priv->ctx, &creds);

    return code;
}

/**
 * Serial a kerberos credential.  Currently just used to serialize TGT, but could be used for other credentials.
 * @param[in] ksess the kerberos session state
 * @param[in] creds the kerberos credential
 * @param[in] output buffer to copy serialized credential to.  If this parameter is NULL then only the length
 *            required is returned, and no bytes are copied.
 * @param[out] length returns the final size of the serialized credential.
 * @return success==CUWA_OK, otherwise CUWA_ERR_KRB
 */
cuwa_err_t kutil_serialize_cred(kutil_session_t ksess, krb5_creds *creds, char *output, int *length)
{
    int code;
    char *out = output;
    cuwa_err_t rc = CUWA_OK;
    char *princ;
    kutil_session_priv_t *priv = (kutil_session_priv_t *) ksess;

    *length = 0;

    cuwa_trace("serialize: %s",output?"write phase":"sizing buffer");

    /* Clent principal */
    if (creds->client)
    {
        code = krb5_unparse_name(priv->ctx, creds->client, &princ);
        FAIL_IF_KRB_ERR(code);

        cuwa_trace("client: %s",princ);
        PUT_BUFFER(princ,strlen(princ),out,*length);
        cuwa_free(princ);
    }

    /* Server principal */
    if (creds->server)
    {
        code = krb5_unparse_name(priv->ctx, creds->server, &princ);
        FAIL_IF_KRB_ERR(code);

        cuwa_trace("server: %s",princ);
        PUT_BUFFER(princ,strlen(princ),out,*length);
        cuwa_free(princ);
    }

    cuwa_trace("offset: %d",*length);

    /* Keyblock */
    PUT_32( creds->keyblock.enctype, out, *length);
    PUT_BUFFER(creds->keyblock.contents, creds->keyblock.length,  out, *length);


    cuwa_trace("offset: %d",*length);

    /* Times */

    PUT_32( creds->times.authtime, out, *length);
    PUT_32( creds->times.starttime, out, *length);
    PUT_32( creds->times.endtime, out, *length);
    PUT_32( creds->times.renew_till, out, *length);

    /* is_skey */
    PUT_32( creds->is_skey, out, *length);

    /* Ticket flags */
    PUT_32( creds->ticket_flags, out, *length);

    cuwa_trace("offset: %d",*length);

    /* Addresses */
    if (creds->addresses)
    {
        int num = 0, i;
        krb5_address **temp = creds->addresses;

        while (*temp++)
            num++;

        cuwa_trace("#addresses: %d",num);
        PUT_32(num, out, *length);

        for (i = 0; i < num; i++)
        {
            PUT_32(creds->addresses[i]->addrtype, out, *length);
            PUT_BUFFER(creds->addresses[i]->contents, creds->addresses[i]->length, out, *length);
        }
    }
    else
    {
        PUT_32(0, out, *length);
    }

    cuwa_trace("authdata offset: %d",*length);

    /* Auth data. */
    if (creds->authdata)
    {
        int num = 0, i;
        krb5_authdata **temp = creds->authdata;

        while (*temp++)
            num++;

        cuwa_trace("#authdata: %d",num);

        PUT_32(num, out, *length);

        for (i = 0; i < num; i++)
        {
            PUT_32(creds->authdata[i]->ad_type, out, *length);
            cuwa_trace(" authdata[%d] len:%d",i,creds->authdata[i]->length);
            PUT_BUFFER(creds->authdata[i]->contents, creds->authdata[i]->length, out, *length);
        }
    }
    else
    {
        PUT_32(0, out, *length);
    }

    cuwa_trace("ticket offset: %d",*length);

    /* Ticket */
    PUT_BUFFER(creds->ticket.data, creds->ticket.length, out, *length);

    cuwa_trace("2nd ticket offset: %d",*length);

    /* Second ticket. */
    PUT_BUFFER(creds->second_ticket.data, creds->second_ticket.length, out, *length);

    cuwa_trace("serialize: %s %d bytes",output?"wrote":"alloc",*length);

cleanup:

    /* nothing to cleanup */

    return rc;
}

/**
 * Given a serialized credential, convert back to kerberos credential and store in the ticket cache.
 * Currently just used to deserialize TGT, but could be used for other credentials.
 * @param[out] ksess pointer to the newly created kerberos session
 * @param[in] in buffer pointing to the serialized cred.
 * @param[in] len length of the cred in bytes.
 * @return success==CUWA_OK, otherwise CUWA_ERR_KRB, CUWA_ERR_MEM
 */
cuwa_err_t kutil_restore_session( kutil_session_t *ksess, char *in, int len, int *authtime, int *endtime )
{
    kutil_session_priv_t *priv;
    krb5_creds creds;
    int code, i;
    cuwa_err_t rc = CUWA_OK;
    krb5_context ctx = NULL;
    int num, length = 0;
    char *netid;
    int totlen = len;

    KUTIL_INIT;

    cuwa_assert( ksess );
    cuwa_assert( in );
    cuwa_assert( len );

    *ksess = NULL;
    memset(&creds, 0, sizeof(krb5_creds));

    code = kutil_init_session(ksess);
    FAIL_IF(code,code);

    priv = (kutil_session_priv_t *) *ksess;
    ctx  = priv->ctx;

    cuwa_trace("restore from: %d bytes",len);

    FAIL_IF((0>=len), CUWA_ERR_BAD_CRED);
    FAIL_IF((NULL == in), CUWA_ERR_BAD_CRED);

    GET_BUFFER(netid, length, in, len, cuwa_malloc);
    cuwa_trace("client: %s",netid);
    code = krb5_parse_name(ctx, netid, &creds.client);
    priv->user = netid; // don't free this one
    FAIL_IF_KRB_ERR(code);

    GET_BUFFER(netid, length, in, len, cuwa_malloc);
    cuwa_trace("server: %s",netid);
    code = krb5_parse_name(ctx, netid, &creds.server);
    cuwa_free(netid);
    FAIL_IF_KRB_ERR(code);

    cuwa_trace("offset: %d",totlen-len);

    GET_32( creds.keyblock.enctype,  in, len );
    GET_BUFFER( creds.keyblock.contents, creds.keyblock.length, in, len, KRB_MALLOC);

    cuwa_trace("offset: %d",totlen-len);

    GET_32( creds.times.authtime,  in, len );
    GET_32( creds.times.starttime, in, len );
    GET_32( creds.times.endtime,   in, len );
    GET_32( creds.times.renew_till,in, len );
    GET_32( creds.is_skey,         in, len );
    GET_32( creds.ticket_flags,    in, len );

    cuwa_trace("offset: %d",totlen-len);

    // addresses
    GET_32( num, in, len );
    cuwa_trace("#addrs: %d, %x",num,num);
    FAIL_IF((0>num), CUWA_ERR_BAD_CRED);
    if (num)
    {
        // one extra for zero termination, calloc sets terminator
        creds.addresses = KRB_CALLOC( num+1, sizeof(krb5_address *));
        for (i=0;i<num;i++)
        {
            creds.addresses[i] = (krb5_address *) KRB_CALLOC(1,sizeof(krb5_address));
            GET_32( creds.addresses[i]->addrtype, in, len );
            GET_BUFFER( creds.addresses[i]->contents, creds.addresses[i]->length, in, len, KRB_MALLOC );
        }
    }

    cuwa_trace("offset: %d",totlen-len);

    // auth data
    GET_32( num, in, len );
    cuwa_trace("#authdata: %d, %x",num,num);
    FAIL_IF(((0>num)), CUWA_ERR_BAD_CRED);

    // one extra for zero termination, calloc sets terminator
    if (num)
    {
        creds.authdata = KRB_CALLOC( num+1, sizeof(krb5_authdata *));
        FAIL_IF(!creds.authdata, CUWA_ERR_MEM);

        for (i=0;i<num;i++)
        {
            creds.authdata[i] = (krb5_authdata *) KRB_MALLOC(sizeof(krb5_authdata));
            FAIL_IF(!creds.authdata[i], CUWA_ERR_MEM);

            creds.authdata[i]->magic = KV5M_AUTHDATA;

            GET_32(creds.authdata[i]->ad_type, in, len);
            GET_BUFFER(creds.authdata[i]->contents, creds.authdata[i]->length, in, len, KRB_MALLOC);
        }
    }
    cuwa_trace("ticket offset: %d",totlen-len);

    // FIXME: what about ticket.data.magic, oddly Kerberos doesn't seem to choke??

    GET_BUFFER(creds.ticket.data, creds.ticket.length, in, len, KRB_MALLOC);
    cuwa_trace("offset: %d",totlen-len);

    cuwa_trace("2nd ticket offset: %d",totlen-len);

    GET_BUFFER(creds.second_ticket.data, creds.second_ticket.length, in, len, KRB_MALLOC);
    cuwa_trace("offset: %d",totlen-len);

    // Store in cache

    code = krb5_cc_initialize(ctx, priv->cache, creds.client);
    FAIL_IF_KRB_ERR(code);
    cuwa_trace("krb5_cc_initialize done");

    code = krb5_cc_store_cred(ctx, priv->cache, &creds);
    FAIL_IF_KRB_ERR(code);
    cuwa_trace("krb5_cc_store_cred done");

    if (authtime) *authtime   = creds.times.authtime;
    if (endtime)  *endtime    = creds.times.endtime;

cleanup:

    if (ctx) krb5_free_cred_contents(ctx, &creds);
    cuwa_trace("krb5_free_cred_contents done");

    if (rc && *ksess)
    {
        kutil_end_session(*ksess);
    }

    cuwa_trace("returning: %d",rc);
    return rc;
}

/**
 * Function to print out GSS error.
 * @param[in] pointer to string with function name
 * @param[in] line line number.
 * @param[in] code major code returned by GSS function.
 * @param[in] type minor_code set by GSS function.
 */
void kutil_gss_error(char *func, int line, OM_uint32 code, int type)
{
    OM_uint32 maj_stat, min_stat;
    gss_buffer_desc msgbuf;
    OM_uint32 msg_ctx;

    if (code==GSS_S_FAILURE)
    {
#ifdef WIN32
        if (type==KRB5_FCC_NOFILE)
        {
            cuwa_warning("krb5 (gss) error (%d) %s:%d YOU NEED TO UPGRADE KFW!  No credentials cache found.",type, func, line);
        }
        else
#endif
        {
            cuwa_warning("krb5 (gss) error (%d) %s:%d %s",type, func, line, error_message(type));
        }
        return;
    }

    msg_ctx = 0;
    while (1)
    {
        maj_stat = gss_display_status(&min_stat, code,
                                      type, GSS_C_NULL_OID,
                                      &msg_ctx, &msgbuf);
        if (msgbuf.value)
        {
            cuwa_warning("GSS-API error_%d:%d %s:%d %s", code, type, func, line, (char *)msgbuf.value);
            (void) gss_release_buffer(&min_stat, &msgbuf);
        }
        else
        {
            cuwa_warning("GSS-API error %s:%d unknown codes: %d:%d", func, line, code, min_stat);

            cuwa_trace("gss_display_status: 0x%x, 0x%x, 0x%x", maj_stat, min_stat, code);
        }


        if (!msg_ctx)
            break;
    }
}

/**
 * Function to print out kerberos error.  May get replaced by logging functions.
 * @param[in] pointer to string with function name
 * @param[in] line line number.
 * @param[in] rc the kerberos error.
 */
void kutil_krb_error(char *func, int line, int rc)
{
    cuwa_warning("Kerberos Error_%d in %s:%d %s",rc, func, line, error_message(rc));
}


/**
 * Called by CUWA, this function accepts credentials from CUWL, mid-tier or fat client. Caller must call kutil_end_sec_context to clean release context.
 * @param[out] ctx pointer to the newly created security context.  This context can be used for wrap/unwrap operations.
 * @param[in] bits pointer to inbound credential.
 * @param[in] bitLen length of the inbound cred.
 * @param[in] serviceName kerberos principal, name of the service (should be fully qualified).
 * @param[in] keytabName path to key table file.  Note this is ignored in windows and instead you'll need to set the
 * environment variable KRB5_KTNAME.
 * @param[out] remoteid kerberos principal of the session initiator (usually the user's ID for setting REMOTE_USER).
 * @return success==CUWA_OK, otherwise CUWA_ERR_KRB, CUWA_ERR_GSS, CUWA_ERR_MEM
 */
cuwa_err_t kutil_accept_sec_context(kutil_sec_ctx_t *ctx, char *bits, int bitLen, char *serviceName, char *keytabName, char **remoteid)
{
    OM_uint32 code, minor_status;
    gss_cred_id_t server_creds = GSS_C_NO_CREDENTIAL;
    gss_name_t client;
    gss_buffer_desc output;
    gss_buffer_desc input;
    cuwa_err_t rc = CUWA_OK;
    kutil_context_priv_t *priv;
    gss_OID mech;
    OM_uint32 ret_flags;

    KUTIL_INIT;

    output.value  = NULL;
    output.length = 0;
    input.value   = bits;
    input.length  = bitLen;

    cuwa_assert(ctx);
    cuwa_assert(serviceName);
    cuwa_assert(*serviceName);
    cuwa_assert(keytabName);
    cuwa_assert(*keytabName);

    cuwa_trace("keytab: %s", keytabName);
    cuwa_trace("service: %s", serviceName);

    priv = (kutil_context_priv_t *) cuwa_calloc(1,sizeof(kutil_context_priv_t));
    FAIL_IF(!priv,CUWA_ERR_MEM);

    priv->ctx                = GSS_C_NO_CONTEXT;
    priv->delegated_cred     = GSS_C_NO_CREDENTIAL;
    priv->buf.value          = NULL;
    priv->netid.value        = NULL;

    cuwa_trace("accept_sec_ctx: kutil_context_priv->buf.value=NULL");

    // Hack: Need to look at kerberos ticket to get authtime
    code = kutil_peek_sec_context(priv, bits, bitLen, serviceName, keytabName);
    FAIL_IF(code,code);

	/* Set keytab name - function call doesn't exist in Windows (sigh)
	   For Windows, need to set environment variable KRB5_KTNAME
	   actually this is now in KFW3.2*/
    cuwa_trace("register keytab filename: %s",keytabName);
    code = krb5_gss_register_acceptor_identity(keytabName);
    FAIL_IF_KRB_ERR(code);

    code = kutil_server_acquire_creds(serviceName, &server_creds, 0);
    FAIL_IF(code,code);

    // check the client cred
    /* NOTE undocumented GSS feature: ret_flag parameter can't be NULL or delegated cred won't get populated!! */
    code = gss_accept_sec_context(&minor_status,
                                  &priv->ctx,
                                  server_creds,
                                  &input,
                                  GSS_C_NO_CHANNEL_BINDINGS,
                                  &client,
                                  &mech,
                                  &output,
                                  &ret_flags,
                                  NULL,
                                  &priv->delegated_cred);
    FAIL_IF_GSS_ERR(code,minor_status);

    code = gss_display_name( &minor_status, client, &priv->netid, &mech);
    FAIL_IF_GSS_ERR(code,minor_status);

    *ctx = priv;

    cuwa_trace("accept netid: %s", (char *)priv->netid.value);
    cuwa_trace("accept delegate: %p", priv->delegated_cred);


    *remoteid = priv->netid.value;

cleanup:

    if (output.value)
    {
        (void) gss_release_buffer(&minor_status, &output);
    }

    if (rc && priv)
    {
        cuwa_free(priv);
    }

    return rc;
}


/**
 * Get information about a GSS context
 * @param[in] ctx security context.
 * @param[out] remoteid, the remote netid.  Caller MUST NOT FREE, bytes are only valid as long as security context is valid.
 * @param[out] authtime the time when the user logged in (rough approximation).
 * @param[out] endtime the time when the credential expires.
 * @return success==CUWA_OK, otherwise CUWA_ERR_GSS
 */
cuwa_err_t kutil_inquire_context(kutil_sec_ctx_t ctx, char **localid, char **remoteid, int *authtime, int *endtime, int *starttime)
{
    cuwa_err_t rc = CUWA_OK;
    OM_uint32 code, minor_status;
    gss_name_t source_name;
    gss_name_t target_name;
    OM_uint32 lifetime;
    gss_OID mech;
    int local_is_init;
    kutil_context_priv_t *priv = (kutil_context_priv_t *) ctx;
    gss_buffer_desc target, initiator;

    cuwa_assert(ctx);

    code = gss_inquire_context(&minor_status, priv->ctx, &source_name, &target_name, &lifetime, NULL, NULL, &local_is_init, NULL);
    FAIL_IF_GSS_ERR(code,minor_status);

    if (endtime)   *endtime   = priv->endtime;
    if (starttime) *starttime = priv->starttime;
    if (authtime)  *authtime  = priv->authtime;

    code = gss_display_name( &minor_status, target_name, &target, &mech);
    FAIL_IF_GSS_ERR(code,minor_status);

    code = gss_display_name( &minor_status, source_name, &initiator, &mech);
    FAIL_IF_GSS_ERR(code,minor_status);

    if (local_is_init)
    {
        if (localid)  *localid  = initiator.value;
        if (remoteid) *remoteid = target.value;
    }
    else
    {
        if (localid)  *localid  = target.value;
        if (remoteid) *remoteid = initiator.value;
    }


cleanup:

    /* NOTE: This may get confusing, localid & remoteid strings aren't allocated
             in this operation and can't be freed by caller */

    return rc;
}


/**
 * This function initiates a security context.  This is called by CUWL after the kerberos session is established.
 * kutil_init_sec_context generates a GSS init_sec_context token to be sent to a CUWA site. Caller must call kutil_end_sec_context to clean release context.
 * @param[out] ctx pointer to the newly created security context.  This context can be used for wrap/unwrap operations.
 * @param[in] ctx_delegate context where delegated credentials can be obtained.
 * @param[in] service kerberos principal, name of the service (should be fully qualified).
 * @param[in] delegate delegatable credential is requested.
 * @param[out] bits pointer to outbound credential.  Caller DOES NOT explicitly free this buffer.  This buffer is freed on kutil_end_sec_context call.
 * @param[out] length length of the outbound cred.
 * @return success==CUWA_OK, otherwise CUWA_ERR_KRB, CUWA_ERR_GSS, CUWA_ERR_MEM
 */

cuwa_err_t kutil_init_sec_context(kutil_sec_ctx_t *ctx, kutil_sec_ctx_t ctx_delegate, char *service, int delegate, char **bits, int *length)
{
    OM_uint32 code, minor_status;
    gss_buffer_desc netidBuf;
    gss_name_t target_name = NULL;
    gss_OID actual_mech;
    cuwa_err_t rc = CUWA_OK;
    OM_uint32 avail_services;
    kutil_context_priv_t *priv;
    gss_cred_id_t delegate_cred = GSS_C_NO_CREDENTIAL;

    KUTIL_INIT;

    cuwa_assert(ctx);
    cuwa_assert(service);
    cuwa_assert(*service);
    cuwa_assert(bits);
    cuwa_assert(length);

    if (ctx_delegate)
    {
        delegate_cred = ((kutil_context_priv_t *)ctx_delegate)->delegated_cred;
    }

    priv = (kutil_context_priv_t*) cuwa_calloc(1,sizeof(kutil_context_priv_t));
    FAIL_IF(!priv,CUWA_ERR_MEM);

    priv->ctx                = GSS_C_NO_CONTEXT;
    priv->delegated_cred     = GSS_C_NO_CREDENTIAL;
    priv->buf.value          = NULL;
    priv->netid.value        = NULL;

    cuwa_trace("init_sec_ctx: %s",(delegate_cred == GSS_C_NO_CREDENTIAL)?"normal cred":"proxy cred");
    cuwa_trace("init_sec_ctx: delegation: %s",delegate?"enabled":"disabled");
    cuwa_trace("init_sec_ctx: kutil_context_priv->buf.value=NULL");
    cuwa_trace("getting cred for %s", service);

    netidBuf.value = service;
    netidBuf.length = strlen(service) ;

    code = gss_import_name(&minor_status, &netidBuf, (gss_OID) gss_nt_user_name, &target_name);
    FAIL_IF_GSS_ERR(code,minor_status);

    cuwa_trace("init_sec_ctx: delegate cred = %p",delegate_cred);

    /* Get the service ticket */
    code = gss_init_sec_context(&minor_status, delegate_cred, &priv->ctx,
                                target_name, (gss_OID) gss_mech_krb5, (delegate?GSS_C_DELEG_FLAG:0), GSS_C_INDEFINITE,
                                GSS_C_NO_CHANNEL_BINDINGS, GSS_C_NO_BUFFER, &actual_mech,
                                &priv->buf, &avail_services, NULL);

    cuwa_trace("init_sec_ctx: kutil_context_priv->buf.value=%p",priv->buf.value);

    if (code!=GSS_S_CONTINUE_NEEDED && code!=GSS_S_COMPLETE)
    {
        kutil_gss_error((char*)__func__,__LINE__,code,minor_status);
        rc = CUWA_ERR_GSS;
        goto cleanup;
    }

    cuwa_trace("init_sec_ctx: actual= %s",(avail_services&GSS_C_DELEG_FLAG)?"DELEG":"NONE");

    *bits   = priv->buf.value;
    *length = (int) priv->buf.length;
    *ctx    = (kutil_sec_ctx_t) priv;

cleanup:

    if (rc)
    {
        cuwa_free(priv);
    }

    if (target_name)
    {
        (void) gss_release_name(&minor_status, &target_name);
    }

    return rc;
}

/**
 * This function releases resources associated with a security context.
 * @param[int] ctx security context to release.
 */
void kutil_end_sec_context(kutil_sec_ctx_t ctx)
{
    OM_uint32 minor_status;
    kutil_context_priv_t *priv = (kutil_context_priv_t *) ctx;

    cuwa_assert(ctx);

    if (priv->buf.value)
    {
        cuwa_trace("free priv->buf: %p",priv->buf.value);
        (void) gss_release_buffer(&minor_status, &priv->buf);
    }

    if (priv->netid.value)
    {
        cuwa_trace("gss_release_buffer priv->netid: %p",priv->netid.value);
        (void) gss_release_buffer(&minor_status, &priv->netid);
    }

    if (priv->ctx != GSS_C_NO_CONTEXT)
    {
        cuwa_trace("gss_delete_sec_context priv->ctx: %p",priv->ctx);
        (void) gss_delete_sec_context ( &minor_status, &priv->ctx, GSS_C_NO_BUFFER );
    }

    if (priv->delegated_cred != GSS_C_NO_CREDENTIAL)
    {
        cuwa_trace("gss_delete_sec_context priv->delegated_cred: %p",priv->delegated_cred);
        (void) gss_release_cred ( &minor_status, &priv->delegated_cred );
    }
    cuwa_trace("free priv: %p",priv);
    cuwa_free( priv );
}

/**
 * Utility function used to support accept_sec_context.
 * @param[in] service_name this is the kerberos principal of the local service.
 * @param[out] server_creds gss credential.
 * @return success==CUWA_OK, otherwise CUWA_ERR_GSS
 */
cuwa_err_t kutil_server_acquire_creds(char *service_name, gss_cred_id_t *server_creds, int wantDelegated)
{
    gss_buffer_desc name_buf;
    gss_name_t server_name;
    OM_uint32 maj_stat, min_stat;
    cuwa_err_t rc = CUWA_OK;

    cuwa_trace("acquire_creds: %s",service_name);

    name_buf.value = service_name;
    name_buf.length = strlen(name_buf.value) + 1;
    maj_stat = gss_import_name(&min_stat, &name_buf,
                               (gss_OID) /*gss_nt_service_name*/ gss_nt_krb5_name, &server_name);
    FAIL_IF_GSS_ERR(maj_stat,min_stat);

    maj_stat = gss_acquire_cred(&min_stat, server_name, 0,
                                GSS_C_NULL_OID_SET, (wantDelegated ? GSS_C_BOTH : GSS_C_ACCEPT),
                                server_creds, NULL, NULL);
    if (maj_stat!=GSS_S_COMPLETE)
    {
        // friendly message for webauth error page
        cuwa_warning("%d-%d: There might be a problem with the keytab file for %s.  Check the file path and make sure it is the correct key file. The GSS error was: %s",maj_stat,min_stat,error_message(min_stat),error_message(min_stat));
    }
    FAIL_IF_GSS_ERR(maj_stat,min_stat);

cleanup:

    (void) gss_release_name(&min_stat, &server_name);
    return rc;
}


/**
 * Basically gss_wrap with some assertions thrown in
 * Here are some constants that may be used instead of the default encryption...
 *   Quality of protection constants, obscured from GSS :-(
 *      GSS_KRB5_INTEG_C_QOP_MD5       (partial* MD5 = "MD2.5" )
 *      GSS_KRB5_INTEG_C_QOP_DES_MD5
 *      GSS_KRB5_INTEG_C_QOP_DES_MAC
 *      GSS_KRB5_INTEG_C_QOP_HMAC_SHA1
 *      GSS_KRB5_INTEG_C_QOP_MASK
 *      GSS_KRB5_CONF_C_QOP_DES
 *      GSS_KRB5_CONF_C_QOP_DES3_KD
 *      GSS_KRB5_CONF_C_QOP_MASK
 * @param[in] ctx security context.
 * @param[in] in pointer to buffer to wrap.
 * @param[in] inLen length of buffer to wrap.
 * @param[out] out pointer to buffer that is allocated by kutil_wrap.  Caller must call kutil_release_buffer.
 * @param[out] outLen length of wrapped output returned.
 * @return success==CUWA_OK, otherwise CUWA_ERR_GSS, CUWA_ERR_MEM
 */
cuwa_err_t kutil_wrap(kutil_sec_ctx_t ctx, char *in, int inLen, char **out, int *outLen)
{
    OM_uint32 minor_status;
    kutil_context_priv_t *priv = (kutil_context_priv_t *) ctx;
    cuwa_err_t rc = CUWA_OK;
    gss_buffer_desc input;
    gss_buffer_desc output;
    int code;

    cuwa_assert(ctx);
    cuwa_assert(in);
    cuwa_assert(out);
    cuwa_assert(outLen);
    cuwa_assert(inLen);

    input.value  = in;
    input.length = inLen;
    output.value = NULL;

    code = gss_wrap(&minor_status, priv->ctx, TRUE, GSS_C_QOP_DEFAULT, &input, NULL, &output);
    FAIL_IF_GSS_ERR(code,minor_status);

    *out    = output.value;
    *outLen = (int) output.length;

cleanup:

    if (rc && output.value)
    {
        (void) gss_release_buffer(&minor_status, &output);
    }

    return rc;
}

/**
 * Basically gss_unwrap with some assertions thrown in
 * @param[in] ctx security context.
 * @param[in] in pointer to buffer to unwrap.
 * @param[in] inLen length of buffer to unwrap.
 * @param[out] out pointer to buffer that is allocated by kutil_unwrap.  Caller must call kutil_release_buffer.
 * @param[out] outLen length of wrapped output returned.
 * @return success==CUWA_OK, otherwise CUWA_ERR_GSS, CUWA_ERR_MEM
 */
cuwa_err_t kutil_unwrap(kutil_sec_ctx_t ctx, char *in, int inLen, char **out, int *outLen)
{
    OM_uint32 minor_status;
    kutil_context_priv_t *priv = (kutil_context_priv_t *) ctx;
    cuwa_err_t rc = CUWA_OK;
    gss_qop_t qop_state;
    int conf_state;
    gss_buffer_desc input;
    gss_buffer_desc output;
    int code;

    cuwa_assert(ctx);
    cuwa_assert(in);
    cuwa_assert(out);
    cuwa_assert(outLen);
    cuwa_assert(inLen);

    input.value  = in;
    input.length = inLen;
    output.value = NULL;

    code = gss_unwrap(&minor_status, priv->ctx, &input, &output, &conf_state, &qop_state);
    FAIL_IF_GSS_ERR(code,minor_status);

    cuwa_trace("gss_unwrap output=%p",output.value);

    /* make sure it was encrypted */
    FAIL_IF(!conf_state,CUWA_ERR_BAD_UNWRAP);

    cuwa_trace("QOP state: %d",qop_state);

    *out    = output.value;
    *outLen = (int) output.length;

cleanup:

    if (rc && output.value)
    {
        (void) gss_release_buffer(&minor_status, &output);
        *out = NULL;
    }

    return rc;
}

/**
 * Release buffer created by wrap and unwrap functions.
 * @param[in] ctx security context.
 * @param[in] buf to release.
 * @param[in] len length of buffer to release.
 */
void kutil_release_buffer(char *buf, int len)
{
    gss_buffer_desc desc;
    OM_uint32 minor_status;

    cuwa_assert(buf);

    desc.value  = buf;
    desc.length = len;

    (void) gss_release_buffer(&minor_status, &desc);
}

/**
 * Clean up a krb5 authentication context (client<->server).
 * @param[in] ctx Kerberos authentication context.
 */
void kutil_end_krb_context(kutil_krb_ctx_t ctx)
{
    kutil_krb_ctx_priv_t *ctxp = (kutil_krb_ctx_priv_t*) ctx;

    cuwa_assert( ctx );

    if (ctxp->session)
    {

        cuwa_trace("kutil_end_krb_context krb5_auth_con_free" );
        krb5_auth_con_free(ctxp->session->ctx,ctxp->auth_ctx);

        if (ctxp->free_session)
        {
            cuwa_trace("kutil_end_krb_context kutil_end_session" );
            kutil_end_session(ctxp->session);
            ctxp->free_session = 0;
        }
    }

    cuwa_free(ctxp);
}

/**
 * Get an initial ticket using keytab.  If serviceid is NULL, gets a TGT.
 * @param[in] ksess the kerberos session state
 * @param[in] serviceid the name of the local id whose key is in the keytab
 * @return success==CUWA_OK, otherwise CUWA_ERR_KRB
 */
cuwa_err_t kutil_get_initial_tkt_key(kutil_session_t ksess, char *keytab, char *serviceid)
{
    kutil_session_priv_t *priv = (kutil_session_priv_t *) ksess;
    krb5_creds creds;
    int code = 0;
    cuwa_err_t rc = CUWA_OK;
    krb5_keytab k5keytab;
    krb5_get_init_creds_opt *opts = NULL;

    memset((char *)&creds, 0, sizeof(creds));

    code = krb5_parse_name(priv->ctx, serviceid, &creds.client);
    FAIL_IF_KRB_ERR(code);

    code = krb5_cc_initialize(priv->ctx, priv->cache, creds.client);
    FAIL_IF_KRB_ERR(code);

    /* Build the name of the TGS */
    code = krb5_build_principal_ext(priv->ctx, &creds.server,
                                    creds.client->realm.length,
                                    creds.client->realm.data,
                                    KRB5_TGS_NAME_SIZE,
                                    KRB5_TGS_NAME,
                                    creds.client->realm.length,
                                    creds.client->realm.data,
                                    0);
    FAIL_IF_KRB_ERR(code);

    code = krb5_kt_resolve(priv->ctx, keytab, &k5keytab);
    FAIL_IF_KRB_ERR(code);

    code = krb5_get_init_creds_opt_alloc(priv->ctx, &opts);
    FAIL_IF_KRB_ERR(code);

    krb5_get_init_creds_opt_set_forwardable(opts, 1);
    krb5_get_init_creds_opt_set_proxiable(opts, 1);

    code = krb5_get_init_creds_keytab(priv->ctx, &creds, creds.client, k5keytab,0, NULL, opts);
    FAIL_IF_KRB_ERR(code);

    code = krb5_cc_store_cred( priv->ctx, priv->cache, &creds);
    FAIL_IF_KRB_ERR(code);

    krb5_unparse_name(priv->ctx, creds.client, &priv->user);

cleanup:

    if (opts)
        krb5_get_init_creds_opt_free(priv->ctx, opts);

    krb5_free_cred_contents(priv->ctx, &creds);

    return rc;
}


/**
 * Interface to krb5_make_req. Assumes that we have a TGT (kutil_session_t).
 * @param[out] ctx Kerberos authentication context.
 * @param[in] ksess kerberos login session.
 * @param[in] remoteid principal of the remote service.
 * @param[out] req the bytes to be sent to server, CALLER MUST FREE.
 * @param[out] req_len number of bytes to be sent to server.
 */
cuwa_err_t kutil_make_req( kutil_krb_ctx_t *ctx, kutil_session_t ksess, char *remoteid, char **req, int *req_len )
{
    int code = 0;
    cuwa_err_t rc = CUWA_OK;
    kutil_session_priv_t *priv = (kutil_session_priv_t*) ksess;
    kutil_krb_ctx_priv_t *ctxp;
    krb5_creds creds;
    krb5_creds *st_creds = NULL;
    krb5_data reqout;
    krb5_address *addr,*addr2;

    KUTIL_INIT;

    memset(&creds,0,sizeof(creds));

    cuwa_assert( ctx );
    cuwa_assert( ksess );
    cuwa_assert( remoteid );
    cuwa_assert( req );
    cuwa_assert( req_len );

    ctxp = (kutil_krb_ctx_priv_t*) cuwa_calloc(1,sizeof(kutil_krb_ctx_priv_t));
    FAIL_IF(!ctxp,CUWA_ERR_MEM);

    ctxp->free_session = 0;
    ctxp->session      = priv;

    code = krb5_cc_get_principal(priv->ctx, priv->cache, &creds.client);
    FAIL_IF_KRB_ERR(code);

    code = krb5_parse_name(priv->ctx, remoteid, &creds.server);
    FAIL_IF_KRB_ERR(code);

    /* Disable replay cache */
    code = krb5_auth_con_init(priv->ctx, &ctxp->auth_ctx);
    FAIL_IF_KRB_ERR(code);

    code = krb5_auth_con_setflags(priv->ctx, ctxp->auth_ctx, KRB5_AUTH_CONTEXT_RET_TIME);
    FAIL_IF_KRB_ERR(code);

    /* Get the service ticket */
    code = krb5_get_credentials(priv->ctx, 0, priv->cache, &creds, &st_creds);
    FAIL_IF_KRB_ERR(code);

    /* Zeroed addresses, we don't need the address check */
    code = kutil_mk_addr( &addr, 0 );
    FAIL_IF(code,code);

    code = kutil_mk_addr( &addr2, 0 );
    FAIL_IF(code,code);

    code = krb5_auth_con_setaddrs(priv->ctx, ctxp->auth_ctx, addr, addr2);
    FAIL_IF_KRB_ERR(code);

    /* Make the request bytes */
    code = krb5_mk_req_extended(priv->ctx, &ctxp->auth_ctx, AP_OPTS_MUTUAL_REQUIRED, NULL, st_creds, &reqout);
    FAIL_IF_KRB_ERR(code);

    *req_len = reqout.length;
    *req     = reqout.data;
    *ctx     = ctxp;

cleanup:

    krb5_free_cred_contents(priv->ctx, &creds);

    if (rc && ctxp)
    {
        cuwa_free(ctxp);
    }

    if (st_creds)
    {
        krb5_free_creds(priv->ctx, st_creds);
    }

    return rc;
}

/**
 * Interface to krb5_rd_req. Accepts authentication context from client.
 * @param[out] ctx Kerberos authentication context.
 * @param[in] req the bytes to be recieved from client.
 * @param[in] req_len number of bytes to be sent to server.
 * @param[in] localid principal of the local service.
 * @param[in] keytab containing key for local service.
 * @param[out] remoteid principal of the remote client.
 */
cuwa_err_t kutil_rd_req(kutil_krb_ctx_t *ctx, char *req, int req_len, char *localid, char *keytab, char **remoteid )
{
    int code = 0;
    cuwa_err_t rc = CUWA_OK;
    kutil_session_priv_t *priv = NULL;
    kutil_krb_ctx_priv_t *ctxp = NULL;
    krb5_data reqin;
    krb5_ticket *tkt = NULL;
    krb5_principal server = NULL;
    krb5_keytab k5keytab;
    krb5_address *addr, *addr2;

    KUTIL_INIT;

    cuwa_assert( ctx );
    cuwa_assert( req );
    cuwa_assert( req_len );
    cuwa_assert( localid );
    cuwa_assert( keytab );
    cuwa_assert( remoteid );

    reqin.length = req_len;
    reqin.data   = req;

    ctxp = (kutil_krb_ctx_priv_t*) cuwa_calloc(1,sizeof(kutil_krb_ctx_priv_t));
    FAIL_IF(!ctxp,CUWA_ERR_MEM);

    priv = (kutil_session_priv_t*) cuwa_calloc(1,sizeof(kutil_session_priv_t));
    FAIL_IF(!priv,CUWA_ERR_MEM);

    ctxp->session      = priv;
    ctxp->free_session = 1;

    code = krb5_init_context(&priv->ctx);
    FAIL_IF_KRB_ERR(code);

    code = krb5_parse_name(priv->ctx, localid, &server);
    FAIL_IF_KRB_ERR(code);

    /* Disable replay cache */
    code = krb5_auth_con_init(priv->ctx, &ctxp->auth_ctx);
    FAIL_IF_KRB_ERR(code);

    code = krb5_auth_con_setflags(priv->ctx, ctxp->auth_ctx, KRB5_AUTH_CONTEXT_RET_TIME);
    FAIL_IF_KRB_ERR(code);

    code = krb5_kt_resolve(priv->ctx, keytab, &k5keytab);
    FAIL_IF_KRB_ERR(code);

    /* Zeroed addresses, we don't need the address check */
    code = kutil_mk_addr( &addr, 0 );
    FAIL_IF(code,code);

    code = kutil_mk_addr( &addr2, 0 );
    FAIL_IF(code,code);

    code = krb5_auth_con_setaddrs(priv->ctx, ctxp->auth_ctx, addr, addr2);
    FAIL_IF_KRB_ERR(code);

    code = krb5_rd_req(priv->ctx, &ctxp->auth_ctx, &reqin, server, k5keytab, NULL, &tkt);
    if(2==code) cuwa_warning("krb5_rd_req returned file not found. Check that %s exists and is a keytab for %s",keytab,localid);
    else if(code) cuwa_warning("krb5_rd_req returned %d: %s. Check that %s is the correct keytab for %s", code, error_message(code), keytab, localid);
    FAIL_IF_KRB_ERR(code);

    cuwa_assert(tkt->enc_part2);

    code = krb5_unparse_name(priv->ctx, tkt->enc_part2->client, remoteid);
    FAIL_IF_KRB_ERR(code);

    ctxp->authtime = tkt->enc_part2->times.authtime;
    ctxp->starttime = tkt->enc_part2->times.starttime;
    ctxp->endtime = tkt->enc_part2->times.endtime;

    *ctx = ctxp;

cleanup:

    if (server)
    {
        krb5_free_principal(priv->ctx,server);
    }

    if (tkt)
    {
        krb5_free_ticket(priv->ctx,tkt);
    }

    if (rc)
    {
        if (priv->ctx)
        {
            krb5_free_context(priv->ctx);
            priv->ctx = NULL;
        }

        if (ctxp)
        {
            cuwa_free(ctxp);
        }

        if (priv)
        {
            cuwa_free(priv);
        }
    }

    cuwa_trace("kutil_rd_req: %d",rc);
    return rc;
}


/**
 * Peek at the ICT to extract the authtime.
 * @param[in/out] ctx pointer to security context.  Output will be the setting of ctx->authtime only.
 * @param[in] bits pointer to inbound credential.
 * @param[in] bitLen length of the inbound cred.
 * @param[in] serviceName kerberos principal, name of the service (should be fully qualified).
 * @param[in] keytabName path to key table file.  Note this is ignored in windows and instead you'll need to set the
 * environment variable KRB5_KTNAME.
 * @return success==CUWA_OK, otherwise CUWA_ERR_KRB
 */
cuwa_err_t kutil_peek_sec_context(kutil_sec_ctx_t ctx, char *bits, int bitLen, char *serviceName, char *keytabName)
{
    kutil_krb_ctx_t krbctx = NULL;
    kutil_context_priv_t *priv = (kutil_context_priv_t *) ctx;
    cuwa_err_t code;
    char *remoteid;
    cuwa_err_t rc=CUWA_OK;

    // Skip the GSS header
    code = kutil_ict_to_ap_req(bits, bitLen, &bits, &bitLen);
    FAIL_IF(code,code);

    code = kutil_rd_req(&krbctx, bits, bitLen, serviceName, keytabName, &remoteid );
    FAIL_IF(code,code);

    // Move kerberos ticket time values into GSS ctx structure for use after gss_accept_sec_context...
    priv->authtime  = ((kutil_krb_ctx_priv_t *)krbctx)->authtime;
    priv->starttime = ((kutil_krb_ctx_priv_t *)krbctx)->starttime;
    priv->endtime   = ((kutil_krb_ctx_priv_t *)krbctx)->endtime;

    cuwa_trace("kutil_peek_sec_context remoteid:%s, authtime=%d",remoteid, priv->authtime );

cleanup:

    if (krbctx) kutil_end_krb_context(krbctx);
    return rc;
}

/**
 * Jump past the GSS header in an ICT, so that the kerberos ap_req structure can be retrieved.
 * @param[in] buf pointer to ICT.
 * @param[in] blen length ICT.
 * @param[out] buf_out pointer to ap_req struct.
 * @param[out] blen_out length of the ap_req struct
 * @return success==CUWA_OK, otherwise CUWA_ERR_BAD_CRED
 */
cuwa_err_t kutil_ict_to_ap_req(char *buf, int blen, char **buf_out, int *blen_out)
{
    unsigned char *byte, *mech, *buf1;
    int i, len, lbytes;
    cuwa_err_t rc=CUWA_OK;

    buf1 = (unsigned char *)buf;

    PEEK_BYTES(byte,1,buf1,blen);
    FAIL_IF((*byte!=0x60),CUWA_ERR_BAD_CRED);

    PEEK_BYTES(byte,1,buf1,blen);
    if (*byte & 0x80)
    {
        lbytes = *byte & 0x7f;
        FAIL_IF((lbytes>sizeof(int)),CUWA_ERR_BAD_CRED);

        len = 0;
        for (i=lbytes;i>0;i--)
        {
            PEEK_BYTES(byte,1,buf1,blen);
            len = (len<<8) + *byte;
        }
    }
    else len = *byte;

    FAIL_IF(len!=blen,CUWA_ERR_BAD_CRED);

    PEEK_BYTES(byte,1,buf1,blen);
    FAIL_IF((*byte!=0x06),CUWA_ERR_BAD_CRED);

    PEEK_BYTES(byte,1,buf1,blen);
    len = *byte;
    PEEK_BYTES(mech,len,buf1,blen);

    PEEK_BYTES(byte,1,buf1,blen);
    FAIL_IF((*byte!=0x01),CUWA_ERR_BAD_CRED);
    PEEK_BYTES(byte,1,buf1,blen);
    FAIL_IF((*byte!=0x00),CUWA_ERR_BAD_CRED);

    *buf_out  = (char *)buf1;
    *blen_out = blen;

cleanup:

    return rc;
}


/**
 * Interface to krb5_rd_rep. Reads a mutual authenticator.
 * @param[in] ctx Kerberos authentication context.
 * @param[in] rep the authenticator.
 * @param[in] rep_len number of bytes received.
 */
cuwa_err_t kutil_rd_rep( kutil_krb_ctx_t ctx, char *rep, int rep_len )
{
    int code = 0;
    cuwa_err_t rc = CUWA_OK;
    krb5_data rep_data;
    krb5_ap_rep_enc_part *rep_content = NULL;
    kutil_krb_ctx_priv_t *ctxp = (kutil_krb_ctx_priv_t*) ctx;

    cuwa_assert(ctx);
    cuwa_assert(ctxp->session);
    cuwa_assert(ctxp->auth_ctx);
    cuwa_assert(rep);
    cuwa_assert(rep_len);

    rep_data.data   = rep;
    rep_data.length = rep_len;

    code = krb5_rd_rep(ctxp->session->ctx, ctxp->auth_ctx, &rep_data, &rep_content);
    FAIL_IF_KRB_ERR(code);

cleanup:

    if (rep_content)
    {
        krb5_free_ap_rep_enc_part(ctxp->session->ctx, rep_content);
    }

    return rc;
}

/**
 * Interface to krb5_mk_priv. Encrypts arbitrary bytes along with timestamp.
 * @param[in] ctx Kerberos authentication context.
 * @param[in] in clear text.
 * @param[in] in_len number of bytes of clear text.
 * @param[out] out cipher text.
 * @param[out] out_len number of bytes of cipher text.
 */
cuwa_err_t kutil_mk_priv( kutil_krb_ctx_t ctx, char *in, int in_len, char **out, int *out_len )
{
    int code = 0;
    cuwa_err_t rc = CUWA_OK;
    kutil_krb_ctx_priv_t *ctxp = (kutil_krb_ctx_priv_t*) ctx;
    krb5_data dataIn, dataOut;
    krb5_replay_data replay;

    cuwa_assert( ctx );
    cuwa_assert( in );
    cuwa_assert( in_len>0 );
    cuwa_assert( out );
    cuwa_assert( out_len );

    memset(&replay,0,sizeof(replay));

    dataIn.length  = in_len;
    dataIn.data    = in;
    dataOut.length = 0;
    dataOut.data   = NULL;

    code = krb5_mk_priv(ctxp->session->ctx, ctxp->auth_ctx, &dataIn, &dataOut, &replay);
    FAIL_IF_KRB_ERR(code);
    *out_len = dataOut.length;
    *out     = dataOut.data;

cleanup:

    return rc;
}


/**
 * Interface to krb5_rd_priv. Decrypts cipher text created with kutil_mk_priv.
 * @param[in] ctx Kerberos authentication context.
 * @param[in] in cipher text.
 * @param[in] in_len number of bytes of cipher text.
 * @param[out] out clear text.
 * @param[out] out_len number of bytes of clear text.
 */
cuwa_err_t kutil_rd_priv( kutil_krb_ctx_t ctx, char *in, int in_len, char **out, int *out_len )
{
    int code = 0;
    cuwa_err_t rc = CUWA_OK;
    kutil_krb_ctx_priv_t *ctxp = (kutil_krb_ctx_priv_t*) ctx;
    krb5_data dataIn, dataOut;
    krb5_replay_data replay;

    cuwa_assert( ctx );
    cuwa_assert( ctxp->auth_ctx );
    cuwa_assert( ctxp->session );
    cuwa_assert( ctxp->session->ctx );
    cuwa_assert( in );
    cuwa_assert( in_len>0 );
    cuwa_assert( out );
    cuwa_assert( out_len );

    dataIn.data   = in;
    dataIn.length = in_len;

    code = krb5_rd_priv(ctxp->session->ctx, ctxp->auth_ctx, &dataIn, &dataOut, &replay);
    FAIL_IF_KRB_ERR(code);
    *out_len = dataOut.length;
    *out     = dataOut.data;

cleanup:

    return rc;

}

/**
 * Create a krb5_address structure, given an internet address.  Currently this is used to create
 * a zeroed address because we are ignoring the IP address.
 * @param[out] addr_ret Address structure to return, caller must free.
 * @param[in] inaddr internet address.
 */
cuwa_err_t kutil_mk_addr( krb5_address **addr_ret, struct in_addr *inaddr )
{
    cuwa_err_t rc = CUWA_OK;
    krb5_address *addr = NULL;
    char *data = NULL;
    int32 netaddr = inaddr?inaddr->s_addr:0;

    cuwa_assert( addr_ret );

    addr = cuwa_malloc(sizeof(krb5_address));
    FAIL_IF(!addr,CUWA_ERR_MEM);

    data = cuwa_malloc(sizeof(netaddr));
    FAIL_IF(!addr,CUWA_ERR_MEM);
    memcpy(data,&netaddr,sizeof(netaddr));

    addr->magic = KV5M_ADDRESS;
    addr->addrtype = ADDRTYPE_INET;
    addr->length = sizeof(netaddr);
    addr->contents = (krb5_octet*) data;

    *addr_ret = addr;

cleanup:

    if (rc)
    {
        if (addr)
        {
            cuwa_free(addr);
        }

        if (data)
        {
            cuwa_free(data);
        }
    }

    return rc;
}

 cuwa_err_t kutil_compare_names(char *name1, char *name2, int *equal)
 {
    cuwa_err_t rc = CUWA_OK;
    OM_uint32 code;
    OM_uint32 minor_status;
    gss_buffer_desc buf;
    gss_name_t gssname1, gssname2;

    cuwa_trace("kutil_compare_names %s and %s",name1,name2);

    buf.value  = name1;
    buf.length = strlen(name1);
    code = gss_import_name( &minor_status, &buf, (gss_OID) gss_nt_krb5_name,  &gssname1);
    FAIL_IF_GSS_ERR(code,minor_status);

    buf.value  = name2;
    buf.length = strlen(name2);
    code = gss_import_name( &minor_status, &buf, (gss_OID) gss_nt_krb5_name,  &gssname2);
    FAIL_IF_GSS_ERR(code,minor_status);

    code = gss_compare_name(&minor_status, gssname1,gssname2,equal);
    FAIL_IF_GSS_ERR(code,minor_status);

cleanup:

    /* Although it looks like we should need a cleanup gssname1 and gssname2, documentation doesn't mention the need.
    Guess we'll have to wait and see if it leaks like a sieve. */

    cuwa_trace("kutil_compare_names rc=%d and equal=%d",rc,*equal);

    return rc;
 }

 /**
 * OBSOLETE... This function takes a TGT (delegated) from a GSS security context and
 * it copies the TGT to a newly created kerberos ticket cache which it associates
 * with a new kutil_session_t.  This becomes the default cache for subsequest
 * GSS ticket requests.  The end result of this call is functionally equivalent to
 * kutil_login in that kutil_session_t is allocated and initialized, and the kerberos ticket
 * cache is populated with a TGT.
 * @param[out] ksess Kerberos authentication context, associated with ticket cache.  Must call kutil_end_session.
 * @param[in] ctx associated with GSS security context.
 */
cuwa_err_t kutil_stow_gss_cred(kutil_session_t *ksess, kutil_sec_ctx_t ctx)
{
    cuwa_err_t err;
    cuwa_err_t rc = CUWA_OK;
    kutil_context_priv_t *priv = (kutil_context_priv_t *) ctx;
    kutil_session_priv_t *sess;
    krb5_error_code code;
    krb5_principal princ = NULL;
    OM_uint32 minor_status;

    *ksess = NULL;

    if (priv->delegated_cred)
    {
        err = kutil_init_session(ksess);
        FAIL_IF(err,err);
        sess = (kutil_session_priv_t*) *ksess;

        code = krb5_parse_name(sess->ctx, priv->netid.value, &princ);
        FAIL_IF_KRB_ERR(code);

        code = krb5_cc_initialize(sess->ctx, sess->cache, princ);
        FAIL_IF_KRB_ERR(code);

        if (priv->delegated_cred)
        {
            gss_krb5_copy_ccache(&minor_status, priv->delegated_cred, sess->cache);
        }
    }

cleanup:

    return rc;
}



// FIXME: this is a lot of dup'd code from kutil_save_session, need to consolidate!!
cuwa_err_t kutil_get_times( kutil_session_t ksess, int *authtime, int *starttime, int *endtime, int *renew_till)
{
    int code;
    cuwa_err_t rc = CUWA_OK;
    krb5_data *realm;
    krb5_creds creds, tgtq;
    kutil_session_priv_t *priv = (kutil_session_priv_t *) ksess;

    cuwa_assert( priv );

    memset(&tgtq, 0, sizeof(tgtq));
    memset(&creds, 0, sizeof(creds));

    /* Get login principal name */
    code = krb5_cc_get_principal(priv->ctx, priv->cache, &tgtq.client);
    FAIL_IF_KRB_ERR(code);

    /* Get login realm */
    realm = krb5_princ_realm(priv->ctx, tgtq.client);

    /* Get TGS name */
    code = krb5_build_principal_ext(priv->ctx,
                                    &tgtq.server,
                                    realm->length,
                                    realm->data,
                                    KRB5_TGS_NAME_SIZE,
                                    KRB5_TGS_NAME,
                                    realm->length,
                                    realm->data,
                                    0);
    FAIL_IF_KRB_ERR(code);

    /* Get TGT Cred... */
    code = krb5_cc_retrieve_cred(priv->ctx, priv->cache,
                                 KRB5_TC_MATCH_SRV_NAMEONLY,
                                 &tgtq, &creds);
    FAIL_IF_KRB_ERR(code);

    if (authtime)   *authtime   = creds.times.authtime;
    if (starttime)  *starttime  = creds.times.starttime;
    if (endtime)    *endtime    = creds.times.endtime;
    if (renew_till) *renew_till = creds.times.renew_till;

cleanup:

    krb5_free_cred_contents(priv->ctx, &creds);
    krb5_free_cred_contents(priv->ctx, &tgtq);

    return rc;
}


cuwa_err_t kutil_dump_cache(kutil_session_t ksess)
{
    cuwa_err_t rc = CUWA_OK;
    kutil_session_priv_t *priv = (kutil_session_priv_t*)  ksess;
    krb5_cc_cursor cursor;
    krb5_error_code code;
    krb5_creds creds;
    char *client,*server;

    cuwa_trace("DUMP Cache..............");
    code = krb5_cc_start_seq_get( priv->ctx, priv->cache, &cursor);
    FAIL_IF_KRB_ERR(code);
    code = krb5_cc_next_cred( priv->ctx, priv->cache, &cursor, &creds);
    while (!code)
    {
        client = NULL; server = NULL;
        if (creds.client)
        {
            code = krb5_unparse_name(priv->ctx, creds.client, &client);
            FAIL_IF_KRB_ERR(code);
        }

        if (creds.server)
        {
            code = krb5_unparse_name(priv->ctx, creds.server, &server);
            FAIL_IF_KRB_ERR(code);
        }
        cuwa_trace(" CRED: %s...%s",client,server);
        if (client) cuwa_free(client);
        if (server) cuwa_free(server);

        code = krb5_cc_next_cred( priv->ctx, priv->cache, &cursor, &creds);
    }
    krb5_cc_end_seq_get(priv->ctx, priv->cache, &cursor);

cleanup:

    return rc;
}

int kutil_dump_sec_context(kutil_sec_ctx_t ctx)
{
    kutil_context_priv_t *priv = (kutil_context_priv_t *) ctx;

    cuwa_assert(ctx);
    
    cuwa_trace("sec_ctx BUF: %p",priv->buf.value);
    cuwa_trace("sec_ctx LEN: %d",priv->buf.length);
    return 0;
}

/**
 * Return the user for this login session.
 * @param[in] ksess the session
 * @param[out] the user name
 */
char * kutil_get_session_user(kutil_session_t ksess)
{
    kutil_session_priv_t *priv = (kutil_session_priv_t *) ksess;
    cuwa_assert( ksess );
    return priv->user;
}

char * kutil_get_cache_name(char *buffer)
{
    // fixme: must use thread specific value for all platforms in order for code to be thread safe.
#ifdef WIN32
    sprintf(buffer,"%s%X",CACHE_NAME, GetCurrentThreadId());
    return buffer;
#else
    sprintf(buffer,"%s%X",CACHE_NAME,(unsigned int)apr_os_thread_current());
    cuwa_trace("cache name:%s",buffer);
    return buffer;
#endif
}


const char id_cred_kutil_c[] = "$Id: kutil.c,v 1.52 2015/10/07 17:37:10 hy93 Exp $";

