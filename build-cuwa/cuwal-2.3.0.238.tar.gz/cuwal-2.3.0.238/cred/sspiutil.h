/************************************************************************
 * sspiutil.h -- Support for microsoft's SSPI
 *
 * Copyright 2009 Cornell University.
 * All Rights Reserved.
 *
 ************************************************************************
 */

#ifndef _SSPIUTIL_H
#define _SSPIUTIL_H
#include <cred.h>

#ifdef IIS_BUILD
#include <apr_pools.h>
void sspiutil_accept_sec_context(cuwa_cred_t *cred, char *bits, int bitLen, char *serviceName);
int sspiutil_restore_sec_context(cuwa_cred_t *cred);
cuwa_err_t sspiutil_init(apr_pool_t *pool);
void sspiutil_begin_ctx();
void sspiutil_revert_ctx();
#else
#define sspiutil_accept_sec_context(a,b,c,d) 
#define sspiutil_restore_sec_context(a) 0
#endif

#endif

