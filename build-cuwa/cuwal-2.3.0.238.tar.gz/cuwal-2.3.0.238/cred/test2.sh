#!/bin/sh

LD_LIBRARY_PATH=/home/pb10/authbuild/krb5-1.6.2/lib:$LD_LIBRARY_PATH
export LD_LIBRARY_PATH

./test_cred ns10-demo "\$tester" "web-agent/bosanko@CIT.CORNELL.EDU" ~/bosanko.keytab
