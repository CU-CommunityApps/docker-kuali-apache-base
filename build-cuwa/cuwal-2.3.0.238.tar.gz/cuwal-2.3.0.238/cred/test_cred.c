#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <kutil.h>
#include <log.h>
#include <cred_base64.h>
#include <cred.h>
#include <cred_krb.h>
#include <cuwa_err.h>
#include <cuwa_malloc.h>

#define CUWA2_LOG_DOMAIN cuwa.cred

void HexDump( char *label, void *ptr, int len);
void cred_test(char *netid, char *password, char *serviceid, char *keytab);
static char *thehost = "http://localhost";

#define syntax_check(c) do {if(argc<c){ printf("syntax: test_cred netid password serviceid keytab\n"); return 0;}} while (0)


int main(int argc, char* argv[])
{
    syntax_check(4);

    cred_test(argv[1],argv[2],argv[3],argv[4]);

    return 0;
}


void cred_test(char *netid, char *password, char *serviceid, char *keytab)
{
    cuwa_err_t err, rc = 0;
    kutil_session_t ksess = NULL;
    char *k1=NULL, *k1_64=NULL, *k2=NULL, *k2_64=NULL, *k22=NULL, *k23=NULL, *k24=NULL, *wa=NULL, *dwa=NULL, *proxy=NULL;
    int k1len, k1_64Len, k2len, k2_64Len, k22Len, k23Len, waLen, dwaLen, k24Len, proxyLen;
    cuwa_cred_t *cred = NULL;
    int64 sessionid = 0xBABADABABADABAD0LL;
    char *waText = "This is a test. Hi there.";

    printf("-------------------------------------\n");
    printf("Testing Base64 functions...\n");
    printf("-------------------------------------\n");

    waLen = cuwa_base64_encode_bytes(strlen(waText));
    printf("encode bytes will be %d\n",waLen);
    wa = malloc(waLen);
    FAIL_IF(!wa,CUWA_ERR_MEM);
    cuwa_base64_encode(waText,strlen(waText),wa);
    HexDump("WA",wa,waLen);

    dwaLen = cuwa_base64_decode_bytes(wa);
    dwa = malloc(dwaLen);
    FAIL_IF(!dwa,CUWA_ERR_MEM);
    dwaLen = cuwa_base64_decode(wa,dwa);
    HexDump("DWA",dwa,dwaLen);

    printf("-------------------------------------\n");
    printf("Testing Cred functions...\n");
    printf("-------------------------------------\n");

    printf("Performing weblogin using netid/password...\n");
    err = kutil_login(&ksess, netid, password);
    FAIL_IF(err,err);

    printf("-------------------------------------\n");
    printf("Create K1...\n");
    err = cuwa_krb_make_k1( ksess, &k1, &k1len);
    FAIL_IF(err,err);

    printf("K1 is %p, length %d...\n",k1,k1len);
    printf("Create WA wrap of %d bytes...\n",k1len);
    err = cuwa_base64_make_wa(&k1_64, &k1_64Len, k1len, 1, k1, k1len, NULL);
    FAIL_IF(err,err);

    printf("K1 is still %p...\n",k1);

    printf("-------------------------------------\n");
    printf("Create K2...\n");
    err = cuwa_krb_make_k2( NULL, thehost, serviceid, &sessionid, 1, &k2, &k2len, NULL );
    FAIL_IF(err,err);

    printf("Create WA wrap of %d bytes...\n",k2len);
    HexDump("bin",k2, k2len);
    err = cuwa_base64_make_wa(&k2_64, &k2_64Len, k2len, 1, k2, k2len, NULL);
    FAIL_IF(err,err);

    printf("End local session...\n");
    kutil_end_session(ksess);
    ksess = NULL;

    printf("Performing webauth...\n");

    printf("-------------------------------------\n");
    printf("test kutil_login_key...\n");
    err = kutil_login_key(&ksess, serviceid, keytab);
    FAIL_IF(err,err);

    printf("End local session...\n");
    kutil_end_session(ksess);
    ksess = NULL;

    printf("-------------------------------------\n");
    printf("Parse K2...\n");
    err = cuwa_cred_parse( &cred, k2_64, k2_64Len, serviceid, keytab, thehost, NULL );
    FAIL_IF(err,err);

    printf("Create proxy K2...\n");
    err = cuwa_krb_make_k2( cred, thehost, serviceid, &sessionid, 1, &k22, &k22Len, NULL );
    FAIL_IF(err,err);

    printf("Release cred...\n");
    cuwa_cred_release(cred);
    cred = NULL;


    printf("-------------------------------------\n");
    printf("Test Delegation support\n");
    printf("... Generate a K2\n");
    printf("-------------------------------------\n");


    printf("LOGIN...\n");
    err = kutil_login(&ksess, netid, password);
    FAIL_IF(err,err);

    err = cuwa_krb_make_k2( NULL, thehost, serviceid, &sessionid, 1, &k23, &k23Len, NULL );
    FAIL_IF(err,err);

    printf("Create WA wrap of %d bytes...\n",k2len);
    HexDump("bin",k2, k2len);
    err = cuwa_base64_make_wa(&k23, &k23Len, k23Len, 1, k23, k23Len, NULL);
    FAIL_IF(err,err);

    printf("Create K2 proxy cred...\n");
    err = cuwa_cred_make_proxy( serviceid, keytab, thehost, serviceid, &sessionid,
                         k23, k23Len, &proxy, &proxyLen);
    FAIL_IF(err,err);

    printf("End local session...\n");
    kutil_end_session(ksess);
    ksess = NULL;

cleanup:

    if (cred) cuwa_cred_release( cred );
    if (k1) free(k1);
    if (k2) free(k2);
    if (k22) free(k22);
    if (k23) free(k23);
    if (k1_64) free(k1_64);
    if (k2_64) free(k2_64);

    printf("DONE, rc=%d\n",rc);
}


#define BYTESPERLINE    (12)

void HexDump( char *label,void *ptr, int len)
{
	static char hexStr[64];
	static char ascStr[64];
	unsigned char *cp = (unsigned char*)ptr;
	unsigned char *hs = (unsigned char *)hexStr;
	unsigned char *as = (unsigned char *)ascStr;
	int i;
	int offset=0;

	printf("%s: HexDump....%d bytes\n",label,len);
	for (i=0;len || i;i++) {
		/* If a line is completed */
		if (i==BYTESPERLINE) {
			*hs = '\0';
			*as = '\0';
			printf("%04x: %s  %s\n",offset,hexStr,ascStr);
			hs = (unsigned char *)hexStr;
			as = (unsigned char *)ascStr;
			i = 0; offset += BYTESPERLINE;
		}

		/* If the buffer is exhausted */
		if (!len) {
			break;
		}
		*hs++ = "0123456789ABCDEF"[ *cp / 16];
		*hs++ = "0123456789ABCDEF"[ *cp % 16];
		
		if ((*cp>31 && *cp<58) || (*cp>60 && *cp<94) || (*cp>96 && *cp<127))
			*as = *cp;
		else *as = '.';
		
		*hs = ' ';
		hs++;
		as++;
		len--;
		cp++;
	}

	/* Pad out last line */
	if (i != 0) {
		for (;i < BYTESPERLINE; i++) {
			*hs++ = ' '; *hs++ = ' '; *hs++ = ' ';
			*as++ = ' '; *as++ = ' '; *as++ = ' ';
		}
		*hs = '\0'; *as = '\0';
		printf("%04x: %s   %s\n",offset, hexStr,ascStr);
	}
}

const char id_cred_test_cred_c[] = "$Id: test_cred.c,v 1.11 2008/08/12 20:34:40 pb10 Exp $";
