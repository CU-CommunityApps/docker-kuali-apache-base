#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <kutil.h>
#include <time.h>
#include <log.h>
#include <cuwa_err.h>
#include <cuwa_malloc.h>

#define CUWA2_LOG_DOMAIN cuwa.cred

#define CRYPTO_TEXT "Hi, this is a crypto test, isn't it great?"

void HexDump( char *label, void *ptr, int len);
void login_test(char *netid, char *password, char *serviceid, char *keytab);
void export(char *netid, char *password);
void import(char *serviceid, char *keytab);
void klogin_test(char *localid, char *localkeytab, char *remoteid, char *remotekeytab);

#define syntax_check(c) do {if(argc<c){ printf("syntax: kutil [-l netid password serviceid keytab | -k localid l_keytab remoteid r_keytab | -e netid password | -i serviceid keytab]\n"); return 0;}} while (0)


int main(int argc, char* argv[])
{
    char *flag;

    syntax_check(2);

    flag = argv[1];

    if (strcmp(flag,"-l")==0)
    {
        syntax_check(6);

        login_test(argv[2],argv[3],argv[4],argv[5]);
    }
    else if (strcmp(flag,"-k")==0)
    {
        syntax_check(6);

        klogin_test(argv[2],argv[3],argv[4],argv[5]);
    }
    else if (strcmp(flag,"-e")==0)
    {
        export(argv[2],argv[3]);
    }
    else if (strcmp(flag,"-i")==0)
    {
        import(argv[2],argv[3]);
    }
    else
    {
        syntax_check(1000); // bad syntax
    }

    return 0;
}


void login_test(char *netid, char *password, char *serviceid, char *keytab)
{
    cuwa_err_t err, rc = 0;
    kutil_session_t ksess = NULL;
    kutil_sec_ctx_t ctx = NULL, ctx2 = NULL;
    char *bits,*cpy, *cred;
    int length, credLen, outLen, outLen2;
    char *remoteid, *out, *out2, *localid;
    int authtime, starttime, endtime, renew_til;

    printf("-------------------------------------\n");
    printf("Testing GSSAPI session functions...\n");
    printf("-------------------------------------\n");

#ifndef WIN32
    printf("Performing basic login...\n");
    err = kutil_login(&ksess, netid, password);
    FAIL_IF(err,err);

    err = kutil_get_times( ksess, &authtime, &starttime, &endtime, &renew_til);
    FAIL_IF(err,err);
    printf("Session times: %d %d %d %d\n",authtime, starttime, endtime, renew_til);
#endif

    printf("Establishing security context side one...\n");
    err = kutil_init_sec_context(&ctx, NULL, serviceid, 1, &cred, &credLen);
    FAIL_IF(err,err);

    printf("Accepting security context side two...\n");
    err = kutil_accept_sec_context(&ctx2, cred, credLen, serviceid, keytab, &remoteid);
    FAIL_IF(err,err);

    printf("ACCEPT success: user's netid is %s\n", remoteid);

    err = kutil_inquire_context(ctx2, &localid, &remoteid, &authtime, &endtime, &starttime);
    FAIL_IF(err,err);

    printf("  Details: local=%s remote=%s authtime=%d endtime=%d starttime=%d now-authtime=%d\n", localid,remoteid,authtime,endtime,starttime,(int)(time(NULL)-authtime));

#ifndef WIN32
    printf("tear down context...\n");

    kutil_end_sec_context(ctx);
    kutil_end_sec_context(ctx2);

    printf("Saving session...\n");

    err = kutil_save_session( ksess, &bits, &length);
    FAIL_IF(err,err);

    printf("  ...copy bits...\n");

    cpy = malloc(length);
    FAIL_IF(!cpy,-1);
    memcpy(cpy,bits,length);

    HexDump("TGT",cpy,length);

    printf("Kill session...\n");

    kutil_end_session(ksess);

    printf("Restore session from saved...\n");

    err = kutil_restore_session( &ksess, cpy, length, NULL, NULL);
    FAIL_IF(err,err);

    printf("Establishing security context side one...\n");

    err = kutil_init_sec_context(&ctx, NULL, serviceid, 1, &cred, &credLen);
    FAIL_IF(err,err);

    printf("New session...\n");
    kutil_end_session(ksess);

    printf("Accepting security context side two...\n");

    err = kutil_accept_sec_context(&ctx2, cred, credLen, serviceid, keytab, &remoteid);
    FAIL_IF(err,err);

    printf("ACCEPT: user's netid is %s\n", remoteid);

    /////////////////////////////////////////////

    printf("Saving session (delegated cred)...\n");
    err = kutil_stow_gss_cred(&ksess, ctx2);
    FAIL_IF(err,err);

    err = kutil_save_session( ksess, &bits, &length);
    FAIL_IF(err,err);

    printf("  ...copy bits...\n");

    cpy = malloc(length);
    FAIL_IF(!cpy,-1);
    memcpy(cpy,bits,length);

    HexDump("TGT",cpy,length);

    printf("Kill session...\n");

    kutil_end_session(ksess);

    printf("Restore session from saved...\n");

    err = kutil_restore_session( &ksess, cpy, length, NULL, NULL);
    FAIL_IF(err,err);

    printf("Establishing security context using delegated cred...\n");

    err = kutil_init_sec_context(&ctx, NULL, serviceid, 1, &cred, &credLen);
    FAIL_IF(err,err);

    err = kutil_accept_sec_context(&ctx2, cred, credLen, serviceid, keytab, &remoteid);
    FAIL_IF(err,err);

    printf("ACCEPT: user's netid is %s\n", remoteid);

    ////////////////////////////////////////////////

#endif

    printf("Encrypt message...\n");
    printf("  Clear text: %s\n",CRYPTO_TEXT);

    err = kutil_wrap(ctx, CRYPTO_TEXT, ((int)strlen(CRYPTO_TEXT))+1, &out, &outLen);
    FAIL_IF(err,err);

    HexDump( "crypt",out, outLen);

    printf("Decrypt message...\n");

    err = kutil_unwrap(ctx2, out, outLen, &out2, &outLen2);
    FAIL_IF(err,err);

    printf("  reconstructed message: %s\n",out2);


    kutil_release_buffer(out, outLen);
    kutil_release_buffer(out2, outLen2);
    if (ctx) kutil_end_sec_context(ctx);
    if (ctx2) kutil_end_sec_context(ctx2);
    if (ksess) kutil_end_session(ksess);

#ifndef WIN32
    printf("-------------------------------------\n");
    printf("GSSAPI delegation test...\n");
    printf("-------------------------------------\n");

    printf("Performing basic login, ns10-demo...\n");
    err = kutil_login(&ksess, netid, password);
    FAIL_IF(err,err);

    printf("Establishing security context ns10-demo to web-agent/bosanko...\n");
    err = kutil_init_sec_context(&ctx, NULL, serviceid, 1, &cred, &credLen);
    FAIL_IF(err,err);

    cpy = malloc(credLen);
    FAIL_IF(!cpy,-1);
    memcpy(cpy,cred,credLen);
    cred = cpy;

    printf("Cleanup...\n");
    kutil_end_sec_context(ctx);
    ctx = NULL;
    kutil_end_session(ksess);
    ksess = NULL;

    printf("Get server side TGT web-agent/bosanko...\n");
    err = kutil_login_key(&ksess, serviceid, keytab);
    FAIL_IF(err,err);

    printf("Accepting security context and aquire delegated cred for ns10-demo...\n");
    err = kutil_accept_sec_context(&ctx2, cred, credLen, serviceid, keytab, &remoteid);
    FAIL_IF(err,err);

    printf("Using delegated cred, get another ticket for web-agent/bosanko...\n");
    err = kutil_init_sec_context(&ctx, ctx2, serviceid, 1, &cred, &credLen);
    FAIL_IF(err,err);

    printf("Cleanup...\n");
    kutil_end_sec_context(ctx);
    kutil_end_sec_context(ctx2);
    kutil_end_session(ksess);

#endif


cleanup:

    printf("DONE, rc=%d\n",rc);
}

void export(char *netid, char *password)
{
    cuwa_err_t err, rc = 0;
    kutil_session_t ksess;
    char *bits;
    int length;
    FILE *f;

    printf("Performing basic login...\n");
    err = kutil_login(&ksess, netid, password);
    FAIL_IF(err,err);

    printf("Saving session...\n");

    err = kutil_save_session( ksess, &bits, &length);
    FAIL_IF(err,err);

    printf("  ...write bits...\n");

    f = fopen("session.save","w");
    FAIL_IF(!f,-1);

    fwrite(bits,1,length,f);
    fclose(f);

    kutil_end_session(ksess);

cleanup:

    printf("DONE, rc=%d\n",rc);
}

void import(char *serviceid, char *keytab)
{
    cuwa_err_t err, rc = 0;
    kutil_session_t ksess;
    kutil_sec_ctx_t ctx = NULL, ctx2 = NULL;
    char bits[1024], *cred;
    int length, credLen;
    char *remoteid;
    FILE *f;

    f = fopen("session.save","r");
    FAIL_IF(!f,-1);

    length = (int) fread(bits,1,1000,f);
    fclose(f);

    err = kutil_restore_session( &ksess, bits, length, NULL, NULL);
    FAIL_IF(err,err);

    printf("Establishing security context side one...\n");

    err = kutil_init_sec_context(&ctx, NULL, serviceid, 1, &cred, &credLen);
    FAIL_IF(err,err);

    printf("Accepting security context side two...\n");

    err = kutil_accept_sec_context(&ctx2, cred, credLen, serviceid, keytab, &remoteid);
    FAIL_IF(err,err);

    printf("ACCEPT: user's netid is %s\n", remoteid);

    kutil_end_sec_context(ctx);
    kutil_end_sec_context(ctx2);
    kutil_end_session(ksess);

cleanup:

    printf("DONE, rc=%d\n",rc);
}


void klogin_test(char *localid, char *localkeytab, char *remoteid, char *remotekeytab)
{
    cuwa_err_t err, rc = 0;
    kutil_session_t ksess;
    kutil_krb_ctx_t ctx = NULL, ctx2 = NULL;
    char *cred;
    int credLen, outLen, outLen2;
    char *decodeid, *out, *out2;

    printf("-------------------------------------\n");
    printf("Testing kerberos session functions...\n");
    printf("-------------------------------------\n");

    printf("Performing login using keytab...\n");
    err = kutil_login_key(&ksess, localid, localkeytab);
    FAIL_IF(err,err);

    printf("Establishing kerberos context side one...\n");
    err = kutil_make_req( &ctx, ksess, remoteid, &cred, &credLen);
    FAIL_IF(err,err);

    printf("Accepting kerberos context side two...%p, %p\n",ctx,ksess);
    err = kutil_rd_req(&ctx2, cred, credLen, remoteid, remotekeytab, &decodeid);

    printf("ACCEPT success: user's netid is %s, %p\n", decodeid,ctx2);

    printf("Encrypt message...\n");
    printf("  Clear text: %s\n",CRYPTO_TEXT);

    err = kutil_mk_priv( ctx, CRYPTO_TEXT, ((int)strlen(CRYPTO_TEXT))+1, &out, &outLen );
    FAIL_IF(err,err);

    HexDump( "crypt",out, outLen);

    printf("Decrypt message...\n");

    err = kutil_rd_priv( ctx2, out, outLen, &out2, &outLen2 );
    FAIL_IF(err,err);

    printf("  reconstructed message: %s\n",out2);

    free(out);
    free(out2);
    kutil_end_krb_context(ctx);
    kutil_end_krb_context(ctx2);
    kutil_end_session(ksess);

cleanup:

    printf("DONE, rc=%d\n",rc);
}


#define BYTESPERLINE    (12)

void HexDump( char *label,void *ptr, int len)
{
	static char hexStr[64];
	static char ascStr[64];
	unsigned char *cp = (unsigned char*)ptr;
	unsigned char *hs = (unsigned char *)hexStr;
	unsigned char *as = (unsigned char *)ascStr;
	int i;
	int offset=0;

	printf("%s: HexDump....%d bytes\n",label,len);
	for (i=0;len || i;i++) {
		/* If a line is completed */
		if (i==BYTESPERLINE) {
			*hs = '\0';
			*as = '\0';
			printf("%04x: %s  %s\n",offset,hexStr,ascStr);
			hs = (unsigned char *)hexStr;
			as = (unsigned char *)ascStr;
			i = 0; offset += BYTESPERLINE;
		}

		/* If the buffer is exhausted */
		if (!len) {
			break;
		}
		*hs++ = "0123456789ABCDEF"[ *cp / 16];
		*hs++ = "0123456789ABCDEF"[ *cp % 16];
		
		if ((*cp>31 && *cp<58) || (*cp>60 && *cp<94) || (*cp>96 && *cp<127))
			*as = *cp;
		else *as = '.';
		
		*hs = ' ';
		hs++;
		as++;
		len--;
		cp++;
	}

	/* Pad out last line */
	if (i != 0) {
		for (;i < BYTESPERLINE; i++) {
			*hs++ = ' '; *hs++ = ' '; *hs++ = ' ';
			*as++ = ' '; *as++ = ' '; *as++ = ' ';
		}
		*hs = '\0'; *as = '\0';
		printf("%04x: %s   %s\n",offset, hexStr,ascStr);
	}
}

const char id_cred_test_kutil_c[] = "$Id: test_kutil.c,v 1.12 2008/06/02 01:44:20 pb10 Exp $";
