#ifndef _COMPAT13_H
#define _COMPAT13_H

#include <httpd.h>
#include <http_config.h>
#include <http_core.h>
#include <http_log.h>
#include <http_main.h>
#include <http_protocol.h>
#include <util_script.h>
#include <ap_compat.h>
#include <ap_alloc.h>
#include <stdio.h>

// config...

typedef struct HeaderKeyCfg
{
    int skew;
    char *keytab;
    char *strip_realm;
} HeaderKeyCfg_t;

extern module MODULE_VAR_EXPORT *cuwa_module;
#define CFG_CUWAKeytab(cfg) cfg->keytab

#define cuwa_wal_get_config(r) (HeaderKeyCfg_t*) ap_get_module_config((r)->per_dir_config, cuwa_module);
#define CFG_CUWAKeytab(cfg) cfg->keytab
#define CUWACfg_t HeaderKeyCfg_t

// Misc apr and apache conversions...

#define apr_table_t table
#define CUWA_USER connection->user
#define apr_psprintf ap_psprintf
#define apr_pcalloc ap_pcalloc
#define apr_table_get ap_table_get
#define apr_table_set ap_table_set
#define apr_table_unset ap_table_unset
#define apr_table_overlay ap_table_overlay
#define apr_table_make ap_make_table
#define apr_table_do ap_table_do
#define apr_pstrdup ap_pstrdup
#define apr_pool_t pool
#define apr_status_t int
#define apr_size_t int

// log...
// A bit of a hack, depends on the request being a local variable named "r"
// but at least it has the same interface as CUWA log functions...

#define cuwa_trace(x, ...) cuwa_log(APLOG_DEBUG,(x), ##__VA_ARGS__)
#define cuwa_info(x, ...) cuwa_log(APLOG_INFO,(x), ##__VA_ARGS__)
#define cuwa_warning(x, ...) cuwa_log(APLOG_WARNING,(x), ##__VA_ARGS__)
#define cuwa_log(level, x, ...) ap_log_rerror(NULL,__LINE__,(level),(r),(x), ##__VA_ARGS__)

// time...
// FIXME: this may have cross platform and 64-bit issues...
#include <time.h>
typedef long long apr_time_t;
typedef long long apr_int64_t;

apr_int64_t apr_atoi64(const char *nptr);
apr_time_t apr_time_now();

// File IO...

#define apr_file_t FILE
#define APR_READ 0
#define APR_UREAD 0
#define APR_SUCCESS 0
#define APR_EOF 1
#define apr_file_open(f,fn,i1,i2,i3) (NULL == (*(f) = fopen((fn),"r"))) ? 1 : 0
#define apr_file_read( f, b, n) ( 0 >= (*(n) = fread((b), 1, *(n), f))) ? APR_EOF : APR_SUCCESS
#define apr_file_close(f) fclose(f)

// base64encode...

int cuwa_base64_encode_bytes( int inLen );
void cuwa_base64_encode( char *in, int inLen, char *encodedBytes);

#endif


