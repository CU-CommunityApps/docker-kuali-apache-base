/************************************************************************
 * headerkey.h -- handles creation and verification of header key
 *
 * Copyright 2008 Cornell University.
 * All Rights Reserved.
 *
 ************************************************************************
 *
 ************************************************************************
 */

#ifndef _HEADERKEY_H
#define _HEADERKEY_H

int cuwa_make_hdr_key( void *request, int verify, int skew);

#endif
