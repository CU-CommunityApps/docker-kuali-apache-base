/************************************************************************
 * mod_headerkey.c
 *
 * Copyright 2008 Cornell University.
 * All Rights Reserved.
 *
 ************************************************************************
 *  $Log: mod_headerkey.c,v $
 *  Revision 1.11  2011/05/12 20:08:43  pb10
 *  change WCMC to wcmc, BB doesn't support uppercase account names :-)
 *
 *  Revision 1.10  2011/05/11 19:01:15  pb10
 *  related fix.
 *
 *  Revision 1.9  2011/05/11 18:52:20  pb10
 *  Use FULL_USER instead of REMOTE_USER
 *
 *  Revision 1.8  2011/05/09 19:06:56  pb10
 *  Changes to support new GuestID for BB.
 *
 *  Revision 1.7  2010/12/21 21:55:48  pb10
 *  Hack for blackboard added to support Weill realm.
 *
 *  Revision 1.6  2010/04/17 17:54:16  pb10
 *  cuwa_hk_delete was throwing out the baby with the bath water.  Mod to not delete
 *  good headers that are part of the HMAC.
 *
 *  Revision 1.5  2008/12/18 20:03:21  pb10
 *  Fixed segfault on mod_headerkey.
 *
 *  Revision 1.4  2008/11/21 15:11:00  pb10
 *  Fix log	comment from 1.3 commit. Should read: Change to deny access if no headerkey is present.
 *
 *  Revision 1.3  2008/11/21 14:51:45  pb10
 *  Change to deny access if no headerkey is present.
 *
 *  Revision 1.2  2008/11/16 19:46:13  pb10
 *  Got mod_headerkey working in linux.
 *
 *  Revision 1.1  2008/11/14 20:26:11  pb10
 *  Initial.
 *
 ************************************************************************
 */

#include <ctype.h>
#include <time.h>
#include <cuwa_err.h>
#include <cuwa_types.h>
#include <compat13.h>
#include <headerkey.h>

#define SKEW_DEFAULT 300000

module MODULE_VAR_EXPORT headerkey_module;
module MODULE_VAR_EXPORT *cuwa_module = &headerkey_module;

int headerkey_authn(request_rec *r)
{
    const char *cuwa_remote_user;
    char *remote_user, *realm;
    HeaderKeyCfg_t *cfg = (HeaderKeyCfg_t*) ap_get_module_config(r->per_dir_config, cuwa_module);
    int skew = cfg->skew;
    
    cuwa_trace("Inbound request: %s %s",r->method,r->unparsed_uri);
    if (r->main && r->main->CUWA_USER)
    {
        cuwa_trace("   r->main->user: %s",r->main->CUWA_USER);
        cuwa_info("OK - %s - %s",r->unparsed_uri, r->main->CUWA_USER);
        return OK;       
    }
    
    if (r->prev && r->prev->CUWA_USER) 
    {
        cuwa_trace("   r->prev->user: %s",r->prev->CUWA_USER);
        cuwa_info("OK - %s - %s",r->unparsed_uri, r->prev->CUWA_USER);
        return OK;
    }

    if (cuwa_make_hdr_key( r, 1, skew)!=CUWA_OK)
    {
        cuwa_info("Denied - %s - Invalid header key",r->unparsed_uri);
        return DECLINED;
    }

    // set remote user and headers
    // allow shaping of remote_user?
    cuwa_remote_user = apr_table_get( r->headers_in,"CUWA_FULL_USER");
    if (!cuwa_remote_user)
    {
        cuwa_info("Denied - %s - Missing CUWA_FULL_USER header",r->unparsed_uri);
        return DECLINED;
    }

    remote_user = apr_pstrdup(r->pool,cuwa_remote_user);
    cuwa_trace("CUWA_FULL_USER: %s",remote_user);

    // Strip or modify realm if needed
    // Fixme: hard coded for cornell realms CORNELL.EDU and Weill A.WCMC-AD.NET
    realm = strchr(remote_user,'@');
    if (realm)
    {
        if (!strcmp(&realm[1],"CORNELL.EDU")) *realm = 0;
        else if (!strcmp(&realm[1],"GUEST.CORNELL.EDU")) *realm = 0;
        else if (!strcmp(&realm[1],"CIT.CORNELL.EDU")) *realm = 0;
        else if (!strcmp(&realm[1],"A.WCMC-AD.NET")) 
        {
            strcpy(realm,"@wcmc");
        }
    }

    // Set REMOTE_USER...
    apr_table_set(r->subprocess_env,"REMOTE_USER",remote_user);
    r->CUWA_USER = apr_pstrdup(r->pool, remote_user);

    cuwa_info("OK - %s - %s %s",r->unparsed_uri, remote_user, cuwa_remote_user);

    return OK;
}


int headerkey_authz(request_rec *r)
{
    return OK;
}


static void *headerkey_create_dir_config(apr_pool_t *p, char *dir)
{
    HeaderKeyCfg_t *cfg = (HeaderKeyCfg_t *) apr_pcalloc(p, sizeof(HeaderKeyCfg_t));
    cfg->skew = SKEW_DEFAULT;
    return cfg;
}

static void *headerkey_create_server_config(apr_pool_t *p, server_rec *s)
{
    HeaderKeyCfg_t *cfg = (HeaderKeyCfg_t *) apr_pcalloc(p, sizeof(HeaderKeyCfg_t));
    cfg->skew = SKEW_DEFAULT;
    return cfg;
}


static void *headerkey_merge_config(apr_pool_t *p, HeaderKeyCfg_t *base, HeaderKeyCfg_t *overrides)
{
    HeaderKeyCfg_t *cfg = (HeaderKeyCfg_t *) apr_pcalloc (p, sizeof (HeaderKeyCfg_t));

    cfg->keytab = overrides->keytab ? overrides->keytab : base->keytab;
    cfg->strip_realm = overrides->strip_realm ? overrides->strip_realm : base->strip_realm;
    cfg->skew = (overrides->skew!=SKEW_DEFAULT) ? overrides->skew : base->skew;

    return cfg;
}


static void *headerkey_merge_dir_config(apr_pool_t *p, void *base_conf, void *new_conf)
{
    return headerkey_merge_config(p,(HeaderKeyCfg_t *)base_conf,(HeaderKeyCfg_t *)new_conf);
}


static void *headerkey_merge_server_config(apr_pool_t *p, void *base_conf, void *new_conf)
{
    return headerkey_merge_config(p,(HeaderKeyCfg_t *)base_conf,(HeaderKeyCfg_t *)new_conf);
}

static void headerkey_post_config(server_rec *s, apr_pool_t *p)
{
    ap_log_error(APLOG_MARK, APLOG_NOERRNO|APLOG_EMERG,s,"mod_headerkey version .1");

    return;
}

const char *cmd_set_keytab(cmd_parms *cmd, void *dirInfo, char *keytab)
{
  server_rec *s = cmd->server;
  HeaderKeyCfg_t *scfg = (HeaderKeyCfg_t *) ap_get_module_config(s->module_config, cuwa_module);
  HeaderKeyCfg_t *cfg = ((HeaderKeyCfg_t *) (dirInfo));

  cfg->keytab = ap_pstrdup(cmd->pool,keytab);
  if (!scfg->keytab) scfg->keytab = ap_pstrdup(cmd->pool,keytab);
  return NULL;
}


const char *cmd_set_strip(cmd_parms *cmd, void *dirInfo, char *realm)
{
  server_rec *s = cmd->server;
  HeaderKeyCfg_t *scfg = (HeaderKeyCfg_t *) ap_get_module_config(s->module_config, cuwa_module);
  HeaderKeyCfg_t *cfg = ((HeaderKeyCfg_t *) (dirInfo));

  cfg->strip_realm = ap_pstrdup(cmd->pool,realm);
  if (!scfg->strip_realm) scfg->strip_realm = ap_pstrdup(cmd->pool,realm);
  return NULL;
}

const char *cmd_set_skew(cmd_parms *cmd, void *dirInfo, char *skewstr)
{
  server_rec *s = cmd->server;
  HeaderKeyCfg_t *scfg = (HeaderKeyCfg_t *) ap_get_module_config(s->module_config, cuwa_module);
  HeaderKeyCfg_t *cfg = ((HeaderKeyCfg_t *) (dirInfo));

  cfg->skew = atoi(skewstr);
  if (scfg->skew==SKEW_DEFAULT) scfg->skew = cfg->skew;
  return NULL;
}

command_rec headerkey_cmds[] =
{
  { "HeaderKeyKeytab",     cmd_set_keytab, NULL, OR_ALL, TAKE1, "HeaderKeyKeytab" },
  { "HeaderKeyModRealm", cmd_set_strip,  NULL, OR_ALL, TAKE1, "HeaderKeyModRealm" },
  { "HeaderKeyClockSkew",  cmd_set_skew,   NULL, OR_ALL, TAKE1, "HeaderKeyClockSkew" },
  { NULL }
};


module MODULE_VAR_EXPORT headerkey_module =
{
    STANDARD_MODULE_STUFF,
    headerkey_post_config,
    headerkey_create_dir_config,
    headerkey_merge_dir_config,
    headerkey_create_server_config,
    headerkey_merge_server_config,
    headerkey_cmds,
    NULL,
    NULL,
    headerkey_authn,
    headerkey_authz,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL
};



