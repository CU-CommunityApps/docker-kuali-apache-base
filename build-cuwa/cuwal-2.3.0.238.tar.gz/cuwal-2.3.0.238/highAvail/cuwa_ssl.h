/************************************************************************
 * ssl.h -- Support connection to server through SSL. 
 *
 * Copyright 2008 Cornell University.
 * All Rights Reserved.
 *
 ************************************************************************
 *  $Log: cuwa_ssl.h,v $
 *  Revision 1.5  2016/08/24 20:10:46  hy93
 *  add new function that calculate extra buffer size needed
 *
 *  Revision 1.4  2015/10/07 17:42:49  hy93
 *  merge TwoFactor treee to the head
 *
 *  Revision 1.3.2.2  2015/01/29 15:28:23  hy93
 *  remove twofactor changes
 *
 *  Revision 1.3.2.1  2014/10/22 19:38:32  hy93
 *  add two factor support
 *
 *  Revision 1.3  2014/10/22 16:22:10  hy93
 *  remove two factor support
 *
 *  Revision 1.2  2014/07/25 17:33:39  hy93
 *  get weblogin server certificate. verify server signature
 *
 *  Revision 1.1  2008/09/08 16:02:44  hy93
 *  Rename ssl.h to cuwa_ssl.h
 *
 *  Revision 1.4  2008/08/11 04:11:56  hy93
 *  add new function
 *
 *  Revision 1.3  2008/04/03 22:03:33  hy93
 *  remove the ifdef for RSAref and SYSSSL since the code doesn't support RSAref and SYSSSL library
 *
 *  Revision 1.2  2008/04/03 19:07:55  hy93
 *  change function names
 *
 *  Revision 1.1  2008/04/02 19:46:09  hy93
 *  high availability support
 *
 *
 ************************************************************************
 */

#ifndef _CUWA_SSL_H_
#define _CUWA_SSL_H_

#include <openssl/rsa.h>
#include <openssl/crypto.h>
#include <openssl/x509.h>
#include <openssl/pem.h>
#include <openssl/err.h>
#include <openssl/ssl.h>
#include <openssl/rand.h>

cuwa_err_t cuwa_ssl_init_context();
cuwa_err_t cuwa_ssl_send_request( char *host, char *request, int nbytes, int allowInvalidCert,char *rHead,
                                  int len1, char *rContent,int len2);
cuwa_err_t cuwa_ssl_send_request_extra_check( char *host, char *request, int nbytes, int allowInvalidCert,char *rHead,
                                  int len1, char *rContent,int len2, int *extraNeed);
#endif
