/************************************************************************
 * highAvail.h -- Support CUWA high availability 
 *
 * Copyright 2008 Cornell University.
 * All Rights Reserved.
 *
 ************************************************************************
 *  $Log: highAvail.h,v $
 *  Revision 1.10  2015/10/07 17:41:40  hy93
 *  merge TwoFactor treee to the head
 *
 *  Revision 1.9.2.3  2015/04/29 12:58:24  hy93
 *  Add HA get permit server string from weblogin server
 *
 *  Revision 1.9.2.2  2015/01/29 15:22:04  hy93
 *  remove changes for two factor
 *
 *  Revision 1.9.2.1  2014/10/22 19:37:22  hy93
 *  add two factor support
 *
 *  Revision 1.9  2014/10/22 16:20:04  hy93
 *  remove two factor support
 *
 *  Revision 1.8  2014/07/25 17:32:53  hy93
 *  add cuwa_ha_verify_signature
 *
 *  Revision 1.7  2008/09/18 18:31:45  hy93
 *  fix first request always failed in IIS
 *
 *  Revision 1.6  2008/08/25 15:32:05  hy93
 *  move code from mod_cuwebauth to ha
 *
 *  Revision 1.5  2008/06/02 13:25:49  hy93
 *  add function prototype to return ha init status.
 *
 *  Revision 1.4  2008/05/06 13:20:10  hy93
 *  modify function prototype
 *
 *  Revision 1.3  2008/04/17 15:18:11  hy93
 *  return error if ha init fail
 *
 *  Revision 1.2  2008/04/09 18:01:19  hy93
 *  remove parameter in cuwa_ha_child_init
 *
 *  Revision 1.1  2008/04/02 19:46:21  hy93
 *  high availability support
 *
 *
 ************************************************************************
 */
#ifndef _CUWA_HIGH_AVAIL_H_

#define _CUWA_HIGH_AVAIL_H_

#define CUWA_WEB_LOGIN_COOKIE_NAME "CUWALastWeblogin="

cuwa_err_t cuwa_ha_init(void *s,apr_pool_t *);
char *cuwa_ha_get_login_server(char *cookie, char **newCookie, apr_pool_t *pool);
void cuwa_ha_child_init();
int cuwa_ha_get_init_status();
char *cuwa_ha_get_permit_server_string();
#endif
