/************************************************************************
 * iis_cfgtree.c -- config treesupport for IIS
 *
 * Copyright 2008 Cornell University.
 * All Rights Reserved.
 *
 ************************************************************************
 *  $Log: iis_cfgtree.c,v $
 *  Revision 1.3  2008/09/25 16:37:24  hy93
 *  add log domain
 *
 *  Revision 1.2  2008/09/16 18:08:27  hy93
 *  add cvs version control block
 *
 *
 ************************************************************************
 */
#include <iis_cfgtree.h>
#include <stdlib.h>
#include <log.h>

#define CUWA2_LOG_DOMAIN cuwa.iis.cfgtree

cuwa_iis_directive *cuwa_iis_add_node(cuwa_iis_directive **parent, 
                                      cuwa_iis_directive *current,
                                      cuwa_iis_directive *toadd, int child)
{
    if (current == NULL) {
        /* we just started a new parent */
        if (*parent != NULL) {
            (*parent)->first_child = toadd;
            toadd->parent = *parent;
        }
        if (child) {
            /* First item in config file or container is a container */
            *parent = toadd;
            return NULL;
        }
        return toadd;
    }
    current->next = toadd;
    toadd->parent = *parent;
    if (child) {
        /* switch parents, navigate into child */
        *parent = toadd;
        return NULL;
    }
    return toadd;
}

void cuwa_iis_cfgtree_show( cuwa_iis_directive *tree )
{
    cuwa_iis_directive *current = tree;

    for (; current!= NULL; current = current->next )
    {
        cuwa_trace("Directive %s %s, line %d", current->directive, current->args, current->line_num);
        if ( current->first_child )
        {
            cuwa_trace("Display children of %s %s", current->directive, current->args);
            cuwa_iis_cfgtree_show( current->first_child );
            cuwa_trace("Done displaying children under %s %s",current->directive, current->args);
        }
    }
}

const char id_iis_iis_cfgtree_c[] = "$Id: iis_cfgtree.c,v 1.3 2008/09/25 16:37:24 hy93 Exp $";
