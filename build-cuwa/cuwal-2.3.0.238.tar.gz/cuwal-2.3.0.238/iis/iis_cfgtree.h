/************************************************************************
 * iis_cfgtree.h -- Config tree support for IIS
 *
 * Copyright 2008 Cornell University.
 * All Rights Reserved.
 *
 ************************************************************************
 *  $Log: iis_cfgtree.h,v $
 *  Revision 1.1  2008/09/16 18:00:13  hy93
 *  iis config support
 *
 *
 ************************************************************************
 */

#ifndef _IIS_CFGTREE_H
#define _IIS_CFGTREE_H

typedef struct cuwa_iis_directive_t cuwa_iis_directive;

/**
 * @brief Structure used to build the config tree.  
 *
 * The config tree only stores
 * the directives that will be active in the running server.  Directives
 * that contain other directions, such as <Directory ...> cause a sub-level
 * to be created, where the included directives are stored.  The closing
 * directive (</Directory>) is not stored in the tree.
 */
struct cuwa_iis_directive_t {
    /** The current directive */
    const char *directive;
    /** The arguments for the current directive, stored as a space 
     *  separated list */
    const char *args;
    /** The next directive node in the tree
     *  @defvar ap_directive *next */
    struct cuwa_iis_directive_t *next;
    /** The first child node of this directive 
     *  @defvar ap_directive *first_child */
    struct cuwa_iis_directive_t *first_child;
    /** The parent node of this directive 
     *  @defvar ap_directive *parent */
    struct cuwa_iis_directive_t *parent;

    /** The line number the directive was on */
    int line_num;
};

cuwa_iis_directive *cuwa_iis_add_node(cuwa_iis_directive **parent,
                                      cuwa_iis_directive *current,
                                      cuwa_iis_directive *toadd, int child);
void cuwa_iis_cfgtree_show( cuwa_iis_directive *tree );


#endif
