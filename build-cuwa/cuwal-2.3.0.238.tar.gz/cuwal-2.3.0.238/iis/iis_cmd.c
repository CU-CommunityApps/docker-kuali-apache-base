/************************************************************************
 * iis_cmd.c -- directive command support for IIS
 *
 * Copyright 2008 Cornell University.
 * All Rights Reserved.
 *
 ************************************************************************
 *  $Log: iis_cmd.c,v $
 *  Revision 1.24  2011/03/18 16:16:54  hy93
 *  remove previous check in - impersonation
 *
 *  Revision 1.23  2011/02/24 18:35:40  hy93
 *  support IIS impersonation
 *
 *  Revision 1.22  2010/12/10 21:28:13  hy93
 *  remove previous check in
 *
 *  Revision 1.21  2010/12/10 19:56:24  hy93
 *  fix location mapping doesn't include /
 *
 *  Revision 1.20  2010/05/21 14:03:04  hy93
 *  fix the wrong delimiter that was used to calculate the component
 *
 *  Revision 1.19  2010/05/06 18:02:12  hy93
 *  remove log rotation feature and checkins that tried to fix log rotation problem
 *
 *  Revision 1.18  2010/02/12 15:01:59  hy93
 *  fix memory problem
 *
 *  Revision 1.17  2009/11/17 18:50:24  hy93
 *  implement log rotation
 *
 *  Revision 1.16  2009/09/11 18:08:11  hy93
 *  check if keytab,sessionFilePath, directory defined in <directory> block exist
 *
 *  Revision 1.15  2009/04/21 14:53:18  hy93
 *  Fix access denied error when <directory> block is defined in conf in some situation
 *
 *  Revision 1.14  2009/03/17 15:54:56  hy93
 *  add error message
 *
 *  Revision 1.13  2009/03/11 15:17:57  hy93
 *  improve error message
 *
 *  Revision 1.12  2009/02/11 03:13:32  hy93
 *  fix missing log messages
 *
 *  Revision 1.11  2008/10/31 19:58:35  hy93
 *  change the content of set_user.
 *
 *  Revision 1.10  2008/10/29 16:45:19  hy93
 *  add directive User
 *
 *  Revision 1.9  2008/10/29 02:52:19  pb10
 *  added diagnostics for tracing handlers
 *
 *  Revision 1.8  2008/10/07 19:36:57  hy93
 *  iis log support
 *
 *  Revision 1.7  2008/09/25 19:50:07  hy93
 *  SetHandler support
 *
 *  Revision 1.6  2008/09/25 16:32:23  hy93
 *  implement location and directory matching and inheritance rules similar to Apache
 *
 *  Revision 1.5  2008/09/22 14:24:47  hy93
 *  modified return type of merge_config function
 *
 *  Revision 1.4  2008/09/19 20:00:40  hy93
 *  modified directory and location handling
 *
 *  Revision 1.3  2008/09/17 03:20:59  hy93
 *  add support for logLevel and errorLog
 *
 *  Revision 1.2  2008/09/16 18:07:11  hy93
 *  add cvs version control block
 *
 ************************************************************************
 */

#include <wal.h>
#include <iis_cfg.h>
#include <iis_cmd.h>
#include <iis_server.h>
#include <cfg.h>
#include <apr_strings.h>
#include <log.h>
#include <apr_file_io.h>
#include <cuwa_parse.h>
#include <stdlib.h>

#define CUWA2_LOG_DOMAIN cuwa.iis.cmd

//Include auto-generated functions and table for directives 
#include <cfg-iis-incl.c>

static const char *iis_dirsection(cuwa_iis_cmd_parms *cmd, void *mconfig, const char *arg);
static const char *iis_set_authtype(cuwa_iis_cmd_parms *cmd, void *cfg,
                                    const char *word1);
static const char *iis_set_authname(cuwa_iis_cmd_parms *cmd, void *cfg,
                                    const char *word1);
static const char *iis_urlsection(cuwa_iis_cmd_parms *cmd, void *mconfig, const char *arg);
static const char *iis_virtualhost_section(cuwa_iis_cmd_parms *cmd, void *dummy,
                                           const char *arg);
static const char *iis_require(cuwa_iis_cmd_parms *cmd, void *cfg, const char *arg);
static const char *iis_set_error_log(cuwa_iis_cmd_parms *cmd, void *cfg, const char *arg);
static const char *iis_set_log_level(cuwa_iis_cmd_parms *cmd, void *cfg, const char *arg);
static const char *iis_set_handler(cuwa_iis_cmd_parms *cmd, void *cfg, const char *arg);
static const char *iis_set_user(cuwa_iis_cmd_parms *cmd, void *cfg, const char *arg);

static const cuwa_iis_command_rec cuwa2_iis_core_cmds[] = {

IIS_INIT_RAW_ARGS("<Directory", iis_dirsection, RSRC_CONF, CUWA_IIS_CORE_CMD,
  "Container for directives affecting resources located in the specified "
  "directories"),

IIS_INIT_RAW_ARGS("<Location", iis_urlsection, RSRC_CONF, CUWA_IIS_CORE_CMD,
  "Container for directives affecting resources accessed through the "
  "specified URL paths"),

IIS_INIT_RAW_ARGS("<VirtualHost", iis_virtualhost_section, RSRC_CONF, CUWA_IIS_CORE_CMD,
  "Container to map directives to a particular virtual host, takes one host address"),

IIS_INIT_TAKE1("AuthType", iis_set_authtype,  OR_AUTHCFG, CUWA_IIS_CORE_CMD,
  "An HTTP authorization type (e.g., \"Basic\")"),

IIS_INIT_TAKE1("AuthName", iis_set_authname, OR_AUTHCFG, CUWA_IIS_CORE_CMD,
  "The authentication realm (e.g. \"Members Only\")"),

IIS_INIT_RAW_ARGS("Require", iis_require, OR_AUTHCFG, CUWA_IIS_CORE_CMD,
  "Selects which authenticated users or groups may access a protected space"),

//errorlog and logLevel don't inherit from parent.
IIS_INIT_TAKE1("ErrorLog", iis_set_error_log, RSRC_CONF, CUWA_IIS_CORE_CMD,
  "The filename of the error log"),

IIS_INIT_TAKE1("LogLevel", iis_set_log_level, RSRC_CONF, CUWA_IIS_CORE_CMD,
  "Level of verbosity in error logging"),

IIS_INIT_TAKE1("SetHandler", iis_set_handler, OR_AUTHCFG, CUWA_IIS_CORE_CMD,
  "a handler name that overrides any other configured handler"),

IIS_INIT_TAKE1("User", iis_set_user, RSRC_CONF, CUWA_IIS_CORE_CMD,
  "Effective user id for this server"),

{NULL}
};

int cuwa_check_file_exist( char *filename )
{
    HANDLE p;
    int result = 1;

    p = CreateFile( filename,GENERIC_READ,FILE_SHARE_READ,NULL,OPEN_EXISTING,0,NULL);
    if ( p == INVALID_HANDLE_VALUE )
    {
        int rv = GetLastError();
        
        cuwa_trace("check file failed:%d",rv);
        if ( rv == 3 || rv == 2 )
            result = 0;
    }
    else
        CloseHandle(p);

    return result;
}

char *cuwa_check_keytab(void *cmd, void *sInfo, const char *arg, CUWACfg_t* scfg, CUWACfg_t* cfg, apr_pool_t * pool, char *what)
{
   if ( !cuwa_check_file_exist( arg ) )  
       return apr_psprintf( pool,"The keytab %s doesn't exist.",arg );
     
    return NULL;
}

char *cuwa_check_sessionfilepath(void *cmd, void *sInfo, const char *arg, CUWACfg_t* scfg, CUWACfg_t* cfg, apr_pool_t * pool, char *what)
{
    if ( !cuwa_check_file_exist( arg ) )
        return apr_psprintf( pool,"The CUWAsessionFilePath %s doesn't exist.",arg);
    return NULL;
}

static char *unclosed_directive(cuwa_iis_cmd_parms *cmd)
{
    return apr_pstrcat(cmd->pool, cmd->directive->directive,
                       "> directive missing closing '>'", NULL);
}

static int iis_count_dirs(const char *path)
{
    register int x, n;
    for (x = 0, n = 0; path[x]; x++)
        if (path[x] == '\\')
            n++;
    return n;
}

static const char *iis_dirsection(cuwa_iis_cmd_parms *cmd, void *mconfig, const char *arg)
{
    const char *errmsg;
    const char *endp = strrchr(arg, '>');
    int old_overrides = cmd->override;
    char *old_path = cmd->path;
    cuwa_iis_dir_config *conf;
    
    cuwa_trace("processing %s %s",cmd->directive->directive, arg);
    if (endp == NULL) {
        return unclosed_directive(cmd);
    }
    arg = apr_pstrndup(cmd->pool, arg, endp - arg);
    if (!arg) 
        return "<Directory > block must specify a path";
    
    cmd->path = cuwa_getword_conf(cmd->pool, &arg);
    cmd->override = OR_ALL;

    if (!strcmp(cmd->path, "~")) 
        return "<Directory ~ > block not allowed";
    
    if ( cmd->path )
    {
        cuwa_util_replace_char_with( cmd->path,'/','\\');
        //verify if path exist
        if (!cuwa_check_file_exist( cmd->path ) )
        {
            return apr_pstrcat(cmd->pool, "<Directory \"", cmd->path,
                               "\"> path is invalid.", NULL);
        }
        
        if (cmd->path[strlen(cmd->path) - 1] != '\\')
            cmd->path = apr_pstrcat(cmd->pool, cmd->path, "\\", NULL);
    }
 
    conf = cuwa_iis_server_new_dirConfig( cmd->pool, cmd->server );
    conf->config = (CUWACfg_t *) apr_pcalloc(cmd->pool, sizeof(CUWACfg_t));
    
    errmsg = cuwa_iis_walk_config(cmd->directive->first_child, cmd, conf->config, conf);
    if (errmsg != NULL)
        return errmsg;

    conf->dir = cmd->path;    
    conf->is_directory = 1;
    
    conf->d_components = iis_count_dirs(conf->dir);
    
    cuwa_trace("directory %s has %d components", conf->dir, conf->d_components);

    cmd->path = old_path;
    cmd->override = old_overrides;
    return NULL;
}

static const char *iis_urlsection(cuwa_iis_cmd_parms *cmd, void *mconfig, const char *arg)
{
    const char *errmsg;
    const char *endp = strrchr(arg, '>');
    int old_overrides = cmd->override;
    char *old_path = cmd->path;
    cuwa_iis_dir_config *conf;
    
    if (endp == NULL) 
        return unclosed_directive(cmd);
    
    arg = apr_pstrndup(cmd->pool, arg, endp - arg);
    cmd->path = cuwa_getword_conf(cmd->pool, &arg);
    cmd->override = OR_ALL;
    
    if (!strcmp(cmd->path, "~")) 
        return "<Location ~> not allowed";
        
    /* initialize our config and fetch it */
    conf =  cuwa_iis_server_new_dirConfig( cmd->pool, cmd->server );
    conf->config = (CUWACfg_t *) apr_pcalloc(cmd->pool, sizeof(CUWACfg_t));

    errmsg = cuwa_iis_walk_config(cmd->directive->first_child, cmd, conf->config, conf);
    if (errmsg != NULL)
        return errmsg;

/*   if (cmd->path[strlen(cmd->path) - 1] != '/')
       cmd->path = apr_pstrcat(cmd->pool, cmd->path, "/", NULL);
 */
    conf->dir = apr_pstrdup(cmd->pool, cmd->path);     
    conf->is_directory = 0;
          
    conf->d_components = 0;
    
    cmd->path = old_path;
    cmd->override = old_overrides;

    cuwa_trace(" Location %s has %d components", conf->dir, conf->d_components);
    return NULL;
}


/*beginning with the <VirtualHost> business */
static const char *iis_virtualhost_section(cuwa_iis_cmd_parms *cmd, void *dummy,
                                           const char *arg)
{
    cuwa_iis_server *main_server = cmd->server, *s;
    const char *errmsg;
    const char *endp = strrchr(arg, '>');
    apr_pool_t *p = cmd->pool;
    const char *err = NULL;

    if (err != NULL) 
        return err;
    
    if (endp == NULL) 
        return unclosed_directive(cmd);
    
    arg = apr_pstrndup(cmd->pool, arg, endp - arg);
    arg = cuwa_getword_conf(cmd->pool, &arg);

    if (main_server->is_virtual) {
        return "<VirtualHost> doesn't nest!";
    }
    errmsg = cuwa_iis_init_virtual_host(p, arg, &s);
    if (errmsg) {
        return errmsg;
    }
    cmd->server = s;
    errmsg = cuwa_iis_walk_config(cmd->directive->first_child, cmd, s->config, NULL);

    cmd->server = main_server;
    return errmsg;
}

static const char *iis_set_authtype(cuwa_iis_cmd_parms *cmd, void *cfg,
                                    const char *word1)
{
    cuwa_iis_dir_config *aconfig = (cuwa_iis_dir_config *)cfg;

    if (!aconfig )
        return apr_pstrcat(cmd->pool, "AuthType ", word1,
                       " is not allowed here", NULL);

    aconfig->auth_type = cuwa_escape_quotes(cmd->pool, word1);
    return NULL;
}

/*
 * Load an authorisation realm into our location configuration, applying the
 * usual rules that apply to realms.
 */
static const char *iis_set_authname(cuwa_iis_cmd_parms *cmd, void *cfg,
                                    const char *word1)
{
    cuwa_iis_dir_config *aconfig = (cuwa_iis_dir_config *)cfg;

    if (!aconfig )
        return apr_pstrcat(cmd->pool, "AuthName ", word1,
                       " is not allowed here", NULL);

    aconfig->auth_name = cuwa_escape_quotes(cmd->pool, word1);
    return NULL;
}

static const char *iis_set_log_level(cuwa_iis_cmd_parms *cmd, void *dummy,
                                     const char *arg)
{
    cuwa_iis_server *server = cmd->server;
    char *str;

    if ((str = cuwa_getword_conf(cmd->pool, &arg))) {
        if (!strcasecmp(str, "alarm")) {
            server->loglevel = CUWA2_L_ALARM;
        }
        else if (!strcasecmp(str, "crit")) {
            server->loglevel = CUWA2_L_CRIT;
        }
        else if (!strcasecmp(str, "warn")) {
            server->loglevel = CUWA2_L_WARNING;
        }
        else if (!strcasecmp(str, "notice")) {
            server->loglevel = CUWA2_L_NOTICE;
        }
        else if (!strcasecmp(str, "info")) {
            server->loglevel = CUWA2_L_INFO;
        }
        else if (!strcasecmp(str, "debug")) {
            server->loglevel = CUWA2_L_TRACE;
        }
        else {
            return "LogLevel requires one of these level keyword: "
                   "alarm/crit/warn/notice/info/debug";
        }
    }
    else {
        return "LogLevel requires level keyword";
    }
    return NULL;
}

static const char *iis_set_error_log(cuwa_iis_cmd_parms *cmd, void *dummy,
                                     const char *arg)
{
    cuwa_iis_server *server = cmd->server;
    apr_file_t *file = NULL;
    apr_status_t rv;

    server->error_log = cuwa_escape_quotes(cmd->pool, arg);

    rv = apr_file_open( &server->log_file, server->error_log, APR_APPEND | APR_WRITE | APR_CREATE | APR_LARGEFILE,
                               APR_OS_DEFAULT, cmd->pool );
    if ( rv )
        cuwa_warning("open log file %s failed", server->error_log);

    return NULL;
}

static const char *iis_require(cuwa_iis_cmd_parms *cmd, void *cfg, const char *arg)
{
   struct require_line *r;
   cuwa_iis_dir_config *c = (cuwa_iis_dir_config *)cfg;

    if (!c )
        return apr_pstrcat(cmd->pool, "Require ", arg,
                       " is not allowed here", NULL);

    r = (struct require_line *)apr_array_push(c->requires);
    r->requirement = apr_pstrdup(cmd->pool, arg);
    return NULL;
}

static const char *iis_set_handler(cuwa_iis_cmd_parms *cmd, void *cfg, const char *arg)
{   
    cuwa_iis_dir_config *c = (cuwa_iis_dir_config *)cfg;
    
    if (!c )
        return apr_pstrcat(cmd->pool, "SetHandler ", arg,
                       " is not allowed here", NULL);

    cuwa_trace("setting handler: %s",arg);
    c->handler = cuwa_escape_quotes(cmd->pool, arg);

    return NULL;
}

static const char *iis_set_user(cuwa_iis_cmd_parms *cmd, void *dummy,
                                const char *arg)
{
    cuwa_iis_server *server = cmd->server;


    return NULL;
}

const char *cuwa_iis_invoke_cmd( const cuwa_iis_command_rec *cmd, cuwa_iis_cmd_parms *parms, CUWACfg_t *config, cuwa_iis_dir_config *dirConfig, const char *args )
{
    char *w;
    void *mconfig = NULL;

    cuwa_trace("invoke cmd:%s %s",cmd->name, args);

    if ((parms->override & cmd->req_override) == 0)
        return apr_pstrcat(parms->pool, cmd->name, " not allowed here", NULL);

    if ( cmd->type == CUWA_IIS_CMD )
        mconfig = config;
    else
        mconfig = dirConfig;

    switch (cmd->args_how)
    {
        case RAW_ARGS:
            return cmd->func(parms, mconfig, args);

        case TAKE1:
            w = cuwa_getword_conf(parms->pool, &args);
            
            if (*w == '\0' || *args != 0)
                return apr_pstrcat(parms->pool, cmd->name, " takes one argument",
                                   cmd->errmsg ? ", " : NULL, cmd->errmsg, NULL);
            return cmd->func(parms, mconfig, w);

        default:
            return apr_pstrcat(parms->pool, cmd->name,
                               " is improperly configured internally (server bug)",
                                NULL);
    }

}

const cuwa_iis_command_rec *cuwa_iis_find_cmd(const char *name)
{
    const cuwa_iis_command_rec *cmds = cuwa2_cmds;

    while (cmds && cmds->name)
    {
        if (!strcasecmp(name, cmds->name))
            return cmds;

        ++cmds;
    }

    cmds = cuwa2_iis_core_cmds;
    while (cmds && cmds->name)
    {
        if (!strcasecmp(name, cmds->name))
            return cmds;

        ++cmds;
    }
    cuwa_trace("command not found");
    return NULL;
}

void cuwa_iis_merge_config( CUWACfg_t *base_config, CUWACfg_t *config)
{
    cuwa_merge_config( base_config, config);
}

const char id_iis_iis_cmd_c[] = "$Id: iis_cmd.c,v 1.24 2011/03/18 16:16:54 hy93 Exp $";

