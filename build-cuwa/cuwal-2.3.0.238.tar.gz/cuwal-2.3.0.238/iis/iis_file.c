/************************************************************************
 * iis_file.c -- conf file support for IIS
 *
 * Copyright 2008 Cornell University.
 * All Rights Reserved.
 *
 ************************************************************************
 *  $Log: iis_file.c,v $
 *  Revision 1.5  2009/03/11 15:17:34  hy93
 *  Support display initialization error messages to browser
 *
 *  Revision 1.4  2008/09/25 16:37:03  hy93
 *  add log domain
 *
 *  Revision 1.3  2008/09/19 20:02:33  hy93
 *  Add find the location of cuwebauth conf file
 *
 *  Revision 1.2  2008/09/16 18:07:42  hy93
 *  add cvs version control block
 *
 ************************************************************************
 */

#include <apr_file_io.h>
#include <apr_pools.h>
#include <cuwa_err.h>
#include <log.h>
#include <iis_cmd.h>
#include <string.h>
#include <apr_strings.h>
#include <cuwa_parse.h>
#include <apr_lib.h>

#define CUWA2_LOG_DOMAIN cuwa.iis.file

#define CUWA_IIS_CONF "cuwebauth.conf"

static void *iis_cfg_getstr(void *buf, size_t bufsiz, apr_file_t *cfp)
{
    apr_status_t rv;
    rv = apr_file_gets(buf, bufsiz, cfp);
    if (rv == APR_SUCCESS) {
        return buf;
    }
    return NULL;
}

char *cuwa_iis_find_conf_file(apr_pool_t *pool)
{
    HMODULE hModule;
    char path[MAX_PATH] ;
    int length;
    PSTR pszDir = "\\CUWebAuth\\" ;
  
    //Get the path info where the CUwebAuth.dll is stored
    hModule=GetModuleHandle("cuwebauth_iis.dll");
    if(hModule)
    {
        length=GetModuleFileName(hModule,path,MAX_PATH);
        
        if(path)
        {
            char *temp=strstr(path,"cuwebauth_iis.dll");
            temp[0]='\0';
        }
        cuwa_trace("found dll path=%s",path);
    }
    else
    {   //Old behaviour --Try to find the conf file in systembootdir\cuwebauth
        length = GetWindowsDirectory(path, MAX_PATH) ;
        strcat(path, pszDir) ;
    }

    // conf file
    return apr_pstrcat(pool, path, CUWA_IIS_CONF, NULL);

}

apr_file_t *cuwa_iis_open_file(char *name, apr_pool_t *p )
{
    apr_file_t *file = NULL;
    apr_status_t rv;
    cuwa_err_t rc = CUWA_OK;
    apr_finfo_t finfo;
    //unsigned char buf[4];
    //apr_size_t len = 3;

    rv = apr_file_open(&file, name, APR_READ | APR_BUFFERED,
                       APR_OS_DEFAULT, p);
    if ( rv )    
        cuwa_crit("failed to open conf file:%s",name);

    CUWA_SHOW_APR_ERROR(rv);
    FAIL_IF( rv, CUWA_ERR_IIS_CONF);

    rv = apr_file_info_get(&finfo, APR_FINFO_TYPE, file);
    if ( rv )
        cuwa_crit("failed at getting file info:%s", name);
    CUWA_SHOW_APR_ERROR(rv);
    FAIL_IF( rv, CUWA_ERR_IIS_CONF);

    if (finfo.filetype != APR_REG &&
        strcasecmp((const char *)apr_filepath_name_get(name), "nul") != 0) 
    {
        cuwa_crit("Access to file %s denied by server: not a regular file",
                   name);
        apr_file_close(file);
        return NULL;
    }
#if 0
    /* Some twisted character [no pun intended] at MS decided that a
     * zero width joiner as the lead wide character would be ideal for
     * describing Unicode text files.  This was further convoluted to
     * another MSism that the same character mapped into utf-8, EF BB BF
     * would signify utf-8 text files.
     *
     * Since MS configuration files are all protecting utf-8 encoded
     * Unicode path, file and resource names, we already have the correct
     * WinNT encoding.  But at least eat the stupid three bytes up front.
     */
    rv = apr_file_read(file, buf, &len);
    if ((rv != APR_SUCCESS) || (len < 3) 
         || memcmp(buf, "\xEF\xBB\xBF", 3) != 0) 
    {
        apr_off_t zero = 0;
        apr_file_seek(file, APR_SET, &zero);
    }
#endif
cleanup:

    return file;
}

/* Read one line from open conf, strip LF, increase line number */
int cuwa_iis_file_getline(char *buf, size_t bufsize, apr_file_t *file, cuwa_iis_cmd_parms *parms)
{
    char *src, *dst;
    char *cp;
    char *cbuf = buf;
    size_t cbufsize = bufsize;

    while (1) 
    {
        ++parms->line_num;
        if (iis_cfg_getstr(cbuf, cbufsize, file) == NULL)
            return 1;

        /*
         *  check for line continuation,
         *  i.e. match [^\\]\\[\r]\n only
         */
         cp = cbuf;
         while (cp < cbuf+cbufsize && *cp != '\0')
             cp++;

         if (cp > cbuf && cp[-1] == LF) {
             cp--;
             if (cp > cbuf && cp[-1] == CR)
                 cp--;
             if (cp > cbuf && cp[-1] == '\\') {
                 cp--;
                 if (!(cp > cbuf && cp[-1] == '\\')) {
                     /*
                      * line continuation requested -
                      * then remove backslash and continue
                      */
                      cbufsize -= (cp-cbuf);
                      cbuf = cp;
                      continue;
                  }
                  else {
                      /*
                       * no real continuation because escaped -
                       * then just remove escape character
                       */
                       for ( ; cp < cbuf+cbufsize && *cp != '\0'; cp++)
                           cp[0] = cp[1];
                  }
             }
         }
         break;
    }
    /*
     * Leading and trailing white space is eliminated completely
     */
    src = buf;
    while (apr_isspace(*src))
        ++src;

    /* blast trailing whitespace */
    dst = &src[strlen(src)];
    while (--dst >= src && apr_isspace(*dst))
        *dst = '\0';

    /* Zap leading whitespace by shifting */
    if (src != buf)
        for (dst = buf; (*dst++ = *src++) != '\0'; )
             ;
    //cuwa_trace( "Read config: %s", buf);
    return 0;
}

const char id_iis_iis_file_c[] = "$Id: iis_file.c,v 1.5 2009/03/11 15:17:34 hy93 Exp $";

