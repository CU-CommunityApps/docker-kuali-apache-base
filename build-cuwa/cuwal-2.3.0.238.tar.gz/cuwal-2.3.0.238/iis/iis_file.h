/************************************************************************
 * iis_file.h -- Config support for IIS
 *
 * Copyright 2008 Cornell University.
 * All Rights Reserved.
 *
 ************************************************************************
 *  $Log: iis_file.h,v $
 *  Revision 1.1  2008/09/16 18:00:37  hy93
 *  iis config support
 *
 *
 ************************************************************************
 */

#ifndef _IIS_FILE_H
#define _IIS_FILE_H

#include <apr_pools.h>
#include <apr_file_io.h>
#include <iis_cmd.h>

#define CUWA_IIS_CONF "cuwebauth.conf"

char *cuwa_iis_find_conf_file(apr_pool_t *pool);
apr_file_t *cuwa_iis_open_file(char *name, apr_pool_t *p );
int cuwa_iis_file_getline(char *buf, size_t bufsize, apr_file_t *file, cuwa_iis_cmd_parms *parms);

#endif
