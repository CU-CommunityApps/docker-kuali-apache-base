/************************************************************************
 * iis_log.h -- log support for IIS
 *
 * Copyright 2008 Cornell University.
 * All Rights Reserved.
 *
 ************************************************************************
 *  $Log: iis_log.h,v $
 *  Revision 1.1  2008/10/07 19:36:44  hy93
 *  iis log support
 *
 *
 *
 ************************************************************************
 */

#ifndef _IIS_LOG_H
#define _IIS_LOG_H

#include <apr_pools.h>

int cuwa_iis_log_init(apr_pool_t *pool);
void cuwa_iis_log_set_key( void *request, void *server );
void cuwa_iis_native_log( apr_status_t apr_err, char *buf );
void cuwa_iis_log_close( void *server, apr_pool_t *pool);
#endif
