#include <stdio.h>
#include <stdlib.h>
#include "iis_cfg.h"
#include <cfg.h>
#include <apr_pools.h>
#include "iis_server.h"
#include <log.h>
#include <cuwa_malloc.h>

void show_cfg(CUWACfg_t *cfg, cuwa_iis_dir_config *dirConfig,cuwa_iis_server *s)
{
    char *str;
    const apr_array_header_t *requires;
    int i;

    cuwa_trace("cfg=%p,dirConfig=%p",cfg,dirConfig);
    cuwa_trace("principal:%s",CFG_CUWAKerberosPrincipal(cfg));
    cuwa_trace("keytab:%s",CFG_CUWAKeytab(cfg));
    cuwa_trace("sessionFile:%s", CFG_CUWAsessionFilePath(cfg));

    str = cuwa_iis_get_authtype(dirConfig);
    cuwa_trace("AuthType:%s",str?str:"not defined");
;
    requires = cuwa_iis_get_requires(dirConfig);
    
    if ( requires )
    {
         cuwa_trace("requires = %d", requires->nelts); 
         for ( i=0; i< requires->nelts;i++)
         {
            str = cuwa_iis_get_require_line(requires->elts,i);
            cuwa_trace("Require:%s", str);
         }
    }
    else
         cuwa_trace("no require");
}

int main()
{

    apr_pool_t *pool;
    CUWACfg_t *root_cfg = NULL, *cfg;
    cuwa_iis_dir_config *dirConfig,*dConfig;
    void *root_vhost;
    int rc,i;
    cuwa_iis_server *s;
    apr_array_header_t *dirs;

    apr_pool_initialize();
    apr_pool_create( &pool, NULL );

    cuwa_malloc_init( pool );
    cuwa_malloc_set_pool( pool );

    rc = cuwa_cfg_init(pool, &root_cfg, &root_vhost);
    if ( rc )
    {
         printf("cfg_init failed with status=%d",rc);
         return -1;
     }
    if ( !root_cfg )
    {
         printf("root_cfg is NULL\n");
         return -1;
    }
    cuwa_trace("****show root config****");
    
    show_cfg( root_cfg,NULL,root_vhost );

    cuwa_trace("****show second host*****");
    s = cuwa_iis_get_next_server( root_vhost );
    if ( s )
    {
        show_cfg( cuwa_iis_server_get_config( s), NULL,s );
        dirs = s->dirConfigs;
        if ( dirs )
        {
           dirConfig = (cuwa_iis_dir_config *)dirs->elts; 
           for ( i =0; i<dirs->nelts; i++)
           {
               dConfig = &dirConfig[i];
               cuwa_trace("*****show dir config*****");
               show_cfg( dConfig->config, dConfig, s);
           }
        }
         
    }
    else
    {
         printf("no second host");
    }    

    printf("\nGET /students/hr/index.html from host abc.com\n");
    s = cuwa_iis_find_server("abc.com","8008");
    cfg = cuwa_cfg_from_path(s,"/students/hr/index.html","/users/hy93/apache/www/html/students/hr/index.html",&dirConfig);

    show_cfg(cfg, dirConfig,s);
    
    printf("\nGET /students/hr/index.html from host pine.cit.cornell.edu\n");
     s = cuwa_iis_find_server("pine.cit.cornell.edu","8008");
    cfg = cuwa_cfg_from_path(s,"/students/hr/index.html","/users/hy93/apache/www/html/students/hr/index.html",&dirConfig);

    show_cfg(cfg, dirConfig,s);

    apr_pool_destroy( pool);

   return 0;
}
