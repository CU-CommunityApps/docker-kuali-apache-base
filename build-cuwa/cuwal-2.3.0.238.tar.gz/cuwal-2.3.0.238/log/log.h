/************************************************************************
 * log.h -- CUWAL2 Logging Subsystem
 *
 * Copyright 2008 Cornell University.
 * All Rights Reserved.
 * 
 *  * Note: Reads environment variables CUWA_LOG and CUWA_LEVEL
 * CUWA_LOG will force logging to the specified file
 * CUWA_LEVEL will override all configuration based log levels
 * 
 *
 ************************************************************************
 *  $Log: log.h,v $
 *  Revision 1.23  2008/10/07 19:30:27  hy93
 *  extract none apache related functions to log_util.c
 *
 *  Revision 1.22  2008/09/16 19:22:15  hy93
 *  remove function prototypes that are internal in log.h
 *
 *  Revision 1.21  2008/08/05 01:27:12  gbr4
 *  rule improvements
 *
 *  Revision 1.20  2008/08/03 21:37:05  gbr4
 *  Makefile changes to support fortify target. Minor tweak to log.h to handle -DFORTIFY (no change to production build). mc2confrec now emits #define CFG_...(x) ((x)!=NULL)?x.foo:NULL instead of (x)?x.foo:NULL to shut up fortify sca. Also put the custom rules under CVS control
 *
 *  Revision 1.19  2008/05/05 19:52:55  gbr4
 *  add more missing assertions to guard null pointers, fix typo in log.h
 *
 *  Revision 1.18  2008/05/05 19:13:15  gbr4
 *  fix error introduced in log 1.37 that broke solaris build. also commit conditional code used in klocwork build and add an assert in rand to check that /dev/urandom read succeeded.
 *
 *  Revision 1.17  2008/01/28 16:33:40  gbr4
 *  Log now reads environment variables CUWA_LOG and CUWA_LEVEL.
 *
 *  Revision 1.16  2008/01/17 16:57:32  hy93
 *  fix compiler warning
 *
 *  Revision 1.15  2008/01/16 20:35:44  hy93
 *  fix log
 *
 *  Revision 1.14  2008/01/16 18:46:06  hy93
 *  use <> instead of " in include
 *
 *  Revision 1.13  2008/01/16 18:37:53  hy93
 *  fix segfault when configuration context is not available.
 *
 *  Revision 1.12  2008/01/11 04:12:29  pb10
 *  Fix #include recursion issue with cfg.h
 *
 *  Revision 1.11  2008/01/10 17:58:58  hy93
 *  Modify log to use config
 *
 ************************************************************************
 */
#ifndef __CUWA2_LOG_H
#define __CUWA2_LOG_H
#include <stdarg.h>

#if defined (APACHE_BUILD) || defined (WIN32)
#include <cfg.h>
#include <log_util.h>
#endif

#ifdef FORTIFY
#include <assert.h>
#endif

#ifdef _MSC_VER
#include <CodeAnalysis/SourceAnnotations.h>
#if _MSC_VER < 1300
#define __FUNCTION__ "???"
#endif
#define __func__ __FUNCTION__
#endif



/**
 * part of unit testing. Will be true if an assertion has failed.
 * not entirely threadsafe -- might want to devise a better mechanisim
 * if that becomes a problem. Right now unit tests define assert(x) as 
 * (void)(x) and then check for an assertion failure via this variable.
 */
extern int cuwa_assert_failed;

/**
 * Assertion successes. This is rarely useful and very verbose.
 */
#define CUWA2_L_ATRACE CUWA2_L_TRACE

/**
 * Highest verbosity debug output. Probably useful only to developers.
 * \arg \e  looking for node in tree ... found at address xyz
 */
#define CUWA2_L_TRACE 7
/**
 * Informational debugging output. Successful events logged at this level.
 * \arg \e  Authenticated user X
 */
#define CUWA2_L_INFO 6
/**
 * Somewhat abnormal activity.
 * \arg \e  Login failed for user X, bad password
 */
#define CUWA2_L_NOTICE 5
/**
 * Recoverable error condition that we expect to be encountered occasionally. 
 * These messages will result from system conditions that might indicate hacking.
 * \arg \e  Kerberos server not available, check configuration
 */
#define CUWA2_L_WARNING 4
/**
 * Unrecoverable (usually) errors. These will indicate either bugs or misconfigurations.
 * \arg \e  cookie integrity check passed but field missing
 */
#define CUWA2_L_CRIT 2

/**
 * Highest severity warning. Currently doesn't do anything special. 
 * Might be an opportunity for IDS integration at some later point.
 * Don't output at this level if you don't want a phone call when it happens.
 * Example: received 500 attempted bad passwords for user xyz in the past half hour
 */
#define CUWA2_L_ALARM 0

/**
 * work around null strings crashing vasprintf
 */

#define DENULL(x) ((NULL!=x)?(x):"(null)")

/**
 * output an assertion passed message
 * @param[in] x format string, all printf format string warnings apply (trusted data only)
 * @see CUWA2_L_ATRACE|cuwa_log
 */
#define cuwa_atrace(x, ...) cuwa_log(CUWA2_L_TRACE,x, ##__VA_ARGS__)

/**
 * output a trace message
 * @param[in] x format string, all printf format string warnings apply (trusted data only)
 * @see CUWA2_L_TRACE|cuwa_log
 */
#define cuwa_trace(x, ...) cuwa_log(CUWA2_L_TRACE,x, ##__VA_ARGS__)

/**
 * output an informational message
 * @param[in] x format string, all printf format string warnings apply (trusted data only)
 * @see CUWA2_L_INFO|cuwa_log
 */
#define cuwa_info(x, ...) cuwa_log(CUWA2_L_INFO,x,##__VA_ARGS__)

/**
 * output a notice message
 * @param[in] x format string, all printf format string warnings apply (trusted data only)
 * @see CUWA2_L_NOTICE|cuwa_log
 */
#define cuwa_notice(x, ...) cuwa_log(CUWA2_L_NOTICE,x, ##__VA_ARGS__)

/**
 * output a warning message
 * @param[in] x format string, all printf format string warnings apply (trusted data only)
 * @see CUWA2_L_WARNING|cuwa_log
 */
#define cuwa_warning(x, ...) cuwa_log(CUWA2_L_WARNING,x, ##__VA_ARGS__)

/**
 * output a critical message
 * @param[in] x format string, all printf format string warnings apply (trusted data only)
 * @see CUWA2_L_CRIT|cuwa_log
 */
#define cuwa_crit(x, ...) cuwa_log(CUWA2_L_CRIT,x, ##__VA_ARGS__)

/**
 * output an alarm
 * @param[in] x format string, all printf format string warnings apply (trusted data only)
 * @see CUWA2_L_ALARM|cuwa_log
 */
#define cuwa_alarm(x, ...) cuwa_log(CUWA2_L_ALARM,x, ##__VA_ARGS__)

/**
 * indicate untested code
 */
#define cuwa_untested(m) cuwa_log(CUWA2_L_WARNING,"Un/Undertested code path");

/**
 * indicate fixme condition
 */
#define cuwa_fixme()	cuwa_log(CUWA2_L_WARNING,"FIXME",NULL);

#ifdef __KLOCWORK__
#define CUWA_CONFIG_LOG_LEVEL CUWA2_L_TRACE
#else

#if (defined APACHE_BUILD || defined WIN32)
#define CUWA_GET_CONTEXT (cuwa_log_get_config_context())
#define CUWA_GET_CONFIG ((CUWA_GET_CONTEXT)->CUWA2_LOG_DOMAIN.v)

#define CUWA_CONFIG_LOG_LEVEL CUWA_GET_CONTEXT? ((CUWA_GET_CONFIG)?(*(CUWA_GET_CONFIG)):-1):-1
#else

#define CUWA_CONFIG_LOG_LEVEL CUWA2_L_TRACE

#endif
#endif

#define STRINGIFY(s) CUWA2_LOG_DOMAIN_STR(s)
#define CUWA2_LOG_DOMAIN_STR(x) #x

/**
 * Log a message at a specified severity
 * @param severity the message severity
 * @param message the message format string
 * @see cuwa_atrace|cuwa_trace|cuwa_info|cuwa_notice|cuwa_warning|cuwa_crit|cuwa_alarm
 */
#define cuwa_log(severity,message,...) cuwa_writelog( CUWA_CONFIG_LOG_LEVEL, STRINGIFY(CUWA2_LOG_DOMAIN),__FILE__,__func__,__LINE__,severity,message, ##__VA_ARGS__)

void cuwa_writelog (int configLogLevel, char *logdomain, const char *file, const char *func,
                    const int line, const int severity, const char *fmt, ...);

/**
 * defined to remove calls to cuwa_dassert from the code for speed. Don't define.
 */
#ifndef FAST_AND_DIRTY

/**
 *debug-only assertion that can safely be removed from release builds if desired.
 *same semantics as the standard C assert
 *@param[in] x expression to test
 *@invariant if cuwa_dassert returns than x is nonzero
 *@see cuwa_assert
 */
#define cuwa_dassert(x) cuwa_assert(x)
#else
#define cuwa_dassert(x) (-1);
#endif




char *cuwa_sprintf (const char *fmt, ...);

/**
 * an assert-like function that will not be removed during release builds.
 * cuwa_assert may be used to ensure that security invariants are not violated as
 * it will not be optimized out. It evaluates its argument exactly once.
 * @param x the expression to be tested for truth
 * @invariant if cuwa_assert(x) returns than x was nonzero
 * @return x
 * @see cuwa_dassert|cuwa_test
 * @note for visual studio also does an __analysis_assume
 */

#ifdef __KLOCWORK__
#define cuwa_assert(x) do { if (!(x)) abort(); } while (0)
#else

#ifdef FORTIFY
#define cuwa_assert(x) if((x)==NULL) abort()
#else

#ifdef _MSC_VER
#define cuwa_assert(x) do{cuwa_assertlog(CUWA_CONFIG_LOG_LEVEL,STRINGIFY(CUWA2_LOG_DOMAIN),__FILE__,__func__,__LINE__,#x, ((x)?-1:0), -1); __analysis_assume(x);} while(0)
#else
#define cuwa_assert(x) cuwa_assertlog(CUWA_CONFIG_LOG_LEVEL,STRINGIFY(CUWA2_LOG_DOMAIN),__FILE__,__func__,__LINE__,#x, ((x)?-1:0), -1)
#endif
#endif
#endif

/**
 * an assert-like function that will not be removed during release builds and that will not abort the program.
 * cuwa_test creates the same log entries as cuwa_assert but does not abort on failure.
 * It evaluates its argument exactly once and returns TRUE if it passes and FALSE otherwise.
 * @param x the expression to be tested for truth
 * @invariant if cuwa_assert(x) returns than x was nonzero
 * @return !x?TRUE:FALSE
 * @see cuwa_dassert|cuwa_assert
 */
#define cuwa_test(x) cuwa_assertlog(CUWA_CONFIG_LOG_LEVEL, STRINGIFY(CUWA2_LOG_DOMAIN),__FILE__,__func__,__LINE__,#x, (x), 0)


int cuwa_assertlog (int configLogLevel, char *logdomain, const char *file, const char *func,
                    const int line, const char *expr, const int value,
                    const int die);


#endif
