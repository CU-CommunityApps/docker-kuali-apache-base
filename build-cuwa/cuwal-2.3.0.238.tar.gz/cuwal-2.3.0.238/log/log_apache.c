/*
 * log_apache.c -- log for Apache
 *
 * Copyright 2007 Cornell University.
 * All Rights Reserved.
 *
 ************************************************************************
 *  $Log: log_apache.c,v $
 *  Revision 1.33  2015/10/07 17:51:16  hy93
 *  merge TwoFactor treee to the head
 *
 *  Revision 1.32.2.1  2015/06/30 13:00:11  hy93
 *  apache 2.4 support
 *
 *  Revision 1.32  2014/10/22 16:26:11  hy93
 *  remove Apache 2.4 support
 *
 *  Revision 1.31  2014/07/25 17:38:46  hy93
 *  Apache 2.4 support
 *
 *  Revision 1.30  2008/10/08 15:28:45  hy93
 *  fix sometimes file name and line number are not shown in log
 *
 *  Revision 1.29  2008/10/07 19:30:17  hy93
 *  extract none apache related functions to log_util.c
 *
 *  Revision 1.28  2008/10/03 19:51:47  hy93
 *  fix file name and line number displayed twice in log
 *
 *  Revision 1.27  2008/09/16 19:22:46  hy93
 *  add static to functions that are internal in the file
 *
 *  Revision 1.26  2008/09/08 16:05:38  hy93
 *  fix seg fault when calling apr_threadkey_private_create on 64 bits Ubuntu
 *
 *  Revision 1.25  2008/08/27 18:50:43  hy93
 *  Add parameter to the destructor of threadkey_private_create to avoid compiler warning on windows
 *
 *  Revision 1.24  2008/08/15 02:01:14  pb10
 *  Fix compiler warnings.
 *
 *  Revision 1.23  2008/08/12 00:50:13  gbr4
 *  support CUWATest HTTP header to facilitate log message tracing. This is only recognized for requests from 127.0.0.1. Add test function cuwat_GET which adds a CUWATest header with the calling test number, line and file to the underlying GET. Also add that to the access log and convert t10portal_permit.t to use the new cuwat_GET. Conversions of the other .t files to cuwat_GET will come shortly.
 *
 *  Revision 1.22  2008/07/30 19:01:16  gbr4
 *  Webauth now searches for notes recursively in both parent and main requests. remove log dependancy on WAL (weblogin wouldn't load).
 *
 *  Revision 1.21  2008/07/28 17:17:33  hy93
 *  add SID in log
 *
 *  Revision 1.20  2008/05/31 00:21:06  gbr4
 *  ugly hack in log_apache.c to prevent a crash in 2.0.63 on RHEL5.1.
 *
 *  Specifically, if the request_rec isn't fully filled out and the headers_in field is NULL then pretend a request_rec isn't available and use ap_log_error instead of ap_log_rerror
 *
 *  ap_log_rerror will attempt to apr_table_get request_rec->headers in
 *
 *  to reproduce request a protected / on an otherwise default 2.0.63 conf without this.
 *
 *  Revision 1.19  2008/05/09 15:20:15  gbr4
 *  typo
 *
 *  Revision 1.18  2008/05/09 15:17:13  gbr4
 *  log_apache now uses the source line number instead of the line within log_apache.c. There is still double-printing of the line number for [debug] messages, not sure where/why this happens (i.e. whether this is configurable within apache). Leaving the explicit print of source information for now.
 *
 *  weblogin.c now calls cuwa_free consistantly to remove crash after cred was updated to use apr's malloc
 *
 *  Revision 1.17  2008/05/05 19:13:15  gbr4
 *  fix error introduced in log 1.37 that broke solaris build. also commit conditional code used in klocwork build and add an assert in rand to check that /dev/urandom read succeeded.
 *
 *  Revision 1.16  2008/04/16 03:23:37  gbr4
 *  Add @ to the log_sanitize whitelist. As far as I know it isn't terribly useful for attacks and makes the log messages much more readable since we use principal@REALM notation in many places.
 *
 *  Revision 1.15  2008/04/04 04:05:29  gbr4
 *  weblogin needs to link log_apache.c
 *
 *  Revision 1.14  2008/04/04 02:56:18  gbr4
 *  revert typo in log_apache
 *
 *  Revision 1.13  2008/04/04 02:50:03  gbr4
 *  added sys/socket and sys/types to try to fix openbsd build
 *
 *  Revision 1.12  2008/03/26 21:06:34  pb10
 *  Enable host checking in webauth. Fix minor log sanitizing glitch.
 *
 *  Revision 1.11  2008/03/26 03:07:32  pb10
 *  Added code to sanitize log messages displayed in the error page.
 *
 *  Revision 1.10  2008/03/24 21:32:22  pb10
 *  Better error page support.
 *
 *  Revision 1.9  2008/01/25 14:41:26  hy93
 *  remove debugging code
 *
 *  Revision 1.8  2008/01/25 03:21:04  hy93
 *  add error checking
 *
 *  Revision 1.7  2008/01/25 01:43:47  gbr4
 *  Added an ID string to every file
 *
 *  Revision 1.6  2008/01/21 19:44:57  hy93
 *  prevent access thread local before log has been initialized
 *
 *  Revision 1.5  2008/01/18 05:06:07  pb10
 *  Fix include cfg.h, compiler warning.
 *
 *  Revision 1.4  2008/01/16 20:35:44  hy93
 *  fix log
 *
 *  Revision 1.3  2008/01/15 14:39:28  hy93
 *  Add version block for cvs
 *
 ************************************************************************
 */
#include <http_request.h>
#include <apr_tables.h>
#include <httpd.h>
#include <http_protocol.h>
#include <http_config.h>
#include <http_log.h>
#include <apr_thread_proc.h>
#include <log.h>
#include <cuwa_err.h>
#include <log_util.h>
#include <cfg.h>
#include <wal.h>

extern module AP_MODULE_DECLARE_DATA *cuwa_module;
#define CUWA2_LOG_DOMAIN cuwa.logger

void cuwa_apache_native_log( apr_status_t apr_err, char *buf)
{
    ap_log_perror(APLOG_MARK, APLOG_ALERT, apr_err, NULL,"thread key error:%s", buf);
}

static char* cuwa_read_notes_recursive(request_rec *r, char *name){
	char *ret=NULL;
	if(!r) return NULL;

	if(!ret && r->notes) ret=(char*)apr_table_get(r->notes,(const char*)name);
	if(!ret && r->main) ret=cuwa_read_notes_recursive(r->main,name);
	if(!ret && r->prev) ret=cuwa_read_notes_recursive(r->prev,name);
	return(ret);
}
	

void cuwa_log_print( int logLevel, char *file, int line, int severity, char *logdomain, char *msg )
{
    void *rec = NULL;
    apr_threadkey_t *request_key = cuwa_log_get_request_key();
    apr_threadkey_t *server_key = cuwa_log_get_server_key();
    apr_threadkey_t *connection_key = cuwa_log_get_connection_key();
    
    /*when log level is not defined in CUWA, let Apache decide to log it or not.
      when log level is defined, we log it no matter what Apache's loglevel is set to
     */
    if ( logLevel < 0 )
        logLevel = severity;
    else
        logLevel = APLOG_ALERT;

    if ( !request_key || !server_key || !connection_key )
    {
        //log hasn't been initialized yet
        cuwa_wal_log_error(NULL,logLevel,file,line,severity,logdomain,msg);
        return;
    }

    apr_threadkey_private_get(&rec, request_key);
    if ( rec )
    {
        char *sidStr = cuwa_read_notes_recursive((request_rec *) rec,"CUWA_SID" );
	request_rec *r=rec;

	//apache 2.0.63 sometimes crashes if rec->headers_in is NULL
	//so work around it -- bit of a hack
	if( r->headers_in){
		//if the request came from localhost, paste the CUWATest header into the log
		//this is a mechanisim for the test harness to paste information into the error log to
		//help match error log entries to tests
		//currently restricted to localhost. Perhaps the header should be sanitized and then
		//allowed from elsewhere?
		char *cuwatest=NULL;
		if(r->connection && cuwa_wal_get_remote_IP(r) && !strcmp(cuwa_wal_get_remote_IP(r),"127.0.0.1")) cuwatest=(char*)apr_table_get(r->headers_in,"CUWATest");
		//apr_threadkey_private_get(&s, server_key);
                cuwa_wal_log_rerror(r,logLevel,file,line,severity,logdomain, msg,cuwatest,sidStr);
	}
	else{
		rec=NULL;
	}
    }

    if(!rec)
    {
        apr_threadkey_private_get(&rec, server_key);
        if ( rec )
        {
            cuwa_wal_log_error(rec,logLevel,file,line,severity,logdomain,msg);
        }
        else
        {
            apr_threadkey_private_get(&rec, connection_key);
            if ( rec )
            {
                cuwa_wal_log_cerror(rec,logLevel,file,line,severity,logdomain, msg);
            }
            else
            {
                cuwa_wal_log_perror(NULL,logLevel,file,line,severity,logdomain,msg);
            }
         }
     }

}

CUWACfg_t *cuwa_log_get_config_context()
{
    CUWACfg_t *cfg = NULL;
    request_rec *r = NULL;
    server_rec *s = NULL;
    apr_status_t apr_err;
    cuwa_err_t status = CUWA_OK;
    apr_threadkey_t *request_key = cuwa_log_get_request_key();
    apr_threadkey_t *server_key = cuwa_log_get_server_key();
    apr_threadkey_t *connection_key = cuwa_log_get_connection_key();

    if ( !request_key || !server_key || !connection_key )
    {
        //log hasn't been initialized yet
        return NULL;
    }

    apr_err = apr_threadkey_private_get((void *)&r, request_key);
    status = cuwa_log_apr_err( apr_err );

    if ( (status == CUWA_OK) && r && r->per_dir_config)
    {
        // Check for r->per_dir_config!=NULL needed because it isn't set yet in early phase of filter
        cfg = ap_get_module_config(r->per_dir_config, cuwa_module);
    }
    if ( !cfg)
    {
        apr_err = apr_threadkey_private_get((void*)&s, server_key);
        status = cuwa_log_apr_err( apr_err );
        if ( (status == CUWA_OK) && s )
        {
            cfg = (CUWACfg_t *)ap_get_module_config(s->module_config, cuwa_module);
        }
    }
    return cfg;
}


const char id_log_log_apache_c[] = "$Id: log_apache.c,v 1.33 2015/10/07 17:51:16 hy93 Exp $";
