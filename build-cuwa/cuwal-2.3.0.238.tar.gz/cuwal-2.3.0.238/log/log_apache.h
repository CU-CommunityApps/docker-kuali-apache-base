/************************************************************************
 * log_apache.h -- CUWAL2 Logging Subsystem
 *
 * Copyright 2007 Cornell University.
 * All Rights Reserved.
 *
 ************************************************************************
 *  $Log: log_apache.h,v $
 *  Revision 1.8  2008/10/07 19:30:20  hy93
 *  extract none apache related functions to log_util.c
 *
 *  Revision 1.7  2008/10/03 19:51:10  hy93
 *  add const in the second parameter of function cuwa_log_apache_print
 *
 *  Revision 1.6  2008/09/16 19:22:28  hy93
 *  remove function prototypes that are internal in log_apache.c
 *
 *  Revision 1.5  2008/04/04 03:58:15  gbr4
 *  files missing from previous checkin
 *
 *  Revision 1.3  2008/03/24 21:32:22  pb10
 *  Better error page support.
 *
 *  Revision 1.2  2008/01/16 20:35:44  hy93
 *  fix log
 *
 *  Revision 1.1  2008/01/10 17:58:18  hy93
 *  Log code for Apache build
 *
 ************************************************************************
 */
#ifndef __CUWA2_LOG_APACHE_H
#define __CUWA2_LOG_APACHE_H

#include <log_util.h>

#define cuwa_log_apache_init cuwa_log_init
#define cuwa_log_apache_set_keys(r,s,c)    cuwa_log_set_keys((void *)r,(void *)s,(void *)c)

void cuwa_apache_native_log( apr_status_t apr_err, char *buf);

#endif

