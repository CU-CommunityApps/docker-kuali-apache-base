/************************************************************************
 * log_util.h -- utility functions for log
 *
 * Copyright 2008 Cornell University.
 * All Rights Reserved.
 *
 ************************************************************************
 *  $Log: log_util.h,v $
 *  Revision 1.1  2008/10/07 19:30:06  hy93
 *  extract none apache related functions to log_util.c
 *
 *
 ************************************************************************
 */

#ifndef _LOG_UTIL_H
#define _LOG_UTIL_H

#include <apr_pools.h>
#include <apr_thread_proc.h>
#include <cfg.h>
#include <cuwa_err.h>

cuwa_err_t  cuwa_log_init(apr_pool_t *pool);
void cuwa_log_set_keys( void *request, void *server, void *conn);
void cuwa_log_print( int configLogLevel,char *file, int line, int level, char *domain, char *msg );
void cuwa_log_stash_msg(int logLevel, char *msg);
int cuwa_log_should_stash(int logLevel);
apr_threadkey_t *cuwa_log_get_request_key();
apr_threadkey_t *cuwa_log_get_server_key();
apr_threadkey_t *cuwa_log_get_connection_key();
CUWACfg_t *cuwa_log_get_config_context();
cuwa_err_t cuwa_log_apr_err( apr_status_t apr_err);
void cuwa_log_delete_key(void *p);
#endif
