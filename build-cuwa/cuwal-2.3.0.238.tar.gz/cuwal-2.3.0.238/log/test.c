#include <log.h>
#include <stdlib.h>

#define CUWA2_LOG_DOMAIN cuwa.logger

int main(int argc, char ** argv){

	cuwa_info("this is info");
	cuwa_notice("this is notice");
	cuwa_warning("this is warning");
	cuwa_alarm("this is alarm");

        if(cuwa_assert(1==1)){
                cuwa_trace("cuwa_assert true ok");
        }
        if(!cuwa_test(1==0)){
                cuwa_crit("cuwa_test true false");
        }
        cuwa_assert(0);

	return 0;
}

const char id_log_test_c[] = "$Id: test.c,v 1.13 2008/01/25 01:43:47 gbr4 Exp $";
