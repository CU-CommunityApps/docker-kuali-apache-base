package TwoFactor::DualHtml;

use MIME::Base64;
use Digest::SHA qw(hmac_sha256);

my @agentList = ('iphone', 'ipod', 'android', 'windows phone', 'blackberry');

sub add_cookie {
    my ($user,$method,$key) = @_;

    my $authTime = time;
    my $cookie = $user.":".$authTime.":".$method;

    my $sig = hmac_sha256($cookie, $key);
    $sig = encode_base64($sig,'');

    return "$cookie:$sig";
}

sub verify_cookie {
   my ($cookie,$key) = @_;

   $cookie = substr $cookie,1, length($cookie)-2;
   my ($netid, $startTime, $sid, $sig) = split(/:/,$cookie);

   my $info = $netid.":".$startTime.":".$sid;
   my $sig1 = hmac_sha256($info, $key);
   $sig1 = encode_base64($sig1,'');

  if ($sig != $sig1 ) {
     $netid="";
  }

  return "$netid";

}

sub encode_string {

    my ($inputStr) = @_;
    my $encodedStr = encode_base64($inputStr,'');

    return "$encodedStr";
}

sub decode_string {

   my ($inputStr) = @_;
   my $decodedStr = decode_base64($inputStr);

   return "$decodedStr";
}

sub is_from_mobile {

    my ($agent) = @_; 
    my $isFromMobile = 0;

    $agent = lc($agent);

    foreach (@agentList) {
        my $result = index($agent, $_);
        if ( $result > 0 ) {
            $isFromMobile = 1;
            break;
        }
    }
   return "$isFromMobile";
}

1;
