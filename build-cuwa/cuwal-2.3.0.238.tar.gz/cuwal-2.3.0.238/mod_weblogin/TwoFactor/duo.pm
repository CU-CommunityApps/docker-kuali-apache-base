package TwoFactor::duo;

use strict;
use warnings;

use Apache2::RequestRec ();
use Apache2::Log;

use CGI ':standard';
use CGI::Cookie;
use TwoFactor::DuoWeb;
use LWP::UserAgent;
use Data::Dumper();
use TwoFactor::DualHtml;
use Apache2::Const qw(REDIRECT OK);
use TwoFactor::init ();

my $keeper = "keeper";
my $content = $TwoFactor::init::duoConfig{html}{web};
my $mContent = $TwoFactor::init::duoConfig{html}{mWeb};
my $HOST = $TwoFactor::init::duoConfig{HOST};
my $PASS_THROUGH = $TwoFactor::init::duoConfig{PASS_THROUGH};
my $IKEY = $TwoFactor::init::duoConfig{keys}{IKEY};
my $SKEY = $TwoFactor::init::duoConfig{keys}{SKEY};
my $AKEY = $TwoFactor::init::duoConfig{keys}{AKEY};
my $CKEY = $TwoFactor::init::duoConfig{keys}{CKEY};


sub handler {
my $query = CGI->new();
my $r = shift;

if($r->method eq 'GET') {

    my %cookies = CGI::Cookie->fetch;
    my $dualCookie = "";
    my $netid = "";

    if ($cookies{'cuwlduals'} ) {
        $dualCookie = $cookies{'cuwlduals'}->value;
  
        $netid = &TwoFactor::DualHtml::verify_cookie($dualCookie,$CKEY);
    }

    if (length($netid) < 2) 
    {
        #invalid netid, send back to dual Handler
        my $newlocation = "/DUOdone?$ENV{'QUERY_STRING'}";

        $r->headers_out->set(Location => $newlocation);
        $r->status(REDIRECT);
        $r->content_type('text/html; charset=ISO-8859-1');

        return OK;
    }
    
    if ( $PASS_THROUGH eq "on" ) {
        my $cookie = "";
        $cookie = &TwoFactor::DualHtml::add_cookie( $netid, "DUO", $CKEY);
        $cookie = "\"".$cookie."\"";
        $cookie="cuwldualv=".$cookie.";path=/; secure; HttpOnly";

        my $newlocation = "/DUOdone?$ENV{'QUERY_STRING'}";

        $r->err_headers_out->add('Set-Cookie' => $cookie);
        $r->headers_out->set(Location => $newlocation);
        $r->status(REDIRECT);
        $r->content_type('text/html; charset=ISO-8859-1');
    }
    else {
        my $sig_request = TwoFactor::DuoWeb::sign_request($IKEY, $SKEY, $AKEY, $netid);
        my $isFromMobile = &TwoFactor::DualHtml::is_from_mobile($ENV{'HTTP_USER_AGENT'});
        my $queryString = &TwoFactor::DualHtml::encode_string($ENV{'QUERY_STRING'});

        $r->log->notice("Requesting DUO for $netid, $ENV{'QUERY_STRING'}");
        $r->no_cache(1);
        $r->content_type('text/html; charset=ISO-8859-1');

       if ($isFromMobile eq 1) {
           $content = $mContent;
       }
       $content =~ s/DUO_HOST/$HOST/i;
       $content =~ s/DUO_SIG_REQUEST/$sig_request/i;     
       $content =~ s/DUO_QUERY_STRING/$queryString/i;
       $r->print($content);
  }

} elsif($r->method eq 'POST') {

    my $sig_response = $query->param('sig_response');
    my $auth_username = TwoFactor::DuoWeb::verify_response($IKEY, $SKEY, $AKEY, $sig_response);

    my $cookie = "";
    my $keeperStr = $ENV{'QUERY_STRING'};
    $keeperStr = substr $keeperStr, length($keeper)+1; 
   
    if ($auth_username) 
    {
        $cookie = &TwoFactor::DualHtml::add_cookie( $auth_username, "DUO", $CKEY); 
        $cookie = "\"".$cookie."\"";
    }
    my $paramString = &TwoFactor::DualHtml::decode_string( $keeperStr );
    my $newlocation = "/DUOdone?$paramString";

    my $outCookie = CGI::Cookie->new(-name => 'cuwldualv',
                                     -value => $cookie);

    $cookie="cuwldualv=".$cookie.";path=/; secure; HttpOnly"; 
    $r->err_headers_out->add('Set-Cookie' => $cookie);
    $r->headers_out->set(Location => $newlocation);
    $r->status(REDIRECT);
    $r->content_type('text/html; charset=ISO-8859-1');
}
return OK;
}
1;

