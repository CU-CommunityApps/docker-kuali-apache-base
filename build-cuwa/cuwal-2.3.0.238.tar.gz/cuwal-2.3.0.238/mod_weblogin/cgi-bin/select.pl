#!/usr/bin/perl
use strict;
use warnings;
#use CGI;
use CGI ':standard';
use LWP::UserAgent;
use Data::Dumper();
use DualHtml;

my @abbrMon = qw(Jan Feb Mar Apr May Jun Jul Aug Sep Oct Nov Dec);
my @abbrDay = qw(Mon Tue Wed Thu Fri Sat Sun);
my $query = CGI->new();

if($query->request_method() eq 'GET') {

    print $query->header();
    print <<HTML;
    <!DOCTYPE html
        PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
        "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
    <html xmlns="http://www.w3.org/1999/xhtml" lang="en-US" xml:lang="en-US">

    <head>
    <title>Cornell Two Factor Authentication</title>
HTML
    &DualHtml::printStyle;
    print "</head>\n";
    &DualHtml::printHeader; 
    &printSelectForm;
   
    &DualHtml::printFooter;

} elsif($query->request_method() eq 'POST') {
    # keep for debugging

     my $choice = $query->param('dualChoice');

     my $cookie = "";
     my $domain =".cornell.edu";

     my $newlocation = "/$choice?$ENV{'QUERY_STRING'}";
     
     (my $sec,my $min, my $hour, my $mday, my $mon, my $year, my $wday, my $yday, my $isdst) = localtime(time);

     $year += 1910;
     my $expirationStr = "$abbrDay[$wday],$mday $abbrMon[$mon] $year $hour:$min:$sec";
 
     print "Set-Cookie: cuwldualmethod=\"$choice\"; domain=$domain; expires=$expirationStr GMT;\n";
     print redirect($newlocation);    
}
print $query->end_html();

sub printSelectForm
{
print <<HTML;

<H3>Selet the authentication method you would like to use</H3>
        <form method="post">
            <p><input type="radio" name="dualChoice" value="RSA" checked>Login with RSA</input></p>
            <p><input type="radio" name="dualChoice" value="DUO">Login with Duo</input></p>
            <p><input type="submit" value="Submit"> </p>
        </form>

HTML

}


