/* post_decode allocates a string from the pool */

#include "httpd.h"
#include "http_config.h"
#include "http_protocol.h"
#include "ap_config.h"
#include "http_log.h"


#define CUWA_APACHE_HACK_LOG

#include "../log/log.h"
#include "../util/list.h"

#include "weblogin.h"
#include "cuwl_aputil.h"

const char id_cuwl_aputil_c[] = "$Id: cuwl_aputil.c,v 1.10 2013/07/30 19:29:53 hy93 Exp $";

#undef CUWA2_LOG_DOMAIN
#define CUWA2_LOG_DOMAIN weblogin

void cuwl_output(weblogin_req_t *wr, const char *s, ...){
    va_list va;
    char *ret;
    va_start(va,s);
    ret=apr_pvsprintf(wr->p, s, va);
    va_end(va);
    ap_rprintf(((request_rec *)(wr->apreq)),ret);
}
void cuwl_debug_out(weblogin_req_t *wr, int level, const char *s,  ...){
    va_list va;
    char *ret;
    va_start(va,s);
    ret=apr_pvsprintf(wr->p, s, va);
    va_end(va);
    ap_rprintf((request_rec *)(wr->apreq),ret);	
}

void cuwl_output_header(weblogin_req_t *wr, char *header, char *value){
	apr_table_add(((request_rec*)(wr->apreq))->err_headers_out, header,value);
}

char* cuwa1_post_decode(apr_pool_t *p, char *data)
{       
    int i, j;
        
    /* for post data, we first need to account for +
       space translations... */
    
    for (i = 0, j = 0; data[i] != '\0'; i++)
        if (data[i] == '+')
            data[i] = ' ';
        
    /* but the rest we can just let the API handle */
    ap_unescape_url(data);
    return apr_pstrdup(p,data);
    
}


//this is broken for multipart encoded forms
int cuwa1_buildPostData (request_rec *r, apr_table_t *pData)
{
    int rc;
    const char *key, *val;
    char *readBuf=NULL;

    if ((rc = ap_setup_client_block(r, REQUEST_CHUNKED_ERROR)) != OK)
    {
        return rc;
    }

    if (ap_should_client_block(r))
    {
        char buf[MAX_STRING_LEN];
        int rsize, len_read, rpos = 0;
        long length = r->remaining;

        readBuf = (char*) apr_pcalloc(r->pool, length + 1);

        while ((len_read = ap_get_client_block(r, buf, sizeof(buf))) > 0)
        {
            if ((rpos + len_read) > length)
            {
                rsize = length - rpos;
            }
            else
            {
                rsize = len_read;
            }
            memcpy(readBuf + rpos, buf, rsize);
            rpos += rsize;
        }
    }

    while (readBuf && *readBuf && (val = ap_getword(r->pool, (const char**) &readBuf, '&')))
    {   
        key = ap_getword(r->pool, &val, '=');

	if (!key || !val)
	{
            ap_log_rerror(APLOG_MARK, APLOG_NOERRNO|APLOG_DEBUG, 0, r,
                "read_post(...): invalid key or value, key = %s, val = %s", key, val);
            break;
        }

        apr_table_add(pData, cuwa1_post_decode(r->pool, (char *)key), cuwa1_post_decode(r->pool, (char *)val));
    }
    return OK;
}

char *cuwl_get_cookie(request_rec *r, char *cookieName)
{
    char *cookie = NULL;

    char *tmp = (char *)apr_table_get(r->headers_in, "Cookie");

    if (tmp)
    {
        char * cprefix;
        cuwa_trace("Parsing cookie:%s",tmp); //fixme-log-leakage
        cprefix=apr_pstrcat(r->pool,cookieName,"=\"",NULL);
        cookie=strstr(tmp,cprefix);
        if(cookie)
        {
            char *cdata_end;
            cookie=apr_pstrdup(r->pool,cookie+strlen(cprefix));
            cdata_end=strchr(cookie,'"');
            if(cdata_end)
            {
                *cdata_end='\0';
                cuwa_trace("Found cookie data: %s",cookie);
            }
        }
    }
    return cookie;
}
