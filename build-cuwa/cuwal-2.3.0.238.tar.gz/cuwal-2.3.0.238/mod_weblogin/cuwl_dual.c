#include <apr_pools.h>
#include <apr_base64.h>
#include <apr_time.h>

#include <weblogin.h>
#include <cuwl_html.h>
#include <cuwl_permit.h>
#include <sha2.h>
#include <hmac_sha2.h>
#include <log.h>
#include <cuwl_dual.h>
#include <cuwl_aputil.h>
#include <util.h>
#include <cuwa_malloc.h>
#include <wal.h>
#include <cfg.h>

#include <time.h>
#include <list.h>

#undef CUWA2_LOG_DOMAIN
#define CUWA2_LOG_DOMAIN weblogin

#define CUWL_DUAL_COOKIE_DATA_MAX 4
#define CUWL_DUAL_COOKIE_KEY "CKEY="
#define CUWL_DUAL_REASON_CODE 2

static unsigned char *weblogin_dual_cookie_key_g = NULL;
static int weblogin_dual_cookie_key_len_g = 0;

/*******************************************************
 * read cookie key from cuwl-2FA.key file.
 * This key is used for hmac sha256 encryption

 ******************************************************/
void cuwl_dual_init( apr_pool_t *pool)
{
    char *key = NULL;

    cuwl_load_file(pool,pool,CFG_CUWL2FAKey(NULL),&key);

    if ( key )
    {
        //get the value of CKEY
        char *p = strstr(key, CUWL_DUAL_COOKIE_KEY);
        char *tmp = NULL;

        if (p)
        {
            p+=strlen(CUWL_DUAL_COOKIE_KEY)+1;
            tmp = strchr(p,'"');
            if ( tmp ) *tmp = '\0';

            key = apr_pstrdup(pool, p);
            weblogin_dual_cookie_key_len_g = strlen(key);
            weblogin_dual_cookie_key_g = (unsigned char *)key;
        }
    }
    if (weblogin_dual_cookie_key_len_g == 0 || !weblogin_dual_cookie_key_g) 
    {
        cuwa_crit("didn't find 2FA cookie key");
    }

}


void cuwl_dual_hash( apr_pool_t *pool, char *data, char **hashedData )
{
    unsigned char hash[SHA256_DIGEST_SIZE];
    char *encoded = apr_palloc(pool,(SHA256_DIGEST_SIZE*2)+3);

    cuwa_trace("data to hash:%s",data);
    hmac_sha256(weblogin_dual_cookie_key_g, weblogin_dual_cookie_key_len_g, (unsigned char *)data, strlen(data),hash,SHA256_DIGEST_SIZE);
    apr_base64_encode_binary(encoded,hash,SHA256_DIGEST_SIZE);

    *hashedData = encoded;
}

/*****************************************************************************
 * Get two factor authentication cookie, verify the cookie is valid 
 * CUWL_DUAL_COOKIE_START cookie has format userID:Time:SID:Sig
 * CUWL_DUAL_COOKIE cookie has format userID:Time:method:Sig
 * CUWL_DUAL_COOKIE_VENDOR has format userID:Time:method:Sig
 ****************************************************************************/
void cuwl_dual_get_cookie( weblogin_req_t *wr, char *cookieName, char **dualAuthUser, apr_time_t *timeInCookie, char **method )
{
    char *cookie = NULL;
    char *user = NULL;
    char *method_or_sid = NULL;
    char *time= NULL;
    char *cookie_sig=0L;
    char *infoToValidate = NULL;

    cookie = cuwl_get_cookie( wr->apreq, cookieName);
    if (cookie)
    {
        char *ptr,*state;

        int i = 0;
        char *encoded = NULL;
        char *cookieData[CUWL_DUAL_COOKIE_DATA_MAX];
	int j = 0;
	for( j=0; j<CUWL_DUAL_COOKIE_DATA_MAX; ++j ) {
            cookieData[j] = NULL;
        }

        cuwa_trace("found cookie %s",cookie);

        ptr = apr_strtok( cookie, ":", &state );
        while (ptr && i < CUWL_DUAL_COOKIE_DATA_MAX)
        {
            cookieData[i] = apr_pstrdup( wr->p, ptr);
            i++;
            ptr = apr_strtok( NULL, ":", &state);
        }
        
        if ( cookieData[0] )    user = cookieData[0];
        if ( cookieData[1] )    time = cookieData[1];
        if ( cookieData[2] )    method_or_sid = cookieData[2];
        if ( cookieData[3] )    cookie_sig = cookieData[3];

 
        if ( !cookieData[0] || !cookieData[1] || !cookieData[2] || !cookieData[3] ) 
        {
            cuwa_warning("dual cookie is malformed; ignoring");
            return;
        }

        cuwa_trace("DualAuthCookie:user=%s, Method(or SID)=%s, Time=%s, signature=%s",user, method_or_sid,time,cookie_sig);

        infoToValidate = apr_psprintf( wr->p, "%s:%s:%s", user, time, method_or_sid);
            
        cuwl_dual_hash( wr->p, infoToValidate, &encoded );
        if ( !encoded )
        {
            cuwa_warning("memory allocation failed");
        }
        else if (strcmp((char *)encoded, cookie_sig))
        {
            cuwa_warning("cuwl_dual cookie is invalid. sig=%s,hashed=%s",cookie_sig,encoded);
            cuwl_audit_add(wr, 0, "sso_dual_invalidsig");
        }
        else   
        {
            *dualAuthUser = user;
            if (timeInCookie) *timeInCookie = atoi(time);
            *method = method_or_sid;
            cuwa_trace("user in cookie %s, time=%" APR_TIME_T_FMT ",method(or sid)=%s", *dualAuthUser, *timeInCookie,*method);
        }
    }
}

/************************************************************************
 * Two factor authentication cookie indicate the user completed two factor
 * authentication. It has format netid:time:signature
************************************************************************/
void cuwl_dual_make_cookie( weblogin_req_t *wr )
{
    char *cookie = apr_psprintf(wr->p, "%s:%" APR_TIME_T_FMT ":%s" , wr->r.dualAuthUser, wr->r.dualAuthTime, wr->r.dualAuthMethod);
    char *encoded = NULL;

    cuwl_dual_hash( wr->p, cookie, &encoded);

    wr->r.dualAuthCookie = apr_pstrcat(wr->p, cookie,":",encoded, NULL);

}

void cuwl_dual_clear_cookie( weblogin_req_t *wr, char *cookieName )
{
    char *tmp= NULL;

    if ( !strcmp(cookieName, CUWL_DUAL_COOKIE)) 
        tmp = apr_psprintf(wr->p,"%s=deleted; expires=01-01-2000; domain=%s; path=/; secure; HttpOnly",cookieName, wr->r.ssodomain);
    else
        tmp = apr_psprintf(wr->p,"%s=deleted; expires=01-01-2000; path=/; secure; HttpOnly",cookieName);

    cuwl_output_header(wr, "Set-Cookie",tmp);
}

/**********************************************************************
 * check if user loggedin in the primary authentication is the same user
 * logged in in two factor auth
 **********************************************************************/
int cuwl_dual_verify_user( apr_pool_t *pool, char *dualUser, char *loginUser )
{
    int match = -1;
    char *cuwlUser = apr_pstrdup(pool, loginUser);

    //if second authentication method does not inculde realm, remove realm for the user
    //in first authentication before comparision 
    if ( !strstr(dualUser,"@") )
    {
        char *tmp = strstr( cuwlUser, "@");

        if (tmp) *tmp = '\0';
    }
    if ( strcmp( dualUser, cuwlUser ) )
    {
        cuwa_warning("User %s authenticated with CUWeblogin doesn't match the user %s authenticated with second factor",cuwlUser, dualUser);
    }
    else match = CUWL_DUAL_USER_SAME;

    return match;
}

/**********************************************************
 *check if user is required to do two factor authentication
 **********************************************************/
/*we use webAuth pass in url parameter to decide for now. We might
 *let web login to decide if dual is needed later. so just comment
 *out this function  
int cuwl_dual_auth_needed( weblogin_req_t *wr )
{
    int needDualAuth = CUWL_DUAL_AUTH_NO;

    if ( wr->needDualAuth != CUWL_DUAL_AUTH_UNKNOWN )
        return wr->needDualAuth;

    if (!wr->r.dualAuthUser )   
    {
        if ( wr->q.dualAuth )
        {
            if (!apr_strnatcasecmp(wr->q.dualAuth,"all") ) 
                needDualAuth = CUWL_DUAL_AUTH_YES;
            else
            {
                //check if user is in the group that require two factor
                int result = 0;
                CUWACfg_t *cfg = cuwa_wal_get_config((void *)wr->apreq);

                cuwa_util_replace_char_with(wr->q.dualAuth,',',' ');

               cuwa_trace("check if user %s is in permit %s", wr->r.cuwlUser, wr->q.dualAuth);
               result = cuwl_in_permit( wr->p, CFG_CUWLPermitPrincipal(cfg), CFG_CUWLPermitKeytab(cfg), wr->q.dualAuth, wr->r.cuwlUser );

               if ( result == CUWL_PERMIT_HAS )   needDualAuth = CUWL_DUAL_AUTH_YES;
               else if ( result == CUWL_PERMIT_MISSING )  needDualAuth = CUWL_DUAL_AUTH_NO;
               else  needDualAuth = CUWL_PERMIT_ERROR;
            }
        }
    }
    if ( needDualAuth != CUWL_PERMIT_ERROR )   
        wr->needDualAuth = needDualAuth;

    cuwa_trace("needDualAuth return %d",needDualAuth);

    return needDualAuth;
}
*/

int cuwl_dual_auth_needed( weblogin_req_t *wr )
{
    int needDualAuth = CUWL_DUAL_AUTH_NO;

    if ( wr->needDualAuth != CUWL_DUAL_AUTH_UNKNOWN )
        return wr->needDualAuth;

    if (!wr->r.dualAuthUser )   
    {
        if ( wr->q.waReasonCode == CUWL_DUAL_REASON_CODE )
            needDualAuth = CUWL_DUAL_AUTH_YES;
    }

    cuwa_trace("needDualAuth return %d",needDualAuth);

    wr->needDualAuth = needDualAuth;
    return needDualAuth;
}

/*************************************************************
 * CUWL_DUAL_COOKIE_METHOD cookie contains the last two factor
 * authentication method that user used. If cookies is available,
 * use method in the cookied for this login. Otherwise, give user
 * the seleciton page that user can choose which method to use.
 **************************************************************/
char * cuwl_dual_get_method( weblogin_req_t *wr )
{
    
    char *rMethod = NULL;
    char *method = NULL;
    char *defaultMethod = "DUO";

    if (wr->q.dualAuthMethod) method = wr->q.dualAuthMethod;
    else
    {
        method = cuwl_get_cookie( wr->apreq, CUWL_DUAL_COOKIE_METHOD);
    }

    if (method)
    {
        if (!apr_strnatcmp(method,"DUO")  ||
            !apr_strnatcmp(method,"TEST"))
            rMethod = method;
        else if (!wr->q.dualAuthMethod) rMethod = defaultMethod;
    }
    else rMethod = defaultMethod;

    cuwa_trace("dual_get_method return %s",rMethod);
    return rMethod;
}

/************************************************************
 * remove the CUWLUser=xxx parameter that is inserted by weblogin
 * server when redirect to two factor auth. This is to prevent
 * CUWLUser appears in URL many times.
 ***********************************************************/
void cuwl_dual_remove_params( weblogin_req_t *wr )
{
    char param[]="&CUWLUser=";

    char *p = strstr( wr->query, param );

    if (p) 
    {
        char *tmp = p+1;
        *p = '\0';

        p = strchr( tmp, '&');
        if ( p ) wr->query = apr_pstrcat(wr->p,wr->query,p, NULL);        
    }
   
}

/*****************************************************
 * set CUWL_DUAL_COOKIE_START cookie before redirect 
 * user to do two factor authentication. This cookie
 * indicates the time that two factor auth screen is 
 * prompted to the user.So later on we can calculate 
 * the total time user spend on two factor auth.
 *****************************************************/
void cuwl_dual_set_start_cookie( weblogin_req_t *wr )
{
    char *sig,*cookie,*tmp,*timeStr;
    apr_time_t startTime = apr_time_sec( apr_time_now());
    apr_time_exp_t xt;

    apr_time_exp_gmt(&xt, apr_time_now());
    timeStr = apr_psprintf( wr->p, "%s,%02d %s %4d %02d:%02d:%02d GMT",
                                    apr_day_snames[xt.tm_wday],
                                    xt.tm_mday,
                                    apr_month_snames[xt.tm_mon],
                                    xt.tm_year+1900,
                                    xt.tm_hour+1,
                                    xt.tm_min,
                                    xt.tm_sec );

    cookie = apr_psprintf(wr->p, "%s:%" APR_TIME_T_FMT ":%s",wr->r.cuwlUser,startTime,wr->sid);
    cuwl_dual_hash( wr->p, cookie, &sig );

    cookie = apr_pstrcat( wr->p, cookie, ":",sig, NULL);

    tmp=apr_psprintf(wr->p,"%s=\"%s\"; path=/; expires=%s; secure;HttpOnly", CUWL_DUAL_COOKIE_START, cookie, timeStr);
    cuwl_output_header(wr,"Set-Cookie",tmp);
    cuwa_info("Sending dualAuth start cookie");

}

/**************************************************************
 * set the two factor authentication method user used in cookie.
 *************************************************************/
char *cuwl_dual_set_method_cookie(weblogin_req_t *wr, char *uri)
{
    char *tmp =NULL,*timeStr;
    char *method = uri+1;   
    apr_time_exp_t xt;

    tmp = strchr( method, '/');
    if ( tmp ) *tmp = '\0';

    tmp = strstr(uri,"done");
    if ( tmp ) *tmp = '\0';

    apr_time_exp_gmt(&xt, apr_time_now());
    timeStr = apr_psprintf( wr->p, "%s,%02d %s %4d %02d:%02d:%02d GMT",
                                    apr_day_snames[xt.tm_wday],
                                    xt.tm_mday,
                                    apr_month_snames[xt.tm_mon],
                                    xt.tm_year+1910,
                                    xt.tm_hour,
                                    xt.tm_min,
                                    xt.tm_sec );

    tmp=apr_psprintf(wr->p,"%s=\"%s\"; path=/; domain=.cornell.edu; expires=%s; Secure; HttpOnly",CUWL_DUAL_COOKIE_METHOD,method,timeStr);
    cuwl_output_header(wr,"Set-Cookie",tmp);

    wr->dualMethod = apr_pstrdup( wr->p, method);
    return method;

}
/*check if user is in allowed 2FA realm */
int cuwl_dual_realm_check(weblogin_req_t * wr )
{
    int rc = CUWA_ERR;
    CUWACfg_t *cfg = cuwa_wal_get_config((void *)wr->apreq);
    char *userRealm = strstr(wr->r.cuwlUser,"@");
    char *realm, *state=NULL;
    char *allowedRealms = CFG_CUWL2FARealms(cfg);

    if (!userRealm) return rc;

    userRealm = userRealm +1;
    cuwa_trace("userRealm:%s",userRealm);

    realm = apr_strtok( allowedRealms," ",&state);
    while ( realm )
    {
       if (!strcmp(realm, userRealm)) return CUWA_OK; 
       realm = apr_strtok(NULL, " ", &state);   
    } 
    cuwa_warning("user %s is not in allowed realm %s",wr->r.cuwlUser, allowedRealms);
    return rc;
}

const char id_cuwl_dual_c[] = "$Id: cuwl_dual.c,v 1.15 2015/10/07 17:56:51 hy93 Exp $";
