#ifndef CUWL_DUAL_INCLUDED

#define CUWL_DUAL_INCLUDED

#include <weblogin.h>

#define CUWL_DUAL_USER_SAME 1
#define CUWL_DUAL_EXTRA_TIME 300 //5 minutes

#define CUWL_DUAL_AUTH_UNKNOWN   0
#define CUWL_DUAL_AUTH_YES       1
#define CUWL_DUAL_AUTH_NO        2

#define CUWL_DUAL_COOKIE_METHOD  "cuwl2famethod"
#define CUWL_DUAL_COOKIE         "cuwlrelogin2f"
#define CUWL_DUAL_COOKIE_START   "cuwlduals"
#define CUWL_DUAL_COOKIE_VENDOR  "cuwldualv"

void cuwl_dual_get_cookie( weblogin_req_t *wr,char *cookieName,char **authUser, apr_time_t *authTime, char **method );
void  cuwl_dual_init( apr_pool_t *pool);
void cuwl_dual_make_cookie( weblogin_req_t *wr );
void cuwl_dual_clear_cookie( weblogin_req_t *wr,char *cookieName );
int cuwl_dual_verify_user( apr_pool_t *pool,char *dualAuthUser, char *cuwlUser );
int cuwl_dual_auth_needed( weblogin_req_t *wr );
char * cuwl_dual_get_method( weblogin_req_t *wr );
void cuwl_dual_remove_params( weblogin_req_t *wr );
void cuwl_dual_set_start_cookie( weblogin_req_t *wr );
char *cuwl_dual_set_method_cookie(weblogin_req_t *wr, char *uri);
int cuwl_dual_realm_check(weblogin_req_t * wr );
#endif
