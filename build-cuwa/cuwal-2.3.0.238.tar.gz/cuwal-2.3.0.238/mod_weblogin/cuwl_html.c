
#include <weblogin.h>
#include <log.h>
#include "http_protocol.h"
#include "http_config.h"
#include <cuwl_mobile.h>
#include <cuwl_dual.h>
#include <cuwl_permit.h>

#define CUWA2_LOG_DOMAIN weblogin
#define ISSET(x) (((x)) && ((x))[0])

int webauth_vercheck(char *have, int maj_req, int min_req, int rev_req){
	int maj=-1,min=-1,rev=-1;
        if(3==sscanf(have,"%d.%d.%d",&maj,&min,&rev)){
		if(maj < maj_req) return 0;
		if(maj > maj_req) return -1;
		if(min < min_req) return 0;
		if(min > min_req) return -1;
		if(rev < rev_req) return 0;
		if(rev >= rev_req) return -1;
	}
	return 0;
}

/** Controls number of characters sent to ap_rprintf which has 8K buffer limit (AP_IOBUFSIZE)*/
#define CUWL_APACHE_PRINTF_LIMIT 4096
#define CUWL_APACHE_PRINTF_LIMIT_FMT "%4096s"
#define CUWL_IE_URL_LIMIT 2048

/** Format string for the base HTML login page */
static char *html_login_base_g=NULL; 

/** Format string for the base HTML login form */
static char *html_login_form_g=NULL; 

/** Format string for realm selection */
static char *html_login_form_realm_g=NULL; 

/** Format string for the main login page */
static char *html_login_g=NULL; 

/** Format string for mobile device  main login page */
static char *html_login_mobile_g=NULL;

/** Format string for fatal errors */
static char *html_fatal_g=NULL;

/** Format string for the configuration page */
static char *html_configure_g=NULL;

/** Format string for the big post page */
static char *html_bigpost2_g=NULL;
static char *html_bigpost1_g=NULL;

/** Format string for the warning page */
static char *html_warning_g=NULL;

/** Format string for the security warning */
static char *html_block_security_g=NULL;

/** Horrible hack -- encryption key for protecting K3's**/
static char *html_nothtml_weblogin_k3_key_g=NULL;

const char id_cuwl_html_c[] = "$Id: cuwl_html.c,v 1.67 2016/05/26 16:06:34 hy93 Exp $";

int cuwl_redirect_to_old_webAuth(weblogin_req_t *wr, char *reason_block);

void cuwl_load_html(apr_pool_t *tmp, apr_pool_t *spool, const char *file, char **data){
    char *html;
    char * fullpath;
    apr_status_t st;
    apr_file_t *f=NULL;
    apr_finfo_t finfo;
    fullpath=ap_server_root_relative(tmp,file);
    cuwa_trace("loading HTML from %s",fullpath);
    st=apr_file_open(&f,fullpath,APR_READ,APR_REG,tmp);
    if(APR_SUCCESS != st){
       char err[512];
       apr_strerror(st,err,512);
       cuwa_alarm("Error loading file %s (%d):%s",file,st,err);
       return;
    }
    //fixme check st

    st=apr_file_info_get(&finfo, APR_FINFO_SIZE,f);
    if(APR_SUCCESS != st){
        char err[512];
        apr_strerror(st,err,512);
        cuwa_alarm("Error loading file %s (%d):%s",file,st,err);
        return;
    }
    //fixme check st

    html=apr_palloc(tmp,finfo.size+1);
    st=apr_file_read_full(f,html,finfo.size,NULL);
    html[finfo.size]='\0';
    *data=apr_pstrdup(spool,html);
  
}

void cuwl_load_file(apr_pool_t *tmp, apr_pool_t *spool, const char *file, char **data)
{
    cuwl_load_html(tmp, spool, file, data);
}

/**
 * Read in the format strings. Not thread safe, call only from child_init
 * This will initialize the module local format strings.
 * */
void cuwl_init_html(apr_pool_t *pool){
    char *head, *tail;
    char *html_login_base_mobile;

    cuwl_load_html(pool,pool,CFG_CUWLhtml(NULL),&html_login_base_g);
    cuwl_load_html(pool,pool,CFG_CUWLformhtml(NULL),&html_login_form_g);
    cuwl_load_html(pool,pool,CFG_CUWLhtml_mobile(NULL),&html_login_base_mobile);

    cuwl_load_html(pool,pool,CFG_CUWLk3key(NULL),&html_nothtml_weblogin_k3_key_g);

    html_login_g=apr_psprintf(pool,html_login_base_g,"\"sf()\"",html_login_form_g);
    html_login_mobile_g=apr_psprintf(pool,html_login_base_mobile,"\"sf()\"", html_login_form_g);

    //html_fatal_g="<html><body><h1>Your request contained errors</h1><p>fixme</p><hr><ul>%s</ul></body></html>";
    html_fatal_g=apr_psprintf(pool,html_login_base_g,"\"sf()\"","<h2>Your request contained errors</h2><hr><ul>%s</ul>");
    html_configure_g="<html><body><h1>Configuration page</h1><p>fixme</p><hr><ul>%s</ul></body></html>";
    html_warning_g=apr_psprintf(pool,html_login_base_g,"\"sf()\"","<h2>CUWebLogin Warning</h2><p>%s</p><p>If you would still like to login, click here <form name=\"continueanyway\" method=\"post\" action=\"%s\"><input type=\"hidden\" name=\"wa\" value=\"%s\"/>Continue to %s (%s)<input type=\"submit\" value=\"continue\" name=\"continue\"/></form>");
    html_block_security_g="<hr><div style=\"font-size: 200\%;line-height: 100\%; color:red\">Security Warning:</div><div style=\"color:red;\"><ul>%s</ul></div><p>Your password is safe, but data on that site might not be secure. Using this configuration for a production service might violate university policy. Please ask the administrator of %s to correct this condition. This issue has also been logged by weblogin.</p><hr>";
    html_login_form_realm_g="";
    
    // This section initializes support for really large credentials that need to be transmitted via POST.
    // Apache has a limit on how much data can be written to the response in a single write (8K) so credential writes happen in 3 sections...
    //   * Head
    //   * Credential - one or more writes
    //   * Tail    
    head=apr_psprintf(pool,html_login_base_g,"\"document.bigpost.submit()\"","%s");
    tail=strstr(head,"%s");
    if (!tail) 
    {
        tail = "";
    }
    else
    {
        *tail = 0;
        tail += 2;
    }
    html_bigpost1_g=apr_psprintf(pool,"%s%s",head,"<h2>Login OK</h2><p>Your login credentials are being transmitted to the website via POST. <noscript>If you are not automatically redirected please click the continue button below<br></noscript><form name=\"bigpost\" enctype=\"application/x-www-form-urlencoded\"  method=\"post\" action=\"%s\"><input type=\"hidden\" name=\"wa\" value=\"");
    html_bigpost2_g=apr_psprintf(pool,"%s%s","\"/><noscript><input type=\"submit\" value=\"continue\" name=\"continue\"/></noscript></form>",tail);    
}


/**
 * Formats and sends a response to the client. You must have called cuwl_init_html from the current process first.
 * @param[in] wr a fully processed weblogin request.
 */
int cuwl_send_response(weblogin_req_t *wr){
    char * reason_block="";
    char * realm_block="<!-- realm -->";
    cuwa_assert(html_login_g);
    cuwa_assert(html_login_mobile_g);
    cuwa_assert(html_fatal_g);
    cuwa_assert(html_configure_g);

    reason_block=apr_pstrcat(wr->p, 
                 wr->r.securitywarning[0]?apr_psprintf(wr->p,html_block_security_g,wr->r.securitywarning,wr->q.ReturnHost):"",
                 "<ul>",wr->q.errors,"</ul>",
                 "<ul>",wr->r.reason,"</ul>",
                 NULL);
	
    if(wr->r.securitywarning[0]) cuwl_audit_add(wr,1,"sec_warning");
	
    //if multiple domains are set, spit out realm select
    cuwa_trace("WAK0Realms: %s",DENULL(wr->q.WAK0Realms));
    if(ISSET(wr->q.WAK0Realms) && strchr(wr->q.WAK0Realms,',')){
         realm_block=apr_pstrcat(wr->p,"<div class=\"form-pair-realm\">\n"
                                      "<div class=\"form-item-realm\">\n"
                                      "<label for=\"realm\">",
                                      wr->r.realmlabel,
                                      " </label>\n"
                                      "</div>\n"
                                      "<div class=\"form-value-realm\">\n"
                                      "<SELECT ID=\"realm\" NAME=\"realm\">\n",NULL);
        
        char *arealm=apr_pstrdup(wr->p,wr->q.WAK0Realms);
        while(ISSET(arealm)){
            char *next=strchr(arealm,',');
            if(next){
                *next='\0';
            }
            realm_block=apr_pstrcat(wr->p, realm_block, "<OPTION VALUE='",arealm,"'>",arealm,"</OPTION>\n",NULL);
            arealm=next?next+1:NULL;
        }
        realm_block=apr_pstrcat(wr->p,realm_block,"</SELECT>\n</div></div>",NULL);
    }
	
	
    if(wr->r.sso && wr->r.ssodomain){
        char *tmp;
        tmp=apr_psprintf(wr->p,"cuwlrelogin=\"%s\"; path=/; domain=%s; secure; HttpOnly",wr->r.sso,wr->r.ssodomain);
        cuwl_output_header(wr,"Set-Cookie",tmp);
        cuwa_info("Sending relogin cookie");
        cuwl_audit_add(wr,1,apr_psprintf(wr->p,"sso_out/%s",cuwl_md5(wr->p,wr->r.sso,0)));
        if(wr->r.ssoendtime){
            tmp=apr_psprintf(wr->p,"cuwltgttime=\"%s\"; path=/; domain=%s",wr->r.ssoendtime,wr->r.ssopresent); //fixme need to insert time
            cuwl_output_header(wr,"Set-Cookie",tmp);
            cuwa_info("Sending cuwltgttime cookie");
        }					

    }
	
    if (wr->r.dualAuthCookie && wr->r.ssodomain) {
        char *tmp;
        tmp=apr_psprintf(wr->p,"%s=\"%s\"; path=/; domain=%s; secure; HttpOnly",CUWL_DUAL_COOKIE,wr->r.dualAuthCookie,wr->r.ssodomain);
        cuwl_output_header(wr,"Set-Cookie",tmp);
        cuwa_info("Sending dualAuth cookie");
        cuwl_audit_add(wr,1,apr_psprintf(wr->p,"dualAuthCookieset/%s",cuwl_md5(wr->p, wr->r.dualAuthCookie,0)));
    }
	
    if(400 <= wr->status){
        //some status has already been set
        //and it is an error
        cuwa_info("Error: Request appears to be malformed, returning %d",wr->status);
        cuwl_audit_add(wr,0,"response_fatal");
        wr->apreq->content_type = "text/html;charset=ISO-8859-1";
        wr->apreq->no_cache = 1;
        ap_rprintf(wr->apreq, html_fatal_g, wr->q.errors);
        wr->apreq->status=wr->status;

        return wr->status;		
    }	
	
    if(wr->status < 300){	
        //cuwa_assert(wr->status); //apparantly this is 0 and that is fine
        //we got here, either there was no cookie present or the cookie was unsatisfactory. Prompt time.	
        cuwa_info("Sending a login form (status: %d)",wr->status);
        //weblogin_show_form(wr->apreq->uri,wr->apreq->args,r->pool,r,wr->q.errors,"NetID");
		
        ap_rprintf(wr->apreq, 
                   cuwl_from_mobile(wr)?html_login_mobile_g:html_login_g,
                   wr->query,
                   reason_block,
                   wr->q.IDName,
                   realm_block);
        wr->apreq->content_type = "text/html;charset=ISO-8859-1";
        wr->apreq->no_cache = 1;
        wr->apreq->status=200;

        //expire duo cookie
        char *tmp;
        tmp=apr_psprintf(wr->p,"%s=\"%s\"; expires=Thu, 01 Jan 1970 00:00:00 UTC;path=/; domain=%s; secure; HttpOnly",CUWL_DUAL_COOKIE,wr->r.dualAuthCookie,wr->r.ssodomain);
        cuwl_output_header(wr,"Set-Cookie",tmp);
        cuwa_info("Expiring dualAuth cookie");

        cuwl_audit_add(wr,1,"response_form");
        return wr->status;
    }
    else{ //status 300-399 
        char *location=NULL;
        cuwa_assert(wr->r.cred);

        if(wr->r.cred){

            cuwl_audit_add(wr,1,apr_psprintf(wr->p,"cred_out/%s",cuwl_md5(wr->p,wr->r.cred,0)));

            //check if user needs to do two factor authentication
            if ( cuwl_dual_auth_needed( wr ) == CUWL_PERMIT_ERROR ) {
                char *msg = apr_psprintf(wr->p,"Checking two factor authenticaiton permit %s failed. Make sure permit name is correct.",wr->q.dualAuth);
                CUWL_REQ_ERROR_FATAL(wr,msg);
                cuwl_audit_add(wr,0,"dual_permit_fail"); 
                wr->apreq->content_type = "text/html;charset=ISO-8859-1";
                ap_rprintf(wr->apreq, html_fatal_g, wr->q.errors);
                wr->apreq->status=wr->status;
                return wr->status;
            }
            if ( wr->needDualAuth == CUWL_DUAL_AUTH_YES )
            {
                char *method = cuwl_dual_get_method(wr);

                if (!method) 
                {
                    char *msg = apr_psprintf(wr->p,"%s is misconfigured with invalid two factor method.",wr->q.ReturnHost);
                    CUWL_REQ_ERROR_FATAL(wr,msg);
                    cuwl_audit_add(wr,0,"dual_permit_fail");
                    wr->apreq->content_type = "text/html;charset=ISO-8859-1";
                    ap_rprintf(wr->apreq, html_fatal_g, wr->q.errors);
                    wr->apreq->status=wr->status;
                    return wr->status;
                }
                //check if user is in allowed 2FA realms
                if ( cuwl_dual_realm_check( wr ) !=CUWA_OK )
                {
                    char *msg = apr_psprintf(wr->p,"The web site you are accessing requires two-step login. But two-step login doesn't support your ID type %s",wr->r.cuwlUser);
                    CUWL_REQ_ERROR_FATAL(wr,msg);
                    cuwl_audit_add(wr,0,"dual_realm_fail");
                    wr->apreq->content_type = "text/html;charset=ISO-8859-1";
                    ap_rprintf(wr->apreq, html_fatal_g, wr->q.errors);
                    wr->apreq->status=wr->status;
                    return wr->status;
                }
                else 
                {
                    cuwl_dual_set_start_cookie( wr );
                    location = apr_psprintf(wr->p, "/%s?%s&CUWLUser=%s",method, wr->query,wr->r.cuwlUser ); 

                    cuwl_output_header(wr,"Location",location);
                    cuwa_info("Success: Issuing a redirect to: %s",location);
                    wr->apreq->status = wr->status;
                    wr->apreq->content_type = "text/html;charset=ISO-8859-1";
                    cuwl_audit_add(wr,1,"response_redirect_dual_form");
                    return(wr->status);
                }
            
            }

            if (wr->q.VerP < 3) {
                //we are dealing with old cuWebAuth. For backward compatibility, use the old way to send request back 
                return cuwl_redirect_to_old_webAuth(wr,reason_block); 
            } 

            location = wr->q.ReturnURL;
           
            cuwl_output_header(wr,"Location",location);

            wr->status=200;
            wr->apreq->status=200;
            wr->apreq->content_type = "text/html;charset=ISO-8859-1";

            if(!wr->r.mustWarn)
            {
                // Build HTML page
                ap_rprintf(wr->apreq,html_bigpost1_g,wr->q.ReturnURL);
                ap_rprintf(wr->apreq,"%s",wr->r.cred);
                ap_rprintf(wr->apreq,html_bigpost2_g);

                cuwa_info("Success: Issuing a redirect to: (via POST) %s",location);
                cuwl_audit_add(wr,1,apr_psprintf(wr->p,"response_redirect_post/%d",(int)strlen(location)));
            }
            else {
               ap_rprintf(wr->apreq,
                           html_warning_g,
                           reason_block,
                           wr->q.ReturnURL,
                           wr->r.cred,
                           wr->q.ReturnHost,
                           wr->q.WAK0Service);
               cuwa_info("Success: Issuing a redirect to: (with warning) %s",location);
               cuwl_audit_add(wr,1,"response_redirect_warning");
            } 
            return 0;
        }
        cuwa_alarm("Error: unreachable code, status is redirect but I lack a credential");
        return(500);
        //unreachable
    }
	
}


/**
 * access function for long term key
 * doesn't belong here.
 */
char * cuwl_get_k3_key(){
    return html_nothtml_weblogin_k3_key_g;
}

//old version(verP=2) of webAuth can't handle delegation cred in post data. So we still redirect request back in the old way
int cuwl_redirect_to_old_webAuth(weblogin_req_t *wr, char *reason_block)
{
    const char *user_agent=NULL;
    char *location=NULL;

    location=apr_pstrcat(wr->p,wr->q.ReturnURL, "?wa=", wr->r.cred, NULL);
    cuwl_output_header(wr,"Location",location);

    // DEBUG
    {
        const char *user_agent=NULL,*ua="UA?";
        if (wr->apreq && wr->apreq->headers_in) {
            user_agent=apr_table_get(wr->apreq->headers_in, "user-agent");
            if (user_agent) ua = strstr(user_agent,"MSIE")?"IE":"notIE";
        }
        cuwl_audit_add(wr,1,apr_psprintf(wr->p,"status/%d-%d-%s-%s",wr->status,(int) strlen(location),ua,wr->q.IIS?"IIS":"Apache"));
    } // end DEBUG

    // Before sending a location make sure IE wont choke on it (CUWL_IE_URL_LIMIT)
    // IIS7 also chokes at CUWL_IE_URL_LIMIT
    // local apache chokes at CUWL_APACHE_PRINTF_LIMIT, requiring spooling out the response
    if(strlen(location) > CUWL_APACHE_PRINTF_LIMIT || (wr->q.IIS && strlen(location) > CUWL_IE_URL_LIMIT) ||
       (strlen(location) > CUWL_IE_URL_LIMIT
          && wr->apreq
          && wr->apreq->headers_in
          && (user_agent=apr_table_get(wr->apreq->headers_in, "user-agent"))
          && strstr(user_agent,"MSIE"))){
            //MS KB 208427
            //there might be a correct way to get to 2083
            if(webauth_vercheck(wr->q.VerC,2,1,3)){
                 //webauth knows how to handle POSTed credentials
                 wr->status=200;
                 wr->apreq->status=200;

                // Build HTML page
                ap_rprintf(wr->apreq,html_bigpost1_g,wr->q.ReturnURL);

                ap_rprintf(wr->apreq,"%s",wr->r.cred);
                ap_rprintf(wr->apreq,html_bigpost2_g);

                cuwa_info("Success: Issuing a redirect to: (via POST) %s",location);
                cuwl_audit_add(wr,1,apr_psprintf(wr->p,"response_redirect_post/%d",(int)strlen(location)));
                return 0;
                //fixme security this bypasses the other clickthrough
            }
            else{
                cuwa_info("Error: This version of cuwebauth doesnt accept POST credentials. Webauth is %s", wr->q.VerC);
                ap_rprintf(wr->apreq, html_login_base_g);
                ap_rprintf(wr->apreq, "Error: This website doesnt handle large credentials. A CUWebAuth upgrade is needed. Please contact the site administrator.");
                wr->status=400;
                wr->apreq->status=wr->status;
                cuwl_audit_add(wr,0,"response_fatal");
                cuwl_audit_add(wr,0,"location_size");
                return wr->status;
           }
   }

   if(!wr->r.mustWarn || wr->post){ //don't add a click through to POST pages -- fixme is this secure?
       cuwa_info("Success: Issuing a redirect to: %s",location);
       wr->apreq->status = wr->status;
       cuwl_audit_add(wr,1,"response_redirect");
       return(wr->status);
   }
   else{
       ap_rprintf(wr->apreq,
               html_warning_g,
               reason_block,
               wr->q.ReturnURL,
               wr->r.cred,
               wr->q.ReturnHost,
               wr->q.WAK0Service);
       wr->apreq->status=200;
       cuwa_info("Success: Issuing a redirect to: (with warning) %s",location);
       cuwl_audit_add(wr,1,"response_redirect_warning");
       return 0;
   }
   return 0;
}
