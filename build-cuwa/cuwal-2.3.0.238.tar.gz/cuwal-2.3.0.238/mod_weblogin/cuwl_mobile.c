#include <cuwl_mobile.h>
#include <list.h>
#include <util.h>
#include <cuwl_html.h>

static cuwa_list  *mobile_list = NULL;

//check if the request is from mobile device
int cuwl_from_mobile( weblogin_req_t *wr ) {

    int isMobile=0;
    char *user_agent=NULL;                                                                
    cuwa_node *mobile = NULL;

    if (wr->apreq && wr->apreq->headers_in) {                                             
        user_agent=(char *)apr_table_get(wr->apreq->headers_in, "user-agent");                                                                                                     
     }
     if (user_agent && mobile_list) {
         mobile = mobile_list->head;
         while ( mobile ) {
           if ( strstr_case_insensitive(user_agent, mobile->data)) {
               isMobile = 1;
               break;
            }
            mobile = mobile->next;
        }
    }                                                                                     
    
    return isMobile;
}                

//load mobile device list from file to memory
void cuwl_init_mobile( apr_pool_t *pool) {

    char *mobileList = NULL;
    char *ptr, *state,*mobile;
 
    cuwl_load_html(pool, pool, CFG_CUWLmobile(NULL), &mobileList);
    
    if ( mobileList ) {
        cuwa_util_replace_char_with( mobileList,'\n','|');
        cuwa_util_replace_char_with( mobileList,'\r','|');

        ptr = apr_strtok( mobileList,"|", &state );
        while ( ptr )
        {

            mobile = apr_pstrdup( pool, ptr);
            cuwa_list_append( &mobile_list, mobile );
            ptr = apr_strtok( NULL, "|", &state );
        }
    }
 }        
