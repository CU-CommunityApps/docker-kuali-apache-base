#ifndef CUWL_MOBILE_INCLUDED
#define CUWL_MOBILE_INCLUDED

#include <weblogin.h>

void cuwl_init_mobile(apr_pool_t *pool);
int cuwl_from_mobile( weblogin_req_t *wr);

#endif
