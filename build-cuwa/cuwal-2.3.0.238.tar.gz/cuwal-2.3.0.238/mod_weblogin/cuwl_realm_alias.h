#ifndef CUWL_REALM_ALIAS_INCLUDED
#define CUWL_REALM_ALIAS_INCLUDED

#include "apr_pools.h"

const char * cuwl_realm_from_alias(char *realm);
int cuwl_find_realm( apr_pool_t *p,char *realmlist, char *realm);

#endif


