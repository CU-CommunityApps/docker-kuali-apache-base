/* 
 * Weblogin 2.0 mod_weblogin
 * $Id: mod_weblogin.c,v 1.42 2016/05/03 15:14:09 hy93 Exp $
 * 
 * Open issues:
 * *Currently password-contaminated memory is not sanitized. Not sure whether this is even possible.
 */ 

#include <autoconfig.h>
#include "httpd.h"
#include "http_config.h"
#include "http_protocol.h"
#include "ap_config.h"
#include <ap_compat.h>
#include <http_core.h>
#include "http_log.h"
#include "log_apache.h"
#include "cuwl_cfg.h"
#include "cred.h"
#include "cfg.h"
#include <unistd.h>
#include <cuwa_malloc.h>
#include <openssl/rand.h>
#undef CUWA2_LOG_DOMAIN
#define CUWA2_LOG_DOMAIN cuweblogin

#define CUWA_APACHE_HACK_LOG

#include "../log/log.h"

#include "../util/list.h"


#include "weblogin.h"
#include "cuwl_aputil.h"

#include "cuwl_html.h"
#include "cuwl_mobile.h"
#include "cuwl_permit.h"
#include "cuwl_dual.h"

#undef CUWA2_LOG_DOMAIN
#define CUWA2_LOG_DOMAIN cuweblogin

//static char * cuwl_login_html=NULL;
//static char * cuwl_error_html=NULL;
//static char * cuwl_configure_html=NULL;

const char id_mod_weblogin_c[] = "$Id: mod_weblogin.c,v 1.42 2016/05/03 15:14:09 hy93 Exp $";

module AP_MODULE_DECLARE_DATA weblogin_module;
module AP_MODULE_DECLARE_DATA *cuwa_module = &weblogin_module;
#include <cfg-apache-incl.c>
#include <apache_wal.c>

void weblogin_send_redirect(request_rec *r, char * where){
    apr_table_set(r->headers_out, "Location",where);
    r->no_cache=1;

}


/* The sample content handler */
static int weblogin_handler(request_rec *r)
{
    apr_time_t now;
    cuwa_log_apache_set_keys(r, r->server, r->connection);
    cuwa_malloc_set_pool(r->pool);
    weblogin_req_t wr;    

    if (strcmp(r->handler, "weblogin")) {
        return DECLINED;
    }
    r->content_type = "text/html";
    //ap_log_error(__FILE__,__LINE__,0,0,r->server,"foo2: " __TIME__);
    apr_table_set(r->headers_out,"cache-control","no-cache, no-store");
    apr_table_set(r->headers_out,"Pragma","no-cache");
    apr_table_set(r->headers_out,"Expires","0");

    if(r->args) RAND_add(r->args, sizeof(r->args),8);
    now=apr_time_now();
    RAND_add(&now,sizeof(apr_time_t),1);
    
    if(!strcmp(r->uri,"/build")){
        ap_rputs("Built: " __DATE__ " at " __TIME__ "\n",r);
        ap_rputs("Build number: " CUWA_BUILDFULL "\n",r);        
        ap_rputs("version: " CUWA_PROD "\n",r);        
        r->status=200;
        return 0;
    }

    //in support of the test harness, print the current time
    if(!strcmp(r->uri,"/time")){
        apr_time_t now = apr_time_now();
        ap_rprintf(r,"%llu",apr_time_sec(now));
        r->status=200;
        return 0;
    }
    
    
    if(!strcmp(r->uri,"/info")){
        ap_rprintf(r,"r.hostname: %s <br>\n",r->hostname);
        ap_rprintf(r,"server_hostname: %s <br>\n",r->server->server_hostname);
        ap_rprintf(r,"error_fname: %s <br>\n",r->server->error_fname);
        ap_rprintf(r,"short_name: %s <br>\n",r->server->process->short_name);
        ap_rprintf(r,"macro: %s <br>\n",ap_server_root_relative(r->pool,"login.html"));
        ap_rputs("Build number: " CUWA_BUILDFULL "\n",r);        
        ap_rputs("version: " CUWA_PROD "\n",r);        
    }
    
    cuwl_parse_request(&wr,r);
    
    if(wr.status){
        cuwa_assert(wr.status >= 400);
        //some status has already been set
        //and it is an error
        cuwl_send_response(&wr);
        cuwl_audit_add(&wr,1,"prestatus");
        apr_table_setn(wr.apreq->notes,"cuwl-audit",wr.audit);
        cuwa_notice("cuwl-audit: %s",wr.audit);
        return 0; //fixme?        
    }
    
    //if the processed weblogin request has a cookie or post data, try a login
    if(wr.trylogin) cuwl_login_K2(&wr);
    
    if(wr.trylogin) cuwl_audit_add(&wr,1,"logindone");

    
    cuwl_send_response(&wr);
    cuwl_audit_add(&wr,1,"setresp");
    apr_table_setn(wr.apreq->notes,"cuwl-audit",wr.audit);
    cuwa_notice("cuwl-audit: %s",wr.audit);
    
    return OK;
    
}

//Handling request after second authentication
static int webloginDualAuth_handler(request_rec *r)
{
    weblogin_req_t wr;
    char *method = NULL;

    cuwa_log_apache_set_keys(r, r->server, r->connection);
    cuwa_malloc_set_pool(r->pool);

    if (strcmp(r->handler, "dualauth")) {
        return DECLINED;
    }

    apr_table_set(r->headers_out,"cache-control","no-cache, no-store");
    apr_table_set(r->headers_out,"Pragma","no-cache");
    apr_table_set(r->headers_out,"Expires","0");

    if ( r->args )
        ap_unescape_url(r->args);

    cuwl_parse_request(&wr,r);

    method =cuwl_dual_set_method_cookie( &wr, r->uri );

    cuwa_trace("Authenticated with %s",method);

    if  (!wr.status ) {
        char *user = NULL;
        char *sid = NULL;

        cuwa_trace("get dual start cookie..");
        cuwl_dual_get_cookie( &wr, CUWL_DUAL_COOKIE_START, &user, &wr.dualStartTime, &sid );

        if ( !user || wr.dualStartTime == 0 || strcmp(sid,wr.sid))
        {
            //url has been modified. Denied the request
            CUWL_REQ_ERROR_FATAL(&wr,"No valid dual start cookie. Request denied.");
        }

        cuwl_dual_clear_cookie( &wr, CUWL_DUAL_COOKIE_START );
    }

    //Second authentication method like RSA runs in apache as authentication module, so after authentication, r->user should be
    //set to the user who finished the second auth. But second auth method like DUO, we have to use cookie to indicate user finished
    //second auth
    if (!strcmp(method,"DUO") || !strcmp(method, "TEST"))
    {
        char *tmp = NULL;

        cuwl_dual_get_cookie( &wr, CUWL_DUAL_COOKIE_VENDOR, &r->user, &wr.dualAuthTime, &tmp);

        //make sure dual vendor cookie is fresh
        if ( tmp && apr_strnatcasecmp( tmp, method) )
        {
            //not DUO vendor cookie. Denied the request
            CUWL_REQ_ERROR_FATAL(&wr,"Invalid DUO vendor cookie. Request denied.");
        }
        else if ( wr.dualAuthTime > 0 ) 
        { 
            int age = 0;
            if ( (age=apr_time_sec(apr_time_now()) - wr.dualAuthTime) > 300 ) 
            {
                //vendor cookie not fresh. Denied the request
                char *msg = apr_psprintf(r->pool,"vendor cookie expired. Request denied.cookie age=%d",age);
                CUWL_REQ_ERROR_FATAL(&wr,msg);
            }
        }
        else CUWL_REQ_ERROR_FATAL(&wr,"vendor cookie is missing or invalid. Request denied.");

        //remove dualAuth cookie that second auth placed
        cuwl_dual_clear_cookie( &wr, CUWL_DUAL_COOKIE_VENDOR );

    }
    else wr.dualAuthTime = apr_time_sec( apr_time_now() );

   
    if (!r->user) 
    {
        //user got here by changing the URL
        cuwa_info("User failed the second auth login");
        CUWL_APPEND_M(wr.p, wr.q.errors, "User failed at the second auth login. This error might be caused by hitting the browser's back button.");
        wr.status = 400;
    }

    if (! wr.cookie )
    {
        //user got here by changing the URL
        cuwa_info("User bypassed the primary login");
        CUWL_APPEND_M(wr.p, wr.q.errors, "User bypassed the primary login");
        wr.status = 400;
    }
    if(wr.status){
        cuwa_assert(wr.status >= 400);
        //some status has already been set
        //and it is an error
        cuwl_send_response(&wr);
        cuwl_audit_add(&wr,1,"prestatus");
        apr_table_setn(wr.apreq->notes,"cuwl-audit",wr.audit);
        cuwa_notice("cuwl-audit: %s",wr.audit);
        return 0;
    }

    wr.dualAuthUser = apr_pstrdup(r->pool, r->user);

    cuwa_trace("user %s authenticated with %s at %" APR_TIME_T_FMT, wr.dualAuthUser, wr.dualMethod, wr.dualAuthTime);


    //try a login to verify sso cookie is valid.
    if(wr.trylogin) cuwl_login_K2(&wr);

    //if nothing wrong with primary login cookie and secondAuthUser is the same as primary auth User wr->r.dualAuthUser should be set
    if (wr.status == 303 )
    {
        if ( wr.r.dualAuthUser )
            cuwl_dual_make_cookie( &wr );
        else
        {
            CUWL_APPEND_M(wr.p, wr.q.errors, "User authenticated with CUWeblogin doesn't match the user authenticated with second factor");
            wr.status = 400;
        }
    }
    cuwl_send_response(&wr);

    return OK;
}

static void weblogin_child_init(apr_pool_t *pchild, server_rec *s){

    pid_t pid = getpid();
    apr_time_t now=apr_time_now();
    cuwl_sanitize(NULL, NULL, 1);
    cuwl_sanitize_weak(NULL, NULL, 1);
    cuwa_log_apache_init(pchild);
    cuwa_malloc_init(pchild);
    cuwa_log_apache_set_keys(NULL, s, NULL);
    cuwa_alarm(CUWA_PROD " child_init %d", pid);

    cuwl_init_html(s->process->pool);
    cuwl_init_mobile(s->process->pool);
    cuwl_init_permit(s->process->pool );
    RAND_add(&pid,sizeof(pid_t),1);
    RAND_add(&now,sizeof(apr_time_t),2);
    RAND_add(cuwl_get_k3_key(),32,32); //best we have and secret by definition.

    cuwl_dual_init( pchild );

}

static int weblogin_post_config(apr_pool_t *p, apr_pool_t *plog, apr_pool_t *ptemp, server_rec *s)
{
    void *data = NULL;
    const char *userdata_key = "shm_cuwa_post_config";
    int rc = OK;
    server_rec *base = s;
    CUWACfg_t *cfg;

    // First pass, check checking the configuration.
    // Second pass, announce the module.
    apr_pool_userdata_get(&data, userdata_key, s->process->pool);
    if (data == NULL)
    {
        apr_pool_userdata_set((const void *)1, userdata_key, apr_pool_cleanup_null, s->process->pool);

        // Validate the config here...
        while (s)
        {
            cfg = ap_get_module_config(s->module_config, cuwa_module);
            if (!cfg) break;

            if (s->is_virtual) 
            {
                if (!CFG_CUWL2FAPrincipal(cfg))
                {
                    ap_log_error(APLOG_MARK, APLOG_NOERRNO|APLOG_WARNING,0,base,"CUWL2FPrincipal is not defined in %s", s->server_hostname);
                    rc = HTTP_INTERNAL_SERVER_ERROR;
                }
                if (!CFG_CUWL2FAKeytab(cfg))
                {
                    ap_log_error(APLOG_MARK, APLOG_NOERRNO|APLOG_WARNING,0,base,"CUWL2FKeytab is not defined in %s", s->server_hostname);
                    rc = HTTP_INTERNAL_SERVER_ERROR;
                }
                if (!CFG_CUWL2FARealms(cfg))
                {
                    ap_log_error(APLOG_MARK, APLOG_NOERRNO|APLOG_WARNING,0,base,"CUWL2FARealms is not defined in %s", s->server_hostname);
                    rc = HTTP_INTERNAL_SERVER_ERROR;
                }
            }
            s = s->next;
        }
    }
    return rc;
}

void *weblogin_create_server_config(apr_pool_t *p, server_rec *s)
{
    return(CUWACfg_t *) apr_pcalloc(p, sizeof(CUWACfg_t));
}

void *weblogin_merge_server_config(apr_pool_t *p, void *base_conf, void *new_conf)
{
    return cuwa_merge_config(p,(CUWACfg_t *)base_conf,(CUWACfg_t *)new_conf);
}

void *weblogin_create_dir_config(apr_pool_t *p, char *dir)
{
    return(CUWACfg_t *) apr_pcalloc(p, sizeof(CUWACfg_t));
}

void *weblogin_merge_dir_config(apr_pool_t *p, void *base_conf, void *new_conf)
{
    return cuwa_merge_config(p,(CUWACfg_t *)base_conf,(CUWACfg_t *)new_conf);
}

static void weblogin_register_hooks(apr_pool_t *p)
{
    ap_hook_handler(weblogin_handler, NULL, NULL, APR_HOOK_MIDDLE);
    ap_hook_handler(webloginDualAuth_handler, NULL, NULL, APR_HOOK_MIDDLE);
    ap_hook_post_config(weblogin_post_config,NULL,NULL,APR_HOOK_MIDDLE);
    ap_hook_child_init(weblogin_child_init,NULL,NULL,APR_HOOK_MIDDLE);
}

/* Dispatch list for API hooks */
module AP_MODULE_DECLARE_DATA weblogin_module = {
    STANDARD20_MODULE_STUFF, 
    weblogin_create_dir_config,
    weblogin_merge_dir_config,
    weblogin_create_server_config,                  /* create per-server config structures */
    weblogin_merge_server_config,                  /* merge  per-server config structures */
    cuwa2_cmds,                  /* table of config file commands       */
    weblogin_register_hooks  /* register hooks                      */
};

