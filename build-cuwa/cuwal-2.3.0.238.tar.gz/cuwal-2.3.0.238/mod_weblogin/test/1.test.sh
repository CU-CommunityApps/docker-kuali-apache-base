#./bin/sh
# test case for weblogin:
# Do a POST only, check that the returned K2 is valid

. ./util/config.sh

export TEST_INFO="Weblogin Test of single form submit with correct password"

. ./util/std-setup.sh

curl --data "netid=$TEST_ID&password=$TEST_PW" $CURL_FLAGS "$WEBLOGIN_TARGET/loginAction?$STANDARD_LOGIN_QUERY"

cat $OUT.headers | egrep '^Location' | cut -d \? -f 2 | cut -b 4-4096 > $OUT.cred

. ./util/std-creddecode.sh

. ./util/std-checks.sh
