#./bin/sh
# template case for weblogin

#include general config
. ./util/config.sh

export TEST_INFO="Test submit of multipart encoded data -- never worked"

#setup for a curl
. ./util/std-setup.sh

#do the curl
curl -F "netid=$TEST_ID" -F "password=$TEST_PW" $CURL_FLAGS "$WEBLOGIN_TARGET/loginAction?$STANDARD_LOGIN_QUERY"

. ./util/std-creddecode.sh

. ./util/std-checks.sh
