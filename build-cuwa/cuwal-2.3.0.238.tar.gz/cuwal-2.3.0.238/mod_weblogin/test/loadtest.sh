#!/bin/sh
NUMP=20
NUMS=1000
NUMPl=`expr $NUMP - 1`
if [ -z "$1" ]; then
	echo cleaning up
	rm ./out/lt*
	MSTART=`date +%s`
	for i in `seq 1 $NUMPl`; do
		(time $0 $i)  2> ./out/lt$i-time &
	done
	(time $0 $NUMP)  2> ./out/lt$i-time
	MEND=`date +%s`
	echo master done in `expr $MEND - $MSTART`
else
	PSTART=`date +%s`
	echo spawning $1 at $PSTART

	for i in `seq 1 1000`; do
		OUT=./out/"lt$1-$i"
		curl --data 'netid=ns10-demo&password=$tester' --dump-header $OUT.headers --output $OUT.data --trace-ascii $OUT.trace "https://web1.login.cornell.edu/loginAction?SID=$1DEADBEEF$i&WAK0Service=web-agent/gbr4-test@CIT.CORNELL.EDU&WAK2Name=NetID&ReturnURL=http://localhost:8007/cuweblogin&VerP=1&VerC=curl&Accept=K2&WAK2Flags=0" &> /dev/null
	done
	PEND=`date +%s`
	PTAKEN=`expr $PEND - $PSTART`
	echo "$1 done at $PEND: $NUMS hits in $PTAKEN seconds (`expr $NUMS / $PTAKEN`h/s)"
fi
