#!/bin/sh
#export WEBLOGIN_TARGET=https://web1.login.cornell.edu
export WEBLOGIN_TARGET=http://localhost:8004
export TEST_ID="ns10-demo"
export TEST_PW='$tester'
export WEBAUTH_SERVICE='web-agent/gbr4-test@CIT.CORNELL.EDU'
export WEBAUTH_KEYTAB='/home/gbr4/web-agent-gbr4-test'
export WEBAUTH_TARGET='http://localhost:8007'
export WEBAUTH_SID='F1234567DEADBEEF'
export STANDARD_LOGIN_QUERY="SID=$WEBAUTH_SID&WAK0Service=$WEBAUTH_SERVICE&WAK2Name=NetID&ReturnURL=$WEBAUTH_TARGET/cuweblogin&VerP=1&VerC=curl&Accept=K2&WAK2Flags=0"

