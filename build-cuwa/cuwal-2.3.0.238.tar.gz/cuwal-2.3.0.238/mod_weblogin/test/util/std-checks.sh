# include this script in other tests
# don't run it manually

TESTEXIT=0
SOMECHECK=""

cd out
for i in $0.*; do
	if [ -f ../correct-$i ]; then
		SOMECHECK=$i
		diff ../correct-$i $i || echo "$TEST_INFO ($0) ** FAIL **: $i and correct-$i differ" && export TESTEXIT=1
	fi
done

test -z $SOMECHECK && echo "$TEST_INFO ($0) ** FAIL **: no correct output on file" &&export TESTEXIT=1

exit $TESTEXIT
	
