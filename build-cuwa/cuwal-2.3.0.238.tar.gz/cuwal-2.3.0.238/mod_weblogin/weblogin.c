#include <autoconfig.h>
#include <stdio.h>
#include "apr_general.h"
#include "apr_strings.h"
#include "apr_tables.h"
#include "apr_errno.h"
#include "apr_file_io.h"
#include "apr_file_info.h"
#include "apr_md5.h"

#include <kutil.h>
#include <log.h>
#include <cred_base64.h>
#include <cred.h>
#include <cred_krb.h>
#include <cuwa_err.h>
#include <cuwa_malloc.h>
#include <cuwl_aputil.h>
#include <cuwa_parse.h>

#include <cuwl_cfg.h>
#include <weblogin.h>
#include <stdlib.h> //needed?
#include <assert.h>
#include "httpd.h"
#include <openssl/rand.h>
#include <openssl/evp.h>
#include "cuwl_html.h"
#include <permit.h>
#include <cuwl_realm_alias.h>
#include <cuwl_permit.h>
#include <cuwl_dual.h>
#include <wal.h>
#include <cuwa_malloc.h>

#define ISSET(x) ((x) && *(x))
#define TRUNCATE(x,y) do{ char *ltmpsym=strchr((x),(y)); if(ltmpsym) *ltmpsym='\0';} while(0)

#define ISMULTIREALM(x) (ISSET((x)) && strchr((x),','))

#define ALLOC_BYTES 1024

#ifdef STANDALONE_TEST

#define ap_rputs(x,y) printf("%s",x)
#define ap_rprintf(r,...) printf(...)
#endif

#undef CUWA2_LOG_DOMAIN
#define CUWA2_LOG_DOMAIN weblogin

const char id_weblogin_c[] = "$Id: weblogin.c,v 1.142 2016/05/03 14:21:35 hy93 Exp $";

void cuwl_audit_add(weblogin_req_t *wr, int success, char *msg){
    wr->audit=apr_pstrcat(wr->p,wr->audit,"{",(success?"s:":"f:"),msg,"}",NULL);
}
int cuwl_authorize_get_k3(weblogin_req_t *wr, char *serviceID);
int cuwl_authorize_get_k2(weblogin_req_t *wr, char *k2target, char *k3owner);
char *cuwl_get_first_realm(weblogin_req_t *wr);

char hexof[] = {'0','1','2','3','4','5','6','7','8','9','A','B','C','D','E','F'};

static char *dualAuthDone = "DualAuth";
static int dualAuthDoneLen = 8;

void cuwl_dump_request(weblogin_req_t *wr){
    cuwa_trace("************Dumping weblogin_req******************");
    cuwa_trace("status:%d",wr->status);
    cuwa_trace("uri:%s",DENULL(wr->uri));
    cuwa_trace("query:%s",DENULL(wr->query));
    cuwa_trace("post:%d",wr->post);
    cuwa_trace("cookie:%s",DENULL(wr->cookie));
    cuwa_trace("sid:%s",DENULL(wr->sid));
    cuwa_trace("q.SID:%qX",wr->q.SID);
    cuwa_trace("q.WAK0Service:%s",DENULL(wr->q.WAK0Service));
    cuwa_trace("q.ReturnURL:%s",DENULL(wr->q.ReturnURL));
    cuwa_trace("q.VerP:%d",wr->q.VerP);
    cuwa_trace("q.VerC:%s",DENULL(wr->q.VerC));
    cuwa_trace("q.Accept:%s",DENULL(wr->q.Accept));
    cuwa_trace("q.WAK2Name:%s",DENULL(wr->q.WAK2Name));
    cuwa_trace("q.WAK2Flags:%s",DENULL(wr->q.WAK2Flags));
    cuwa_trace("q.WAK0Realms:%s",DENULL(wr->q.WAK0Realms));
    cuwa_trace("q.WAK2Age:%ld",wr->q.WAK2Age);
    cuwa_trace("q.netID:%s",DENULL(wr->q.netID));
    cuwa_trace("q.password: (masked)");
    cuwa_trace("q.errors:%s",DENULL(wr->q.errors));
    cuwa_trace("q.ReturnHost:%s",DENULL(wr->q.ReturnHost));
    cuwa_trace("q.realm:%s",DENULL(wr->q.realm));
    cuwa_trace("q.IDName:%s",DENULL(wr->q.IDName));
    cuwa_trace("q.WAK3:%s",DENULL(wr->q.WAK3));
}


char * cuwl_md5(apr_pool_t *p, char *in, int length){
    unsigned char digest[APR_MD5_DIGESTSIZE];
    char out[APR_MD5_DIGESTSIZE+APR_MD5_DIGESTSIZE+1];
    int i;

    if(!in) in="";
    if(!length) length=strlen(in);
    apr_md5(digest,in,length);
    
    //base16 encode
    for(i=0; i<APR_MD5_DIGESTSIZE; i++){
        out[i+i]=hexof[digest[i]>>4];
        out[i+i+1]=hexof[digest[i]&0xf];
    }
    out[APR_MD5_DIGESTSIZE<<1]='\0';
    
    return(apr_pstrdup(p,out));
}

//strong sanitize routine applied to each argument
char * cuwl_sanitize(apr_pool_t *pool, char *msg, int init) //fixme should use version in log_apache
{
    char *out;
    unsigned char *s;
    static int clean_chars[256];

    //the black black black list is
    // ' " < > # -- don't even think of adding any of those
    if (init)
    {
        // Initialize white list once per child...
        memset(clean_chars,0,sizeof(clean_chars));
        clean_chars['-'] = 1;
        clean_chars['_'] = 1;
        clean_chars[','] = 1;
        clean_chars['.'] = 1;
        clean_chars['/'] = 1;
        clean_chars[':'] = 1;
        clean_chars['@'] = 1;


#define SET_RANGE(f,t,c) do {int i;for (i=(f);i<=(t);i++) (c)[i]=1;} while(0)

        SET_RANGE('a','z',clean_chars);
        SET_RANGE('A','Z',clean_chars);
        SET_RANGE('0','9',clean_chars);
        return NULL;
    }
    if(!msg) return NULL;

    // Replace potentially dangerous characters with space
    out = apr_pstrdup( pool, msg );
    s = (unsigned char *) out;
    for (;*s;s++) if (!clean_chars[*s]) *s = ' ';

    return out;
}

//weak sanitize routine to be used for sanitizing URL's
//avoid using where unnecessary, it is rather permissive
char * cuwl_sanitize_weak(apr_pool_t *pool, char *msg, int init) //fixme should use version in log_apache
{
    char *out;
    unsigned char *s;
    static int clean_chars[256];

    //the black black black list is
    // ' " < > # -- don't even think of adding any of those

    if (init)
    {
        // Initialize white list once per child...
        memset(clean_chars,0,sizeof(clean_chars));
        clean_chars['-'] = 1;
        clean_chars['_'] = 1;
        clean_chars[','] = 1;
        clean_chars['.'] = 1;
        clean_chars['/'] = 1;
        clean_chars[':'] = 1;
        clean_chars['?'] = 1;
        clean_chars['%'] = 1;
        clean_chars['='] = 1;
        clean_chars['&'] = 1;
        clean_chars['+'] = 1;
        clean_chars['@'] = 1;


        SET_RANGE('a','z',clean_chars);
        SET_RANGE('A','Z',clean_chars);
        SET_RANGE('0','9',clean_chars);
        return NULL;
    }
    if(!msg) return NULL;

    // Replace potentially dangerous characters with space
    out = apr_pstrdup( pool, msg );
    s = (unsigned char *) out;
    for (;*s;s++) if (!clean_chars[*s]) *s = ' ';

    return out;
}

//remove leading and ending spaces of a netID
char *cuwl_remove_leading_trailing_spaces(char *id)
{
    char *out,*p;
    int idLen=0;
    int i,startIndex,endIndex;

    if ( !id ) return id; 

    idLen = strlen(id);
    if (!idLen || (id[0]!=' ' && id[idLen-1]!=' ')) return id;

    for ( i=0; i<idLen; i++)
    {
        if (id[i]==' ') continue;
        else break;
    } 

    if (i==idLen) return id;
    startIndex = i;

    for ( i=(idLen-1); i>=0; i--)
    {
        if (id[i]==' ') continue;
        else break;
    }
    endIndex = i;

    out = cuwa_malloc(endIndex-startIndex+1+1);
    p = id;
    p += startIndex;
    strncpy(out, p, endIndex-startIndex+1);
    out[endIndex-startIndex+1]='\0';

    cuwa_trace("startIndex=%d,endIndex=%d, out=%s",startIndex,endIndex,out);
    return out;
}

//check if there is any upper case in netID
int cuwl_warning_upper_case( char *id )
{
    int warnUser = 0;
    unsigned char *s;
    char *p = strchr(id,'@');

    //this shouldn't happen
    if (!p) return warnUser;
    
    p++;
    if (strcmp(p, "CIT.CORNELL.EDU") && strcmp(p,"DEV.CORNELL.EDU")) return warnUser;

    s = (unsigned char *)id;
    for (;*s;s++) 
    {
        if (*s=='@') break;
        if (*s>='A' && *s <= 'Z') 
        {
            warnUser = 1;
            break;
        }
   }
   cuwa_trace("checking upper case for %s return %d", id, warnUser);
   return warnUser;
} 


apr_table_t* weblogin_parseparams(char *uri, char *query, apr_pool_t *pool, void *r){

    char * tok_state=NULL;
    char * tok=NULL;

    char * query2=NULL;

    apr_table_t *out;
    out=apr_table_make(pool,10);

    if(query) query2=apr_pstrdup(pool,query);
    
    while(query2 && (tok=apr_strtok(tok?NULL:query2,"&",&tok_state))){
        if(tok){
            char *n,*v;
            //ap_rputs(tok,r); ap_rputs("\n",r);
            n=apr_pstrdup(pool,tok);
            v=strchr(n,'=');
            if(NULL != v) *(v++)='\0';
            if(!v){
                //ap_rputs("BAD",r); ap_rputs("\n",r);
            }else{
                apr_table_setn(out,n,cuwl_sanitize(pool,v,0));
                apr_table_setn(out,apr_psprintf(pool,"unsanitary-%s",n),v);
                //ap_rprintf(r,"<p>%s=%s</p>\n",n,v);
            }
        }
    }

    return(out);
}


void weblogin_send_redirect(void *, char *);


#define CUWL_LK2_CLEANUP_CODE do{ \
                                if(ksess) kutil_end_session(ksess); \
                                ksess=NULL; \
                                if(cred) cuwa_cred_release(cred); \
                                cred=NULL; \
                                if(bCred) cuwa_free(bCred); \
                                bCred=NULL; \
                                if(cred64) cuwa_free(cred64); \
                                cred64=NULL; \
                              }while(0)


/**
 * Given a parsed weblogin_req that contains either post data or a SSO cookie attempts to
 * write a k2 token into the .r.cred field
 *
 * sets the status field and returns the status field:
 * 200 series: display a login form
 * 400 series: unrecoverable error, don't display a login form
 * 300 series: success, issue a redirect and return
 */

int cuwl_login_K2(weblogin_req_t *wr){
    kutil_session_t ksess = NULL;
    cuwa_cred_t *cred=NULL;
    cuwa_err_t err=0;
    char *bCred=NULL, *cred64=NULL, *f1;
    char *bK1=NULL; int cbK1=0;
    int cbCred, cbCred64;
    int authtime, starttime, endtime, renew_til;
    CUWACfg_t *cfg = cuwa_wal_get_config((void *)wr->apreq);

    cuwa_trace("trying a login");
    
    if(wr->post){
        
        if(!wr->q.netID){
            char *msg = wr->user_msg;
            if (!msg) {
                msg = apr_pstrcat(wr->p,"You did not supply a ", wr->q.IDName, NULL);
                cuwl_audit_add(wr, 0, "user_missing");
            } 
            CUWL_REQ_ERROR_RETRY(wr,msg);
            return(wr->status);
        }
        if(!wr->q.password){
            CUWL_REQ_ERROR_RETRY(wr,"You did not supply a password");
            cuwl_audit_add(wr, 0, apr_psprintf(wr->p,"password_missing/%s",wr->q.netID));
            return(wr->status);
        }
        
        cuwa_trace("attempting login for: %s", wr->q.netID);
        // TEST HERE FOR KRB5KDC_ERR_NAME_EXP if we want to trap password expired
        err = kutil_login(&ksess, wr->q.netID, wr->q.password);
        if(err){
            int warnUpperCase = cuwl_warning_upper_case( wr->q.netID );
            char *msg = apr_psprintf(wr->p,"Unable to log in with the supplied %s and password.%s",wr->q.IDName,
                                     (ISMULTIREALM(wr->q.WAK0Realms))?" Be sure that you have selected the correct ID type (realm).":"");

            if (warnUpperCase) msg = apr_pstrcat(wr->p,msg, " NetID is case sensitive.", NULL);

            CUWL_REQ_ERROR_RETRY(wr,msg);
            CUWL_LK2_CLEANUP_CODE;
            cuwl_audit_add(wr, 0, apr_psprintf(wr->p,"password_bad/%s",wr->q.netID));
            return(wr->status);
        }
    
        kutil_get_times(ksess, &authtime, &starttime, &endtime, &renew_til);
        wr->r.ssoendtime=apr_psprintf(wr->p,"%u",endtime);

        cuwa_notice("Session: %s, Login appears to have worked for %s", wr->sid, wr->q.netID);
        cuwl_audit_add(wr, 1, apr_psprintf(wr->p,"login_password/%s",wr->q.netID));

        wr->r.cuwlUser = apr_pstrdup(wr->p, wr->q.netID);

        //if this was a login, build a k1
        //at this point we have a usable credential, so no error will be returned to the client regardless
        if(ksess){
            cuwa_trace("Session, %s: building SSO cookie",wr->sid);
            err=cuwa_krb_make_k1(ksess, &bK1, &cbK1);
            if(err){
                cuwa_warning("Session, %s: building SSO credential failed (%d)",wr->sid,err);
                cuwl_audit_add(wr, 0, "sso_creation");
            }
            else{

                cuwl_audit_add(wr,1,apr_psprintf(wr->p,"k1_out/%d:%s",cbK1,cuwl_md5(wr->p,bK1,cbK1)));
                err=cuwa_base64_make_wa(&cred64, &cbCred64, cbK1, 1, bK1, cbK1);
                if(err){
                    cuwa_warning("Session, %s: encoding SSO cookie failed (%d)",wr->sid,err);
                    cuwl_audit_add(wr, 0, "sso_encoding");
                }
                else{
                    cuwa_auditlog(wr, "SSO cookie created successfully.");
                    wr->r.sso=apr_pstrdup(wr->p,cred64);
                    cuwl_audit_add(wr, 1, "sso_created");
                    //kutil_inquire_context(kutil_sec_ctx_t ctx, char **localid, char **remoteid, int *authtime, int *endtime)
                    //wr->r.ssopresent=
                }
            }
        }

    }
    else if(wr->cookie){
        char *k1user=NULL; //k1 user is not trustworthy
        apr_time_t timeNow = apr_time_sec(apr_time_now());
        long cookieAuthTime;

        cuwa_trace("trying to parse a session cookie");
        err = cuwl_parse_wak1(wr->p,&cred,wr->cookie,wr->r.includeK3?(&bK1):NULL,&cbK1);
        //err = cuwa_cred_parse(&cred, wr->cookie, strlen(wr->cookie), NULL, NULL, NULL, NULL );
        if(err || !cred){
            char *msg = apr_psprintf(wr->p,"Your single-sign-on session cookie contained an error, please log in again (%d).",err);
            cuwa_info("Failed to parse single-sign-on cookie \"%s\": %d",wr->cookie, err);
            cuwl_audit_add(wr, 0, "sso_bad_parse");
            //this cookie is unparsable, get rid of it
            wr->r.sso="";
            wr->cookie=NULL;

            CUWL_REQ_ERROR_RETRY(wr,msg);
            CUWL_LK2_CLEANUP_CODE;
            return(wr->status);
        }
        k1user=cuwa_cred_get_attribute(cred,"CUWA_LOGIN_USER",0);
        k1user=k1user?k1user:"NULL";

        cookieAuthTime = cuwa_cred_get_auth_time(cred);

        cuwl_audit_add(wr,1,apr_psprintf(wr->p,"sso_maybe_user/%s",k1user));
        cuwa_info("Session: %s, trying single sign on cookie,k1user=%s", wr->sid,k1user);
        cuwa_trace("credential authtime: %d", cookieAuthTime);
    
        wr->r.cuwlUser = apr_pstrdup(wr->p, k1user);

        if ( wr->dualAuthUser )
        {
             cuwa_trace("sso_dual_maybe_user %s - %s", wr->dualAuthUser,wr->dualMethod);
             cuwl_audit_add(wr,1,apr_psprintf(wr->p,"sso_dual_maybe_user/%s/%s",wr->dualAuthUser,wr->dualMethod));
             //make sure is the same user
             if ( cuwl_dual_verify_user( wr->p,wr->dualAuthUser, k1user ) == CUWL_DUAL_USER_SAME )
             {
                 //make sure user doesn't use the old cookie
                 if ( cookieAuthTime - wr->dualAuthTime < 120 )
                 {
                     if ( !wr->q.dualAuthMethod || !apr_strnatcasecmp(wr->q.dualAuthMethod, wr->dualMethod))
                     {
                         wr->r.dualAuthUser = apr_pstrdup(wr->p, k1user);
                         wr->r.dualAuthTime = wr->dualAuthTime;
                         wr->r.dualAuthMethod = apr_pstrdup(wr->p, wr->dualMethod);
                     } else {
                         cuwa_warning("sso_dual_method_mismatch/%s/%s",wr->q.dualAuthMethod,wr->dualMethod);
                         cuwl_audit_add(wr,0,apr_psprintf(wr->p,"sso_dual_method_mismatch/%s/%s",wr->q.dualAuthMethod,wr->dualMethod));
                     }
                 } else {
                     cuwa_warning("sso_dual_old_cookie dualAuthTime=%" APR_TIME_T_FMT,wr->dualAuthTime);
                     cuwa_warning("sso_dual_old_cookie cookieAuthTime=%" APR_TIME_T_FMT,cookieAuthTime);
                     cuwl_audit_add(wr,0,apr_psprintf(wr->p,"sso_dual_old_cookie"));
                 }
             } else {
                 cuwa_warning("sso_dual_user_mismatch/%s/%s",k1user,wr->dualAuthUser);
                 cuwl_audit_add(wr,0,apr_psprintf(wr->p,"sso_dual_user_mismatch/%s/%s",k1user,wr->dualAuthUser));
             }
        }

        //we don't know if user will need to do two factor. Do following checking anyway. It's not a big deal to let credential 
        //expires 5 minutes earlier. We can't do permit checking here because credential cache will be used to make k2 later on
        //Do permit checking will wipe out cc and cause credential cache not found error when making k2. 
        if (!wr->r.dualAuthUser)
        {
            long endTime = cuwa_cred_get_end_time(cred);
            //make sure SSO still has good amount of time to allow second auth. If not, force user to do primary auth first
            if ( (endTime - timeNow) < CUWL_DUAL_EXTRA_TIME )
            {
                cuwa_trace("Session: %s, cookie is too old to satisfy dual request, prompting for a password",wr->sid);
                char *msg= apr_psprintf(wr->p, "Single sign on cookie is too old to satisfy request. Please log in.");
                CUWL_REQ_ERROR_RETRY(wr,msg);
                cuwl_audit_add(wr, 0, "sso_dual_unfresh");

                CUWL_LK2_CLEANUP_CODE;
                return(wr->status);
            }
        }

        if(wr->q.WAK2Age != -1){    //check authtime. Note that this is advisory only
            //to allow reprompting
            //adversary could falsify this check, webauth
            //make definitive check of acceptability of cred
            long cookieAge;

            //user migh have spent some time on second factor login, we don't want to reprompt user becuase of the extra second factor login time
            if ( wr->dualStartTime > 0 && wr->r.dualAuthTime > 0) cookieAuthTime = wr->r.dualAuthTime;

            cookieAge=timeNow - cookieAuthTime;
            cuwa_info("Session: %s, request specified WAK2Age (%d), credential is (%d) seconds old",wr->sid, wr->q.WAK2Age,cookieAge);
            if(cookieAge > wr->q.WAK2Age){
                cuwa_trace("Session: %s, cookie is too old to satisfy request, prompting for a password",wr->sid);
                char *msg= apr_psprintf(wr->p, "You last logged in %ld seconds ago. %s requires users to login within %ld seconds of access. Please log in.",cookieAge,wr->q.ReturnHost,wr->q.WAK2Age);
                CUWL_REQ_ERROR_RETRY(wr,msg);
                cuwl_audit_add(wr, 0, "sso_unfresh");
   
                CUWL_LK2_CLEANUP_CODE;
                return(wr->status);
            }
        }

        if(ISSET(wr->q.WAK0Realms)){
            char *k1realm = strstr(k1user,"@");
            if(ISSET(k1realm)){
                k1realm++; //advance past the @
                if(!cuwl_find_realm(wr->p,wr->q.WAK0Realms,k1realm)){
                    char *msg = apr_psprintf(wr->p, "Your existing single-sign-on session is using an ID Type not accepted by the web site. Please log in or contact the administrator of %s if you think your ID %s should have access.",wr->q.ReturnHost, k1user);
                    CUWL_REQ_ERROR_RETRY(wr,msg);
                    cuwl_audit_add(wr,0,"sso_realm");

                    CUWL_LK2_CLEANUP_CODE;
                    return(wr->status);                                
                }
            }
            else{
                CUWL_REQ_ERROR_FATAL(wr,"Your single-sign-in ID is missing a realm");
                CUWL_LK2_CLEANUP_CODE;
                return(wr->status);                                
            }
        }
        
        cuwa_notice("Session: %s, using single sign on cookie", wr->sid);        
        //fixme should cookie be validated further (login for weblogin service and accept)?
    }
    else if(wr->q.WAK3){
        char *k3;
        int cbk3=0;
        char *service;
        apr_time_t formed;

        cuwa_trace("Got a WAK3 credential: %s",wr->q.WAK3); 
        err = cuwl_parse_remove_wa(wr->p,&k3,&cbk3,wr->q.WAK3);
        cuwa_trace("extracted %d bytes of K3",cbk3);
        if (!err) err = cuwl_parse_k3(wr->p, k3, cbk3, &bK1, &cbK1, &service, &formed,&wr->dualAuthUser,&wr->dualMethod, &wr->dualAuthTime);
        if (err){
            char *msg = apr_psprintf(wr->p,"The K3 (proxy token) presented is invalid (%d).",err);
            cuwl_audit_add(wr, 0, "proxy_parse_k3");
            wr->r.sso="";
            wr->cookie=NULL;
            CUWL_REQ_ERROR_FATAL(wr,msg);
            wr->status=403;
            CUWL_LK2_CLEANUP_CODE;
            return(wr->status);
        }
        cuwl_audit_add(wr, 1, apr_psprintf(wr->p,"proxy_from:%s",service));
        cuwl_audit_add(wr,1,apr_psprintf(wr->p,"k3k1_in/%d:%s",cbK1,cuwl_md5(wr->p,bK1,cbK1)));
        
        //IMPORTANT: kutil code doesn't like more than one concurrant session
        //DO NOT change the ordering in a way that will cause a ksess to exist
        //before this line
        cuwa_assert(ksess==NULL);
        cuwa_assert(cred==NULL);
        if(!cuwl_authorize_get_k2(wr,wr->q.WAK0Service, service)){
            char *msg = apr_psprintf(wr->p,"Service %s is not authorized to obtain a proxied credential to access %s",service,wr->q.WAK0Service);
            cuwl_audit_add(wr, 0, "proxy_unauthorized");
            wr->r.sso="";
            wr->cookie=NULL;
            memset(bK1,0,cbK1);
            CUWL_REQ_ERROR_FATAL(wr,msg);
            wr->status=403;
            CUWL_LK2_CLEANUP_CODE;
            return(wr->status);
        }
        
        err = cuwa_cred_parse(wr->p, &cred, bK1, cbK1, NULL, NULL, NULL, NULL );
        if(err || !cred){
            char *msg = apr_psprintf(wr->p,"The K3 (proxy token) presented by %s contained an invalid K1 (single sign on cookie). (%d).",service,err);
            cuwl_audit_add(wr, 0, "proxy_parse_k1");
            //this cookie is unparsable, get rid of it
            wr->r.sso="";
            wr->cookie=NULL;
            CUWL_REQ_ERROR_FATAL(wr,msg);
            CUWL_LK2_CLEANUP_CODE;
        }

        wr->r.cuwlUser = apr_pstrdup(wr->p, cuwa_cred_get_attribute(cred,"CUWA_LOGIN_USER",0));
        if ( wr->dualAuthUser && cuwl_dual_verify_user(wr->p,wr->dualAuthUser, wr->r.cuwlUser) == CUWL_DUAL_USER_SAME )
        {
            if ( !wr->q.dualAuthMethod || !apr_strnatcasecmp(wr->q.dualAuthMethod, wr->dualMethod))
            {
                wr->r.dualAuthUser = apr_pstrdup( wr->p, wr->dualAuthUser );
                wr->r.dualAuthMethod = apr_pstrdup( wr->p, wr->dualMethod );
                wr->r.dualAuthTime = wr->dualAuthTime;
                cuwa_trace("proxy k3 user %s logged on with %s at %" APR_TIME_T_FMT, wr->r.dualAuthUser, wr->r.dualAuthMethod,wr->r.dualAuthTime);
            }
        }
        //fixme? should WAK2Age be checked by weblogin?        

    }

    if(!cred && !ksess){
        //don't have a K1 credential or a Kerberos session
        //this code path shouldn't happen
        cuwa_crit("Session: %s, Unexpected code path, have neither a credential nor a kerberos context but no error occoured yet, dieing",wr->sid);
        CUWL_REQ_ERROR_RETRY(wr,"An unexpected error occurred processing your request, please log in." CUWL_AT);
        cuwl_audit_add(wr, 0, "unexpected_" CUWL_AT);
        return(wr->status);
    }

    // Create f1 authenticator element from WAK2Flags
    f1 = apr_pstrdup(wr->p,wr->q.WAK2Flags);
    
    if(wr->r.includeK3){
        char *k3=NULL;
        int cbk3=0;
        cuwa_trace("K3 requested and authorized, building one");
        cuwl_audit_add(wr,1,apr_psprintf(wr->p,"k3k1_out/%d:%s",cbK1,cuwl_md5(wr->p,bK1,cbK1)));
        cuwl_make_k3(wr->p, &k3, &cbk3, bK1, cbK1, wr->q.WAK0Service,wr->r.dualAuthUser,wr->r.dualAuthMethod, wr->r.dualAuthTime);

        err = cuwa_krb_make_k2( NULL, wr->q.ReturnHost, wr->q.WAK0Service, &(wr->q.SID), 0, &bCred, &cbCred,
                                "k3",k3,cbk3,"f1",f1,strlen(f1),NULL);
    }
    else{
        err = cuwa_krb_make_k2( NULL, wr->q.ReturnHost, wr->q.WAK0Service, &(wr->q.SID), 0, &bCred, &cbCred,
                                "f1",f1,strlen(f1),NULL);
    }    

    if(err){
        cuwa_info("Failed to build a k2 using cookie: %d",err);           
        if(cred){
            char *msg;
             msg=apr_psprintf(wr->p,"Your single-sign-on session appears to have expired.");
             CUWL_REQ_ERROR_RETRY(wr,msg);
        }
        else{
             //checkme-make sure this doesn't get printed for mundane errors.
            char *msg;
            msg=apr_psprintf(wr->p,"An error occurred creating a credential for %s. This might be because the server %s is misconfigured. Try again, if that doesn't succeed please contact the administrator of %s",wr->q.WAK0Service,wr->q.ReturnHost,wr->q.ReturnHost);
            CUWL_REQ_ERROR_RETRY(wr,msg);
        }
        wr->cookie=NULL;   //fixme -- testme -- will this kill a SSO for malformed servers?
        cuwl_audit_add(wr, 0, "login_sso_bad");
        CUWL_LK2_CLEANUP_CODE;
        return(wr->status);
    }

    if (wr->q.VerP >=3 && wr->r.dualAuthUser) {
        char *twoFactorToken;
        int twoFactorTokenLen = 0;
        char *dualAuthTimeStr = apr_itoa(wr->p,wr->r.dualAuthTime);

        cuwa_trace("Make 2F token: method=%s,dualAuthTime=%" APR_TIME_T_FMT, wr->r.dualAuthMethod,wr->r.dualAuthTime );

        if (ksess) 
        {
            //this code path shouldn't happen
            cuwa_crit("Unexpected code path,should not have kerbersos context. dieing",wr->sid);
            CUWL_REQ_ERROR_RETRY(wr,"An unexpected error occurred processing your request, please log in." CUWL_AT);
            cuwl_audit_add(wr, 0, "unexpected_" CUWL_AT);
            return(wr->status);
        }

        if (cred) cuwa_cred_release(cred);
        cred = NULL;

        err = kutil_login_key(&ksess, CFG_CUWL2FAPrincipal(cfg), CFG_CUWL2FAKeytab(cfg) );
        if(err){
            char *msg = apr_psprintf(wr->p,"Unable to log in with twoFactor Keytab");

            CUWL_REQ_ERROR_FATAL(wr,msg);
            CUWL_LK2_CLEANUP_CODE;
            cuwl_audit_add(wr, 0, apr_psprintf(wr->p,"%s",msg));
            return(wr->status);
        }

        err = cuwa_krb_make_2F( wr->q.ReturnHost, wr->q.WAK0Service, &(wr->q.SID),&twoFactorToken, &twoFactorTokenLen, "2u",wr->r.dualAuthUser, strlen(wr->r.dualAuthUser),"2m",wr->r.dualAuthMethod, strlen(wr->r.dualAuthMethod),"2t", dualAuthTimeStr,strlen(dualAuthTimeStr), NULL );

        if(err){
           cuwa_info("Failed to build a k2 using 2F token: %d",err);
           char *msg;
            msg=apr_psprintf(wr->p,"An error occurred creating a 2F credential for %s. This might be because the server %s is misconfigured. Try again, if that doesn't succeed please contact the administrator of %s",wr->q.WAK0Service,wr->q.ReturnHost,wr->q.ReturnHost);
            CUWL_REQ_ERROR_FATAL(wr,msg);
            cuwl_audit_add(wr, 0, "login_2F_bad");
            CUWL_LK2_CLEANUP_CODE;
            return(wr->status);
        }

        err = cuwa_base64_make_wa(&cred64, &cbCred64, cbCred+twoFactorTokenLen, 2, bCred, cbCred,twoFactorToken,twoFactorTokenLen); 
    }
    else
        err=cuwa_base64_make_wa(&cred64, &cbCred64, cbCred, 1, bCred, cbCred);

    if(err){
        char *msg;
        msg=apr_psprintf(wr->p,"An error occurred building your login token (%d). Please retry your login.",err);
        cuwa_crit("Session: %s, Error base64 encoding a k2, should never happen",wr->sid);
        CUWL_REQ_ERROR_RETRY(wr,msg);                
        CUWL_LK2_CLEANUP_CODE;
        cuwl_audit_add(wr, 0, "base64_fail");
        return(wr->status);
    }
    
    cuwa_info("Session: %s, succeeded in building a K2",wr->sid);
    cuwa_auditlog(wr,"WAK2 constructed successfully");
    wr->r.cred=apr_pstrdup(wr->p,cred64);
    wr->status=303;
    
    if(!wr->post) cuwl_audit_add(wr, 1, "login_sso");
    
    if(cred64) cuwa_free(cred64);
    cred64=NULL;
    if(bCred) cuwa_free(bCred);
    bCred=NULL;
    if(wr->q.password) RAND_add(wr->q.password, strlen(wr->q.password),8);
    if(wr->cookie) RAND_add(wr->cookie, strlen(wr->cookie),2);
            
    CUWL_LK2_CLEANUP_CODE;
    return wr->status;
}


char *cuwl_get_first_realm(weblogin_req_t *wr)
{
    char *realm = NULL;
    if(ISSET(wr->q.WAK0Realms)){ 
        realm=apr_pstrdup(wr->p,wr->q.WAK0Realms);
        TRUNCATE(realm,',');
    }
    return realm;
}

void cuwl_parse_request(weblogin_req_t *wr, request_rec *r){
    apr_table_t *args;
    const char *tmp;
    char *t;
    char *realm;
    
    memset(wr,0,sizeof(weblogin_req_t));
    cuwa_trace("Parsing request (%s)...",r->method);
    
    //initialize simple members
    wr->apreq=r;
    wr->query=r->args;
    wr->p=r->pool;
    wr->uri=r->uri;
    wr->status=0;
    wr->trylogin=0;
    wr->cookie=NULL; //FIXME
    wr->r.reason="";
    wr->r.details="";
    wr->r.debug="";
    wr->q.errors="";
    wr->r.securitywarning="";
    wr->r.mustWarn=0;
    wr->audit="{CUWL_AUDIT/" CUWA_VERSTRING "}";
    wr->user_msg = NULL; 
    wr->needDualAuth = CUWL_DUAL_AUTH_UNKNOWN;
    wr->dualStartTime = 0;
 
    //is this a post or a get
    if(!apr_strnatcasecmp(r->method,"POST")){
        CUWL_APPEND_D(wr->p, wr->r.debug, "POST");
        wr->post=-1;
    }
    else{
        CUWL_APPEND_D(wr->p, wr->r.debug, "GET");
        wr->post=0;
    }
    
    cuwa_trace("wr->post=%d",wr->post);
    
    //read query string paramaters
    args=weblogin_parseparams(wr->uri,wr->query,wr->p,r);
    
    //now sanitize them -- fixme would it be better to construct args explicitly?
    wr->query=cuwl_sanitize_weak(wr->p,wr->query,0);
    if(wr->query && r->args && strcmp(wr->query,r->args)){
        cuwa_warning("URL sanitization did something ... this might be a bug. before: [%s] after: [%s]",r->args,wr->query);
    }
    
    tmp=apr_table_get(args,"SID");
    
    if(tmp){
        sscanf(tmp,"%llX",&(wr->q.SID));
        wr->sid=apr_psprintf(wr->p,"%qX",wr->q.SID);
        if(apr_strnatcasecmp(tmp,wr->sid)){ //if the string wasn't read properly
            t=apr_psprintf(wr->p,"Your Session Identifier was malformed (SID could not be converted to a uint64: Raw: %s, Cooked: %s)", tmp,wr->sid);
            wr->sid=NULL;
            CUWL_REQ_ERROR_FATAL(wr,t);
        }
        else if(strlen(wr->sid) <=8){ //if the string wasn't read properly
            CUWL_REQ_ERROR_FATAL(wr,"The supplied SessionID was too short. Either you are very unlucky (chance: 1 in 4 billion) or the application you are trying to access is misconfigured.");
            wr->sid=NULL;
        }
    }
    else{
        CUWL_REQ_ERROR_FATAL(wr,"Query string argument SID is required (Session ID)");
    }
    
    
    tmp=apr_table_get(args,"VerP");
    if(tmp) wr->q.VerP=atoi(tmp);
    wr->q.WAK0Service=(char*)apr_table_get(args,"WAK0Service");
    wr->q.WAK3=(char*)apr_table_get(args,"unsanitary-WAK3"); //fixme this should be sanatized to some level
    if(wr->q.WAK3) wr->trylogin=1;
    wr->q.ReturnURL=(char*)apr_table_get(args,"ReturnURL");
    wr->q.VerC=(char*)apr_table_get(args,"VerC");
    wr->q.Accept=(char*)apr_table_get(args,"Accept");
    wr->q.WAK2Name=(char*)apr_table_get(args,"WAK2Name");
    wr->q.WAK2Flags=(char*)apr_table_get(args,"WAK2Flags");
    if(!wr->q.WAK2Flags) wr->q.WAK2Flags="0";
    wr->q.WAK0Realms=(char*)apr_table_get(args,"WAK0Realms");
    wr->q.WAreason=(char*)apr_table_get(args,"WAreason");
    wr->q.waReasonCode=ISSET(wr->q.WAreason)?atoi(wr->q.WAreason):0;
    wr->q.IDName = apr_pstrdup(wr->p, ISSET(wr->q.WAK2Name)?wr->q.WAK2Name:"NetID");
    wr->q.VerS=(char*)apr_table_get(args,"VerS");
    wr->q.IIS=ISSET(wr->q.VerS) ? ((strstr(wr->q.VerS,"IIS")==NULL)?0:1) : 0;
    wr->q.dualAuth = (char *)apr_table_get(args, "DualAuth");
    wr->q.dualAuthMethod = (char *)apr_table_get(args, "DualMethod");

    //remove any url parameters that has been added for two factor authentication
    if ( wr->query )
        cuwl_dual_remove_params( wr );

    //unencode encoded spaces in IDName (%20 which becomes  20)
    {
        char *idtmp;
        while((idtmp=strstr(wr->q.IDName," 20"))){
            idtmp++;
            while(*(idtmp+2)){
                *idtmp=*(idtmp+2);
                idtmp++;
            }
            *idtmp='\0';
        }
    }
        
    
    {
        char *dirtyReturn=(char*)apr_table_get(args,"unsanitary-ReturnURL");
        
        if(wr->q.ReturnURL && dirtyReturn && strcmp(wr->q.ReturnURL,dirtyReturn)){
            CUWL_APPEND_M(wr->p, wr->q.errors, "Warning: ReturnURL contained illegal characters which were replaced with spaces." CUWL_AT );
        }
    }
    
    //use the right drop-down menu label depending on WAK0Realms values
    realm=cuwl_get_first_realm(wr); 
    if (realm) {
        if (cuwl_realm_from_alias(realm)) {
            wr->r.realmlabel = apr_pstrdup(wr->p,"ID Type:");    
        } 
        else {
            wr->r.realmlabel= apr_pstrdup(wr->p,"Realm:");
        }
    }    
    
    cuwa_trace("checking domain");
    //if WAK0Realms isn't set infer it from WAK0Service
    if(!ISSET(wr->q.WAK0Realms) && ISSET(wr->q.WAK0Service)){
        char * rtmp = strchr(wr->q.WAK0Service,'@');
        if(rtmp){
            wr->q.WAK0Realms=apr_pstrdup(wr->p,rtmp+1);
        }
    }
    
    cuwa_trace("checked domain");
    
    //if this is a post then read the post data
    //fixme -- multipart encoding?
    if(wr->post){
        apr_table_t *tpost;
        tpost=apr_table_make(r->pool,10);
        cuwa1_buildPostData(r,tpost);    
        //WARNING: tpost data has not been sanitized at this point (unlike args)
        
        wr->q.netID=cuwl_sanitize(r->pool,(char*)apr_table_get(tpost,"netID"),0);
        wr->q.netID=cuwl_remove_leading_trailing_spaces(wr->q.netID);
        wr->q.password=(char*)apr_table_get(tpost,"password"); //don't sanitize password!
        wr->q.realm=cuwl_sanitize(r->pool,(char*)apr_table_get(tpost,"realm"),0);
        if(!ISSET(wr->q.netID)){
            cuwa_info("empty netid");
            wr->q.netID=NULL;
        }
        
        if(!ISSET(wr->q.password)){
            cuwa_info("empty password");
            wr->q.password=NULL;        
        }
        
        /******************************
         * compute the realm
         *
         * precedence order:
         * 1. userid contains @REALM
         * 2. realm post paramater set
         * 3. first element of WAK0Realms if set
         * 4. realm from WAK0Service
         *
         ******************************/
        
        if(!ISSET(wr->q.realm)){
            // Realm popup has not been selected, use first realm in list. (Infer realm)
            wr->q.realm=cuwl_get_first_realm(wr); 
        }
        
        //check for a realm and add it onto the userid
        if(wr->q.netID){
            char *rtmp;
            const char *lookup;
            if(ISSET(wr->q.realm)){
                rtmp=strchr(wr->q.netID,'@');
                if(!rtmp){
                    wr->q.netID=apr_psprintf(wr->p,"%s@%s",wr->q.netID,wr->q.realm);
                }
                else{
                    // User typed realm in ID field
                    cuwa_info("Realm in userid");
                    // HACK - only disallow cornell.edu realm typing so that test harness can continue to work.
                    // This is mostly to work around there being both an MIT and AD realm that have overlapping
                    // function.  This block of code should go away when the MIT realm is retired.
                    if (!strcasecmp("@cornell.edu",rtmp))
                    {
                        *rtmp++ = 0;
                        //wr->user_msg = apr_psprintf(wr->p,"Please enter your ID, \"%s\", without the trailing \"@%s\".",wr->q.netID,rtmp);
                        //cuwl_audit_add(wr, 0, apr_psprintf(wr->p,"netid_realm/%s",rtmp));
                        //wr->q.netID = NULL;
                       wr->q.netID=apr_psprintf(wr->p,"%s@%s",wr->q.netID,wr->q.realm); 
                    }
                }
            }
            // Got the realm.  Convert it if it's an alias.
            if (wr->q.netID) {
                rtmp=strchr(wr->q.netID,'@');
                if (rtmp) {
                    lookup = cuwl_realm_from_alias(rtmp+1);
                    if (lookup) {
                        *rtmp = 0;
                        wr->q.netID=apr_psprintf(wr->p,"%s@%s",wr->q.netID,lookup);                    
                    }
                }
            }
        }
                
        if(!wr->q.netID) cuwa_info("post without netid");
        if(!wr->q.password) cuwa_info("post without password");
        else wr->trylogin=1;
    }
    
    //extract relogin cookie if present
    //fixme what if multiple cookie headsrs
    wr->cookie = cuwl_get_cookie( r, CFG_CUWLreloginName(wr));
    if ( wr->cookie )
    { 
        char *cdata = wr->cookie;
        if(strlen(cdata) < 5 || cdata[0]!= 'W' || cdata[1] !='A' ){
            wr->cookie=NULL;
            cuwa_trace("Cookie is either too short or doesn't start with WA, throwing it away.");
            wr->r.sso="";
        }
        else{
            cuwa_trace("Cookie data appears well formed: %s",wr->cookie);
            wr->trylogin=1;
        }
    }
    else{
        CUWL_DEBUG(wr,"No cookies");
        cuwa_trace("Cookie not found");
    }
    
    if(wr->cookie){
        cuwl_audit_add(wr,1,apr_psprintf(wr->p,"sso_in/%s",cuwl_md5(wr->p,wr->cookie,0)));

        //only get dualAuth cookie when SSO cookie if present
        cuwl_dual_get_cookie( wr, CUWL_DUAL_COOKIE, &wr->dualAuthUser, &wr->dualAuthTime, &wr->dualMethod);
    }

    if(wr->q.WAK3){
        cuwl_audit_add(wr,1,apr_psprintf(wr->p,"wak3_in/%s",cuwl_md5(wr->p,wr->q.WAK3,0)));
    }

    if ( wr->dualAuthUser ) {
        cuwl_audit_add(wr,1,apr_psprintf(wr->p,"sso_dual_in/%s",cuwl_md5(wr->p,wr->dualAuthUser,0)));
    }
 
    tmp=apr_table_get(args, "WAK2Age");
    if(tmp){
        wr->q.WAK2Age=atol(tmp);
    }
    else{
        wr->q.WAK2Age=-1;
    }
    
    //Make sure the required paramaters are present
    P_REQUIRE_PARAM(wr,WAK0Service, "WebAuth Kerberos principal to receive credential");        
    P_REQUIRE_PARAM(wr,ReturnURL, "URL for successful login");
    P_REQUIRE_PARAM(wr,VerP, "CUWebLogin protocol version");
    P_REQUIRE_PARAM(wr,VerC, "CUWebLogin client version string");
    P_REQUIRE_PARAM(wr,Accept, "Desired credential type");
    
    
    
    //build ReturnHost, a prefix of ReturnURL
    if(wr->q.ReturnURL){
        cuwa_trace("ReturnURL is: %s",wr->q.ReturnURL);
        wr->q.ReturnHost = apr_pstrdup(wr->p, wr->q.ReturnURL);
        t=strstr(wr->q.ReturnHost,"://");
        if(t){
            t+=3;
            t=strchr(t+1,'/');
            if(t) *t='\0';
            cuwa_trace("ReturnHost is: %s",wr->q.ReturnHost);
        }    
    
        if(!t){
            cuwa_info("ReturnURL malformed: %s", wr->q.ReturnURL);
            CUWL_APPEND_M(wr->p, wr->q.errors, "ReturnURL is malformed, must contain ://.../" CUWL_AT );
            wr->status=400;
        }
    }
    
    /*figure out which server this is and where SSO cookies should be set*/
    /*also get the domain for the SSO present cookie (two part name containing server)*/
    {
        char *req_host;
        char *svr_host;
        req_host=cuwl_sanitize( wr->p , wr->apreq->hostname?wr->apreq->hostname:NULL , 0 );
        svr_host=apr_pstrdup(wr->p,wr->apreq->server->server_hostname);
        wr->r.ssodomain=NULL;
        wr->r.ssopresent=NULL;
        if(req_host && !strcmp(req_host,svr_host)){ //trim off the hostname
            svr_host=strchr(svr_host,'.');
            if(svr_host && *svr_host){
                svr_host++;
                cuwa_assert(strchr(svr_host,'.'));
                if(strchr(svr_host,'.') == strrchr(svr_host,'.')){
                    //one dot left after the hostname was trimmed. TGT doesn't belong in that large a domain. Use the hostname.
                    cuwa_info("Sending SSO to %s because %s looks insecure (two part name)",req_host, svr_host);
                    wr->r.ssodomain=req_host;
                    wr->r.ssopresent=svr_host;
                }
                else{
                    wr->r.ssodomain=svr_host;
                    wr->r.ssopresent=svr_host;
                    //trim the ssopresent domain until it contains only one '.'
                    while(strchr(wr->r.ssopresent,'.') != strrchr(wr->r.ssopresent,'.')){
                        wr->r.ssopresent=strchr(wr->r.ssopresent,'.');
                        cuwa_assert(wr->r.ssopresent);
                        wr->r.ssopresent++;
                    }                    
                }
            }
            else{
                cuwa_info("I seem to be a one-part-name. Blocking SSO functionality");
                wr->r.ssodomain=NULL;
            }    
        }
        else{
            char *msg=apr_psprintf(wr->p,"Your browser requested this page from %s; The server thinks this should be %s. Single-sign-on functionality has been disabled as a precaution.",req_host,svr_host);
            CUWL_APPEND_M(wr->p, wr->r.securitywarning, msg );
            cuwa_info("Mismatched hostnames. Blocking SSO functionality");
            wr->r.ssodomain=NULL;
        }
        
    }
    
    cuwa_info("SSO path is %s, Present path is %s",DENULL(wr->r.ssodomain),DENULL(wr->r.ssopresent));

    if(wr->q.ReturnHost && wr->q.WAK0Service){
        char * ReturnHostname;
        char * homeDomain = ".cornell.edu"; //change len too
        int homeLen=12; //don't compute length of this string every request
        int returnLen;
        char *msg;

        //build ReturnHostname, the DNS name from returnhost
        //strip http(s)://
        ReturnHostname=apr_pstrdup(wr->p,wr->q.ReturnHost);
        ReturnHostname=strstr(ReturnHostname,"//");
        if(!ReturnHostname || !ReturnHostname[2]){
            cuwa_info("ReturnURL malformed, should contain //: %s", wr->q.ReturnURL);
            CUWL_APPEND_M(wr->p, wr->q.errors, "ReturnURL is malformed, must contain ://.../" CUWL_AT );
            wr->status=400;
            ReturnHostname=NULL;
        }
        else{
            ReturnHostname+=2;    
            //strip port
            msg=strrchr(ReturnHostname,':');
            if(msg) *msg=0;
            msg=NULL;
        }
        
        if(wr->status != 400 && ReturnHostname){
            //check 1. returnHost doesn't end in homeDomain
            returnLen=strlen(ReturnHostname);
            if(returnLen <= homeLen || apr_strnatcasecmp(homeDomain, &(ReturnHostname[returnLen-homeLen]))){
                if(strncmp(wr->q.WAK0Service,"http-external/",14)){
                    msg=apr_psprintf(wr->p,"The web site %s is asking you to login. This website is outside of %s and therefore might not be subject to the same policies.", ReturnHostname,homeDomain);
                    CUWL_APPEND_M(wr->p,wr->r.securitywarning,msg );
                    wr->r.mustWarn=1;
                }
            }
        }

    
        
        //check 2. SSL only ServiceID but non-ssl ReturnURL
        if( wr->status != 400 && (!strncmp(wr->q.WAK0Service, "https",5) && strncmp(wr->q.ReturnURL,"https://",8))){
            msg=apr_psprintf(wr->p,"The web site %s is configured incorrectly. It is using a SSL-only serviceID (%s) but is asking that you be redirected to %s (without SSL). Please contact the administrator of %s.",wr->q.ReturnHost,wr->q.WAK0Service,wr->q.ReturnURL,DENULL(ReturnHostname));
            cuwa_notice(msg);
            CUWL_APPEND_M(wr->p, wr->q.errors, msg );
            wr->status=400;
        }

        //check 3. principal doesn't follow naming convention -- doesn't start with http(s)/
        if(strncmp(wr->q.WAK0Service,"http/",5) 
            && strncmp(wr->q.WAK0Service,"HTTP/",5) 
            && strncmp(wr->q.WAK0Service,"https/",6) 
            && strncmp(wr->q.WAK0Service,"http-external/",14) 
            && strncmp(wr->q.WAK0Service,"HTTPS/",6) ){
        
            char *msg;
            msg=apr_psprintf(wr->p,"The site (%s) is configured with a test-only ServiceID (%s). Logins here are not secure.",wr->q.ReturnHost,wr->q.WAK0Service);
            cuwa_notice(msg);
            CUWL_APPEND_M(wr->p,wr->r.securitywarning,msg );
            //wr->status=400; -- uncomment to block
            wr->r.mustWarn=1;

        }
        else{
            //Check 3.b principal/host mismatch
            char * instance; //instance=principal instance without realm or service
            instance=apr_pstrdup(wr->p,strchr(wr->q.WAK0Service,'/'));
            if(instance && *(instance+1)){
                instance++; //strip '/'
                msg=strchr(instance,'@'); //strip realm
                if(msg) *msg='\0';
                msg=NULL;
            }
            else{
                msg=apr_psprintf(wr->p,"The web site %s is configured incorrectly. It is specifying WAK0Service of %s which appears to be malformed.",wr->q.ReturnHost,wr->q.WAK0Service);
                cuwa_notice(msg);
                CUWL_APPEND_M(wr->p, wr->q.errors, msg );
                wr->status=400;    
            }
            if(!instance || !ReturnHostname || apr_strnatcasecmp(ReturnHostname,instance)){
                msg=apr_psprintf(wr->p,"The site (%s) is using a ServiceID for a different site (%s).",wr->q.ReturnHost,wr->q.WAK0Service);
                CUWL_APPEND_M(wr->p, wr->q.errors, msg );

                 msg=apr_psprintf(wr->p,"A note for the server administrator: ServiceID's of the form http/X or https/X can only be used web site X. Please request either the correct production serviceid (http[s]/%s) or http-test/[netid or project] to allow development and testing (with a warning)",DENULL(ReturnHostname));
                CUWL_APPEND_M(wr->p, wr->q.errors, msg );
                wr->r.mustWarn=1;
                wr->status=400;
            }

        }
        cuwl_audit_add(wr,1,apr_psprintf(wr->p,"req_for/%s/%s",wr->q.ReturnHost,wr->q.WAK0Service));
    }
    
    //if this request potentially has enough information to try a login go ahead and authorize the return of a K3 credential if one was requested
    //this is done here to work around a kutil bug. kutil only supports being one user at a time due to gss cache limitations
    //so do the permit related check here before we log the user in
    //ideally it would be better to log the user in before bothering the permit server.
    if(!wr->status && wr->trylogin){
        //does this request want a K3 to be included in the K2
        if(wr->q.WAK2Flags && !strcmp(wr->q.WAK2Flags,"1")){
            if(cuwl_authorize_get_k3(wr,wr->q.WAK0Service)){
                cuwa_trace("K3 requested and authorized, flagging it for inclusion.");
                wr->r.includeK3=1; //authorizing before making the k3 to avoid doing it twice (once on the parse once on the submit)
            }
            else{
                cuwa_info("%s made an unauthorized request for a K3",wr->q.WAK0Service);
                cuwl_audit_add(wr,0,"k3_authz");
            }
        }

        //the authorization related to the use of an inbound K3 is done
        //right before use in cuwl_login_k2 since at that point no kerberos
        //session exists

        
    }

    cuwl_dump_request(wr);
}
/**
 * cuwl_parse_wak1 is a wrapper around cuwa_cred_parse that can optionally extract the binary K1.
 *
 * @param[out] cred credential object returned from parse operation.  Caller must call cuwa_cred_release to free.
 * @param[in] pool the pool from which to allocate bk1
 * @param[in] wak1 the WA[K1] credential to parse
 * @param[in/out] bk1 a binary K1 credential for inclusion in a K3. Allocated from pool.
 *                If NULL is passed this will delegate to cuwa_cred_parse and not extract this field
 * @param[out] cbk1 the size of bk1
 */

int cuwl_parse_wak1(apr_pool_t *pool, cuwa_cred_t **credout, char * wak1, char **bk1, int *cbk1){
    cuwa_assert(wak1);
    if(NULL == bk1 || NULL == cbk1){
        cuwa_trace("K3 credential wasn't requested");
        return(cuwa_cred_parse(pool, credout, wak1, strlen(wak1), NULL, NULL, NULL, NULL ));
    }
    else{
        cuwa_trace("K3 credential was requested");
        if(!cuwl_parse_remove_wa(pool,bk1,cbk1,wak1)){
            return(cuwa_cred_parse(pool, credout,*bk1,*cbk1, NULL, NULL, NULL, NULL ));
        }
        else{
            return(CUWA_ERR_CRED_NOT_SUPPORTED);
        }
    }
}

/**
 * cuwl_parse_remove_wa removes the base64 WA coating around a credential. Expects exactly one credential.
 *
 */
int cuwl_parse_remove_wa(apr_pool_t *pool, char **out, int *cbout, char *in)
{
    int rc;
    int numCreds=0;

    cuwa_assert(out);
    cuwa_assert(in);
    cuwa_assert(cbout);
    if(strncmp(in,"WA",2)){
    cuwa_warning("Got an alleged WA that didn't start with WA");
    return(CUWA_ERR_CRED_NOT_SUPPORTED);
    }
    rc = cuwa_base64_extract_wa( in, strlen(in), out, cbout, &numCreds );
    if(rc) return rc;

    if(numCreds != 1)
    {
        cuwa_warning("I only expected one cred in my WA but I got %d, rejecting it", numCreds);
        return(CUWA_ERR_CRED_NOT_SUPPORTED);
    }

    return 0;
}


//k3 payload format:
// 'K''3'[time][service]'\0'k1
//where time is the 64-bit result from apr_now
int cuwl_make_k3(apr_pool_t *pool, char **k3, int *cbk3, char *bk1, int cbk1, char *service,char *dualAuthUser,char *dualMethod, apr_time_t dualAuthTime){
    //form the cleartext k3 payload
    //'K''3' +  apr_now + service + '\0' + (DualAuth + dualAuthUser +'\0' + dualMethod+'\0\' + dualAuthTime) +bk1
    apr_time_t now=apr_time_now();
    int cbservice = strlen(service)+1;
    int cbDualAuthUser = dualAuthUser ? strlen(dualAuthUser)+1:0;
    int cbDualMethod = dualMethod ? strlen(dualMethod)+1:0;
    int cbDualAuthTime = dualAuthTime > 0 ? sizeof(apr_time_t):0;
    int cbDualAuthTotal = dualAuthUser? dualAuthDoneLen+cbDualAuthUser+cbDualMethod+cbDualAuthTime:0;
    int offset=0;
    int cbk3clear = 2 + sizeof(apr_time_t) + cbservice + cbk1+cbDualAuthTotal;
    char *k3clear = apr_palloc(pool, cbk3clear);
    unsigned char key[WEBLOGIN_K3_KEY_LENGTH];
    char *keyblock;
    
    cuwl_keys_gen(pool, &keyblock, key);
    k3clear[offset++]='K';
    k3clear[offset++]='3';
    memcpy(k3clear+offset,&now,sizeof(apr_time_t));
    offset+=sizeof(apr_time_t);

    memcpy(k3clear+offset,service,cbservice);
    offset+=cbservice;

    if (dualAuthUser)
    {
        cuwa_trace("put dualAuthDone info into k3");
        memcpy(k3clear+offset,dualAuthDone,dualAuthDoneLen);
        offset += dualAuthDoneLen;

        memcpy(k3clear+offset,dualAuthUser, cbDualAuthUser);
        offset += cbDualAuthUser;

        memcpy(k3clear+offset,dualMethod, cbDualMethod);
        offset += cbDualMethod;

        memcpy(k3clear+offset,&dualAuthTime,cbDualAuthTime);
        offset += cbDualAuthTime;
    }

    memcpy(k3clear+offset,bk1,cbk1);
    cuwl_aes_crypt(pool,k3,cbk3,WEBLOGIN_K3_KEYBLOCK_LENGTH,k3clear,cbk3clear,key,1);
    *cbk3=*cbk3+WEBLOGIN_K3_KEYBLOCK_LENGTH;
    memcpy(*k3,keyblock,WEBLOGIN_K3_KEY_LENGTH);
    cuwa_trace("K3 made for %s",service);
    cuwa_trace("k3#%s %d bytes", cuwl_md5(pool,*k3,*cbk3), *cbk3);
    cuwa_trace("k1#%s %d bytes", cuwl_md5(pool,bk1,cbk1),cbk1);
    cuwa_trace("keyblock#%s, key#%s",cuwl_md5(pool,keyblock,WEBLOGIN_K3_KEYBLOCK_LENGTH),cuwl_md5(pool,(char *)key,WEBLOGIN_K3_KEY_LENGTH));
    return 0;
}

//k3 payload format:
// 'K''3'[time][service]'\0'k1
//where time is the 64-bit result from apr_now
int cuwl_parse_k3(apr_pool_t *pool, char *k3, int cbk3, char **bk1, int *cbk1, char **service, apr_time_t *formed,
                  char **dualAuthUser, char **dualMethod, apr_time_t *dualAuthTime){
    //form the cleartext k3 payload
    //'K''3' +  apr_now + service + '\0' + (DualAuth +dualAuthUser + '\0' +dualMethod+'\0' +dualAuthTime)+ bk1
    char *msgkey;
    int cbmsgkey;
    cuwl_aes_crypt(pool,&msgkey,&cbmsgkey,0,k3,WEBLOGIN_K3_KEYBLOCK_LENGTH,cuwl_get_k3_key(),0);
    if(cbmsgkey != WEBLOGIN_K3_KEY_LENGTH){
        cuwa_warning("decrypted message key is %d bytes, expected %d",cbmsgkey,WEBLOGIN_K3_KEY_LENGTH);
        return -1;
    }

    cuwl_aes_crypt(pool,bk1,cbk1,0,k3+WEBLOGIN_K3_KEYBLOCK_LENGTH,cbk3-WEBLOGIN_K3_KEYBLOCK_LENGTH,(unsigned char*)msgkey,0);
    if(strncmp(*bk1,"K3",2)){
        cuwa_warning("decrypted K3 is malformed, doesn't start with K3");
        return -1;
    }
    (*bk1)+=2;
    (*cbk1)-=2;
    if(formed) memcpy(formed,*bk1,sizeof(apr_time_t));
    (*bk1)+=sizeof(apr_time_t);
    (*cbk1)-=sizeof(apr_time_t);
    *service=*bk1;
    (*bk1)+=(strlen(*service)+1);
    (*cbk1)-=(strlen(*service)+1);

    //check if dualAuth info is in k3
    if ( !strncmp(*bk1,dualAuthDone,dualAuthDoneLen) )
    {
        (*bk1) += dualAuthDoneLen;
        (*cbk1)-= dualAuthDoneLen;

        *dualAuthUser = *bk1;
        (*bk1)+=(strlen(*dualAuthUser)+1);
        (*cbk1)-=(strlen(*dualAuthUser)+1);

        *dualMethod = *bk1;
        (*bk1) +=(strlen(*dualMethod)+1);
        (*cbk1)-=(strlen(*dualMethod)+1);

        if (dualAuthTime) memcpy(dualAuthTime,*bk1,sizeof(apr_time_t));
        (*bk1)+=sizeof(apr_time_t);
        (*cbk1)-=sizeof(apr_time_t); 
        cuwa_trace("In K3,User %s authenticated with %s",dualAuthUser, dualMethod);
    }

    cuwa_trace("K3 parsed for %s: k3#%s %d bytes, k1#%s %d bytes, keyblock#%s, key#%s ",*service, cuwl_md5(pool,k3,cbk3), cbk3, cuwl_md5(pool,*bk1,*cbk1),*cbk1,cuwl_md5(pool,k3,WEBLOGIN_K3_KEYBLOCK_LENGTH),cuwl_md5(pool,msgkey,cbmsgkey));
    return(0);
}


/** cuwl_aes_crypt
 * @param pool[in] the pool from which out should be allocated
 * @param out [out] processed data. this apr_palloc's a buffer. data is written starting at *out[padding]
 * @param cbout[out] the number of bytes written to out, excluding padding
 * @param padding[in] number of extra bytes of padding to allocate at the beginning of out.
 * @param in[in] the data to process
 * @param cbin[in] the length of the data
 * @param key[in] the encryption key
 * @param do_encrypt[in] 1 for encryption 0 for decryption
 */
int cuwl_aes_crypt(apr_pool_t *pool, char **out, int *cbout, int padding, char *in, int cbin, unsigned char *key, int do_encrypt){
    *cbout = cbin+EVP_MAX_BLOCK_LENGTH;
    *out = apr_pcalloc(pool,(*cbout) + padding);
    int final_block_len;
    EVP_CIPHER_CTX ctx;

    cuwa_trace("cuwl_aes_crypt, in: %p, cbin: %d, key at %p, do_encrypt: %d",in,cbin,key,do_encrypt);
    unsigned char iv[] = {0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15};
    /* Don't set key or IV because we will modify the parameters */
    EVP_CIPHER_CTX_init(&ctx);
    EVP_CipherInit_ex(&ctx, EVP_aes_256_cbc(), NULL, NULL, NULL, do_encrypt);
    EVP_CIPHER_CTX_set_key_length(&ctx, 10);
    /* We finished modifying parameters so now we can set key and IV */
    EVP_CipherInit_ex(&ctx, NULL, NULL, key, iv, do_encrypt);
    if(!EVP_CipherUpdate(&ctx, (unsigned char *)(*out)+padding, cbout, (unsigned char*)in, cbin)){
        printf("xx\n%d\n",*cbout);
        EVP_CIPHER_CTX_cleanup(&ctx);
        return -1;
    }
    if(!EVP_CipherFinal_ex(&ctx, (unsigned char*)(*out)+*cbout+padding, &final_block_len)){
        /* Error */
        EVP_CIPHER_CTX_cleanup(&ctx);
        return -1;
    }
    (*cbout)+=final_block_len;

    EVP_CIPHER_CTX_cleanup(&ctx);
    return 0;
}    


/**
 * reads long term key
 * and generates a single use key
 * returns the keyglock encrypted under the long term key
 */
int cuwl_keys_gen(apr_pool_t *pool, char ** keyblock, unsigned char *key){
    unsigned char *ltkey = cuwl_get_k3_key();
    int cbout;
    RAND_bytes(key,WEBLOGIN_K3_KEY_LENGTH);
    if(cuwl_aes_crypt(pool,keyblock,&cbout,0,(char *) key,WEBLOGIN_K3_KEY_LENGTH,ltkey,1)) return(-1);
    cuwa_assert(WEBLOGIN_K3_KEYBLOCK_LENGTH==cbout);
    return(0);
}

int cuwl_authorize_get_k3(weblogin_req_t *wr, char *serviceID){
    CUWACfg_t *cfg = cuwa_wal_get_config((void *)wr->apreq);
    cuwa_trace("Attempting to authorize creation of a K3 for %s",serviceID);
    return (CUWL_PERMIT_HAS == cuwl_in_permit(wr->p, CFG_CUWLPermitPrincipal(cfg), CFG_CUWLPermitKeytab(cfg), "cit.weblogin.getk3",serviceID));
}

int cuwl_authorize_get_k2(weblogin_req_t *wr, char *k2target, char *k3owner){
    // HACK: Need to replace / with _, AD doesn't support slash in SAM account names
    // Note - this is the only place where we used slashes in permit name
    CUWACfg_t *cfg = cuwa_wal_get_config((void *)wr->apreq);
    char *ptr = apr_pstrdup(wr->p,k2target);
    char *ptr2 = strchr(ptr,'/');

    if (ptr2) *ptr2 = '_';
    cuwa_trace("Attempting to authorize creation of a K2 for %s from  a K3 issued to %s",ptr, k3owner);
    return (CUWL_PERMIT_HAS == cuwl_in_permit(wr->p, CFG_CUWLPermitPrincipal(cfg), CFG_CUWLPermitKeytab(cfg), apr_psprintf(wr->p, "cit.weblogin.getk2.%s",ptr),k3owner));

}
