#ifndef CUWL_WEBLOGIN_H_INCLUDED
#define CUWL_WEBLOGIN_H_INCLUDED

#include "apr_general.h"
#include "apr_tables.h"
#include "apr_strings.h"
#include "apr_pools.h"
#include "cuwa_types.h"
#include "httpd.h"
#include "cred.h"
#include <cuwl_cfg.h>
//aes-256 key is 32 bytes
#define WEBLOGIN_K3_KEY_LENGTH 32
//CBC encrypted aes-256 key adds an aes block length, which is 16 bytes
#define WEBLOGIN_K3_KEYBLOCK_LENGTH 48

typedef struct weblogin_req{
    apr_pool_t *p;
    request_rec *apreq;
    int status;
    int trylogin; //this request might have enough data. try to login the user    
    char *uri;
    char *query;
    int post;
    char *cookie;
    char *dualAuthUser;
    char *dualMethod;
    apr_time_t dualAuthTime;
    apr_time_t dualStartTime;
    int  needDualAuth;
    char *sid; //take the SID paramater, convert it to a uint64 and then convert it back
    struct{
        uint64 SID;
        char * WAK0Service;
        char * ReturnURL;
        int VerP;
        char * VerC;
        char * VerS;
        char * Accept;
        char * WAK2Name;
        char * WAK2Flags;
        char * WAK0Realms;
        long    WAK2Age;
        char * netID;
        char * password;
        char * errors;
        char * ReturnHost;
        char * realm;
        char *IDName;
        char * WAK3;
        char * bK1;
        int cbK1;
        char * WAreason;
        int waReasonCode;
        int IIS;
        char *dualAuth;
        char *dualAuthMethod;
    } q;
    struct{
        int includeK3; //K3 requested AND AUTHORIZED
        char * securitywarning;
        char * reason;
        char * details;
        char * debug;
        char * cred;
        char * sso; //outgoing SSO cookie
        char * ssoendtime; //outgoing SSO cookie
        char * ssodomain; //domain for SSO -- server's domain. must be at least a 3-part name.
        char * ssopresent; //domain for SSO present -- two part dns name containing server
        int mustWarn; //block relogin use due to some warning which we need to display
        char * realmlabel;
        char * dualAuthCookie; //outgoing dual authentication cookie
        char * dualAuthUser;
        apr_time_t dualAuthTime;  //time when user finished the second auth
        char * cuwlUser;
        char *dualAuthMethod;
    } r;
    char *audit;
    char *user_msg;
} weblogin_req_t;




void cuwl_audit_add(weblogin_req_t *wr, int success, char *msg);
char * cuwl_md5(apr_pool_t *p, char *in, int length);

apr_table_t* weblogin_parseparams(char *uri, char *query, apr_pool_t *pool, void *r);
int weblogin_show_form(char *uri, char * query, apr_pool_t *pool, void *r, char * reason, char * id_name);


void cuwl_output(weblogin_req_t *wr, const char *s, ...);
void cuwl_debug_out(weblogin_req_t *wr, int level, const char *s, ...);
void cuwl_output_header(weblogin_req_t *wr, char *header, char *value);
void cuwl_parse_request(weblogin_req_t *wr, request_rec *r);
char * cuwl_sanitize(apr_pool_t *pool, char *msg, int init);
char * cuwl_sanitize_weak(apr_pool_t *pool, char *msg, int init);
int cuwl_login_K2(weblogin_req_t *wr);
int cuwl_keys_gen(apr_pool_t *pool, char ** keyblock, unsigned char *key);
int cuwl_aes_crypt(apr_pool_t *pool, char **out, int *cbout, int padding, char *in, int cbin, unsigned char *key, int do_encrypt);
int cuwl_parse_k3(apr_pool_t *pool, char *k3, int cbk3, char **bk1, int *cbk1, char **service, apr_time_t *formed, 
                  char **dualAuthUser,char **dualMethod, apr_time_t *dualAuthTime);
int cuwl_make_k3(apr_pool_t *pool, char **k3, int *cbk3, char *bk1, int cbk1, char *service,
                 char *dualAuthUser,char *dualMethod, apr_time_t dualAuthTime);
int cuwl_parse_wak1(apr_pool_t *pool, cuwa_cred_t **credout, char * wak1, char **bk1, int *cbk1);
int cuwl_parse_remove_wa(apr_pool_t *pool, char **out, int *cbout, char *in);

#define CUWL_SS(x) #x
#define CUWL_S(x) CUWL_SS(x)
#define CUWL_AT  "(" __FILE__ ":" CUWL_S(__LINE__) ")"
#define CUWL_APPEND_M(p,s,msg) s=apr_pstrcat(p,s, "<li>", msg, "</li>\n", NULL)
#define CUWL_APPEND_D(p,s,msg)  s=apr_pstrcat(p, s, "<li>", msg, CUWL_AT, "</li>\n", NULL)
#define CUWL_DEBUG(x,msg) CUWL_APPEND_D(x->p, x->r.debug,msg)


#define CUWL_REQ_ERROR(x,msg,code) do{ \
                                    CUWL_APPEND_M((x)->p, (x)->q.errors,msg); \
                                    if((x)->status < (code)) (x)->status=(code); \
                                    cuwa_info("Session: %s, Request contains an error (%d): %s",(x)->sid, (code),(msg)); \
                                    } while(0)


#define CUWL_REQ_ERROR_RETRY(x,msg) CUWL_REQ_ERROR(x,msg,200);
#define CUWL_REQ_ERROR_FATAL(x,msg) CUWL_REQ_ERROR(x,msg,400);

#define cuwa_auditlog(wr,x, ...) cuwa_log(CUWA2_L_NOTICE,x, ##__VA_ARGS__)                                        
                                        
#define P_REQUIRE_PARAM(s,pa,m) do{ \
                                    if(! (s->q).pa ){ \
                                        CUWL_APPEND_M(s->p, s->q.errors, "Query string argument " #pa " is required (" m ")"); \
                                        s->status=400; \
                                        cuwa_info("%s","Query string argument " #pa " is required (" m ")"); \
                                    } \
                                } while(0)


#endif
//
