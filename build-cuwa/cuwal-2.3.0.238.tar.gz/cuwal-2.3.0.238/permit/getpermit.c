#define CUWA_ERR_STRINGS

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <kutil.h>
#include <apr_strings.h>
#include <permit.h>
#include <cuwa_err.h>
#include <cuwa_malloc.h>
#include <log.h>
#include <unistd.h>
#include <cuwa_err.h>
#include <autoconfig.h>
#include <util.h>

#define CUWA2_LOG_DOMAIN cuwa.permit

#define SYNTAX(m) {syntax(argv[0],(m));}

void syntax (char *progName, char *message);

void process_cmdline (apr_pool_t *pool, int argc, char *argv[],
                      char **localid, char **keytab, char **host, int *port, char **serviceid,
                      char **netid, char **permits, int *cmd);

char *cuwa_version_get_full()
{
    return "getpermit v1 " CUWA_PROD;
}


int main(int argc, char* argv[])
{
    int rc=0, code;
    kutil_session_t ksess;
    char *permit_names,*netid, *memberships=NULL, *nonmember=NULL;
    char *localid;
    char *keytab;
    char *host,*hosts;
    char *serviceid;
    int port;
    int cmd;

    apr_pool_t *pool;

    apr_pool_initialize();
    apr_pool_create( &pool, NULL );
    cuwa_malloc_init(pool);
    cuwa_malloc_set_pool(pool);

    process_cmdline(pool, argc, argv, &localid, &keytab, &hosts, &port, &serviceid, &netid, &permit_names, &cmd);

    code = kutil_login_key(&ksess, localid, keytab);
    FAIL_IF(code,code);
    
    while ( (host = cuwa_nextword(&hosts, ' ') )!=NULL) 
    {
        switch (cmd)
        {
            case 'A':
                code = cuwa_permit_add(ksess, localid, host, port, serviceid,netid, permit_names, pool, &memberships, &nonmember); 
                //memberships = permit_names; 
                break;
            case 'D':
                code = cuwa_permit_delete(ksess, localid, host, port, serviceid,netid, permit_names, pool,&memberships, &nonmember);
                //nonmember = permit_names;
                break;
            default:
                code = cuwa_permit_check(ksess, localid, host, port, serviceid, netid, permit_names, &memberships, &nonmember, pool);
                break;
        }

        if (!code || code != CUWA_ERR_SOCKET) break;
   }
 
   FAIL_IF(code, code);

cleanup:
    if (rc) fprintf(stderr,"Error: %d, %s\n",rc,DENULL(CUWA_ERR_TO_STR(rc)));

    printf("MEMBER: %s\n", memberships?memberships:"");
    printf("NON-MEMBER: %s\n", nonmember?nonmember:"");

    return rc;
}


// getpermit -i local_id -k keytab -h permitd_host -p permitd_port -s permitd_serviceid netid permit [netid permit...]
void process_cmdline (apr_pool_t *pool, int argc, char *argv[],
                      char **localid, char **keytab, char **host, int *port, char **serviceid,
                      char **netid, char **permits, int *cmd)
{
	int c, i, pcnt;
    char **lnetids, **lpermits;
    char *level;
    int debug = 0;

    *localid   = NULL;
    *keytab    = NULL;
    *host      = NULL;
    *port      = 759;
    *serviceid = NULL;
    *netid     = NULL;
    *permits   = NULL;
    *cmd       = 'G';

	while ((c=getopt(argc, argv, "ADd:i:k:h:p:s:n:V")) != -1) {
		switch (c) {
			case 'd':
				debug = atoi(optarg);
				break;
			case 'A':
				*cmd = 'A';
				break;
			case 'D':
				*cmd = 'D';
				break;
   			case 'p':
				*port = atoi(optarg);
				break;
			case 'i':
				*localid = optarg;
				break;
			case 'k':
				*keytab = optarg;
				break;
            case 'h':
                *host = optarg;
				break;
			case 's':
				*serviceid = optarg;
				break;
			case 'n':
				*netid = optarg;
				break;
			case 'V':
				fprintf(stderr, "getpermit version 2.0\n" CUWA_PROD "\n");
				exit(0);
			default:
				fprintf(stderr, "Unknown option: %c\n",c);
				SYNTAX(NULL);
		}
	}

    // Set debug level first before any debugging output is generated
    level = apr_psprintf(pool, "CUWA_LEVEL=%d",debug);
    putenv(level);

    pcnt = argc-optind;
    *permits = NULL;
    if (pcnt)
    {
        for (i=0;i<pcnt;i++)
        {
            if (*permits) *permits = apr_pstrcat(pool,*permits," ",argv[optind++],NULL);
            else *permits = argv[optind++];
        }
    }

    if (!*localid || !*keytab || !*host || !serviceid || !*netid) SYNTAX("localid, keytab, host, serviceid, netid are required.");
    if (!*permits) SYNTAX("Must specify at least one permit.");

}

void syntax (char *progName, char *msg)
{
	if (msg) fprintf(stderr, "%s\n",msg);
	fprintf(stderr, "getpermit (%s)\n", CUWA_VERSTRING);
	fprintf(stderr, "Usage: %s -d debugLevel -i local_id -k keytab -h permitd_host [-D | -A] -p permitd_port -s permitd_serviceid -n netid permit [permit...]\n", progName);
	fprintf(stderr, "       %s -V\n", progName);
	fprintf(stderr, "          local_id          = the local id associated with keytab\n");
	fprintf(stderr, "          keytab            = keytab used to authenticate to permit server\n");
	fprintf(stderr, "          permitd_host      = DNS name of permit server\n");
	fprintf(stderr, "          permitd_port      = IP port of permit server\n");
	fprintf(stderr, "          permitd_serviceid = Serviceid of permit server\n");
	fprintf(stderr, "          netid             = netid to lookup permit on behalf of\n");
	fprintf(stderr, "          permit            = permit to lookup\n");
	fprintf(stderr, "          list_netid        = all permits are listed for this netid\n");
	fprintf(stderr, "          debugLevel        = 0=no debug, 7=trace\n");
	fprintf(stderr, "          -A                = Add permit\n");
	fprintf(stderr, "          -D                = Delete permit\n");
	fprintf(stderr, "          -V                = Print version number of %s\n",progName);
	exit(-1);
}

const char id_permit_test_permit_c[] = "$Id: getpermit.c,v 1.11 2011/03/15 15:56:30 hy93 Exp $";
