/************************************************************************
 * permit.h -- Lookup ownership of one or more permits
 *
 * Copyright 2007 Cornell University.
 * All Rights Reserved.
 *
 ************************************************************************
 *  $Log: permit.h,v $
 *  Revision 1.8  2009/12/22 15:27:59  hy93
 *  support add/delete multiple permits in one command.
 *
 *  Revision 1.7  2009/10/09 03:30:38  pb10
 *  Add and delete functions are now supported in mod_permit.
 *  Also added support into getpermit command for testing purposes, but not into permit portal.
 *  May remove feature from getpermit command after testing completes TBD.
 *
 *  Revision 1.6  2008/08/09 01:16:49  pb10
 *  Support listPermit call (CUWAInquire permit all).
 *
 *  Revision 1.5  2008/04/24 14:13:05  hy93
 *  replace socket implementation with APR_SOCKET
 *
 *  Revision 1.4  2008/04/10 17:08:20  gbr4
 *  removed the cvs-log keyword from each of these files as it was causing line ending problems.
 *
 *  Revision 1.3  2008/04/10 17:02:00  gbr4
 *  more line ending problems
 *
 *  Revision 1.2  2008/04/10 16:57:11  gbr4
 *  Line endings only. This set of files had mixed line endings which breaks visual studio (and looks ugly in vim). Each file was converted to the format that resulted in the fewest line changes (i.e. whichever format it was mostly in).
 *
 *  Revision 1.1  2007/10/18 20:08:38  pb10
 *  initial
 *
 *
 ************************************************************************
 */

#ifndef _PERMIT_H
#define _PERMIT_H

#include "kutil.h"

#include <apr_pools.h>

int cuwa_permit_check(kutil_session_t ksess, char *localid,
                      char *permitHostName, int permitPort, char *permitid,
                      char *netid, char *permit_names, char **memberships, char **nonmember, apr_pool_t *pool);

int cuwa_permit_add(kutil_session_t ksess, char *localid,
                       char *permitHostName, int permitPort, char *permitid,
                       char *netid, char *permit_name, apr_pool_t *pool, char **membership, char **nonmember);

int cuwa_permit_delete(kutil_session_t ksess, char *localid,
                       char *permitHostName, int permitPort, char *permitid,
                       char *netid, char *permit_name, apr_pool_t *pool, char **membership, char **nonmember);

#endif /* _PERMIT_H */

