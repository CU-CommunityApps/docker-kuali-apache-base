/************************************************************************
 * permit_cache.h -- cache permit lookups
 *
 * Copyright 2007 Cornell University.
 * All Rights Reserved.
 *
 ************************************************************************
 *  $Log: permit_cache.h,v $
 *  Revision 1.2  2015/10/07 17:39:55  hy93
 *  merge TwoFactor treee to the head
 *
 *  Revision 1.1.6.1  2015/10/01 16:06:26  hy93
 *  add session to cuwa_permit_cache_check
 *
 *  Revision 1.1  2008/08/09 01:19:07  pb10
 *  Initial coding.
 *
 *
 ************************************************************************
 */

#ifndef _PERMIT_CACHE_H
#define _PERMIT_CACHE_H

#include <apr_pools.h>
#include <cfg.h>
#include <session.h>

cuwa_err_t cuwa_permit_cache_check( void *request, apr_pool_t *pool, void *s, CUWACfg_t *cfg, char *localid, char *keytab,
                                    char *netid, char *permitlist, char **memberships, char **nonmember );

void cuwa_permit_cache_load(void *r, cuwa_session_t *session, apr_pool_t *pool);

#endif /* _PERMIT_H */


