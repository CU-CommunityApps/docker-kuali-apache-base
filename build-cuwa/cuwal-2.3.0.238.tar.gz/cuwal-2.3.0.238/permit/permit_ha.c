/************************************************************************
 * cuwa_permit_ha.c -- permit support in CUWA.
 *
 * Copyright 2008 Cornell University.
 * All Rights Reserved.
 *
 ************************************************************************/
#include <util.h>
#include <permit.h>
#include <permit_ha.h>
#include <log.h>
#include <apr_pools.h>
#include <apr_strings.h>
#include <wal.h>
#include <apr_time.h>
#include <stdlib.h>

#define CUWA2_LOG_DOMAIN cuwa.permit

typedef struct cuwa_permit_server
{
    char *host;
    char *id;
    char * port;
}cuwa_permit_server_t;

#define CUWA2_LOG_DOMAIN cuwa.permit

#define CUWA_MAX_PERMIT_SERVER 3

static cuwa_permit_server_t cuwa_permit_list[CUWA_MAX_PERMIT_SERVER];
static int cuwa_permit_server_used = 0;
static int cuwa_permit_server_total = 0;

static void cuwa_permit_list_show();
static int cuwa_permit_parse_service(apr_pool_t *pool, char *pserver, char **id, char **host, char **port);

int cuwa_permit_parse_service(apr_pool_t *pool, char *pserver, char **id, char **host, char **port)
{
    char *str;

    if (!pserver)
        return CUWA_ERR;

    cuwa_assert(id);
    cuwa_assert(host);
    cuwa_assert(port);

    str = apr_pstrdup(pool, pserver);

    *id = str;

    str = strrchr( str, '@' );
    if (!str)
    {
        cuwa_warning("Bad syntax for CUWAPermitServer: %s.  SYNTAX: serviceId@host:port",pserver);
        return CUWA_ERR;
    }
    *str++ = '\0';
    *host = str;

    str = strchr( str, ':' );
    if (str)
    {
        *str++ = '\0';
        *port = str;
    }
    else *port = "0";

    cuwa_trace("permit serviceid:%s host:%s port:%s", *id, *host, *port);

    return CUWA_OK;
}

void cuwa_permit_list_show()
{
    int index;
    cuwa_permit_server_t *permit;

    for (index=0; index < cuwa_permit_server_total; index++)
    {
        permit = &cuwa_permit_list[index];

        cuwa_trace("Permit host: %s, port: %s, id:%s", permit->host, permit->port, permit->id);
    }
}

void cuwa_permit_ha_add_servers( char *serverList , apr_pool_t *pool)
{
    int code;
    char *permitSvr, *state;
    cuwa_permit_server_t *permit;

    if ( !serverList )
        return;

    cuwa_trace("adding permit servers:%s", serverList);

    cuwa_util_replace_char( serverList, '\t' );
    cuwa_util_replace_char( serverList, ',' );
    cuwa_util_replace_char( serverList, ';' );

    memset( &cuwa_permit_list, 0, CUWA_MAX_PERMIT_SERVER*sizeof( cuwa_permit_server_t) );

    permitSvr = apr_strtok( serverList, " ", &state);
    while ( permitSvr  && cuwa_permit_server_total < CUWA_MAX_PERMIT_SERVER )
    {
        permit = &cuwa_permit_list[cuwa_permit_server_total];

        code = cuwa_permit_parse_service( pool, permitSvr, &permit->id , &permit->host, &permit->port );
        if (!code)
        {
            cuwa_permit_server_total++;
        }
        permitSvr = apr_strtok( NULL, " ", &state);
    }

    cuwa_permit_list_show();
}

int cuwa_permit_ha_check( apr_pool_t *pool, CUWACfg_t *cfg, char *localid, char *keytab,
                          char *netid, char *permitlist, char **memberships, char **nonmember)
{
    int code = 0;
    int index, lastUsed;
    cuwa_permit_server_t *permit;
    kutil_session_t ksess = NULL;
 
    cuwa_assert(pool);

    if ( !cuwa_permit_server_total )
    {
        cuwa_warning("no permit server defined");
        return CUWA_ERR;
    }  
    lastUsed = cuwa_permit_server_used;
    index = lastUsed;

    code = kutil_login_key(&ksess, localid, keytab );
    if (code)
    {
        cuwa_warning("Server is unable to initiate kerberos request, error=%d.", code);
        return code;
    }

    cuwa_trace("permit server last used %d, totalServer: %d", index, cuwa_permit_server_total);

        do
        {
            permit = &cuwa_permit_list[index];
            cuwa_trace("Try permit server %d:%s", index,permit->host);
            if ( code )
            {
                //if we have a failure from previous contact to permit server, we wait 5 milliseconds before we try again
                apr_sleep(5000);
		#ifdef WIN32
			//fixme until we figure out how to disable the windows replay cache
			//MIT chose the current time in seconds as the protocol nonce.
			//so we need to wait for the next second.
			cuwa_info("Sleeping for a second before retrying kerberos call to avoid being flagged as a replay. Need to figure out how to get rid of the replay cache on windows.");
			apr_sleep(1000000);
		#endif
            }
            code = cuwa_permit_check( ksess, localid, permit->host, atoi(permit->port),permit->id,
                                      netid, permitlist, memberships, nonmember, pool );
            
            if (!code || (code!= CUWA_ERR_SOCKET && code!=CUWA_ERR_BRIDGE_INIT) )
                break;

            // no good, try the next server if there is one.
            cuwa_warning("Permit server error: %d", code);

            index ++;
            if ( index >= cuwa_permit_server_total )
                index = 0;
        }while (index != lastUsed);


    if ( !code  && (cuwa_permit_server_used!= index) )
        cuwa_permit_server_used = index;

    kutil_end_session( ksess );

    cuwa_trace("cuwa_permit_ha done");

    if (code)
        cuwa_warning("checking permit failed with errCode=%d",code);

    return code;
}

const char id_permit_permit_ha_c[] = "$Id: permit_ha.c,v 1.11 2015/10/07 17:41:04 hy93 Exp $";
