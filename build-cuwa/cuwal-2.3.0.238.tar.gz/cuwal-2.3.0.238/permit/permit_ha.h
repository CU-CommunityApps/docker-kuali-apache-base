/************************************************************************
 * permit_ha.h -- permit high availability support
 *
 * Copyright 2007 Cornell University.
 * All Rights Reserved.
 *
 ************************************************************************
 *  $Log: permit_ha.h,v $
 *  Revision 1.1  2008/08/09 01:19:07  pb10
 *  Initial coding.
 *
 *  Revision 1.1  2008/04/24 14:09:15  hy93
 *  permit support
 *
 *
 ************************************************************************
 */

#ifndef _PERMIT_HA_H
#define _PERMIT_HA_H

#include <apr_pools.h>
#include <cfg.h>

void cuwa_permit_ha_add_servers( char *permitList , apr_pool_t *pool);

int cuwa_permit_ha_check( apr_pool_t *pool, CUWACfg_t *cfg, char *localid, char *keytab,
                          char *netid, char *permitlist, char **memberships, char **nonmember);

#endif
