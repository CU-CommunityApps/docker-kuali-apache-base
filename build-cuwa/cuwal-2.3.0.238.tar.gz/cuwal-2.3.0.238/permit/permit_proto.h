/************************************************************************
 * permit_proto.h -- Contants for communication with the permit server
 *
 * Copyright 2008 Cornell University.
 * All Rights Reserved.
 *
 ************************************************************************
 *  $Log: permit_proto.h,v $
 *  Revision 1.1  2008/10/02 19:39:49  pb10
 *  Initial coding for permit client that uses HTTP instead of CUSSP.
 *
 *
 *
 ************************************************************************
 */

#ifndef _PERMIT_PROTO_H
#define _PERMIT_PROTO_H

enum pErr
{
    pSuccess, pGeneralError, pNoSuchPermitName, pNoPermit,
    pIdRevoked, pMissingParms, pObsolete1, pObsolete2, pSenderNoLookup,
    pSenderNoUpdate, pSenderNoAdmin, pSenderNoOwner, pSenderNoMaster,
    pBadNetID, pInfoTooLong, pBadAclCode, pBadModeCode, pInvalidPermitName,
    pPermitExists, pReplaceFailed, pNoSlaveUpdate, pCusspLibErr,
    pBadAuthenticator, pPermitExpired, pBadLogFile, pBulkRunning,
    pDbOpenErr, pDbReadErr, pDbWriteErr,
    pNumErrMsgs
};

#define WRAP_LABEL "base64-wrap:"

#endif
