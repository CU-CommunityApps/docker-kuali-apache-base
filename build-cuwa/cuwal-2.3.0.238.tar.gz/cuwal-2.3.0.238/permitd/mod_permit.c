/************************************************************************
 * mod_permit.c
 *
 * Copyright 2008 Cornell University.
 * All Rights Reserved.
 *
 ************************************************************************
 *  $Log: mod_permit.c,v $
 *  Revision 1.20  2010/01/22 16:08:36  hy93
 *  fix huge memory consumption when there are many entries in return result
 *
 *  Revision 1.19  2010/01/20 21:47:31  hy93
 *  add audit log in notes field
 *
 *  Revision 1.18  2010/01/08 17:58:11  hy93
 *  Fix memory leek and missing log info
 *
 *  Revision 1.17  2008/12/11 20:24:42  hy93
 *  set content length in the header
 *
 *  Revision 1.16  2008/10/29 16:46:52  pb10
 *  Further cleanup around removing permits from log in listpermits command.
 *
 *  Revision 1.15  2008/10/29 16:43:41  pb10
 *  Fix DB normalize.
 *
 *  Revision 1.14  2008/10/23 19:54:44  pb10
 *  Add return value for each permit lookup to the log.
 *
 *  Revision 1.13  2008/10/23 15:43:52  pb10
 *  Fix log.
 *
 *  Revision 1.12  2008/10/23 15:21:33  pb10
 *  Add event logging.
 *
 *  Revision 1.11  2008/10/09 19:22:21  pb10
 *  Needed another wal function.
 *
 *  Revision 1.10  2008/10/09 19:20:02  pb10
 *  Add some wal functions because of addition of log_util.
 *
 *  Revision 1.9  2008/10/02 15:27:13  pb10
 *  Fix authorization.
 *
 *  Revision 1.8  2008/10/02 12:00:13  pb10
 *  Minor tweaks.
 *
 *  Revision 1.7  2008/10/01 14:35:14  pb10
 *  removed wal dependency.
 *
 *  Revision 1.6  2008/10/01 14:19:50  pb10
 *  Add listpermit support.
 *
 *  Revision 1.5  2008/09/23 19:10:00  pb10
 *  Fixed some URL parsing issues.
 *
 *  Revision 1.4  2008/09/23 17:23:16  pb10
 *  Basically working.
 *
 *  Revision 1.3  2008/09/23 09:05:53  pb10
 *  Fixed config.  Added initialization and DB path.
 *
 *  Revision 1.2  2008/09/22 19:45:56  pb10
 *  Adding support for getpermit function.
 *
 ************************************************************************
 */

#define CUWA_ERR_STRINGS

#include <apr_buckets.h>
#include <apr_general.h>
#include <apr_lib.h>
#include <apr_strings.h>
#include <apr_atomic.h>
#include <ap_compat.h>
#include <util_filter.h>
#include <http_request.h>
#include <httpd.h>
#include <http_config.h>
#include <http_protocol.h>
#include <http_connection.h>
#include <http_log.h>
#include <http_core.h>

#include "../autoconfig.h"
#ifdef HAVE_UNISTD_H
#include <unistd.h>
#endif

#include <ctype.h>
#include <time.h>
#include <cuwa_err.h>
#include <kutil.h>
//#include <cuwa_request.h>
//#include <cuwa_version.h>
//#include <cuwa_parse.h>
#include <log.h>
#include <portal_error_page.h>
#include <cuwarand.h>
#include <log_apache.h>
#include <cuwa_types.h>
#include <cfg.h>
#include <cfg-dump.h>
#include <cuwa_malloc.h>
#include <cred.h>
#include <cred_base64.h>
#include <permit_command.h>
#include <wal.h>

#define CUWA2_LOG_DOMAIN cuwa.apache
#define WRAP_LABEL "base64-wrap:"

module AP_MODULE_DECLARE_DATA permit_module;
module AP_MODULE_DECLARE_DATA *cuwa_module = &permit_module;

// Include auto-generated functions and table for apache directives, depends on cuwa_module defined above :-)

#include <cfg-apache-incl.c>

#define PERMIT_ERR(m) do {status=500;msg=(m);goto cleanup;} while(0)
#define POST_BLOCK 1024

// FIXME dup'd from portal code
void cuwa_portal_log(request_rec *r, apr_pool_t *pool, const char *fmt, ... )
{
    va_list va;
    char *msg;
    char *log;

    va_start(va,fmt);
    msg = apr_pvsprintf(pool,fmt,va);
    va_end(va);

    cuwa_trace("PORTAL: %s",msg);

    log = (char*) apr_table_get( r->notes,"PORTAL_LOG");
    if (log)
    {
        msg = apr_pstrcat(pool,log,"\n",msg,NULL);
    }

    apr_table_set(r->notes,"PORTAL_LOG",msg);
}

// FIXME dup'd from mod_cuwebauth
const char *cuwa_table_get(request_rec *r, char *name)
{
    // Get table entry from notes.  Support subrequests and internal redirects by looking at main and prev.
    const char *returns = NULL;
    if(!r) return(NULL);
    if(r->notes)   returns = apr_table_get( r->notes,name);

    if (!returns && r->main)
    {
        returns = cuwa_table_get( r->main,name);
    }
    if (!returns && r->prev)
    {
        returns = cuwa_table_get( r->prev,name);
    }
    return returns;
}

// FIXME dup'd from mod_cuwebauth
apr_pool_t *cuwa_wal_get_pool( void *req )
{
    request_rec *r = (request_rec *)req;

    return (r->pool);
}

// FIXME dup'd from mod_cuwebauth
char *cuwa_wal_note_get(void *request, char *name)
{
    request_rec *r = (request_rec *)request;

    if ( r->notes )
        return (char *) cuwa_table_get( r, name );
    else
        return NULL;
}

// FIXME dup'd from mod_cuwebauth
void cuwa_wal_note_set( void *request, char *name, char *value)
{
    request_rec *r = (request_rec *)request;

    apr_table_set( r->notes, name, value);
}



static int permit_send_page(request_rec *r, int status, char *html)
{
    r->status = status;
    r->content_type = "text/html;charset=ascii";
    r->no_cache = 1;
    r->no_local_copy = 1;
    ap_set_content_length(r, strlen(html));
    ap_send_http_header(r);
    ap_rprintf(r,"%s",html);
    return DONE;
}


void permit_log_event(apr_pool_t *pool, char *netid, apr_table_t *args_in, int status, int code)
{
    const char *lookupid = NULL;
    const char *cmd = NULL;

    if (args_in)
    {
        cmd      = apr_table_get( args_in,"cmd");
        lookupid = apr_table_get( args_in,"netid");
    }

    if (!netid)    netid = "-";
    if (!cmd)      cmd = "-";
    if (!lookupid) lookupid = "-";

    cuwa_info("RSP %s %s %s %d %d",cmd,netid,lookupid,(!status)?200:status,code);
}

int permit_error_response(request_rec *r, short status, int code, const char *fmt, ... )
{
    va_list args;
    char *reason;
    const char *log    = apr_table_get( r->notes,"PORTAL_LOG");
    const char *detail = apr_table_get( r->notes,"CUWA-LogError");
    const char *emsg   = CUWA_ERR_TO_STR(code);
    char       *html   = NULL;

    va_start(args, fmt);
    reason = apr_pvsprintf(r->pool,fmt,args);
    va_end(args);

    if (!detail) detail = "no further detail";
    if (!emsg)   emsg   = "no further detail";
    if (!log)    log   = "";

    cuwa_trace("PORTAL Error: %d--%s--%d--%s--%s--%s",status,reason,code,emsg,detail,log);
    html = apr_psprintf(r->pool,cuwa_portal_error_page,status,reason,code,emsg,detail,log);
    return permit_send_page(r, status, html);
}

static int permit_parse_args(request_rec *r, apr_table_t *args_in, char *args)
{
    char *name;
    char *val;

    cuwa_portal_log(r, r->pool, "Command arguments...");
    name = args;
    val = strchr(name,'=');
    while(val)
    {
        *val++=0;
        args = strchr(val,'&');
        if (args) *args++=0;
        if (strlen(val)>1 && *val=='"')
        {
            val++;
            val[strlen(val)-1]=0;
        }

        cuwa_portal_log(r, r->pool, "Name: %s Value: %s",name,val);
        apr_table_add(args_in,name,val);

        if (!args) break;
        name = args;
        val = strchr(name,'=');
    }
    return 0;
}

// permit_portal_handler...
// Handles either POST or GET, authenticated or anonymous.
// Command arguments can be in POST data or in the URI args
// Either case, same format arg1name=arg1val&arg2name=arg2val...
// Authenticated requests have a single argument WA=wacred
// Parse credential has argument string in it's authenticator, same format as above.
static int permit_portal_handler(request_rec *r)
{
    int code = 0, status = 0;
    cuwa_cred_t *cred = NULL;
    char *netid = NULL;
    char *fullid = NULL;
    char *args = "";
    char *msg = "", *audit;
    apr_table_t *args_in=NULL;
    CUWACfg_t *cfg = ap_get_module_config(r->per_dir_config, cuwa_module);

    if ( !r->handler || strcmp(r->handler, "cuwa_permit") ) return DECLINED;
    if ( r->method_number != M_GET && r->method_number != M_POST) return HTTP_METHOD_NOT_ALLOWED;

    cuwa_log_apache_set_keys(r,r->server,r->connection);
    cuwa_malloc_set_pool(r->pool);

    if ( r->method_number == M_GET )
    {
          if (!r->parsed_uri.query) args = "";
          else args = apr_pstrdup( r->pool, r->parsed_uri.query );
          if (ap_unescape_url(args)!=OK) cuwa_portal_log(r,r->pool,"Bad URL: %s", r->parsed_uri.query);
    }
    else
    {
        // Read the POST data
        code = ap_setup_client_block(r, REQUEST_CHUNKED_ERROR);
        if (code) PERMIT_ERR("Error processing post data");

        if (ap_should_client_block(r))
        {
            char buf[POST_BLOCK+1];
            int len_read;

            cuwa_portal_log(r,r->pool,"read post: %d bytes",r->remaining);

            // Maybe we should add a limit to the size of POST allowed to be read
            while ((len_read = ap_get_client_block(r, buf, POST_BLOCK)) > 0)
            {
                buf[len_read] = 0;
                args = apr_pstrcat(r->pool,args,buf,NULL);
                if (!args) PERMIT_ERR("Not enough memory");
                cuwa_portal_log(r,r->pool,"read bytes: %d",len_read);
                if (len_read==r->remaining) break;     // I think this compensates for a bug in ap_get_client_block
            }
        }
    }


    // Authenticated?
    if (strncmp(args,"WA=",3)==0)
    {
        args += 3;
        code = cuwa_cred_parse( r->pool, &cred, args, strlen(args), CFG_CUWAKerberosPrincipal(cfg),
                                CFG_CUWAKeytab(cfg), NULL, NULL );
        if (code) PERMIT_ERR("Error processing credential");

        args   = cuwa_cred_get_attribute( cred, "CUWA_T1", 0);
        netid  = cuwa_cred_get_attribute( cred, "REMOTE_USER", 0);
        fullid = cuwa_cred_get_attribute( cred, "CUWA_FULL_USER", 0);
        cuwa_trace("ARGS: %s",args);
    }
    audit = apr_psprintf(r->pool,"%s,%s", fullid,args);

    apr_table_set(r->notes, "Permit-Audit",audit);

    args_in = apr_table_make(r->pool,5);
    if (!args_in) PERMIT_ERR("Not enough memory");

    code = permit_parse_args(r,args_in,args);
    if (code) PERMIT_ERR("Error processing args");

    code = permit_command(r,netid,fullid,args_in,&args);
    if (code) PERMIT_ERR("Error processing command");

    if (cred)
    {
        // wrap the response...
        int size, wrapLen;
        char *wrap;
        kutil_sec_ctx_t ctx = (kutil_sec_ctx_t) cuwa_cred_get_context( cred, CUWA_CRED_CTX_GSS, 0 );

        code = kutil_wrap(ctx, args, strlen(args), &wrap, &wrapLen);
        if (code) PERMIT_ERR("Error: GSS wrap failed");

        size = cuwa_base64_encode_bytes( wrapLen );
        args = apr_pcalloc(r->pool,size+strlen(WRAP_LABEL)+1);
        strcpy(args,WRAP_LABEL);
        cuwa_base64_encode( wrap, wrapLen, &args[strlen(WRAP_LABEL)]);

        kutil_release_buffer( wrap, wrapLen );
    }

cleanup:

    permit_log_event(r->pool,netid,args_in,status,code);

    if (cred) cuwa_cred_release( cred );

    if (status) return permit_error_response(r,status,code,msg);

    return permit_send_page(r, 200, args);
}


void *permit_create_dir_config(apr_pool_t *p, char *dir)
{
    return(CUWACfg_t *) apr_pcalloc(p, sizeof(CUWACfg_t));
}

void *permit_create_server_config(apr_pool_t *p, server_rec *s)
{
    return(CUWACfg_t *) apr_pcalloc(p, sizeof(CUWACfg_t));
}


void *permit_merge_dir_config(apr_pool_t *p, void *base_conf, void *new_conf)
{
    return cuwa_merge_config(p,(CUWACfg_t *)base_conf,(CUWACfg_t *)new_conf);
}


void *permit_merge_server_config(apr_pool_t *p, void *base_conf, void *new_conf)
{
    return cuwa_merge_config(p,(CUWACfg_t *)base_conf,(CUWACfg_t *)new_conf);
}

static int permit_post_config(apr_pool_t *p, apr_pool_t *plog, apr_pool_t *ptemp, server_rec *s)
{
    void *data = NULL;
    const char *userdata_key = "shm_cuwa_post_config";
    int rc = OK;
    server_rec *base = s;

    cuwa_log_apache_init(p);
    cuwa_malloc_init(p);
    cuwa_log_apache_set_keys(NULL,base,NULL);

    // First pass, check checking the configuration.
    // Second pass, announce the module.
    apr_pool_userdata_get(&data, userdata_key, s->process->pool);
    if (data == NULL)
    {
        /* First Pass */
        apr_pool_userdata_set((const void *)1, userdata_key, apr_pool_cleanup_null, s->process->pool);

        // Validate the config here...

        return rc;
    }

    // We're up and running, announce mod_permit version...

    ap_log_error(APLOG_MARK, APLOG_NOERRNO|APLOG_EMERG,0,s,"mod_permit version .1");

    return rc;
}

static void permit_init_child(apr_pool_t *p, server_rec *s)
{
    cuwa_err_t  rc;
    CUWACfg_t *cfg = ap_get_module_config(s->module_config, cuwa_module);

    cuwa_rand_init_g();

    rc = cuwa_log_apache_init(p);
    if (rc)
    {
        ap_log_error(APLOG_MARK, APLOG_NOERRNO|APLOG_INFO,0,s,"Error initializing logging: %d",rc);
    }

    cuwa_log_apache_set_keys(NULL,s,NULL);
    cuwa_malloc_set_pool(p);

    rc = permit_command_init(CFG_PermitDBPath(cfg));
    if (rc)
    {
        ap_log_error(APLOG_MARK, APLOG_NOERRNO|APLOG_INFO,0,s,"Error initializing database: %d",rc);
    }
}

static void permit_register_hooks(apr_pool_t *p)
{
    ap_hook_handler(permit_portal_handler, NULL, NULL, APR_HOOK_MIDDLE);
    ap_hook_post_config(permit_post_config,NULL,NULL,APR_HOOK_MIDDLE);
    ap_hook_child_init(permit_init_child,NULL,NULL,APR_HOOK_MIDDLE);
}

module AP_MODULE_DECLARE_DATA permit_module =
{
    STANDARD20_MODULE_STUFF,
    permit_create_dir_config,
    permit_merge_dir_config,
    permit_create_server_config,
    permit_merge_server_config,
    cuwa2_cmds,
    permit_register_hooks
};


