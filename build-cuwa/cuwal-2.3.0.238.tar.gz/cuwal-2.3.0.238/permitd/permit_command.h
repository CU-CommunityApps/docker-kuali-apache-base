/************************************************************************
 * permit_command.h -- Handle permit commands
 *
 * Copyright 2008 Cornell University.
 * All Rights Reserved.
 *
 ************************************************************************
 *  $Log: permit_command.h,v $
 *  Revision 1.7  2010/01/22 16:09:07  hy93
 *  fix huge memory consumption when there are many entries in return result
 *
 *  Revision 1.6  2008/10/01 14:35:14  pb10
 *  removed wal dependency.
 *
 *  Revision 1.5  2008/10/01 14:19:50  pb10
 *  Add listpermit support.
 *
 *  Revision 1.4  2008/09/23 09:05:53  pb10
 *  Fixed config.  Added initialization and DB path.
 *
 *  Revision 1.3  2008/09/23 03:12:32  pb10
 *  Fix indenting and lineend.
 *
 *  Revision 1.2  2008/09/22 19:45:56  pb10
 *  Adding support for getpermit function.
 *
 ************************************************************************
 */

#ifndef _PERMIT_COMMAND_H
#define _PERMIT_COMMAND_H


#include <http_request.h>
#include <apr_tables.h>
#include <apr_pools.h>

int permit_command(request_rec *r, char *netid, char *fullid, apr_table_t *args_in, char **args_out);
int permit_error_response(request_rec *r, short status, int code, const char *fmt, ... );
void cuwa_portal_log(request_rec *r, apr_pool_t *pool, const char *fmt, ... );
int permit_command_init(char *path);

#endif
