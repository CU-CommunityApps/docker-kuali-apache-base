/*
permitdb.h -- Permit server database routine headers

Copyright 1996 Mandarin Consortium, Inc. All rights reserved.
*/

/********************************************************************
 * $Log: permitdb.h,v $
 * Revision 1.6  2010/01/26 19:34:43  hy93
 * fix possible buffer overflow when listing netids in a pemit
 *
 * Revision 1.5  2008/09/23 09:05:53  pb10
 * Fixed config.  Added initialization and DB path.
 *
 * Revision 1.4  2008/09/23 03:16:45  pb10
 * Fix brain-dead CVS log tags.
 *
 * Revision 1.3  2008/09/23 03:12:32  pb10
 * Fix indenting and lineend.
 *
 * Revision 1.2  2008/09/23 03:07:53  pb10
 * Compiles.
 *
 * Revision 1.1  2008/09/22 19:45:56  pb10
 * Adding support for getpermit function.
 *
 * Revision 1.2  2006/06/26 18:01:40  se10
 * Now does Solaris clusters!
 *
 * Revision 2.0  96/02/06  17:36:47  laurie
 * *** empty log message ***
 *
*********************************************************************/

#ifndef __PERMITDB__
#define __PERMITDB__

#include <gdbm.h>			/* this host has ndbm */

/* databases live in PERMITDIR specified in permitd.c */
/* filenames shouldn't be longer than FILENAME_MAX (stdio.h) */
#define IDDBNAME		 "netid_db"
#define IDLOCKFILE  	 "netid_db.lock"
#define PDDBNAME		 "pdinfo_db"
#define PDLOCKFILE  	 "pdinfo_db.lock"
#define CROSSDBNAME	 "cross_index"
#define CROSSLOCKFILE "cross_index.lock"
#define LARGELISTS    "largelists/"     // subdirectory for largelists

#define DBM_MAXLEN 30000 /* orig 997 */
#define PNAMELEN		128
#define MAXIDLEN		 50
#define ID_ACLLEN 	512	
#define PD_ACLLEN 	128	
#define INFOLEN		128

#define GDBM_BLOCK_SIZE 1024

/* permit descriptor database contains the permit description
 * - key = permit name
 * - record = PdInfo	struct
 * - dbm restricts size of record to 1024 (for Solaris (and AIX?)), but gdbm rocks!
*/

#include <sys/time.h>
#include <stdio.h>

enum pErr
{
    pSuccess, pGeneralError, pNoSuchPermitName, pNoPermit,
    pIdRevoked, pMissingParms, pObsolete1, pObsolete2, pSenderNoLookup,
    pSenderNoUpdate, pSenderNoAdmin, pSenderNoOwner, pSenderNoMaster,
    pBadNetID, pInfoTooLong, pBadAclCode, pBadModeCode, pInvalidPermitName,
    pPermitExists, pReplaceFailed, pNoSlaveUpdate, pCusspLibErr,
    pBadAuthenticator, pPermitExpired, pBadLogFile, pBulkRunning,
    pDbOpenErr, pDbReadErr, pDbWriteErr,pNoMem,
    pNumErrMsgs
};

enum
{ /* access privileges */
    allowNothing, allowLookup, allowUpdate, allowAdmin, allowOwner, allowMaster
};

#define MASTERPERMIT "master"
#define true 1
#define false 0

struct PdInfo
{
    char pName[PNAMELEN];        /* permit name */
    short pKey;                     /* unique number */
    char friendlyName[PNAMELEN]; /* english translation */
    char owner[MAXIDLEN];        /* permit owner */
    int   public;                   /* anyone can look at permits */
    int   visible;                     /* include in permit list */
    int largeList;                  /* don't store in reverse index */
    char idLookupACL[ID_ACLLEN]; /* lookup ID permits */
    char idUpdateACL[ID_ACLLEN]; /* update ID permits */
    char pdAdminACL[PD_ACLLEN];  /* update permit descriptor */
    time_t created;                /* when permit descriptor created */
    time_t modified;            /* when permit descriptor last modified */
    time_t cut_off;              /* permits older than this date are expired */
};
typedef struct PdInfo PdInfo, *PdInfoPtr;

/*  NetID's database contains permits
 * - key = netid_pKey   (netid to permit mapping)
 * - record = PermitInfo
*/
struct PermitInfo
{
    int numPermits;            /* how many ways a person has been authorized */
    int revoked;               /* yes or no */
    time_t created;            /* time created */
    time_t modified;           /* time last modified */
    time_t expire;             /* time scheduled to expire */
    char userInfo[INFOLEN];    /* service provider space */
};
typedef struct PermitInfo PermitInfo, *PermitInfoPtr;


/* reverse index databases are re-created periodically to
   preserve data integrity (sse: Huh?) */

/*  reverse index permit descriptor database contains lists of netid's
 *  large lists not stored (>32,000 ID's) but generated on the fly
 * - key = permit name
 * - record = list of netids (IDlist[4k])
*/

/*  reverse index netid's database contains lists of permits
 * - key = netids
 * - record = list of pKey (pKey[4k])
*/

// int InitializeDb() ;
void SetIdKey (char *, char *, short) ;
int DbGetPdInfo (char *, PdInfo **) ;
int LoadPdInfoList (void) ;
PdInfoPtr GetPdInfoFromName (char *) ;
PdInfoPtr GetPdInfoFromKey (short) ;
int ResetLargeLists (void) ;
int StoreLargeList (char *, char *) ;
int DbGetPermit (char *, PdInfo *, char *, char *, char *, char *, char *, char *);
int DbAddPermit (char *, PdInfo *, int) ;
int DbChangePermit(char *netID, PdInfo *, char *) ;
int DbDeletePermit (char *, PdInfo *) ;
int DbRevokePermit (char *, PdInfo *, unsigned char) ;
int DbListPermits(char *, char *, char *, short, char *) ;
int DbRemoveNetID (char *, char *) ;
int DbGetPermitList (char *, short, PdInfo *, char **, FILE **) ;
char * DbShowFriendly (PdInfo *) ;
char * DbShowOwner (PdInfo *) ;
char * DbShowMode (PdInfo *, char *) ;
char * DbShowAcl (PdInfo *, char *) ;
int DbCreatePdInfo (PdInfo *, char *) ;
int DbRemovePermits (PdInfo *, int) ;
int DbChangeOwner (PdInfo *, char *) ;
int DbChangeFriendly (PdInfo *, char *) ;
int DbChangeAcl (PdInfo *, char *, char *, int) ;
int DbChangeMode (PdInfo *, short, int) ;

void CrossIndexPermitDescriptor (GDBM_FILE, PdInfo *) ;
int SenderAccess (char *, PdInfo *) ;
int DbChCutOff (PdInfo *, time_t *) ;
int DbChFriendly (PdInfo *, char *) ;
int CrossIndexAdd(GDBM_FILE, char *, char *, int);
void TouchDbFile (char *, char *, int);
int GetPermitMaster (void) ;
int DbSetPath(char *path);

#endif /*__PERMITDB__*/

