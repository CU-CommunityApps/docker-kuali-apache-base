/************************************************************************

 * session.c -- session manager for CUWebAuth
 *
 * Copyright 2007 Cornell University.
 * All Rights Reserved.
 *
 ************************************************************************
 *  $Log: session.c,v $
 *  Revision 1.107  2015/10/07 17:38:20  hy93
 *  merge TwoFactor treee to the head
 *
 *  Revision 1.106.2.10  2015/10/01 15:59:49  hy93
 *  fix permit is not saved in session cache when looked up during authorization stage
 *
 *  Revision 1.106.2.9  2015/08/04 19:43:00  hy93
 *  fix misspell
 *
 *  Revision 1.106.2.8  2015/06/08 13:44:19  hy93
 *  remove error log for CUWA_ERR_SESSION_NO_DUAL
 *
 *  Revision 1.106.2.7  2015/04/28 16:42:54  hy93
 *  check optin permit
 *
 *  Revision 1.106.2.6  2015/04/24 21:19:12  hy93
 *  user full user when doing permit lookup
 *
 *  Revision 1.106.2.5  2015/04/23 15:03:30  hy93
 *  remove parameter that is not being used
 *
 *  Revision 1.106.2.4  2015/03/09 14:25:53  hy93
 *  fix variable dualAuthTime is not initialized
 *
 *  Revision 1.106.2.3  2015/01/29 19:25:06  hy93
 *  change CUWAdualAuth to CUWA2FARequire and CUWAdualMethod to CUWA2FAMethod
 *
 *  Revision 1.106.2.2  2015/01/29 15:54:36  hy93
 *  remove using signature for validating 2F token, remove opt-in support
 *
 *  Revision 1.106.2.1  2014/10/22 19:51:52  hy93
 *  add two factor support
 *
 *  Revision 1.106  2014/10/22 16:41:41  hy93
 *  remove two factor support
 *
 *  Revision 1.105  2014/10/21 17:55:05  hy93
 *  support multiple dual method
 *
 *  Revision 1.104  2014/07/25 17:04:58  hy93
 *  save weblogin server url to the request. Verify d1 signature
 *
 *  Revision 1.103  2013/11/22 19:14:48  hy93
 *  verify if user opt in for two factor
 *
 *  Revision 1.102  2013/11/12 19:04:26  hy93
 *  use dualAuthTime when available to calculate credentialAge
 *
 *  Revision 1.101  2013/10/10 14:07:33  hy93
 *  load permit cache so permit checking can check cache first
 *
 *  Revision 1.100  2013/09/27 18:17:52  hy93
 *  calculate time spent on two factor even when cuwebauth doesn't require two factor because we support user opt in
 *
 *  Revision 1.99  2013/08/06 18:28:45  hy93
 *  verify the two factor vendor if CUWAdualMethod is defined
 *
 *  Revision 1.98  2013/07/31 16:00:06  hy93
 *  fix data in CFG_CUWAdualAuth got changed
 *
 *  Revision 1.97  2013/07/30 19:16:26  hy93
 *  Two factor authentication support
 *
 *  Revision 1.96  2013/02/25 16:28:27  hy93
 *  backout debugging code in previous two check in
 *
 *  Revision 1.95  2013/02/25 14:51:12  hy93
 *  debugging code, will remove later
 *
 *  Revision 1.94  2013/02/23 12:47:30  hy93
 *  add log message to troubleshoot access deny error when updating primary session file
 *
 *  Revision 1.93  2013/02/15 15:47:01  hy93
 *  return session not found error to force a new session to be created if the version of the session file is different than the version that current cuwebauth supported
 *
 *  Revision 1.92  2012/03/19 15:27:17  hy93
 *  remove cuwa_session_check_session_path because functionality has been moved to cuwa_check_sessionfilepath
 *
 *  Revision 1.91  2012/03/19 14:08:57  hy93
 *  change log messages
 *
 *  Revision 1.90  2011/08/02 16:19:03  hy93
 *  write/read proxyCookiesTable to/from disk
 *
 *  Revision 1.89  2011/08/01 04:18:06  pb10
 *  Add allCookies feature to proxy portal.
 *
 *  Revision 1.88  2010/12/23 19:47:31  hy93
 *  add warning in log when cuwebauth can't do garbage collection
 *
 *  Revision 1.87  2009/07/06 14:31:33  hy93
 *  Fix large post data encryption error
 *
 *  Revision 1.86  2009/06/12 20:17:03  pb10
 *  AD / IIS integration, add DuplicateHandle support.
 *
 *  Revision 1.85  2009/06/10 20:17:18  pb10
 *  Remove compiler warnings.
 *
 *  Revision 1.84  2009/04/22 18:26:37  hy93
 *  replace %qX with %llX in cuwa_trace
 *
 *  Revision 1.83  2009/04/21 12:57:24  hy93
 *  Fix file not closed
 *
 *  Revision 1.82  2009/04/20 16:58:14  hy93
 *  encryption support
 *
 *
 *  Revision 1.80  2009/01/27 16:23:47  hy93
 *  Use session endtime to set the expiration time of use File when inactivityTimeout is set to 0. This will avoid session get removed during garbage collection
 *
 *  Revision 1.79  2008/10/10 16:03:16  hy93
 *  fix session cause cred assert when cuwa_cred_parse failed
 *
 *  Revision 1.78  2008/10/03 17:19:04  hy93
 *  comment out not very useful log message
 *
 *  Revision 1.77  2008/09/19 03:52:25  pb10
 *  Always check CUWACredAge against start_time and auth_time (not just when processing login cred).
 *
 *  Revision 1.76  2008/09/16 19:19:37  hy93
 *  add static to functions that are internal in the file
 *
 *  Revision 1.75  2008/09/10 14:40:00  hy93
 *  fix inactivityTimeout doesn't work sometime
 *
 *  Revision 1.74  2008/09/10 02:49:13  hy93
 *  fix inactivityTimeout doesn't display correctly in log
 *
 *  Revision 1.73  2008/09/07 19:35:01  gbr4
 *  rename rand.[ch] to cuwarand.[ch]. Too many packages have a rand.h and some versions of libtool grab the wrong one. This fixes builds against debian 4.0r4.
 *
 *  Revision 1.72  2008/08/27 13:23:20  hy93
 *  Relaced the code with CUWA_SESSION_WRITE_NUM and CUWA_SESSION_READ_NUM macro
 *
 *  Revision 1.71  2008/08/26 19:53:40  hy93
 *  fix compiler warning on windows
 *
 *  Revision 1.70  2008/08/20 14:08:58  gbr4
 *  change all occurances of %llx and %qx to $llX and %qX respectively.
 *
 *  Revision 1.69  2008/08/20 13:50:34  hy93
 *  should rename file before release session
 *
 *  Revision 1.68  2008/08/19 19:58:29  hy93
 *  garbage collection enhancement
 *
 *  Revision 1.67  2008/08/17 16:34:04  pb10
 *  Removed session->k3.
 *
 *  Revision 1.66  2008/08/17 14:18:03  pb10
 *  Remove unused code from session manager and cred manager.
 *
 *  Revision 1.65  2008/08/15 04:49:26  pb10
 *  Added table based attribute support to session code.
 *  Still need to put support into auth.c and lastly need to remove old code from everywhere.
 *
 *  Revision 1.64  2008/08/12 20:34:40  pb10
 *  Convert cred manager interface to use apr_table to transfer credential attributes.
 *  Also supporting the old interface to keep things working while I update  session
 *  manager and auth code.
 *
 *  Revision 1.63  2008/08/11 04:31:56  hy93
 *  add the flag so proxy cookie can be saved to cache
 *
 *  Revision 1.62  2008/08/11 04:07:15  hy93
 *  delegation support
 *
 *  Revision 1.61  2008/08/09 01:16:49  pb10
 *  Support listPermit call (CUWAInquire permit all).
 *
 *  Revision 1.60  2008/08/04 18:18:41  gbr4
 *  CUWAPortal for permits is now working. handler is cuwa_permit, see t10portal_permit.t test case.
 *
 *  autoconf infrastructure now supports APR_INSTALLBUILDDIR and APR_VERSION to support permit makefile. permit makefile modified to remove hard coded path.
 *
 *  Revision 1.59  2008/08/04 16:05:36  hy93
 *  move some code from cuwa_permit_lookup to session
 *
 *  Revision 1.58  2008/08/04 14:41:50  hy93
 *  add protection in case there is no session
 *
 *  Revision 1.57  2008/08/01 16:56:18  hy93
 *  free kerberos session after permit call
 *
 *  Revision 1.56  2008/07/28 17:18:44  hy93
 *  set CUWA_SID  in notes
 *
 *  Revision 1.55  2008/07/28 16:44:01  hy93
 *  change log message
 *
 *  Revision 1.54  2008/07/28 15:30:37  hy93
 *  fix the problem with checking error code when file doesn't exist
 *
 *  Revision 1.53  2008/07/25 18:57:54  hy93
 *  permit cache support
 *
 *  Revision 1.52  2008/07/18 16:07:40  hy93
 *  fix previous check in caused compiler error on windows
 *
 *  Revision 1.51  2008/07/16 16:33:26  hy93
 *  fix previous check in cause segfault on Solaris
 *
 *  Revision 1.50  2008/07/16 14:12:01  hy93
 *  delegation support
 *
 *  Revision 1.49  2008/06/06 17:26:51  hy93
 *  prevent replay wa
 *
 *  Revision 1.48  2008/06/02 14:07:46  hy93
 *  add store session cache version
 *
 *  Revision 1.47  2008/06/02 01:44:20  pb10
 *  Add starttime and endtime to fields being hacked out of GSS credential with
 *  KRB5 calls.  The starttime is being used by session manager to support
 *  cred age test... too old = starttime-authtime > CUWACredentialAge
 *
 *  Revision 1.46  2008/05/30 20:01:52  hy93
 *  remove un-used replay related code
 *
 *  Revision 1.45  2008/05/20 17:02:22  hy93
 *  use APR macro to check if file not exist
 *
 *  Revision 1.44  2008/05/08 15:48:24  hy93
 *  fix compiler warning
 *
 *  Revision 1.43  2008/05/06 14:26:05  hy93
 *  Add checking if session is NULL in session_to_cookie
 *
 *  Revision 1.42  2008/05/05 20:09:36  gbr4
 *  more asserts moved to before use. also fix a typo in weblogin (srv not svr)
 *
 *  Revision 1.41  2008/05/05 19:50:55  gbr4
 *  fix a couple places where pointers were dereferenced and then checked for NULL
 *
 *  Revision 1.40  2008/04/29 13:33:27  hy93
 *  fix warning regarding assignment differ in signedness
 *
 *  Revision 1.39  2008/04/19 14:21:27  pb10
 *  Convert malloc's to APR allocations.
 *
 *  Revision 1.38  2008/04/18 04:17:34  pb10
 *  Add replayed file to track when the request has been replayed. This is done
 *  to avoid replaying the request multiple times (very bad with POST).
 *
 *  Revision 1.37  2008/04/14 18:17:43  gbr4
 *  change %llX to %qd to try to fix win32
 *
 *  Revision 1.36  2008/04/14 17:25:10  hy93
 *  add checking for session file path
 *
 *  Revision 1.35  2008/04/14 15:53:12  hy93
 *  Allow inactivityTimeout to accept 0
 *
 *  Revision 1.34  2008/04/14 04:12:36  pb10
 *  Fix CUWACredentialAge to only check age on initial website page hit.  CUWACrentialDefaultAge obsolete.
 *
 *  Revision 1.33  2008/04/10 23:08:06  gbr4
 *  fixed all *compile* errors under msvc9.0 (studio 2008). Still has link errors
 *  and tons of warnings. This might cause regressions.
 *
 *  Revision 1.32  2008/04/04 02:30:43  gbr4
 *  quiet some of the warnings. No functional changes
 *
 *  Revision 1.31  2008/04/02 20:12:23  hy93
 *  change the return error code
 *
 *  Revision 1.30  2008/03/28 16:04:50  hy93
 *  release session if session_from_credential failed
 *
 *  Revision 1.29  2008/03/24 21:32:22  pb10
 *  Better error page support.
 *
 *  Revision 1.28  2008/03/24 19:04:44  hy93
 *  Set the modified timestamp of session use file to be the time that session expires based on inactivityTimeout if it is defined
 *
 *  Revision 1.27  2008/03/21 19:39:39  hy93
 *  save some data in session so we don't need to get them over and over again
 *
 *  Revision 1.26  2008/03/20 20:36:36  hy93
 *  Don't need to restore session in session_from_sessionid
 *
 *  Revision 1.25  2008/03/19 20:30:12  pb10
 *  Moved weblogin credential parsing from the filter to mod_cuwebauth.c so that
 *  kerberos directives could be based on virtual host.
 *
 *  Revision 1.24  2008/03/19 16:37:19  hy93
 *  remove show_apr_error function
 *
 *  Revision 1.23  2008/03/11 17:57:14  hy93
 *  When error occur, set flag save so we can delete the session during session flush
 *
 *  Revision 1.21  2008/03/11 12:58:39  hy93
 *  session should be only cleared during session release
 *
 *  Revision 1.20  2008/03/10 18:17:39  hy93
 *  support garbage collection on session cache files
 *
 *  Revision 1.19  2008/02/25 19:44:18  hy93
 *  support CUWAmaxSessionSize
 *
 *  Revision 1.18  2008/01/29 18:05:53  hy93
 *  change the display of sessionID to hex in log
 *
 *  Revision 1.17  2008/01/25 13:56:32  hy93
 *  fix buffer overflow in READ_STRING
 *
 *  Revision 1.16  2008/01/25 01:43:47  gbr4
 *  Added an ID string to every file
 *
 *  Revision 1.15  2008/01/21 19:43:21  hy93
 *  prefix session files to increase session cache security
 *
 *  Revision 1.14  2008/01/18 21:21:19  hy93
 *  remove memset in session clear
 *
 *  Revision 1.13  2008/01/18 18:50:38  hy93
 *  retrun error status when session is not in correct state
 *
 *  Revision 1.12  2008/01/18 17:12:00  hy93
 *  fix session state read incorrect from file
 *
 *  Revision 1.11  2008/01/15 14:48:22  hy93
 *  Fix compiler warning.
 *
 *  Revision 1.10  2008/01/15 13:56:38  hy93
 *  Add inactivityTimeout support
 *
 *  Revision 1.9  2008/01/14 16:08:36  hy93
 *  use cuwa_rand64_g() to generate random number and other changes.
 *
 *  Revision 1.8  2008/01/13 21:27:10  pb10
 *  Lowercase CUWA2_LOG_DOMAIN setting.
 *
 *  Revision 1.7  2008/01/10 17:48:49  hy93
 *  Modified code that get configuration for sessionTimeout and sessionFilePath. Modified some of the code to use apr function to duplicate string.
 *
 *  Revision 1.6  2008/01/02 04:36:04  pb10
 *  Added flush function, fixed compiler warnings, adjusted to change to k2 token calls.
 *
 *  Revision 1.5  2007/12/21 19:49:53  hy93
 *  change the call to make_c0
 *
 *  Revision 1.4  2007/12/21 19:27:38  hy93
 *  Modified functions because of cuwa_session_t changes
 *
 *  Revision 1.3  2007/12/17 18:44:34  hy93
 *  Modified functions because of the change of pool
 *
 *  Revision 1.2  2007/12/11 18:29:08  hy93
 *  no message
 *
 *  Revision 1.1  2007/12/05 19:02:22  hy93
 *  no message
 *
 ************************************************************************

 */
#include <session.h>
#include <stdlib.h>
#include <stdio.h>
#include <cred.h>
#include <cred_getput.h>
#include <cred_session.h>
#include <cred_base64.h>
#include <log.h>
#include <cuwarand.h>
#include <apr_strings.h>
#include <cuwa_malloc.h>
#include <kutil.h>
#include <wal.h>
#include <cuwa_parse.h>
#include <session_file.h>
#include <sha1.h>
#include <sys/types.h>
#include <sspiutil.h>
#include <permit_cache.h>
#include <util.h>
#include <cred_krb.h>
#include <highAvail.h>

#include "../autoconfig.h"
#ifdef HAVE_UNISTD_H
#include <unistd.h>
#endif
#define CUWA2_LOG_DOMAIN cuwa.session

#define CUWA_SESSION_HEADER "#!/bin/cat\n"
#define DEFAULT_FORCE_TIME 60*5 /* 5 minute credential age */

#define CUWA_SESSION_VERSION "2.0"

#define CUWA_SESSION_SID   "CUWA_SID"
#define CUWA_TWO_FACTOR_OPT_IN "CIT-optin-twofactor"

#define CUWA_SESSION_READ_HEADER(pFile) do {                           \
 apr_size_t len = strlen(CUWA_SESSION_HEADER);                         \
 char *header = cuwa_malloc(len);                                      \
 apr_status_t rv;                                                      \
 cuwa_assert(header);                                                  \
 rv = apr_file_read(pFile, header, &len);                              \
 cuwa_free(header);                                                    \
 FAIL_IF_FILE_ERROR( rv );                                             \
 }while(0)

static cuwa_err_t cuwa_session_flush( cuwa_session_t *session );

/**
 * cuwa_session_get_inactivity_timeout return inactivity timeout value.
 * Internal function
 */
static int cuwa_session_get_inactivity_timeout(CUWACfg_t *cfg)
{
    int *timeout = NULL;
    int inactivityTimeout = -1;

    cuwa_trace("In cuwa_session_get_inactivity_timeout");

    timeout =  CFG_CUWAinactivityTimeout(cfg);
    if ( timeout )
    {
        inactivityTimeout = *timeout;
    }
    cuwa_trace("cuwa_session_get_inactivity_timeout return %d", inactivityTimeout);

    return inactivityTimeout;
}

/**
 * cuwa_session_get_max_session_size return maximum session size value.
 * Internal function
 */
static int cuwa_session_get_max_session_size(CUWACfg_t *cfg)
{
    int *maxSessionSize = NULL;
    int size = 0;

    cuwa_assert(cfg);

    maxSessionSize =  CFG_CUWAmaxSessionSize(cfg);
    if ( maxSessionSize )
    {
        size = (*maxSessionSize);        //max session size is in bytes
    }

    return size;
}

/**
 * cuwa_session_get_use_primary_file_name allocate memory and return .pri filename for session
 * INTERNAL to session manager
 * @param[in] pool used for memory allocation.
 * @param[in] path session file name
 * @param[out] fileName.
 */
void cuwa_session_get_primary_file_name( apr_pool_t *pool, char *path, char **fileName )
{
    *fileName = apr_psprintf(pool,"%s.%s", path,"pri");
}

static cuwa_err_t cuwa_session_hash_sid( cuwa_session_t *session, uint64 *newSid )
{
    cuwa_err_t sts = CUWA_OK;
    char *sidStr = apr_psprintf(session->pool, "%16qX", session->sessionID);
    SHA1Context ctx;

    SHA1Reset(&ctx);

    SHA1Input(&ctx,(unsigned char*)"3.14159265358",12);
    SHA1Input(&ctx,(unsigned char*)sidStr,16);
    SHA1Input(&ctx,(unsigned char*)"1.4142135623",12);

    if(!SHA1Result(&ctx)) 
    {
        cuwa_warning("hash sid failed");
        sts = CUWA_ERR_SESSION_SHA1;
    }
    else
        *newSid = ((((apr_uint64_t)(ctx.Message_Digest[0])) << 32) | ((apr_uint64_t)(ctx.Message_Digest[1])));
    
    cuwa_trace("hashed sid=%llX",*newSid); 
    return sts;
}


/**
 * cuwa_session_get_session_file_path return the file name for primary session including path.
 * if CUWASessionPath is not defined, session file will be stored in default directory
 * Internal function.
 */
cuwa_err_t cuwa_session_get_session_file_path(char **pathOut, cuwa_session_t *session, int idToUse)
{
    char *filename = NULL;
    char *path;
    cuwa_err_t sts = CUWA_OK;
 
    //determin where the session files should store
    filename =  CFG_CUWAsessionFilePath(session->cfg);
    if ( filename )
    {
         path = apr_psprintf( session->pool, "%s", filename);
    }
    //if CUWASessionPath is not defined, write session file to /tmp
    else
    {
        cuwa_trace("CUWASessionPath is not defined, use tmp directory");
        cuwa_assert(session->pool);
        path = apr_psprintf( session->pool, "%s",CUWA_SESSION_DEFAULT_PATH);
    }
    if ( (idToUse == CUWA_SESSION_FILE_UNKNOWN ) ||
         (idToUse == CUWA_SESSION_FILE_SESSION_ID ) )
    {
        *pathOut = apr_psprintf(session->pool, "%s/%qX", path,session->sessionID );

        session->encrypt = CUWA_SESSION_ENCRYPTION_NO;
        if ( idToUse == CUWA_SESSION_FILE_UNKNOWN )
        {
            apr_status_t code;
            char *priFile;
            apr_finfo_t  finfo; 
 
            cuwa_session_get_primary_file_name( session->pool, *pathOut, &priFile );

            //check if session file using sessionID exist on disk. If not, hash file name to check
            code = apr_stat(&finfo, priFile,APR_FINFO_SIZE|APR_FINFO_LINK, session->pool);
            if ( code )
                idToUse = CUWA_SESSION_FILE_ENCRYPTED_ID;
        } 
    }           

    if ( idToUse == CUWA_SESSION_FILE_ENCRYPTED_ID )
    {
        uint64 newId = 0;

        sts = cuwa_session_hash_sid( session, &newId );

        if ( sts == CUWA_OK )
        {
            *pathOut = apr_psprintf( session->pool, "%s/%qX", path, newId);
  
            session->encrypt = CUWA_SESSION_ENCRYPTION_YES;
        }
    }
   return sts;
}

/**
 * cuwa_session_dump print out the primary session data. This function is for debuging purpose
 *
 * @param[in] session: the session.
 */
static void cuwa_session_dump( cuwa_session_t *session )
{
    if ( session )
    {
        cuwa_trace("***** dumping session data *****");
        cuwa_trace("sessionID: 0x%llX", session->sessionID );
        cuwa_trace("sessionKey:0x%llX", session->sessionKey );
        cuwa_trace("State: %d", session->state );
        cuwa_trace("End time:%u", (int)session->endTime );
        {
            // Had to put this code in to satisfy the test harness :-)
            char *k3 = cuwa_session_get_attribute(session,"CUWA_K3",0)
            if ( k3) cuwa_trace("k3:%s", k3);
        }

        if ( session->permitList )
            cuwa_trace("CachedPermits:%s", session->permitList);

        if ( session->proxyTable )
        {
            //write proxy table
            const apr_array_header_t *arr = apr_table_elts( session->proxyTable);
            const apr_table_entry_t *elts = (const apr_table_entry_t *)arr->elts;
            int i;

            for (i=0; i < arr->nelts; i++ )
            {
                cuwa_trace("write proxy:key=%s,value=%s",elts[i].key,elts[i].val);
            }
        }

        cuwa_trace("***** dump done *****");
   }
}

/**
 * cuwa_session_clear remove all the data in session.
 *
 * @param[in] session: the session.
 * @return NONE
 */
static void cuwa_session_clear( cuwa_session_t *session )
{
    if ( session )
    {

        if (session->cred) cuwa_cred_release( session->cred );

        cuwa_trace("Clear session data");

        session->sessionID = 0;
        session->save = 0;
        session->endTime = 0;
        session->state = 0;
        session->sessionKey = 0;

        if ( session->proxyTable)
        {
            apr_table_clear( session->proxyTable );
            session->proxyTable = NULL;
        }

        if ( session->proxyCookiesTable)                                                                                                            
        {                                                                                                                                    
            apr_table_clear( session->proxyCookiesTable );                                                                                          
            session->proxyCookiesTable = NULL;                                                                                                      
        }  
    }
}

/**
 * cuwa_session_from_file populate data in session field by reading session data from from session file
 *
 * @param[in] session: the session.
 * @return CUWA_OK or CUWA_ERR_MEM CUWA_ERR_SESSION_NOT_FOUND CUWA_ERR_SESSION_DB_ERR
 */
static cuwa_err_t cuwa_session_restore_from_file( cuwa_session_t *session )
{
    apr_status_t rv;
    cuwa_err_t rc = CUWA_OK;
    apr_file_t *pFile = NULL;
    char *version = NULL;

    cuwa_trace("In cuwa_session_restore_from_file");
    rv = apr_file_open( &pFile, session->sessionFile, APR_READ, APR_UREAD|APR_UWRITE, session->pool );
    if ( rv == APR_SUCCESS )
    {
        //read header
        CUWA_SESSION_READ_HEADER( pFile );

        //read session verion
        CUWA_SESSION_READ_STRING( pFile, &version );
        cuwa_trace("read session cache version = %s", version );
    
        //session files that have different version number might have different format, so don't use it  
        FAIL_IF( strcmp(version,CUWA_SESSION_VERSION), CUWA_ERR_SESSION_NOT_FOUND );

        //read session state
        CUWA_SESSION_READ_NUM( pFile, session->state );
        cuwa_trace("read session state return status=%d, state=0x%x", rv, session->state);

        //read key
        CUWA_SESSION_READ_NUM( pFile,session->sessionKey );
        cuwa_trace("read sessionKey, status=%d, key=0x%llX", rv, session->sessionKey);

        //read endTime
        CUWA_SESSION_READ_NUM( pFile, session->endTime );
        cuwa_trace("read session endtime return status=%d, endtime=%u", rv, session->endTime);

        if ( session->state & CUWA_SESSION_ACTIVE )
        {

            if ( session->state & CUWA_SESSION_HAS_PERMIT )
            {
                //read permit list
                CUWA_SESSION_READ_STRING( pFile, &session->permitList );
                cuwa_trace("read session permitList=%s", session->permitList);
            }

            rc = cuwa_session_read_table( session->pool, pFile, &session->proxyTable );
            FAIL_IF(rc,rc);

            rc = cuwa_session_read_table( session->pool, pFile, &session->proxyCookiesTable );
            FAIL_IF(rc,rc);

            rc = cuwa_cred_deserialize( session->pool, &session->cred, pFile );
            FAIL_IF(rc,rc);
        }
        cuwa_session_dump( session );
    }
    else
        rc = CUWA_ERR_SESSION_NOT_FOUND;

cleanup:
    if (pFile)
        apr_file_close(pFile);

    cuwa_trace("cuwa_session_restore_from_file return status %d", rc);
    return rc;
}

/**
 * cuwa_session_get_use_file_name allocate memory and return .use filename for session
 * INTERNAL to session manager
 * @param[in] pool used for memory allocation.
 * @param[in] path session file name
 * @param[out] fileName.
 */
void cuwa_session_get_use_file_name( apr_pool_t *pool, char *path, char **fileName )
{
    *fileName = apr_psprintf(pool,"%s.%s", path,"use");
}

/**
 * cuwa_session_get_req_file_name allocate memory and return .req filename for session
 * INTERNAL to session manager
 * @param[in] pool used for memory allocation.
 * @param[in] path session file name
 * @param[out] fileName.
 */
void cuwa_session_get_req_file_name( apr_pool_t *pool, char *path, char **fileName )
{
    *fileName = apr_psprintf(pool,"%s.%s", path,"req");
}


/**
 * cuwa_session_delete delete sessions on disk due to session expired
 * @param[in] session: the session that needs to verify
 */
static void cuwa_session_delete( cuwa_session_t *session )
{
    cuwa_trace("In cuwa_session_delete");

    //remove all files associated with this session
    apr_file_remove( session->sessionFile, session->pool );

    apr_file_remove( session->useFile, session->pool );

    apr_file_remove( session->reqFile, session->pool );

    cuwa_trace("done delete session");
}

/*
 * cuwa_session_get_access_time returns last modified time of the file
 *
 * @param[in] file - the file to check.
 * @param[in] pool - pool to use
 * @param[out] access_time.
 * @return CUWA_OK, CUWA_ERR
 */
cuwa_err_t cuwa_session_get_access_time( char *file, apr_pool_t *pool, apr_time_t *mtime )
{
    apr_status_t code;
    apr_finfo_t  finfo;
    cuwa_err_t rc = CUWA_OK;

    code = apr_stat(&finfo,file,APR_FINFO_MTIME|APR_FINFO_LINK, pool);
    FAIL_IF_FILE_ERROR( code );

    if (finfo.mtime<=0)
    {
        cuwa_warning("invalid modified time stamp for %s", file);
        rc = CUWA_ERR_SESSION_DB_ERR;
    }
    else
        *mtime = apr_time_sec(finfo.mtime);

cleanup:

    return rc;
}

cuwa_err_t cuwa_session_get_access_time_uid( char *file, apr_pool_t *pool, apr_time_t *mtime, apr_uid_t *uid )
{
    apr_status_t code;
    apr_finfo_t  finfo;
    cuwa_err_t rc = CUWA_OK;

    code = apr_stat(&finfo,file,APR_FINFO_MTIME|APR_FINFO_LINK, pool);
    FAIL_IF_FILE_ERROR( code );

    if (finfo.mtime<=0)
    {
        cuwa_warning("invalid modified time stamp for %s", file);
        rc = CUWA_ERR_SESSION_DB_ERR;
    }
    else
    {
        *mtime = apr_time_sec(finfo.mtime);
        *uid = finfo.user;
    }

cleanup:

    return rc;
}

/**
 * cuwa_session_validate valify if the session is valid
 *
 * @param[in] session: the session that needs to verify
 * @param[in] sessionKey: sessionKey
 * @return CUWA_OK or CUWA_ERR_SESSION_EXPIRED or CUWA_ERR_SESSION_INVALID
 */
static cuwa_err_t cuwa_session_validate( cuwa_session_t *session, uint64 sessionKey )
{
    cuwa_err_t status = CUWA_OK;
    apr_time_t now = apr_time_sec( apr_time_now() );
    int inactivityTimeout;

    cuwa_assert( session );
    inactivityTimeout = session->inactivityTimeout;
    cuwa_trace("In cuwa_session_validate, currTime=%u, endTime=%u, inactivityTimeout=%d",(int)now, (int)session->endTime, inactivityTimeout);

    if ( !(session->state & CUWA_SESSION_ACTIVE) )
    {
        cuwa_trace("cuwa_session_validate state err: %d", session->state);
        status = CUWA_ERR_SESSION_INVALID;
    }
    else if ( session->sessionKey != sessionKey )
    {
        cuwa_trace("cuwa_session_validate sessionkey err: 0x%llX 0x%llX", session->sessionKey,sessionKey);
        status = CUWA_ERR_SESSION_INVALID;
    }
    else if ( now > session->endTime )
    {
        status = CUWA_ERR_SESSION_EXPIRED;
    }
    else if ( inactivityTimeout >= 0 )
    {
        apr_time_t lastAccess;

        //get last access time
        status = cuwa_session_get_access_time( session->sessionFile, session->pool, &lastAccess );

        if ( status == CUWA_OK )
        {
           cuwa_trace("now=%u,lastAccess=%u,timeout=%d",(int)now, (int)lastAccess, inactivityTimeout);
           if ( now > lastAccess +inactivityTimeout )
           {
               status = CUWA_ERR_SESSION_EXPIRED;
           }
        }	
    }
    cuwa_trace("cuwa_session_validate return status:%d", status);
    return status;
}

static uint64 cuwa_session_random()
{
    uint64 random=cuwa_rand64_g();

    cuwa_trace("random number generated 0x%llX", random);
    return random;
}


/**
 * cuwa_session_setup setup inactivityTimeout,maxSessionSize,sessionFile,useFile and reqFile fields in session
 *
 * @param[in] session the session.
 * idToUse: 0  unknow
 *          1  sessionID
 *          2  encryptedID 
 */
static cuwa_err_t cuwa_session_setup( cuwa_session_t *session, int idToUse)
{
    char *path;
    cuwa_err_t status = CUWA_OK;

    status = cuwa_session_get_session_file_path( &path, session , idToUse);

    session->maxSessionSize = cuwa_session_get_max_session_size( session->cfg );
    session->inactivityTimeout = cuwa_session_get_inactivity_timeout( session->cfg );
    session->encryptionCtx = NULL;
    session->noneEncryptDataLen = 0;
    session->encryptedLen = 0;
    cuwa_session_get_primary_file_name( session->pool, path, &session->sessionFile );
    cuwa_session_get_use_file_name( session->pool, path, &session->useFile );
    cuwa_session_get_req_file_name( session->pool, path, &session->reqFile );

    return status;
}

/**
 * cuwa_session_new creates a new session. The new session is initialized as
 *  - Generates a sessionID
 *  - Generates a sessionKey
 *  - Sets the AccessTime=now,
 *  - Sets the state attribute to CUWA_SESSION_NEW
 *
 * @param[in] pool: pool used for apr memory allocaiton.
 * @param[in] cfg config contex
 * @param[out] session: the newly created session. Caller must call cuwa_session_release to release session if function succeed
 * @return CUWA_OK or CUWA_ERR_MEM
 */
cuwa_err_t cuwa_session_new( void *request, apr_pool_t *pool, CUWACfg_t *cfg, cuwa_session_t **session)
{
    cuwa_err_t status = CUWA_OK;
    cuwa_session_t *newSession = NULL;

    cuwa_trace("In cuwa_session_new");
    newSession = (cuwa_session_t *)apr_pcalloc( pool, sizeof(cuwa_session_t) );

    if ( !newSession )
    {
        status = CUWA_ERR_MEM;
    }
    else
    {
        newSession->save = CUWA_SESSION_SAVE_PRIMARY | CUWA_SESSION_SAVE_ACCESS;
        newSession->sessionID = cuwa_session_random();
        newSession->sessionKey = cuwa_session_random();
        newSession->endTime = apr_time_sec(apr_time_now()) + CUWA_SESSION_DEFAULT_TIMEOUT;
        newSession->state = CUWA_SESSION_NEW;
        newSession->pool = pool;
        newSession->cfg = cfg;
        newSession->sessionSize = 0;

        cuwa_wal_note_set( request, CUWA_SESSION_SID, apr_psprintf(pool,"%qX",newSession->sessionID) );

        cuwa_session_setup( newSession, CUWA_SESSION_FILE_SESSION_ID );

        cuwa_session_dump( *session );
    }

    *session = newSession;

    cuwa_trace("cuwa_session_new return status %d", status);
    return status;
}


/**
 * cuwa_session_open_request open the request file for reading or writing
 *
 * @param[in] session: the session.
 * @param[in] write: ==1 if the file should be open for writing, otherwise it is opened for read access
 * @return CUWA_OK, CUWA_ERR_SESSION_NOT_FOUND (write==0 only), CUWA_ERR_SESSION_DB_ERR
 */
cuwa_err_t cuwa_session_open_request( cuwa_session_t *session, int write)
{
    apr_file_t *pFile;
    apr_status_t rv;
    cuwa_err_t rc = CUWA_OK;

    cuwa_trace("In cuwa_session_open_request");
    cuwa_assert( session );

    cuwa_trace("ready to open request file %s for %s", session->reqFile, write? "write":"read");

    if ( write )
    {
        cuwa_session_garbage_collect( session, 0 );

        //open request file for write
        rv = apr_file_open( &pFile, session->reqFile, APR_WRITE|APR_CREATE, APR_UREAD|APR_UWRITE, session->pool );
       //write header
       if ( !rv )
       {
           apr_size_t len = strlen(CUWA_SESSION_HEADER);
           rv = apr_file_write( pFile, CUWA_SESSION_HEADER, &len);

           while ( APR_STATUS_IS_ENOSPC(rv))
           {
               //file system probably is full, do garbage collection
               apr_file_close( pFile );
               if (cuwa_session_garbage_collect( session, 1 ))
                   break;

               //try again
               cuwa_trace("Try write header for request file again");
               rv = apr_file_open( &pFile, session->reqFile, APR_WRITE|APR_CREATE, APR_UREAD|APR_UWRITE, session->pool );
               if (!rv)
               {
                   len =  strlen(CUWA_SESSION_HEADER);
                   rv = apr_file_write( pFile, CUWA_SESSION_HEADER, &len);
               }
           }
       }
    }
    else
    {
        rv = apr_file_open( &pFile, session->reqFile, APR_READ, APR_UREAD|APR_UWRITE, session->pool );
        //read header and discard
        if (!rv )
        {
            CUWA_SESSION_READ_HEADER( pFile );
        }
    }

    FAIL_IF_FILE_ERROR( rv );

cleanup:

    if ( rc == CUWA_ERR_SESSION_NOT_FOUND )
    {
        cuwa_warning("session not found:%s", session->reqFile);
        CUWA_SHOW_APR_ERROR(rv);
    }

    if (!rv)
    {
        //succeed
        session->reqFH = pFile;
        cuwa_trace("open request file %s succeed", session->reqFile);
    }
    else
        session->save = CUWA_SESSION_REMOVE;

    cuwa_trace("cuwa_session_open_request return status %d", rc);
    return rc;
}

    
/**
 * cuwa_session_read_request read bytes from the request file
 *
 * @param[in] session: the session.
 * @param[in] buf pointer to where bytes are written
 * @param[in/out] count on entry number of bytes requested, exit number of bytes actually read.
 * @return CUWA_OK, CUWA_ERR_SESSION_DB_ERR, CUWA_ERR_SESSION_EOF
 */
cuwa_err_t cuwa_session_read_request( cuwa_session_t *session, char *buf, apr_size_t *count)
{
    apr_file_t *pFile = NULL;
    apr_status_t rv = 0;
    cuwa_err_t rc = CUWA_OK;
    char *p = buf;

    cuwa_trace("In cuwa_session_read_request,read %d bytes", *count);
    cuwa_assert(session);

    pFile = session->reqFH;
    cuwa_assert( pFile );

    if ( session->encrypt == CUWA_SESSION_ENCRYPTION_NO )
    {
        rv = apr_file_read_full( pFile, buf, *count, count );
        FAIL_IF_FILE_ERROR( rv );
    }
    else
    {
        apr_size_t dataRead = 0;
        int dataRequested = *count;
 
        if ( session->noneEncryptDataLen > 0 ) 
        {
            dataRead = ( session->noneEncryptDataLen > dataRequested )? dataRequested: session->noneEncryptDataLen;

            cuwa_trace("Read none encrypted data:%d", dataRead);
            //we have none encrypted data, let's read that first
            rv = apr_file_read_full( pFile, buf, dataRead, &dataRead );
            FAIL_IF_FILE_ERROR( rv );

            session->noneEncryptDataLen = session->noneEncryptDataLen - dataRead; 
            p += dataRead;
        }

        if ( dataRead < dataRequested )
        {
            apr_size_t dataToRead = dataRequested - dataRead;

            //we now need to read encrypted data
            rc = cuwa_session_encryption_read( session, p, &dataToRead );
            if ( rc ) goto cleanup;

            dataRead += dataToRead; 
            buf[dataRead] = '\0';

            cuwa_trace("%d bytes of Data returned", dataRead);
        }
        *count = dataRead;
  }

cleanup:
    if ( rv == APR_EOF )
        rc = CUWA_ERR_SESSION_EOF;

    if (!rv)
        buf[*count] = '\0';
    else
        session->save = CUWA_SESSION_REMOVE;

    //cuwa_trace("cuwa_session_read_request return %d", rc);
    return rc;
}

cuwa_err_t cuwa_session_do_write( cuwa_session_t *session, char *buf, int count)
{
     cuwa_err_t rc = CUWA_OK;
     apr_file_t *pFile = NULL;
     apr_status_t rv;
     apr_size_t bytesWritten = count;
     apr_off_t size;

     pFile = session->reqFH;
     cuwa_assert( pFile );

     rv = apr_file_write( pFile, buf, &bytesWritten);

     while(  APR_STATUS_IS_ENOSPC(rv) )
     {
        apr_file_close( pFile );
        cuwa_trace("force garbage collection");
        if (cuwa_session_garbage_collect( session, 1 ))
            break;

        cuwa_trace("rewrite request again");
        rv = apr_file_open( &pFile, session->reqFile, APR_WRITE|APR_CREATE, APR_UREAD|APR_UWRITE, session->pool );
        FAIL_IF_FILE_ERROR( rv );

        session->reqFH = pFile;

        //calculate the total bytes we have written to the file previously
        size = session->sessionSize + strlen(CUWA_SESSION_HEADER);

        rv = apr_file_seek( pFile, APR_CUR, &size );
        FAIL_IF_FILE_ERROR( rv );

        bytesWritten = count;
        rv = apr_file_write( pFile, buf, &bytesWritten);
    }

    FAIL_IF_FILE_ERROR( rv );

    if ( bytesWritten != count )
        rc = CUWA_ERR_SESSION_WRITE_INCOMPLETE;

cleanup:
    if ( rc )
        session->save = CUWA_SESSION_REMOVE;

    return rc;
}

/**
 * cuwa_session_write_request write bytes from the request file
 *
 * @param[in] session: the session.
 * @param[in] buf pointer to bytes to be written to the file
 * @param[in] count number of bytes to write.
 * @param[in] doEncryption encrypt data before written to disk or not
 * @return CUWA_OK, CUWA_ERR_SESSION_DB_ERR
 */
cuwa_err_t cuwa_session_write_request( cuwa_session_t *session, char *buf, int count, int doEncryption)
{
    cuwa_err_t rc = CUWA_OK;

    cuwa_assert(session);

    if ( session->maxSessionSize )
    {
        //check is request size exceed maximum session size
         if ( session->sessionSize + count > session->maxSessionSize )
        {
            rc = CUWA_ERR_SESSION_EXCEED_MAX_SESSION;
            goto cleanup;
        }
    }

    session->sessionSize += count;

    if ( doEncryption )
    {

        rc = cuwa_session_encryption_write( session, buf, count );
    }   
    else
    {
        rc = cuwa_session_do_write( session, buf, count);
        session->noneEncryptDataLen += count;
    }

cleanup:
    if ( rc )
        session->save = CUWA_SESSION_REMOVE;

    return rc;
}

/**
 * cuwa_session_close_request close the request file
 *
 * @param[in] session: the session.
 */
void cuwa_session_close_request( cuwa_session_t *session )
{
    apr_file_t *pFile = NULL;

    cuwa_trace("In cuwa_session_close_request");
    cuwa_assert(session);

    pFile = session->reqFH;
    if ( pFile )
    {
        apr_file_close( pFile );
    }
    session->reqFH = NULL;

    cuwa_trace("Done close request" );
}


/**
 * cuwa_session_release releases memory resources associated with a session, and flushed modified data
 *                      to the session database.
 *
 * @param[in] session: the session.
 * @return CUWA_OK, CUWA_ERR_MEM, CUWA_ERR_SESSION_DB_ERR
 *
 */
cuwa_err_t cuwa_session_release( cuwa_session_t *session )
{
    cuwa_err_t status = CUWA_OK;

    cuwa_trace("In cuwa_session_release");

    //If session has already been released, just return
    if ( (!session) || (!session->sessionID) )
        return status;

    cuwa_session_garbage_collect( session, 0);

    status = cuwa_session_flush( session );

    cuwa_session_clear( session );

    cuwa_trace("cuwa_session_release return status %d", status);
    return status;
}

static cuwa_err_t cuwa_session_save_primary( cuwa_session_t *session, char *file )
{
    apr_size_t nbytes;
    apr_status_t rv;
    cuwa_err_t rc = CUWA_OK;
    apr_file_t *pFile = NULL;

    cuwa_trace("About to save primary session data");
    rv = apr_file_open( &pFile, file, APR_WRITE|APR_CREATE, APR_UREAD|APR_UWRITE, session->pool );
    FAIL_IF_FILE_ERROR( rv );

    //flush data to file
    cuwa_trace("ready to flush the primary session data");

    //write a header
    nbytes = strlen(CUWA_SESSION_HEADER);
    rv = apr_file_write( pFile, CUWA_SESSION_HEADER, &nbytes);
    FAIL_IF_FILE_ERROR(rv);

    //write session version
    CUWA_SESSION_WRITE_STRING( pFile, CUWA_SESSION_VERSION);

    //write session state
    CUWA_SESSION_WRITE_NUM( pFile, session->state);

    //write session Key
    CUWA_SESSION_WRITE_NUM( pFile, session->sessionKey);

    //write endTime
    CUWA_SESSION_WRITE_NUM( pFile, session->endTime);

    if ( session->state & CUWA_SESSION_ACTIVE )
    {
        if ( session->state & CUWA_SESSION_HAS_PERMIT )
        {
            //write permit
            cuwa_trace("write permit");
            CUWA_SESSION_WRITE_STRING( pFile, session->permitList );
        }

        rc = cuwa_session_write_table( pFile, session->proxyTable );
        FAIL_IF(rc, rc);

        rc = cuwa_session_write_table( pFile, session->proxyCookiesTable );
        FAIL_IF(rc, rc);

        cuwa_assert(session->cred);
        rc = cuwa_cred_serialize( session->cred, pFile );
        FAIL_IF(rc,rc);
    }
    cuwa_trace("Done saving primary session, status=%d", rc);

cleanup:
    if ( pFile )
        apr_file_close( pFile );

    cuwa_trace("cuwa_session_save_primary return status %d", rc);
    return rc;

}

static cuwa_err_t cuwa_session_update_use_file( cuwa_session_t *session )
{
    apr_time_t expireTime;
    cuwa_err_t rc = CUWA_OK;
    apr_file_t *pFile;
    apr_status_t rv;
    apr_time_t mtime;

    cuwa_trace("ready to update accessTime, path=%s", session->useFile);

    if ( cuwa_session_get_access_time(session->useFile,session->pool,&mtime) ==  CUWA_ERR_SESSION_NOT_FOUND )
    {
        rv = apr_file_open( &pFile, session->useFile, APR_WRITE|APR_CREATE, APR_UREAD|APR_UWRITE, session->pool );
        FAIL_IF_FILE_ERROR( rv );

        CUWA_SESSION_WRITE_NUM( pFile, session->sessionSize );
        CUWA_SESSION_WRITE_NUM( pFile, session->noneEncryptDataLen ); 
        CUWA_SESSION_WRITE_NUM( pFile, session->encryptedLen );
        apr_file_close(pFile);
    }

    //if inactivityTimeout is defined, use it to calculate when session is expired. Otherwise use endTime.
    //if inactivityTimeout is defined to 0, administrator means to force user login. In this case, we set
    //the expirationTime of the useFile to endTime. So their session won't be deleted by garbage collection.
    if ( session->inactivityTimeout > 0 )
        expireTime = apr_time_from_sec(session->inactivityTimeout) + apr_time_now();
    else
        expireTime = apr_time_from_sec(session->endTime);

    apr_file_mtime_set( session->useFile,expireTime, session->pool );

    cuwa_trace("update accessTime to %u,inactivityTimeout=%d",(int)expireTime,session->inactivityTimeout);
cleanup:
    return rc;
}

/**
 * cuwa_session_flush flushes changes made to the session to permanent storage.
 *
 * @param[in] session: the session.
 * @return CUWA_OK, CUWA_ERR_MEM, CUWA_ERR_SESSION_DB_ERR
 *
 */
static cuwa_err_t cuwa_session_flush( cuwa_session_t *session )
{
    cuwa_err_t rc = CUWA_OK;

    cuwa_trace("In cuwa_session_flush");
    cuwa_assert( session );

    cuwa_session_dump( session );

    if ( session->save == CUWA_SESSION_REMOVE )
    {
        //there is error condition occur, remove this session
        cuwa_session_delete( session );
    }

    //create primary session file and flush data to the file if savePrimary is true
    if ( session->save & CUWA_SESSION_SAVE_PRIMARY )
    {
        rc = cuwa_session_save_primary( session, session->sessionFile );
        while (rc == CUWA_ERR_SESSION_NO_DISK_SPACE)
        {
            if (cuwa_session_garbage_collect( session, 1 ))
                break;
            rc = cuwa_session_save_primary( session, session->sessionFile );
        }

        //update the modifed timestamp on req session file using endTime,then at the time for garbage collection,
        //we only need to check the time stamp on the session file
        apr_file_mtime_set( session->reqFile,apr_time_from_sec(session->endTime), session->pool);
    }

    //update the time stamp of primay session file so it indicate when the session was last accessed
    apr_file_mtime_set( session->sessionFile, apr_time_now(), session->pool );

    //update access time. The modified timestamp on the useFile indicate when session should expired.
    if ( (rc == CUWA_OK) && ( session->save & CUWA_SESSION_SAVE_ACCESS ) )
    {
        rc = cuwa_session_update_use_file( session );

    }

    cuwa_trace("cuwa_session_flush return status %d", rc);
    return rc;

}


/**
 * cuwa_session_from_credentials given a session cookie and/or a URL credential, will
 * find the associated session record, and
 * the loads the session. cuwa_session_from_credentials validates that the SessionKey in
 * session the session cookie before acceptance.
 *
 * @param[in] pool handle to pool.
 * @param[in] cfg configuration context
 * @param[in] host the URL of this virtual host.
 * @param[in] urlCred(WA) credential string, NULL if one was not attached to the request
 * @param[in] urlCredLen length of the credential string.
 * @param[in] cookie (WA) credential string. NULL if one was not attached to the request
 * @param[in] cookieLen length of the credential string.
 * @param[in] serviceID
 * @param[in] keytab
 * @param[out] session the newly loaded session.  Caller must call cuwa_session_release to release session if function succeed.
 * @return CUWA_OK, CUWA_ERR_MEM, CUWA_ERR_SESSION_NOT_FOUND, CUWA_ERR_SESSION_DB_ERR, CUWA_ERR_BAD_CRED,
 *         CUWA_ERR_KRB, CUWA_ERR_GSS, CUWA_ERR_SESSION_DB_ERR
 */
cuwa_err_t cuwa_session_from_credential( void *request, apr_pool_t *pool, CUWACfg_t *cfg, char *host, char *urlCred, int urlCredLen, char *cookie,
                                         int cookieLen, char *serviceName, char *keytab, cuwa_session_t **sessionOut)
{
    cuwa_err_t status = CUWA_OK;
    cuwa_session_t *session = NULL;
    int checkCookie = 1;
    int needDual = -1;
    char *dualAuthUser = NULL, *dualAuthMethod=NULL;
    int dualAuthTime = 0;

    cuwa_trace("In cuwa_session_from_credential");

    *sessionOut = NULL;

    if ( (!urlCredLen && !cookieLen) ||
         (!urlCred && !cookie) )
        return CUWA_ERR_BAD_CRED;

    //create session
    session = (cuwa_session_t *)apr_pcalloc( pool, sizeof(cuwa_session_t) );
    if ( !session )
        return CUWA_ERR_MEM;

    session->pool = pool;
    session->cfg = cfg;

    // if a URL credential is present,it is checked first
    if ( urlCred && urlCredLen )
    {
        cuwa_trace(" use login credential");

        status = cuwa_cred_parse( pool, &session->cred, urlCred, urlCredLen, serviceName, keytab, host, NULL );

        if ( status == CUWA_OK )
        {
            status = cuwa_cred_get_sessionid( session->cred ,&session->sessionID);
            cuwa_wal_note_set( request, CUWA_SESSION_SID, apr_psprintf(pool,"%qX",session->sessionID ));

            cuwa_trace("cuwa_cred_get_sessionid return status: %d,sessionID=0x%llX", status, session->sessionID);
            status = cuwa_session_setup( session, CUWA_SESSION_FILE_UNKNOWN );

            if ( status == CUWA_OK )
                status = cuwa_session_restore_from_file( session );

            if ( status == CUWA_OK )
            {

                if ( session->state == CUWA_SESSION_NEW )
                {
                    cuwa_trace("session is in new state, set up session data,%d", session->state);

                    session->save = CUWA_SESSION_SAVE_PRIMARY | CUWA_SESSION_SAVE_ACCESS;
                    session->state = CUWA_SESSION_ACTIVE;

                    session->endTime   = cuwa_cred_get_end_time( session->cred );

                    cuwa_session_dump( session );
                    checkCookie = 0;

                }
#if 0
                //if session is in active state, but there is no cookie, use url credential
                else if ( (session->state == CUWA_SESSION_ACTIVE) &&
                          (!cookieLen) )
                {
                    cuwa_trace("session is active, but no cookie,validate session");
                    status = cuwa_session_validate( session, session->sessionKey );
                    if ( status == CUWA_OK )
                        session->save = CUWA_SESSION_SAVE_ACCESS;

                    checkCookie = 0;
                }
#endif
                else
                {
                    cuwa_trace("wa replay");
                    status = CUWA_ERR_SESSION_REPLAY;
                }
            }
        }
    }

    if ( checkCookie && cookie && (cookieLen > 0) )
    {
        cuwa_trace("use cookie credential");

        status = cuwa_cred_parse( pool, &session->cred, cookie, cookieLen, serviceName, keytab, host, NULL );

        if ( status == CUWA_OK )
        {
            status = cuwa_cred_get_sessionid( session->cred , &session->sessionID);
            cuwa_wal_note_set( request, CUWA_SESSION_SID, apr_psprintf(pool,"%qX",session->sessionID ));
            cuwa_trace("cuwa_cred_get_sessionid return status: %d", status);

            status = cuwa_session_setup( session, CUWA_SESSION_FILE_UNKNOWN );

            if ( status == CUWA_OK )
                status = cuwa_session_restore_from_file( session );

            if ( status == CUWA_OK )
            {

                uint64 key;

                status  = cuwa_cred_get_sessionkey(session->cred, &key);
                cuwa_trace("cuwa_cred_get_sessionkey return status: %d", status);

                if ( status == CUWA_OK )
                    status = cuwa_session_validate( session, key );

                if ( status == CUWA_OK )
                {
                    session->save = CUWA_SESSION_SAVE_ACCESS;
                    status = sspiutil_restore_sec_context(session->cred);
                }
            }
        }
    }

    //check if dualAuth is requested, if yes, check if user has been authenticated with dualAuth
    if ( status == CUWA_OK )
    {
        char *dualAuth = NULL;
        char *permits = CUWA_TWO_FACTOR_OPT_IN;

        if (CFG_CUWA2FARequire(cfg) )
        {
            dualAuth = apr_pstrdup(pool,CFG_CUWA2FARequire(cfg));

            //check if this user need two factor
           if ( !apr_strnatcasecmp( dualAuth, "all") )
               needDual = 1; 
           else if ( !apr_strnatcasecmp( dualAuth, "none") )
               needDual = 0; 
           else 
           {
               cuwa_util_replace_char_with(dualAuth,',',' ');
               permits = apr_pstrcat( pool, permits, " ", dualAuth, NULL);
           }
        }

        if ( needDual < 0 )
        {
            char *memberships;
            char *user = cuwa_cred_get_attribute( session->cred, "CUWA_FULL_USER",0);

            cuwa_trace("check if user %s is in permit %s", user, permits);
            cuwa_permit_cache_load( request, session, pool );
            status = cuwa_permit_lookup(request, pool, session, serviceName, keytab, user,permits, &memberships);

            if (status)  return status;
            else if (memberships) needDual = 1;
            else needDual = 0;
        }
  
        if ( status==CUWA_OK && needDual )
        {
            cuwa_trace("Require 2F, check if they are in cred");
            cuwa_cred_get_dual_auth(session->cred, &dualAuthUser, &dualAuthMethod, &dualAuthTime );

            cuwa_trace("User %s authenticated with %s", dualAuthUser,dualAuthMethod);
            if ( !dualAuthUser || !dualAuthMethod || dualAuthTime==0)
            {
                cuwa_trace("user not authenticated with DualAuth");
                status = CUWA_ERR_SESSION_NO_DUAL;
            }
            else if (CFG_CUWA2FAMethod(cfg) )
            {
                 char *method, *state = NULL;
                 char *methodList = apr_pstrdup(pool, CFG_CUWA2FAMethod(cfg));
                 int good = 0;

                 method = apr_strtok( methodList, " ", &state);
                 while ( method )
                {
                    if (!apr_strnatcasecmp(method, dualAuthMethod) )
                    {
                        good = 1;
                        break;
                    }
                    method = apr_strtok( NULL, " ", &state);
                }

                //if dualMethod is defined and user logged on with different method
                // user has to relogin
                if ( good == 0 )
                {
                    cuwa_trace("user authenticated with %s, but app requires %s", dualAuthMethod,CFG_CUWA2FAMethod(cfg));
                    status = CUWA_ERR_SESSION_NO_DUAL;
                }
            }

        }
    }

    // Make sure credential meets CUWACredentialAge requirement...
    if ( (status == CUWA_OK) && CFG_CUWACredentialAge(cfg))
    {
        int authTime = cuwa_cred_get_auth_time(session->cred);

        if ( dualAuthTime > 0 ) authTime = dualAuthTime;

        if ((cuwa_cred_get_start_time(session->cred) - authTime) > *CFG_CUWACredentialAge(cfg))
        {
            // credential is too old, need to refresh
            status = CUWA_ERR_CRED_TOO_OLD;
            cuwa_trace("cuwa_session_from_credential, cred too old: %d - %d",cuwa_cred_get_auth_time(session->cred),cuwa_cred_get_auth_time(session->cred));
        }
        else cuwa_trace("cuwa_session_from_credential, cred is good");
    }

    *sessionOut = session;

    cuwa_session_dump(*sessionOut);
    if ( status != CUWA_OK)
    {
        if ( status != CUWA_ERR_SESSION_NOT_FOUND && status != CUWA_ERR_SESSION_NO_DUAL)
            cuwa_notice("cuwa_session_from_credential failed with status %d", status);
        session->save = CUWA_SESSION_REMOVE;
        cuwa_session_release( session );
    }

    cuwa_trace("cuwa_session_from_credential return status %d", status);
    return status;
}


/**
 * cuwa_session_get_sessionid returns sessionid.
 *
 * @param[in] session the session.
 * @param[out] sessionid sessionid returned to caller.
 * @return CUWA_OK
 */
int cuwa_session_get_sessionid( cuwa_session_t *session, uint64 *sessionid )
{
    cuwa_err_t status = CUWA_OK;

    *sessionid = session->sessionID;

    return status;
}

/**
 * cuwa_session_to_cookie generates a cookie.  State of the session must be CUWA_SESSION_ACTIVE
 * or cuwa_session_to_cookie returns CUWA_ERR.
 * The cookie has the following format: [ SessionID SessionKey ]base16
 *
 * @param[in] session the session.
 * @param[out] cookie newly allocated buffer containing NULL terminated cookie string.  Caller must free.
 * @return CUWA_OK, CUWA_ERR
 */
cuwa_err_t cuwa_session_to_cookie( cuwa_session_t *session, char **cookie, int *cookieLen )
{
    cuwa_err_t rc, code;
    char *c0 = NULL;
    int c0Len;

    if (!session)
        return CUWA_ERR;

    code = cuwa_cred_make_c0( session->sessionID, session->sessionKey, &c0, &c0Len );
    FAIL_IF(code,code);

    rc = cuwa_base64_make_wa(cookie, cookieLen, c0Len, 1, c0, c0Len);
    FAIL_IF(code,code);

cleanup:

    if (c0) cuwa_free(c0);

    return rc;
}

/*
 * cuwa_session_get_req_size returns the size of request file
 *
 * @param[in] session the session.
 * @param[out] size file size.
 * @return CUWA_OK, CUWA_ERR
 */
cuwa_err_t cuwa_session_get_req_size(cuwa_session_t *session, apr_off_t *size)
{
    apr_status_t code;
    cuwa_err_t rc = CUWA_OK;
    apr_file_t *pFile;
    
    code = apr_file_open( &pFile, session->useFile, APR_READ, APR_UREAD|APR_UWRITE, session->pool);
    FAIL_IF_FILE_ERROR( code );

    CUWA_SESSION_READ_NUM( pFile, session->sessionSize );
    cuwa_trace("request size is %d", session->sessionSize);

    CUWA_SESSION_READ_NUM( pFile, session->noneEncryptDataLen );
    cuwa_trace("none encrypted data len is:%d", session->noneEncryptDataLen );

    CUWA_SESSION_READ_NUM( pFile, session->encryptedLen );
    cuwa_trace("encrypted data len is:%d", session->encryptedLen );

    *size = session->sessionSize;

    apr_file_close(pFile);
cleanup:
   if ( rc == CUWA_ERR_SESSION_NOT_FOUND )
   {
       cuwa_warning("session not found:%s", session->useFile);
       CUWA_SHOW_APR_ERROR(code);
   }
    return rc;
}

/*
 * cuwa_session_from_sessionid returns session, give sessionid
 *
 * @param[in] pool to allocate the session from.
 * @param[in] cfg configuration, used to get the session file path.
 * @param[in] sessionid the sessionid.
 * @param[out] sessionOut session retured.
 * @return CUWA_OK, CUWA_ERR
 */
cuwa_err_t cuwa_session_from_sessionid( void *request, apr_pool_t *pool, CUWACfg_t *cfg, uint64 sessionid, cuwa_session_t **sessionOut)
{
    cuwa_session_t *session;
    cuwa_err_t status = CUWA_OK;

    cuwa_trace("session_from_sessionid:%llX", sessionid);
    cuwa_wal_note_set( request, CUWA_SESSION_SID, apr_psprintf(pool,"%qX",sessionid ));

    session = (cuwa_session_t *)apr_pcalloc( pool, sizeof(cuwa_session_t) );

    if ( !session ) return CUWA_ERR_MEM;

    session->pool      = pool;
    session->cfg       = cfg;
    session->sessionID = sessionid;

    status = cuwa_session_setup( session, CUWA_SESSION_FILE_UNKNOWN );
    if ( status == CUWA_OK )
    {
        *sessionOut        = session;
    }
    return status;
}

void  cuwa_session_update_permit_cache( void *req, apr_pool_t *pool, void *s, CUWACfg_t *cfg, char *cachePermits )
{
    uint64 sid;
    cuwa_session_t *session = (cuwa_session_t *)s;
    cuwa_err_t status = CUWA_OK;
    char *sidStr = cuwa_wal_note_get( req, CUWA_SESSION_SID );

    cuwa_trace("in cuwa_session_update_permit_cache");

    if (!session)
    {
        if ( !sidStr ) return;

        sscanf( sidStr, "%llX", &sid);

        status = cuwa_session_from_sessionid(req, pool, cfg, sid, &session);
        if ( !status )
            status = cuwa_session_restore_from_file( session ); 
     } 
     if ( status == CUWA_OK && session )
     {
         cuwa_trace("Permit cache %s", cachePermits);
         session->permitList = cachePermits;

         cuwa_trace("permit_cashe:state is 0x%x", session->state);
         session->state |= CUWA_SESSION_HAS_PERMIT;
         cuwa_trace("permit_cashe:state now is 0x%x", session->state);

         //if function is called in authorization phase, update session file. Otherwise session will be saved in session_release
         if (!s)
         {
             char *fileName = apr_psprintf(pool,"%s.%lu", session->sessionFile,(unsigned long)getpid());
             cuwa_trace("save permit cache to temporary file:%s", fileName );

             cuwa_session_save_primary( session, fileName );
             apr_file_rename( fileName, session->sessionFile, pool );

             cuwa_session_update_use_file( session );

             cuwa_session_clear( session );
         }
     }
}

const char *cuwa_session_get_proxy_cookie(cuwa_session_t *session, const char *proxy)
{
    const char *proxyCred = NULL;

    if ( session && session->proxyTable )
    {
        proxyCred = apr_table_get( session->proxyTable, proxy );
    }
    return proxyCred;
}

void cuwa_session_save_proxy_cookie(cuwa_session_t *session, const char *proxy, const char *val)
{
    if ( !session )
        return;

    cuwa_trace("save proxy cookie:proxy=%s",proxy);
    if (!session->proxyTable)
        session->proxyTable = apr_table_make(session->pool,1);

    if ( session->proxyTable)
        apr_table_set( session->proxyTable, proxy, val );

    session->save |= CUWA_SESSION_SAVE_PRIMARY;

}

const char *cuwa_session_get_proxy_cookies(cuwa_session_t *session, const char *proxy)
{
    const char *proxyCred = NULL;

    if ( session && session->proxyCookiesTable )
    {
        proxyCred = apr_table_get( session->proxyCookiesTable, proxy );
    }
    return proxyCred;
}

void cuwa_session_save_proxy_cookies(cuwa_session_t *session, const char *proxy, const char *val)
{
    if ( !session )
        return;

    if (!session->proxyCookiesTable)
        session->proxyCookiesTable = apr_table_make(session->pool,1);

    if ( session->proxyCookiesTable)
        apr_table_set( session->proxyCookiesTable, proxy, val );

    session->save |= CUWA_SESSION_SAVE_PRIMARY;

}

const char id_session_session_c[] = "$Id: session.c,v 1.107 2015/10/07 17:38:20 hy93 Exp $";
