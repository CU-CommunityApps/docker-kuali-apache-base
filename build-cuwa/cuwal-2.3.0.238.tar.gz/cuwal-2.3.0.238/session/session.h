/************************************************************************

 * session.h -- Session Manager for cuwebauth
 *
 * Copyright 2007 Cornell University.
 * All Rights Reserved.
 *
 ************************************************************************
 *  $Log: session.h,v $
 *  Revision 1.38  2015/10/07 17:38:53  hy93
 *  merge TwoFactor treee to the head
 *
 *  Revision 1.37.2.3  2015/10/01 16:00:18  hy93
 *  fix permit is not saved in session cache when looked up during authorization stage
 *
 *  Revision 1.37.2.2  2015/01/29 15:55:11  hy93
 *  remove saving webloing server name to session
 *
 *  Revision 1.37.2.1  2014/10/22 20:05:20  hy93
 *  add two factor support
 *
 *  Revision 1.37  2014/10/22 16:41:47  hy93
 *  remove two factor support
 *
 *  Revision 1.36  2014/07/25 17:05:32  hy93
 *  save weblogin server url to the request
 *
 *  Revision 1.35  2011/08/01 04:18:06  pb10
 *  Add allCookies feature to proxy portal.
 *
 *  Revision 1.34  2010/12/23 19:47:34  hy93
 *  add warning in log when cuwebauth can't do garbage collection
 *
 *  Revision 1.33  2009/04/20 16:56:09  hy93
 *  *** empty log message ***
 *
 *  Revision 1.32  2008/09/19 03:52:25  pb10
 *  Always check CUWACredAge against start_time and auth_time (not just when processing login cred).
 *
 *  Revision 1.31  2008/09/16 19:20:23  hy93
 *  remove function prototypes that are internal in session.c
 *
 *  Revision 1.30  2008/08/26 19:53:43  hy93
 *  fix compiler warning on windows
 *
 *  Revision 1.29  2008/08/17 16:34:04  pb10
 *  Removed session->k3.
 *
 *  Revision 1.28  2008/08/17 14:18:03  pb10
 *  Remove unused code from session manager and cred manager.
 *
 *  Revision 1.27  2008/08/15 20:10:03  pb10
 *  Change auth code to use attributes table.
 *
 *  Revision 1.26  2008/08/15 04:49:26  pb10
 *  Added table based attribute support to session code.
 *  Still need to put support into auth.c and lastly need to remove old code from everywhere.
 *
 *  Revision 1.25  2008/08/11 04:07:11  hy93
 *  delegation support
 *
 *  Revision 1.24  2008/08/09 01:16:49  pb10
 *  Support listPermit call (CUWAInquire permit all).
 *
 *  Revision 1.23  2008/08/04 16:05:54  hy93
 *  moidfy function prototype
 *
 *  Revision 1.22  2008/07/28 17:19:00  hy93
 *  change function prototypes
 *
 *  Revision 1.21  2008/07/25 18:57:58  hy93
 *  permit cache support
 *
 *  Revision 1.20  2008/07/16 14:12:14  hy93
 *  delegation support
 *
 *  Revision 1.19  2008/06/02 01:44:20  pb10
 *  Add starttime and endtime to fields being hacked out of GSS credential with
 *  KRB5 calls.  The starttime is being used by session manager to support
 *  cred age test... too old = starttime-authtime > CUWACredentialAge
 *
 *  Revision 1.18  2008/05/30 20:01:55  hy93
 *  remove un-used replay related code
 *
 *  Revision 1.17  2008/04/29 13:33:55  hy93
 *  fix warning regarding assignment differ in signedness
 *
 *  Revision 1.16  2008/04/18 04:17:34  pb10
 *  Add replayed file to track when the request has been replayed. This is done
 *  to avoid replaying the request multiple times (very bad with POST).
 *
 *  Revision 1.15  2008/04/14 18:21:08  hy93
 *  add prototype
 *
 *  Revision 1.14  2008/04/14 04:12:36  pb10
 *  Fix CUWACredentialAge to only check age on initial website page hit.  CUWACrentialDefaultAge obsolete.
 *
 *  Revision 1.13  2008/03/21 19:40:15  hy93
 *  add fields in session
 *
 *  Revision 1.12  2008/03/19 20:30:13  pb10
 *  Moved weblogin credential parsing from the filter to mod_cuwebauth.c so that
 *  kerberos directives could be based on virtual host.
 *
 *  Revision 1.11  2008/03/19 16:37:54  hy93
 *  remove prototype for show_apr_error
 *
 *  Revision 1.10  2008/03/11 17:55:04  hy93
 *  add prototype
 *
 *  Revision 1.9  2008/03/10 18:17:57  hy93
 *  Add prototypes
 *
 *  Revision 1.8  2008/02/25 19:43:27  hy93
 *  add sessionSize
 *
 *  Revision 1.7  2008/01/15 14:47:06  hy93
 *  Modified function prototype
 *
 *  Revision 1.6  2008/01/14 16:05:56  hy93
 *  Modified include to use <> instead of "
 *
 *  Revision 1.5  2008/01/10 17:47:40  hy93
 *  Add config context pointer in session_t. Modified function interfaces
 *
 *  Revision 1.4  2008/01/02 04:36:04  pb10
 *  Added flush function, fixed compiler warnings, adjusted to change to k2 token calls.
 *
 *  Revision 1.3  2007/12/21 19:26:37  hy93
 *  Modified function interfaces.
 *
 *  Revision 1.1  2007/12/05 19:02:35  hy93
 *  no message
 *
 *
 ************************************************************************
 */

#ifndef _SESSION_H

#define _SESSION_H

#include <apr_file_io.h>

#include <cuwa_types.h>
#include <cuwa_err.h>
#include <cred.h>
#include <apr_pools.h>
#include <cfg.h>
#include <list.h>
#include <session_file.h>
#include <openssl/evp.h>

#define CUWA_SESSION_DEFAULT_TIMEOUT     10*60*60  //session timeout default is 10 hours
#define CUWA_SESSION_DEFAULT_PATH        "/tmp"

#define CUWA_SESSION_SAVE_PRIMARY     0x0001
#define CUWA_SESSION_SAVE_ACCESS      0x0010
#define CUWA_SESSION_REMOVE           0x1000

#define CUWA_SESSION_NONE             0x0000
#define CUWA_SESSION_NEW              0x0001
#define CUWA_SESSION_ACTIVE           0x0010
#define CUWA_SESSION_HAS_PERMIT       0x0100

#define CUWA_SESSION_ENCRYPTION_UNKNOWN    1 
#define CUWA_SESSION_ENCRYPTION_YES        2
#define CUWA_SESSION_ENCRYPTION_NO         3

#define CUWA_SESSION_FILE_UNKNOWN         1
#define CUWA_SESSION_FILE_SESSION_ID      2
#define CUWA_SESSION_FILE_ENCRYPTED_ID    3

#define CUWA_SESSION_BUF_SIZE       1024 
 
typedef struct cuwa_session
{
    uint64 sessionID;               /** 64-bit nonce. Created to maintain the session */
    uint64 sessionKey;              /** 64-bit nonce. */
    int state;                      /** The state of the session.  and CUWA_SESSION_ACTIVE */
    apr_time_t endTime;                    /** The time that the user's credentials expire */
    apr_table_t *proxyTable;        /** store delegation credentials */
    apr_table_t *proxyCookiesTable; /** store cookie batch, including delegation credentials*/
    cuwa_cred_t *cred;              /** the credentials */

    /* Internal to session manager */
    int save;                       /** value can be CUWA_SESSION_SAVE_PRIMARY or/and CUWA_SESSION_SAVE_ACCESS*/
    apr_file_t *reqFH;              /** file handler of request file */
    apr_pool_t *pool;               /** handle to the pool used in allocation */
    CUWACfg_t *cfg;                 /** config context */
    int sessionSize;                // size of request we have saved so far
    int inactivityTimeout;          // session inactivity timeout value
    int maxSessionSize;             // maximum session size
    char *sessionFile;              // primary session file name
    char *reqFile;                  // request file name
    char *useFile;                  // use file name
    char *permitList;               //for cache permit.Format: /|/permit1==val/|/permit2==val2/|/

    //session encrypted?
    int encrypt;                   //indicate encryption state  
    EVP_CIPHER_CTX *encryptionCtx;   //context used for encryption
    char *buf;                      //store data that needs to be encrypted
    char *readBuf;                 //store data read from disk
    int bufLen;                   //total length of data waiting for encryption
    int noneEncryptDataLen;
    int encryptedLen;
    int bufAllocLen;               //allocated buffer len  
} cuwa_session_t;

cuwa_err_t cuwa_session_new( void *req, apr_pool_t *pool,  CUWACfg_t *cfg, cuwa_session_t **session);
cuwa_err_t cuwa_session_open_request( cuwa_session_t *session, int write);
cuwa_err_t cuwa_session_read_request( cuwa_session_t *session, char *buf, apr_size_t *count);
cuwa_err_t cuwa_session_write_request( cuwa_session_t *session, char *buf, int count,int encryption);
void cuwa_session_close_request( cuwa_session_t *session );
cuwa_err_t cuwa_session_release( cuwa_session_t *session );
cuwa_err_t cuwa_session_from_credential( void *req, apr_pool_t *pool,  CUWACfg_t *cfg, char *host, char *urlCred, int urlCredLen,
                                         char *cookie, int cookieLen, char *serviceName, char *keytab,
                                         cuwa_session_t **sessionOut);
int cuwa_session_get_sessionid( cuwa_session_t *session, uint64 *sessionid );
cuwa_err_t cuwa_session_to_cookie( cuwa_session_t *session, char **cookie, int *cookieLen );
cuwa_err_t cuwa_session_get_req_size(cuwa_session_t *session, apr_off_t *size);
void cuwa_session_get_use_file_name( apr_pool_t *pool, char *path, char **fileName );
void cuwa_session_get_req_file_name( apr_pool_t *pool, char *path, char **fileName );
void cuwa_session_get_primary_file_name( apr_pool_t *pool, char *path, char **fileName );
cuwa_err_t cuwa_session_get_access_time( char *file, apr_pool_t *pool, apr_time_t *mtime );
int cuwa_session_garbage_collect( cuwa_session_t *session,int force);
cuwa_err_t cuwa_session_from_sessionid( void *req, apr_pool_t *pool, CUWACfg_t *cfg, uint64 sessionid, cuwa_session_t **sessionOut);
cuwa_err_t cuwa_session_check_session_path( char *, apr_pool_t * );
void  cuwa_session_update_permit_cache( void *r, apr_pool_t *pool, void *s, CUWACfg_t *cfg, char *cachePermits );
const char *cuwa_session_get_proxy_cookie(cuwa_session_t *session, const char *proxy);
void cuwa_session_save_proxy_cookie(cuwa_session_t *session, const char *proxy, const char *val);
const char *cuwa_session_get_proxy_cookies(cuwa_session_t *session, const char *proxy);
void cuwa_session_save_proxy_cookies(cuwa_session_t *session, const char *proxy, const char *val);

#define cuwa_session_get_permit_cache( session ) session->permitList
#define cuwa_session_get_attributes( session ) session->cred?cuwa_cred_get_attributes(session->cred):NULL
#define cuwa_session_get_attribute(session,key,idx) (session)->cred?cuwa_cred_get_attribute((session)->cred,(key),(idx)):NULL;

cuwa_err_t cuwa_session_do_write( cuwa_session_t *session, char *buf, int count);
cuwa_err_t cuwa_session_get_session_file_path(char **pathOut, cuwa_session_t *session, int idToUse);

cuwa_err_t cuwa_session_encryption_write( cuwa_session_t *session, char *buf, int count );
cuwa_err_t cuwa_session_encryption_read( cuwa_session_t *session, char *buf, apr_size_t *count );
cuwa_err_t cuwa_session_encryption_done( cuwa_session_t *session );
cuwa_err_t cuwa_session_encryption_set( cuwa_session_t *session );

cuwa_err_t cuwa_session_get_access_time_uid( char *file, apr_pool_t *pool, apr_time_t *mtime, apr_uid_t *uid );

#endif
