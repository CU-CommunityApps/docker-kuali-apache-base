/************************************************************************
 * session_garbage_collect.c -- Garbage collection for session caches
 *
 * Copyright 2007 Cornell University.
 * All Rights Reserved.
 *
 ************************************************************************
 *  $Log: session_garbage_collect.c,v $
 *  Revision 1.20  2015/10/07 17:39:18  hy93
 *  merge TwoFactor treee to the head
 *
 *  Revision 1.19.2.1  2015/04/15 14:36:23  hy93
 *  fix compiler warning in Windows build
 *
 *  Revision 1.19  2012/07/03 19:42:21  hy93
 *  remove checking if current process is the same as the owner of sessionFile in Windows
 *
 *  Revision 1.18  2010/12/23 19:57:19  hy93
 *  add warning in log when cuwebauth can't do garbage collection
 *
 *  Revision 1.17  2010/12/23 19:47:39  hy93
 *  add warning in log when cuwebauth can't do garbage collection
 *
 *  Revision 1.16  2008/08/26 19:53:47  hy93
 *  fix compiler warning on windows
 *
 *  Revision 1.15  2008/08/21 01:31:23  hy93
 *  replace ap_make_full_path with cuwa_make_full_path
 *
 *  Revision 1.14  2008/08/20 21:03:53  gbr4
 *  add missing #include -- this depends on ap_make_full_path
 *
 *  Revision 1.13  2008/08/19 19:58:21  hy93
 *  garbage collection enhancement
 *
 *  Revision 1.12  2008/07/25 18:58:07  hy93
 *  permit cache support
 *
 *  Revision 1.11  2008/05/30 21:26:26  pb10
 *  Removed code that cleans up replay file (which is no longer being used).
 *
 *  Revision 1.10  2008/04/24 20:07:37  gbr4
 *  win32 warning cleanup pass.
 *
 *  Revision 1.9  2008/04/18 04:17:34  pb10
 *  Add replayed file to track when the request has been replayed. This is done
 *  to avoid replaying the request multiple times (very bad with POST).
 *
 *  Revision 1.8  2008/04/11 03:51:09  gbr4
 *  More ugly hacks to support Win32. Actually I think CVS's acronym is more descriptive (woe).
 *  It actually fully compiles now. I am sure that it doesn't run yet without even testing it :-)
 *
 *  In the very least permit.c needs its ioctl call changed to something more portable.
 *
 *  Revision 1.7  2008/04/03 19:57:38  hy93
 *  remove warning
 *
 *  Revision 1.6  2008/04/02 20:13:13  hy93
 *  error code change
 *
 *  Revision 1.5  2008/03/24 19:09:10  hy93
 *  Modified the way to clean session caches based on the modified timestamp of session use file
 *
 *  Revision 1.4  2008/03/19 16:38:45  hy93
 *  changed the call show_apr_error to macro
 *
 *  Revision 1.3  2008/03/11 17:55:35  hy93
 *  Do garbage collection also based on inactivityTimeout
 *
 *  Revision 1.2  2008/03/11 14:05:49  hy93
 *  change return code
 *
 *  Revision 1.1  2008/03/10 18:20:07  hy93
 *  support garbage collection on session cache files
 *
 *
 ************************************************************************
 */

#include <session.h>
#include <apr_pools.h>
#include <log.h>
#include <cfg.h>
#include <list.h>
#include <apr_strings.h>
#include <cuwa_parse.h>

#define CUWA2_LOG_DOMAIN cuwa.session.garbage

//if CUWAsessionCleanupTime is not set by administrator, we will cleanup session caches every 5 minutes
#define CUWA_SESSION_DEFAULT_CLEANUP_TIME 5*60

//find the oldest session and delete it so we can have some disk space for new session
void cuwa_session_free_space( apr_dir_t *dirp, char *sessionFilePath, cuwa_session_t *session )
{
    apr_finfo_t dirent;
    apr_time_t soonest = 0, accessTime;
    char *path,*reqFile,*primaryFile,*useFile;
    char *oldestSessionid = NULL;
    apr_pool_t *pool = session->pool;
    apr_status_t rv;

    cuwa_trace("in session_free_space");
    while (apr_dir_read(&dirent, APR_FINFO_DIRENT, dirp) == APR_SUCCESS)
    {
 	if ( (path = strstr(dirent.name,".use")) )
        {
            if ( strstr( session->useFile, dirent.name ) )
                continue;

            *path ='\0';

            path = cuwa_make_full_path(pool, sessionFilePath, dirent.name);
            cuwa_session_get_use_file_name( pool, path, &useFile );

            if ( !cuwa_session_get_access_time( useFile, pool, &accessTime)) 
            {
                if ( !soonest || soonest > accessTime)
                {
                    soonest = accessTime;
                    oldestSessionid = apr_pstrdup( pool, path );
                }
            }
        }
    }
    if ( oldestSessionid )
    {
        cuwa_session_get_primary_file_name(pool, oldestSessionid, &primaryFile );
        cuwa_session_get_req_file_name(pool, oldestSessionid, &reqFile );
        cuwa_session_get_use_file_name( pool, oldestSessionid, &useFile );

        rv = apr_file_remove( primaryFile, pool );
        CUWA_SHOW_APR_ERROR(rv); 

        rv = apr_file_remove( reqFile, pool );
        CUWA_SHOW_APR_ERROR(rv);

        rv = apr_file_remove( useFile, pool );
        CUWA_SHOW_APR_ERROR(rv);

        cuwa_warning("Active session %s removed due to disk full", oldestSessionid);
    } 
}
    
int cuwa_session_do_garbage_collect(char *sessionFilePath, cuwa_session_t *session, int needSpace)
{
   //loop through all the session cache, find the one whose endTime passed current time, then remove them
   apr_time_t timeNow = apr_time_sec( apr_time_now() );
   apr_status_t rv;
   apr_dir_t *dirp;
   apr_finfo_t dirent;
   char *useFile,*primaryFile,*reqFile;
   char *path;
   cuwa_err_t rc = CUWA_OK;
   apr_time_t accessTime;
   int checkCleanup;
   apr_pool_t *pool = session->pool;
   int sessionRemoved = 0;

   cuwa_trace("Garbage collect directory %s", sessionFilePath);
   rv = apr_dir_open(&dirp, sessionFilePath, pool);
   FAIL_IF_FILE_ERROR(rv); 
   
   while (apr_dir_read(&dirent, APR_FINFO_DIRENT, dirp) == APR_SUCCESS)
   {
       checkCleanup = 0;
           
       if ( (path = strstr(dirent.name,".req")) )
       {
           checkCleanup = 1;
       }
       else if ( (path = strstr(dirent.name,".use")) )
       {
           checkCleanup = 2;
       }

       if ( checkCleanup > 0)
       {
           *path ='\0';

           if ( strstr( session->useFile, dirent.name) )
                continue;

           path = cuwa_make_full_path(pool, sessionFilePath, dirent.name);
           cuwa_session_get_req_file_name( pool, path, &reqFile );
           cuwa_session_get_use_file_name( pool, path, &useFile );
           cuwa_session_get_primary_file_name(pool, path, &primaryFile );

           if ( checkCleanup == 1)
           {
               //use session endTime to check if session expired
               rc = cuwa_session_get_access_time( reqFile, pool, &accessTime);
           }
           else 
           {
               //use inactivity timeout to check if session expired
               rc = cuwa_session_get_access_time( useFile, pool, &accessTime);
           }

           if ( (rc == CUWA_OK) && (timeNow > accessTime))
           {
               //session expired. Remove session

               cuwa_trace("Remove session cache %s, mtime=%u, now=%u",path, accessTime,timeNow);

               apr_file_remove( primaryFile, pool );
               apr_file_remove( reqFile, pool );
               apr_file_remove( useFile, pool );

               sessionRemoved = 1;
           }
        }
   }
   rc = CUWA_OK;

   //if we need space for new session and all sessions are active, we are going to delete the oldest session
   if ( needSpace && !sessionRemoved )
   {
       if (!apr_dir_rewind(dirp))
           cuwa_session_free_space( dirp, sessionFilePath, session );
   }

cleanup:
   if (dirp)
       apr_dir_close(dirp);

   timeNow = apr_time_sec( apr_time_now() ) - timeNow;

   cuwa_trace("Garbage collect took %u", timeNow);

   return rc;
}

/**
 * cuwa_session_garbage_collect Decide if we need to cleanup session cache files
 * @param[in] session The session.
 * @param[in] force 1 - performed garbage collection no matter what and delete oldest session if all sessions are active 0 - performed garbage collection only if current time exceed last cleanup time by CUWAsessionCleanupTime or our default cleanup time
 * @param[in] needSpace 1 - need to free space. If all the sessions are active, oldest session will be removed. 0 - just cleanup expired sessions.
 * @param[out] OK or CUWA_ERR .
 */
int cuwa_session_garbage_collect( cuwa_session_t *session , int force)
{
    char *path, *fileName;
    int *cleanupTimePtr = NULL;
    int cleanupTime = 0;
    apr_time_t lastCleanupTime;
    cuwa_err_t rc = CUWA_OK;
    apr_status_t rv;
    apr_file_t *pFile;
    apr_time_t timeNow = apr_time_sec( apr_time_now() );
    int type;
    apr_uid_t uid;
#ifndef WIN32
    apr_uid_t currentUid;
    apr_gid_t groupid;
#endif

    cuwa_trace("In cuwa_session_garbage_collect,force=%d",force);
    if ( !force )
    {
        cleanupTimePtr =  CFG_CUWAsessionCleanupTime(session->cfg);
        if ( cleanupTimePtr )
        {
            cleanupTime = *cleanupTimePtr;
        }
        else
            cleanupTime = CUWA_SESSION_DEFAULT_CLEANUP_TIME;

        cuwa_trace("cuwa session cleanup time %d", cleanupTime);
    }

    path = CFG_CUWAsessionFilePath(session->cfg);
    if (!path)
        path = CUWA_SESSION_DEFAULT_PATH;

    //check the last garbage collection time
    fileName = apr_psprintf(session->pool,"%s/%s", path,"cleanup.time");

    rc = cuwa_session_get_access_time_uid( fileName, session->pool, &lastCleanupTime, &uid );
    if ( rc == CUWA_ERR_SESSION_NOT_FOUND )
    {
        //cleanup file not exist yet, create one
        cuwa_trace("create clean up file %s", fileName);

        rv = apr_file_open( &pFile, fileName, APR_WRITE|APR_CREATE, APR_UREAD|APR_UWRITE, session->pool );
        FAIL_IF_FILE_ERROR( rv );
        apr_file_close(pFile);

        rc = CUWA_OK;
    }
#ifndef WIN32
    else if ( rc == CUWA_OK )
    { 
        rv = apr_uid_current( &currentUid, &groupid, session->pool);
        if (!rv)
        { 
            //check if current uid is the ower of the cleanup file. If not, output error message in the log. This is to warn user 
            //don't use same sessionFilePath for all apache instances. Otherwise, it causes session caches not cleaned up
            if ( uid != currentUid )
            {
                cuwa_warning("User(%d) can not clean up expired session files in %s. Define CUWAsessionFilePath to use different directory for each webServer instance.",currentUid, path);
                return CUWA_ERR;
            }
        }
    }
#endif

    if ( force || (( timeNow - lastCleanupTime ) > cleanupTime) )
    {
        type = APR_FLOCK_EXCLUSIVE;
        if (!force )
            type = type | APR_FLOCK_NONBLOCK;

        //do garbage collection
        rv = apr_file_open(&pFile, fileName, APR_WRITE, APR_OS_DEFAULT, session->pool);
        if ( !rv )
        {
            if ( apr_file_lock( pFile,type ) == APR_SUCCESS )
            {
                //update last modified time
                apr_file_mtime_set( fileName,apr_time_now(), session->pool);

                rc = cuwa_session_do_garbage_collect(path, session, force);

                apr_file_unlock(pFile);

            }
            apr_file_close(pFile);
        }
    }
cleanup:
    return rc;
}

const char id_session_session_garbage_collect_c[] = "$Id: session_garbage_collect.c,v 1.20 2015/10/07 17:39:18 hy93 Exp $";
