#include <stdio.h>
#include <session.h>
#include <kutil.h>
#include <log.h>
#include <cred_session.h>

#define CUWA2_LOG_DOMAIN cuwa.session.test

static char *thehost = "http://pine.cit.cornell.edu";

int login( uint64 sessionid, char **cred, char *netid, char *passwd, char *serviceid)
{
    cuwa_err_t err, rc=0;
    kutil_session_t ksess = NULL;
    char *k2=NULL,*k2_64=NULL;
    int k2len, k2_64Len;

    err = kutil_login(&ksess, netid, passwd);

    FAIL_IF(err,err);

    cuwa_trace("login: sessionid=%llu\n", sessionid);
    err = cuwa_krb_make_k2( NULL, thehost, serviceid, &sessionid, 1, &k2, &k2len, NULL );

    FAIL_IF(err,err);

    err = cuwa_base64_make_wa(&k2_64, &k2_64Len, k2len, 1, k2, k2len);

    FAIL_IF(err,err);	

cleanup:

    if (ksess) kutil_end_session(ksess);

    if (k2) free(k2);

    *cred = k2_64;
    cuwa_trace("DONE LOGIN, rc=%d\n",rc);

    return rc;
}

int check_session( cuwa_session_t *session,char *req ,char *netid)
{
    cuwa_err_t sts = CUWA_OK;
    char *buf =NULL;
    int len;

    cuwa_trace("About to check session \n");
    sts = cuwa_session_open_request( session, 0);

    buf = malloc(len+1);
    cuwa_assert(buf);

    sts = cuwa_session_read_request( session, buf, &len);
    if ( sts == CUWA_ERR_SESSION_EOF)
        sts = CUWA_OK;

    if ( sts )
        goto cleanup;

    if ( strcmp( buf, req) )
        cuwa_trace("read failed\n");
    else
        cuwa_trace("read succeed\n");

    free(buf);
    buf=NULL;

    cuwa_session_close_request( session );

    sts = cuwa_session_get_netid( session, &buf);
    if ( sts )
  	cuwa_trace("session_get_netid return %d\n", sts);
    else
    {
    if ( strcmp( buf, netid ) )
        cuwa_trace("test netid failed, buf=%s, netid=%s\n", buf, netid);
    else
        cuwa_trace("test netid succeed\n");
    }

    cuwa_session_get_realm( session, &buf);
    cuwa_trace("realm %s\n", buf);

cleanup:

    return sts;
}
#define syntax_check(c) do {if(argc<c){ cuwa_trace("syntax: test_session netid password serviceid keytab\n"); return 0;}} while (0)

int main(int argc, char *argv[])
{
    apr_pool_t *pool;

    cuwa_session_t *session, *session1;
    cuwa_err_t sts;
    char req[]="This is a test";
    uint64 sessionID;
    char *cred = NULL;
    char *netid = argv[1];
    char *passwd = argv[2];
    char *serviceid = argv[3];
    char *keytab = argv[4];
    int len, rc=0;
    char *buf = NULL;
    CUWACfg_t cfg;
    char test_path[] = "/users/hy93/apache/apache_2.0.59/logs";
    int timeout = 1;

    syntax_check(4);

    CFG_CUWAinactivityTimeout(&cfg)  = &timeout;
    CFG_CUWAsessionFilePath(&cfg) = test_path;

    apr_pool_initialize();
    apr_pool_create( &pool, NULL );

    sts = cuwa_session_new(pool, &cfg, &session);
    if ( sts )
        goto cleanup1;

    sts = cuwa_session_open_request( session, 1);
    if ( sts )
        goto cleanup2;

    len = strlen( req );
    cuwa_trace("About to write request, len=%d\n", len);
    sts = cuwa_session_write_request( session,req, len);
    if ( sts )
        goto cleanup3;

    cuwa_session_close_request( session );

    cuwa_session_get_sessionid( session, &sessionID );

    cuwa_session_release( session );
    session = NULL;

    cuwa_trace("About to log in,sessionID=%llu ...\n",sessionID);
    sts = login( sessionID, &cred, netid, passwd, serviceid );

    if ( sts )
        goto cleanup1;

    cuwa_trace("\n****test cuweblogin credential\n");
    sts = cuwa_session_from_credential( pool, &cfg, thehost, cred, strlen(cred), NULL, 0, serviceid, keytab, &session);
    if ( sts )
        goto cleanup1;

    sts = check_session( session, req, netid);
    if ( sts )
        goto cleanup2;

    sts = cuwa_session_to_cookie( session, &buf, &len );
    if ( sts )
        goto cleanup2;


    cuwa_session_release( session );

    sleep(40);

    cuwa_trace("\n****test cookie credential\n");
    sts = cuwa_session_from_credential( pool, &cfg, thehost,NULL, 0, buf, len, serviceid, keytab,&session );
    if ( sts )
        goto cleanup1;

    sts = check_session( session, req, netid );
    if ( sts )
        goto cleanup2;

    cuwa_session_release( session );

    sleep(30);

    cuwa_trace("\n****test cookie credential again\n");
    sts = cuwa_session_from_credential( pool, &cfg, thehost,NULL, 0, buf, len, serviceid, keytab,&session );
    if ( sts )
        goto cleanup1;

    sts = check_session( session, req, netid );
    if ( sts )
        goto cleanup2;

    cuwa_session_release( session );

/*
    printf("test cuwl credential when session is in active state, but no cookie\n");
    sts = cuwa_session_from_credential( pool, &cfg, thehost,cred, strlen(cred), NULL, 0, serviceid, keytab,&session );
    if ( sts )
        goto cleanup1;
    sts = check_session( session, req, netid );
    if ( sts )
        goto cleanup2;
    cuwa_session_release(session );
    sleep(60);
*/
    cuwa_trace("\n****test cookie credential when cuwl credential also exist\n");
    sts = cuwa_session_from_credential( pool, &cfg, thehost, cred, strlen(cred), buf, len, serviceid, keytab,&session );
    if ( sts )
        goto cleanup1;

    sts = check_session( session, req, netid );
    if ( sts )
        goto cleanup2;

    cuwa_session_release( session );

    sleep(60);
    cuwa_trace("\n****test credential expired\n");
    sts = cuwa_session_from_credential( pool, &cfg, thehost, cred, strlen(cred), buf, len, serviceid, keytab,&session );
    if ( sts == CUWA_ERR_SESSION_EXPIRED)
    {
        cuwa_trace("session expired, as expected\n");
        sts = CUWA_OK;
    }
    else
    {
        sts = CUWA_ERR;
        goto cleanup2;
    }

    cuwa_session_release( session );

cleanup3:
    if ( sts )
        cuwa_session_close_request( session );

cleanup2:
    if ( sts )
        cuwa_session_release( session );

cleanup1:
    if ( cred )
        free(cred);

    if (buf)
        free(buf);

    if ( sts )
        cuwa_trace("test failed\n");
    else
        cuwa_trace("test succeed\n");

    return 1;
}
const char id_session_test_session_c[] = "$Id: test_session.c,v 1.12 2008/07/14 14:47:44 pb10 Exp $";
