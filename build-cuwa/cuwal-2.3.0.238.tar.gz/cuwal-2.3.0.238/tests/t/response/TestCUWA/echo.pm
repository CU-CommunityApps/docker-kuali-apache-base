package TestCUWA::echo;

use strict;
use warnings FATAL => 'all';
use Apache2::RequestRec;
use Apache2::RequestIO;
use Apache2::SubRequest ();

use APR::Brigade ();
use APR::Bucket ();
use Apache2::Filter ();
use Apache2::Connection ();
use constant IOBUFSIZE => 8192;


use Apache2::Const -compile => qw(MODE_READBYTES OK);
use APR::Const    -compile => qw(SUCCESS BLOCK_READ);

sub handler{
	my $r = shift;
	$r->subprocess_env; #pick up ENV hash
	if($ENV{QUERY_STRING} =~ m/content_type=([^&]*)/){
		$r->content_type($1);
	}else{
		$r->content_type('text/plain');
	}
	$r->write("TestCUWA::echo\n");
	$r->write($ENV{SERVER_PROTOCOL} . " " . $ENV{REQUEST_METHOD} . " " . $ENV{REQUEST_URI} . "\n");

	foreach my $var (sort(keys(%ENV))) {
		my $val = $ENV{$var};
		if(defined $val){
			$val =~ s|\n|\\n|g;
			$val =~ s|"|\\"|g;
			$r->write("${var}=\"${val}\"\n");
		}
	}
	my $user=$r->user();
	$user="" unless defined $user;
	$r->write("APACHE2_REQUESTREC_USER=\"$user\"\n");
	my $qs=$ENV{QUERY_STRING};
	my ($action,$method)=("","");
	foreach my $qa (split(/&/,$qs)){
		my ($qan,$qav) = split(/=/,$qa);
		if(defined($qav)){
			if($qan =~ m/^ir$/i){
				$r->write("<InternalRedirect uri=\"$qav\">\n");
				$r->internal_redirect($qav);
				$r->write("</InternalRedirect uri=\"$qav\">\n");
			}
			if($qan =~ m/^sr$/i){
				$r->write("<Subrequest uri=\"$qav\">\n");
				$r->lookup_uri($qav)->run;
				$r->write("</Subrequest uri=\"$qav\">\n");
			}
			if($qan =~ m/^form_action$/i){
				if($qav) {$action=" Action=\"$qav\"";}
			}
			if($qan =~ m/^form_method$/i){
				if($qav) {$method=" Method=\"$qav\"";}
			}
			if($qan =~ m/^form$/i){
				$r->write("<form$action$method>\n");
				$r->write("<input type=\"hidden\" name=\"hname1\" value=\"hvalue1\"/>\n");
				$r->write("<input type=\"text\" name=\"text\" value=\"default\"/>\n");
				$r->write("<input type=\"submit\" name=\"submit\" value=\"ok\"/>\n");
				$r->write("</form>\n");
			}
		}
	}
	if($ENV{REQUEST_METHOD} eq "POST"){
		$r->write("<PostData>\n");
		$r->write(read_post($r));
		$r->write("\n");
		$r->write("</PostData>\n");
	}

	Apache2::Const::OK;
}

#stolen from mod_perl's TestCommon::Util
sub read_post {
    my $r = shift;
    my $debug = shift || 0;

    my $bb = APR::Brigade->new($r->pool,
                               $r->connection->bucket_alloc);

    my $data = '';
    my $seen_eos = 0;
    my $count = 0;
    do {
        $r->input_filters->get_brigade($bb, Apache2::Const::MODE_READBYTES,
                                       APR::Const::BLOCK_READ, IOBUFSIZE);

        $count++;

        warn "read_post: bb $count\n" if $debug;

        while (!$bb->is_empty) {
            my $b = $bb->first;

            if ($b->is_eos) {
                warn "read_post: EOS bucket:\n" if $debug;
                $seen_eos++;
                last;
            }

            if ($b->read(my $buf)) {
                warn "read_post: DATA bucket: [$buf]\n" if $debug;
                $data .= $buf;
            }

            $b->delete;
        }

    } while (!$seen_eos);

    $bb->destroy;

    return $data;
}


1;
__DATA__
<NoAutoConfig>
#	<VirtualHost TestCUWA::echo>

<Location /TestCUWA__echo.pl>
	SetHandler modperl
	PerlResponseHandler TestCUWA::echo
</Location>

<Location /TestCUWA__echo.pl/restricted>
	SetHandler modperl
	PerlResponseHandler TestCUWA::echo
	AuthType all
	AuthName cornell
	require valid-user
</Location>

<Location /TestCUWA__echo.pl/restricted/K3>
	SetHandler modperl
	PerlResponseHandler TestCUWA::echo
	AuthType all
	AuthName cornell
	require valid-user
	CUWAWAK2Flags 1
</Location>


<Location /TestCUWA__echo.pl/r/valid-user>
	SetHandler modperl
	PerlResponseHandler TestCUWA::echo
	AuthType all
	AuthName cornell
	require valid-user
</Location>

<Location /TestCUWA__echo.pl/r/valid-user-cit>
	SetHandler modperl
	PerlResponseHandler TestCUWA::echo
	AuthType all
	AuthName cornell
<IfVersion < 2.4.0>
	require valid-user@CIT.CORNELL.EDU
</IfVersion>
<IfVersion >= 2.4.0>
       require valid-user CIT.CORNELL.EDU
</IfVersion>
</Location>

<Location /TestCUWA__echo.pl/r/valid-user-dev>
	SetHandler modperl
	PerlResponseHandler TestCUWA::echo
	AuthType all
	AuthName cornell
<IfVersion < 2.4.0>
	require valid-user@DEV.CORNELL.EDU
</IfVersion>
<IfVersion >= 2.4.0>
       require valid-user DEV.CORNELL.EDU
</IfVersion>
</Location>

<Location /TestCUWA__echo.pl/r/citonly>
	SetHandler modperl
	PerlResponseHandler TestCUWA::echo
	AuthType all
	AuthName cornell
	CUWAWAK0Realms CIT.CORNELL.EDU
<IfVersion < 2.4.0>
	require valid-user@CIT.CORNELL.EDU
</IfVersion>
<IfVersion >= 2.4.0>
       require valid-user CIT.CORNELL.EDU
</IfVersion>
</Location>

<Location /TestCUWA__echo.pl/r/dev-implied>
SetHandler modperl
PerlResponseHandler TestCUWA::echo
AuthType all
AuthName cornell
CUWAWAK0Realms CIT.CORNELL.EDU
<IfVersion < 2.4.0>
    require valid-user@CIT.CORNELL.EDU
    require valid-user@DEV.CORNELL.EDU
</IfVersion>
<IfVersion >= 2.4.0>
    require valid-user CIT.CORNELL.EDU
    require valid-user DEV.CORNELL.EDU
</IfVersion>
</Location>

<Location /TestCUWA__echo.pl/r/alias-citonly>
SetHandler modperl
PerlResponseHandler TestCUWA::echo
AuthType all
AuthName cornell
CUWAWAK0Realms "DevID,NetID"
<IfVersion < 2.4.0>
    require valid-user@CIT.CORNELL.EDU
</IfVersion>
<IfVersion >= 2.4.0>
     require valid-user CIT.CORNELL.EDU
</IfVersion>
</Location>

<Location /TestCUWA__echo.pl/r/alias>
SetHandler modperl
PerlResponseHandler TestCUWA::echo
AuthType all
AuthName cornell
CUWAWAK0Realms "DevID,NetID"
<IfVersion < 2.4.0>
    require valid-user@CIT.CORNELL.EDU
    require valid-user@DEV.CORNELL.EDU
</IfVersion>
<IfVersion >= 2.4.0>
    require valid-user CIT.CORNELL.EDU
    require valid-user DEV.CORNELL.EDU
</IfVersion>
</Location>


<Location /TestCUWA__echo.pl/r/netid/cuwa-test>
	SetHandler modperl
	PerlResponseHandler TestCUWA::echo
	AuthType all
	AuthName cornell
	require netid cuwa-test
</Location>

<Location /TestCUWA__echo.pl/r/netid-dev/cuwa-test>
	SetHandler modperl
	PerlResponseHandler TestCUWA::echo
	AuthType all
	AuthName cornell
	require netid cuwa-test@DEV.CORNELL.EDU
</Location>

<Location /TestCUWA__echo.pl/r/GUESTX/valid>
	SetHandler modperl
	PerlResponseHandler TestCUWA::echo
	AuthType all
	AuthName cornell
        AuthName cornell
<IfVersion < 2.4.0>
	require valid-user@GUESTX.CORNELL.EDU
</IfVersion>
<IfVersion >= 2.4.0>
         require valid-user GUESTX.CORNELL.EDU
</IfVersion>
</Location>

<Location /TestCUWA__echo.pl/r/GUESTX/cuwa-test>
	SetHandler modperl
	PerlResponseHandler TestCUWA::echo
	AuthType all
	AuthName cornell
	require netid cuwa.test@GUESTX.CORNELL.EDU
</Location>

<Location /TestCUWA__echo.pl/r/GUESTX/dual>
	# this is a nonsensical configuration because GUESTX is
	# not a dual-factor-enabled realm. I just want to make sure
	# that weblogin gives the right error message.
	SetHandler modperl
	PerlResponseHandler TestCUWA::echo
	AuthType all
	AuthName cornell
        CUWA2FARequire all
        CUWA2FAMethod DUO
<IfVersion < 2.4.0>
	require valid-user@GUESTX.CORNELL.EDU
</IfVersion>
<IfVersion >= 2.4.0>
         require valid-user GUESTX.CORNELL.EDU
</IfVersion>
</Location>

<Location /TestCUWA__echo.pl/r/netid-cit/cuwa-test>
	SetHandler modperl
	PerlResponseHandler TestCUWA::echo
	AuthType all
	AuthName cornell
	require netid cuwa-test@CIT.CORNELL.EDU
</Location>

<Location /TestCUWA__echo.pl/r/netid/ns10-demo>
	SetHandler modperl
	PerlResponseHandler TestCUWA::echo
	AuthType all
	AuthName cornell
	require netid ns10-demo
</Location>


<Location /TestCUWA__echo.pl/r/netid/few-test>
	SetHandler modperl
	PerlResponseHandler TestCUWA::echo
	AuthType all
	AuthName cornell
	require netid ns10-demo cuwa-test
</Location>

<Location /TestCUWA__echo.pl/r/netid/few-notest>
	SetHandler modperl
	PerlResponseHandler TestCUWA::echo
	AuthType all
	AuthName cornell
	require netid  pb10 hy93
</Location>
<Location /TestCUWA__echo.pl/r/returnurl>
        SetHandler modperl
        PerlResponseHandler TestCUWA::echo
        CUWAReturnURL http://localhost.cornell.edu:8529%p
        AuthType all
        AuthName cornell
        require valid-user
</Location>

<Location /TestCUWA__echo.pl/r/dualauth>
        SetHandler modperl
        PerlResponseHandler TestCUWA::echo
        AuthType all
        AuthName cornell
        require valid-user
        CUWA2FARequire all
        CUWA2FAMethod TEST 
</Location>

<Location /TestCUWA__echo.pl/r/dualauthcookie>
        SetHandler modperl
        PerlResponseHandler TestCUWA::echo
        AuthType all
        AuthName cornell
        require valid-user
        CUWA2FARequire all
</Location>

<Location /TestCUWA__echo.pl/r/dualauthmethod>
        SetHandler modperl
        PerlResponseHandler TestCUWA::echo
        AuthType all
        AuthName cornell
        require valid-user
        CUWA2FARequire cuwa-test.public-yes,cuwa-test.public-no
        CUWA2FAMethod TEST
</Location>

<Location /TestCUWA__echo.pl/r/dualauthpermit>
        SetHandler modperl
        PerlResponseHandler TestCUWA::echo
        AuthType all
        AuthName cornell
        require valid-user
        CUWA2FARequire cuwa-test.public-yes,cuwa-test.public-no
        CUWA2FAMethod TEST
</Location>

<Location /TestCUWA__echo.pl/r/dualauthmethodduo>
	# want to make sure that a valid TEST 2f cannot get in here because it requires DUO
        SetHandler modperl
        PerlResponseHandler TestCUWA::echo
        AuthType all
        AuthName cornell
        require valid-user
        CUWA2FARequire all
        CUWA2FAMethod DUO
</Location>

<Location /TestCUWA__echo.pl/r/dualauth-inactivityTimeout-10>
        SetHandler modperl
        PerlResponseHandler TestCUWA::echo
        AuthType all
        AuthName cornell
        require valid-user
        CUWA2FARequire all
        CUWA2FAMethod TEST 
        CUWAinactivityTimeout 10
        CUWACredentialAge 600
</Location>

<Location /TestCUWA__echo.pl/r/dualauth-inactivityTimeoutAndCredentialAge-10>
        SetHandler modperl
        PerlResponseHandler TestCUWA::echo
        AuthType all
        AuthName cornell
        require valid-user
        CUWA2FARequire all
        CUWA2FAMethod TEST 
        CUWAinactivityTimeout 10
        CUWACredentialAge 10
</Location>

<Location /TestCUWA__echo.pl/r/dualauth-K3>
        SetHandler modperl
        PerlResponseHandler TestCUWA::echo
        AuthType all
        AuthName cornell
        require valid-user
        CUWA2FARequire all
        CUWA2FAMethod TEST
	CUWAWAK2Flags 1
</Location>

<Location /restricted2FA>
        AuthType all
        AuthName cornell
        require valid-user
        CUWA2FARequire cuwa-test.public-yes,cuwa-test.public-no
        CUWA2FAMethod TEST
</Location>

#	</VirtualHost>
</NoAutoConfig>
