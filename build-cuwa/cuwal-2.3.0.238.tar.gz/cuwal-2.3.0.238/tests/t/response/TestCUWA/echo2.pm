package TestCUWA::echo2;

my @ISA = TestCUWA::echo;

1;
__DATA__
<NoAutoConfig>
#	<VirtualHost TestCUWA::echo>

<Location /TestCUWA__echo2.pl>
	SetHandler modperl
	PerlResponseHandler TestCUWA::echo
</Location>

<Location /TestCUWA__echo2.pl/r/p/cuwa-test.public-yes>
	SetHandler modperl
	PerlResponseHandler TestCUWA::echo
	AuthType all
	AuthName cornell
	require permit cuwa-test.public-yes
</Location>
<Location /TestCUWA__echo2.pl/r/p/cuwa-test.public-no>
	SetHandler modperl
	PerlResponseHandler TestCUWA::echo
	AuthType all
	AuthName cornell
	require permit cuwa-test.public-no
</Location>
<Location /TestCUWA__echo2.pl/r/p/cuwa-test.exist-no>
        SetHandler modperl
        PerlResponseHandler TestCUWA::echo
        AuthType all
        AuthName cornell
        require permit cuwa-test.exist-no
</Location>

<Location /TestCUWA__echo2.pl/r/noprompt>
	SetHandler modperl
	PerlResponseHandler TestCUWA::echo
	AuthType all
	AuthName cornell
	require noprompt
	CUWAInquire "permit cuwa-test.public-yes cuwa-test.public-no"
</Location>


<Location /TestCUWA__echo2.pl/r/p2/cuwa-test.public-yes>
	SetHandler modperl
	PerlResponseHandler TestCUWA::echo
	AuthType all
	AuthName cornell
	require permit cuwa-test.public-no
	require permit cuwa-test.public-yes
</Location>


<Location /TestCUWA__echo2.pl/r/all>
        SetHandler modperl
        PerlResponseHandler TestCUWA::echo
        AuthType all
        AuthName cornell
        require valid-user
        CUWAInquire "permit all"
</Location>

<Location /TestCUWA__echo2.pl/r/p/cuwa-test.any1>
	SetHandler modperl
	PerlResponseHandler TestCUWA::echo
	AuthType all
	AuthName cornell
	require permit cuwa-test.public-yes cuwa-test.public-no cuwa-test.exist-no
</Location>
<Location /TestCUWA__echo2.pl/r/p/cuwa-test.any3>
	SetHandler modperl
	PerlResponseHandler TestCUWA::echo
	AuthType all
	AuthName cornell
	require permit cuwa-test.public-no cuwa-test.exist-no
	require permit cuwa-test.public-yes 
</Location>
<Location /TestCUWA__echo2.pl/r/p/cuwa-test.any4>
	SetHandler modperl
	PerlResponseHandler TestCUWA::echo
	AuthType all
	AuthName cornell
	cuwainquire "permit all"
	require permit cuwa-test.public-yes
</Location>

<Location /TestCUWA__echo2.pl/dual/p/cuwa-test.public-yes>
	SetHandler modperl
	PerlResponseHandler TestCUWA::echo
	AuthType all
	AuthName cornell
	CUWA2FARequire all
        CUWA2FAMethod TEST
	require permit cuwa-test.public-yes
</Location>
<Location /TestCUWA__echo2.pl/dual/p/cuwa-test.public-no>
	SetHandler modperl
	PerlResponseHandler TestCUWA::echo
	AuthType all
	AuthName cornell
	CUWA2FARequire all
        CUWA2FAMethod TEST
	require permit cuwa-test.public-no
</Location>
<Location /TestCUWA__echo2.pl/dual/p/cuwa-test.exist-no>
        SetHandler modperl
        PerlResponseHandler TestCUWA::echo
        AuthType all
        AuthName cornell
	CUWA2FARequire all
        CUWA2FAMethod TEST
        require permit cuwa-test.exist-no
</Location>


<Location /TestCUWA__echo2.pl/dual/all>
        SetHandler modperl
        PerlResponseHandler TestCUWA::echo
        AuthType all
        AuthName cornell
        require valid-user
	CUWA2FARequire all
        CUWA2FAMethod TEST
        CUWAInquire "permit all"
</Location>

<Location /TestCUWA__echo2.pl/dual/p/cuwa-test.any1>
	SetHandler modperl
	PerlResponseHandler TestCUWA::echo
	AuthType all
	AuthName cornell
	CUWA2FARequire all
        CUWA2FAMethod TEST
	require permit cuwa-test.public-yes cuwa-test.public-no cuwa-test.exist-no
</Location>
<Location /TestCUWA__echo2.pl/dual/p/cuwa-test.any3>
	SetHandler modperl
	PerlResponseHandler TestCUWA::echo
	AuthType all
	AuthName cornell
	CUWA2FARequire all
        CUWA2FAMethod TEST
	require permit cuwa-test.public-no cuwa-test.exist-no
	require permit cuwa-test.public-yes 
</Location>
<Location /TestCUWA__echo2.pl/dual/p/cuwa-test.any4>
	SetHandler modperl
	PerlResponseHandler TestCUWA::echo
	AuthType all
	AuthName cornell
	CUWA2FARequire all
        CUWA2FAMethod TEST
	cuwainquire "permit all"
	require permit cuwa-test.public-yes
</Location>




