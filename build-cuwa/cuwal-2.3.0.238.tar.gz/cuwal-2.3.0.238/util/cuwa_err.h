/************************************************************************
 * cuwa_err.h -- Lookup ownership of one or more permits
 *
 * Copyright 2007 Cornell University.
 * All Rights Reserved.
 *
 ************************************************************************
 *  $Log: cuwa_err.h,v $
 *  Revision 1.49  2016/08/24 17:34:06  hy93
 *  add error code
 *
 *  Revision 1.48  2015/10/07 18:32:51  hy93
 *  merge TwoFactor treee to the head
 *
 *  Revision 1.47.2.2  2015/06/30 15:24:16  hy93
 *  Apache 2.4 support
 *
 *  Revision 1.47.2.1  2014/10/22 17:50:11  hy93
 *  two factor support
 *
 *  Revision 1.47  2014/10/22 16:43:53  hy93
 *  remove two factor support
 *
 *  Revision 1.46  2014/10/21 17:57:52  hy93
 *  new error code
 *
 *  Revision 1.45  2014/07/25 17:42:49  hy93
 *  Apache 2.4 support
 *
 *  Revision 1.44  2014/07/25 17:40:55  hy93
 *  add error code for verifying signature
 *
 *  Revision 1.43  2013/07/30 19:20:38  hy93
 *  Two factor authentication support
 *
 *  Revision 1.42  2012/03/19 14:08:04  hy93
 *  change apr file error in warning level. Add a new error status to distinguish file read/write/stat error with file not exist
 *
 *  Revision 1.41  2010/06/17 14:17:44  hy93
 *  modify error message
 *
 *  Revision 1.40  2010/05/26 16:37:49  hy93
 *  fix error message
 *
 *  Revision 1.39  2010/05/21 16:38:49  hy93
 *  new error code
 *
 *  Revision 1.38  2010/05/04 15:41:41  hy93
 *  add error code
 *
 *  Revision 1.37  2010/03/19 17:29:44  hy93
 *  add error code
 *
 *  Revision 1.36  2009/08/06 20:04:06  hy93
 *  add a missing error message
 *
 *  Revision 1.35  2009/08/03 16:13:04  hy93
 *  add error code for permit decoding
 *
 *  Revision 1.34  2009/04/27 16:09:00  hy93
 *  moved the new errors in previous check in to the end of error codes
 *
 *  Revision 1.33  2009/04/20 17:00:38  hy93
 *  add error code and message
 *
 *  Revision 1.32  2008/12/17 17:26:29  gbr4
 *  FAIL_IF changed to include #error which will make some but not all error message
 *  s more descriptive.
 *
 *  Revision 1.31  2008/09/16 18:11:18  hy93
 *  add error code for iis config
 *
 *  Revision 1.30  2008/08/19 20:10:59  pb10
 *  Return a log on portal error.  Move permit portal code to auth.c.
 *
 *  Revision 1.29  2008/08/19 19:57:47  hy93
 *  more error code
 *
 *  Revision 1.28  2008/08/15 04:49:26  pb10
 *  Added table based attribute support to session code.
 *  Still need to put support into auth.c and lastly need to remove old code from everywhere.
 *
 *  Revision 1.27  2008/08/11 04:09:57  hy93
 *  add error code for proxy support
 *
 *  Revision 1.26  2008/08/04 16:04:34  hy93
 *  removed error code that doesn't need anymore
 *
 *  Revision 1.25  2008/07/25 18:51:51  hy93
 *  remove wal.h in util directory
 *
 *  Revision 1.24  2008/06/06 17:26:32  hy93
 *  add session replay error code
 *
 *  Revision 1.23  2008/05/06 02:15:34  gbr4
 *  add missing , between messages for  CUWA_ERR_CRED_TOO_OLD and CUWA_ERR_HIGH_AVAILABILITY
 *
 *  Revision 1.22  2008/04/24 14:14:46  hy93
 *  Add macro for APR SOCK ERR
 *
 *  Revision 1.21  2008/04/14 17:25:50  hy93
 *  add error code CUWA_ERR_SESSION_PATH_NOT_EXIST
 *
 *  Revision 1.20  2008/04/03 19:59:20  hy93
 *  replace cuwa_warning with cuwa_trace
 *
 *  Revision 1.19  2008/04/02 20:10:54  hy93
 *  add error code
 *
 *  Revision 1.18  2008/03/24 21:32:22  pb10
 *  Better error page support.
 *
 *  Revision 1.17  2008/03/19 20:30:13  pb10
 *  Moved weblogin credential parsing from the filter to mod_cuwebauth.c so that
 *  kerberos directives could be based on virtual host.
 *
 *  Revision 1.16  2008/03/19 16:40:09  hy93
 *  Add define CUWA_SHOW_APR_ERROR
 *
 *  Revision 1.15  2008/03/14 19:49:48  hy93
 *  add error code for obsolete authType
 *
 *  Revision 1.14  2008/03/13 18:59:09  pb10
 *  Added code to redirect to weblogin when session not found or timeout, per Hong's request.
 *  Added human readable messages to err_codes.  Not being displayed yet.
 *
 *  Revision 1.13  2008/03/11 14:06:15  hy93
 *  Add error code
 *
 *  Revision 1.12  2008/02/26 19:45:29  hy93
 *  add error code
 *
 *  Revision 1.11  2008/02/22 18:40:54  hy93
 *  use strerror instead of strerror_r because solaris doesn't support it
 *
 *  Revision 1.10  2008/02/22 15:42:34  hy93
 *  remove line feed
 *
 *  Revision 1.9  2008/01/28 16:00:12  gbr4
 *  errors shouldn't be trace
 *
 *  Revision 1.8  2008/01/10 18:00:48  hy93
 *  Add err code.
 *
 *  Revision 1.7  2008/01/02 04:42:09  pb10
 *  Added error codes.
 *
 *  Revision 1.6  2007/12/21 19:54:11  hy93
 *  Add error code.
 *
 *  Revision 1.5  2007/12/20 03:14:02  pb10
 *  Integration with session manager.
 *
 *  Revision 1.4  2007/12/05 19:06:08  hy93
 *  Add error code and a macro define
 *
 *  Revision 1.3  2007/11/07 03:24:32  pb10
 *  Added windows macro to circumvent the lack of __func__ define.  This should be moved to cuwa_types TBD.
 *
 *  Revision 1.2  2007/10/23 21:29:36  pb10
 *  Added support for cred manager.
 *
 *  Revision 1.1  2007/10/18 20:09:43  pb10
 *  initial
 *
 *
 ************************************************************************
 */

#ifndef _CUWA_ERR_H
#define _CUWA_ERR_H

#ifdef _MSC_VER
#if _MSC_VER < 1300
#define __FUNCTION__ "???"
#endif
#define __func__ __FUNCTION__
#endif


typedef enum
{
    CUWA_OK,
    CUWA_ERR = 5100, /* Arbitrary starting point so that CUWA error codes can be easily identified */
    CUWA_ERR_MEM,
    CUWA_ERR_DNS,
    CUWA_ERR_SOCK_CLOSED,
    CUWA_ERR_SOCK_TIMEOUT,
    CUWA_ERR_PERMIT_PROTO,
    CUWA_ERR_BAD_CRED,
    CUWA_ERR_KRB,
    CUWA_ERR_GSS,
    CUWA_ERR_BAD_UNWRAP,
    CUWA_ERR_SOCKET,
    CUWA_ERR_CRED_INVALID,
    CUWA_ERR_CRED_NOT_SUPPORTED,
    CUWA_ERR_CRED_WRONG_HOST,
    CUWA_ERR_CRED_ARTIFACT_INVALID,
    CUWA_ERR_CRED_MISSING,
    CUWA_ERR_SESSION_DB_ERR,
    CUWA_ERR_SESSION_NO_DISK_SPACE,
    CUWA_ERR_SESSION_NOT_FOUND,
    CUWA_ERR_SESSION_INVALID,
    CUWA_ERR_SESSION_EXPIRED,
    CUWA_ERR_SESSION_REPLAY,
    CUWA_ERR_SESSION_EOF,
    CUWA_ERR_SESSION_WRITE_INCOMPLETE,
    CUWA_ERR_SESSION_EXCEED_MAX_SESSION,
    CUWA_ERR_SESSION_PATH_NOT_EXIST,
    CUWA_ERR_BAD_SESSION,
    CUWA_ERR_REQUEST_SAVE,
    CUWA_ERR_THREAD_KEY,
    CUWA_ERR_AUTH_TYPE_OBSOLETE,
    CUWA_ERR_CRED_TOO_OLD,
    CUWA_ERR_HIGH_AVAILABILITY,
    CUWA_ERR_PORTAL,
    CUWA_ERR_PROXY_NO_K3,
    CUWA_ERR_PROXY,
    CUWA_ERR_SSL,
    CUWA_ERR_SSL_CONTEXT,
    CUWA_ERR_SSL_CERT_INVALID,
    CUWA_ERR_IIS_CONF,
    CUWA_ERR_IIS,
    CUWA_ERR_SESSION_SHA1,
    CUWA_ERR_SESSION_ENCRYPTION,
    CUWA_ERR_PERMIT_DECODE,
    CUWA_ERR_LDAP_NOT_EXIST,
    CUWA_ERR_LDAP,
    CUWA_ERR_BRIDGE_INIT,
    CUWA_ERR_PERMIT_CMD,
    CUWA_ERR_BRIDGE,
    CUWA_ERR_INVALID_CHAR,
    CUWA_ERR_UPDATE_DENY,
    CUWA_ERR_CREATE,
    CUWA_ERR_ARS_LOGIN,
    CUWA_ERR_SESSION_NO_DUAL,
    CUWA_ERR_AUTHZ_DENY,
    CUWA_ERR_BUFFER_SMALL,
    CUWA_ERR_MAX
} cuwa_err_t;

#define CUWA_ERR_TO_STR(e) ((e)<CUWA_ERR||(e)>=CUWA_ERR_MAX) ? NULL : cuwa_err_str[((e)-CUWA_ERR)+1]

#ifdef CUWA_ERR_STRINGS
const char *cuwa_err_str[] = {
    "No error was detected.",
    "A webauth/weblogin error occurred.",
    "Out of memory resources.",
    "DNS failure.",
    "Peer closing session was unexpected.",
    "TCP connection can't be established.",
    "Permit server protocol error (wrong server?).",
    "An invalid Kerberos credential was presented.",      // CUWA_ERR_BAD_CRED misused by session_mgr (FIXME)
    "A Kerberos error occurred.",
    "A GSSAPI error occurred.",
    "Encryption is required for GSS credential.",
    "Socket resource error.",                             // CUWA_ERR_SOCKET not used
    "Webauth/login credential is invalid.",
    "Webauth/login credential is not supported.",
    "Webauth/login credential intended for a different host, possibly a replay attack." ,
    "Webauth/login credential contains an invalid artifact.",
    "Your login is required to access a protected web page.",
    "A session database error occurred.",
    "No space to save session.",
    "Your session is no longer valid (not found).",
    "Your session is no longer valid (key invalid).",
    "Your session has expired (website session limit).",
    "Session replay by wa.",
    "The session file may be corrupted (unexpected EOF).",
    "Could not save session data.",
    "Maximum number of sessions exceeded.",
    "CUWAsessionFilePath doesn't exist. Please create it.",
    "Session file is corrupted.",                         // CUWA_ERR_BAD_SESSION not used
    "No idea what this error was!",                       // CUWA_ERR_REQUEST_SAVE not used
    "Thread key creation failed.",
    "AuthType obsolete.",                                 //CUWA_ERR_AUTH_TYPE_OBSOLETE
    "Your session has expired (website login limit).",
    "High Availability Error.",
    "Portal request has invalid format.",
    "k3 is not available in session.",
    "Proxy error.",
    "SSL connection error.",
    "Can not create SSL context.",
    "SSL cert error",
    "IIS conf file error",
    "IIS error.",
     "Hash SID failed.",
    "Data encryption failed.",
    "Permit config error.",
    "Requested ldap entry does not exist in AD.",
    "Search AD failed.",
    "Permit server failed at initialization.",
    "Permit command not supported or missing parameter.",
    "Error occured when handling permit command.",
    "Invalid characters in permit name.",                                                                          
    "User not allowed to update permit.",
    "Create group failed.",
    "Login to ARS server failed.",
    "User not authenticated with two factor",
    "Access denied.",
    "Buffer is not big enough"
};
#endif


/* EXPERIMENTAL

#define CUWA_TRY             cuwa_err_t cuwa_try_rc = CUWA_OK
#define CUWA_TRY_CATCH       cuwa_try_cleanup:
#define CUWA_TRY_END         return cuwa_try_rc
#define CUWA_TRY_THROW(err)  do {cuwa_try_rc=err;goto cuwa_try_cleanup;} while(0)

#define FAIL_IF(cond,errcode) do {if ((cond)) {cuwa_trace("Err: %s:%d %d",(char*)__func__,__LINE__,(errcode)); CUWA_TRY_THROW(errcode)}} while(0)
*/


/**
 * FAIL_IF macro handles general errors by jumping to cleanup code,
 * and appropriately logging event. Assumes that calling function defines
 * a "cleanup" label and an int called rc which is returned by the function.
 * @param[in] cond fmt format string (same as *printf)
 * @param[in] errcode function will return this error, should be of type kutil_err_t.
 */
#define FAIL_IF(cond,errcode) do {if ((cond)) {cuwa_warning("Err: %s:%d %d %s",(char*)__func__,__LINE__,(errcode),#errcode); rc = errcode; goto cleanup;}} while(0)

/**
 * FAIL_IF_KRB_ERR macro handles kerberos errors by jumping to cleanup code,
 * and appropriately logging event. Assumes that calling function defines
 * a "cleanup" label and an int called rc which is returned by the function.
 * @param[in] errcode code returned from kerberos function.  If this is an error,
 *            the calling function returns KTUTIL_ERR_KRB.
 */
#define FAIL_IF_KRB_ERR(errcode) do {if ((errcode)) {rc = CUWA_ERR_KRB; kutil_krb_error((char*)__func__,__LINE__,(errcode)); goto cleanup;}} while(0)

/**
 * FAIL_IF_GSS_ERR macro handles GSS errors by jumping to cleanup code,
 * and appropriately logging event. Assumes that calling function defines
 * a "cleanup" label and an int called rc which is returned by the function.
 * @param[in] errcode code returned from GSS function.  If this is an error the calling function returns KTUTIL_ERR_KRB.
 * @param[in] minor minor error code returned from GSS function.  This is used to display error details in the log.
 */
#define FAIL_IF_GSS_ERR(errcode,minor) do {if ((errcode!=GSS_S_COMPLETE)) {rc = CUWA_ERR_GSS; kutil_gss_error((char*)__func__,__LINE__,(errcode),(minor)); goto cleanup;}} while(0)

/**
 * FAIL_IF_ERR macro handles errno related errors. Assumes that calling function defines
 * a "cleanup" label and an int called rc which is returned by the function.
 * @param[in] cond fmt format string (same as *printf)
 * @param[in] errcode function will return this error, should be of type kutil_err_t.
 */
#define FAIL_SOCK_ERR(cond) do {if ((cond)) {                                                   \
    rc = CUWA_ERR_SOCKET;                                                                       \
    cuwa_warning("Err: %s:%d %d %s\n",(char*)__func__,__LINE__,CUWA_ERR_SOCKET,strerror(errno));\
    goto cleanup;                                                                               \
    }} while(0)

/**
 * displays human readable string describing the specified apr error
 */
#define CUWA_SHOW_APR_ERROR( rv )    do {           \
char buf[512];                                      \
if (rv)                                             \
{                                                   \
    apr_strerror( rv, buf, 512 );                   \
    cuwa_warning("APR Error %d:%s", rv, buf);       \
}                                                   \
}while(0)                                           \

/**
 * FAIL_IF_FILE_ERR macro handles file writing/reading errors. Assumes that calling function defines
 * a "cleanup" label and an int called status which are returned by the function.
 * @param[in] rv status after write
 * @param[out] status
 */
#define FAIL_IF_FILE_ERROR( rv )     do {              \
    if ( rv )                                          \
    {                                                  \
        if ( APR_STATUS_IS_ENOSPC(rv) )                \
            rc = CUWA_ERR_SESSION_NO_DISK_SPACE;       \
        else if ( APR_STATUS_IS_ENOENT(rv) )           \
            rc = CUWA_ERR_SESSION_NOT_FOUND;           \
        else                                           \
            rc = CUWA_ERR_SESSION_DB_ERR;              \
       if ( rc != CUWA_ERR_SESSION_NOT_FOUND)          \
           CUWA_SHOW_APR_ERROR( rv );                  \
        goto cleanup;                                  \
    } } while(0)                                       \


#define FAIL_IF_APR_SOCK_ERR(cond) do {if ((cond)) {    \
    rc = CUWA_ERR_SOCKET;                               \
    CUWA_SHOW_APR_ERROR( cond );                        \
    goto cleanup;                                       \
    }} while(0)


#endif /* _PERMIT_H */











