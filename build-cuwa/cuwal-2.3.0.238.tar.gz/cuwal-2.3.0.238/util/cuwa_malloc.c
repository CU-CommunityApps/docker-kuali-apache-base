/************************************************************************
 * cuwa_malloc.c -- Memory allocation debug code
 *
 * Copyright 2007 Cornell University.
 * All Rights Reserved.
 *
 ************************************************************************
 *  $Log: cuwa_malloc.c,v $
 *  Revision 1.19  2008/09/25 15:58:59  hy93
 *  make cuwa_malloc_get_pool available to other files
 *
 *  Revision 1.18  2008/09/16 19:19:20  hy93
 *  add static to functions that are internal in the file
 *
 *  Revision 1.17  2008/08/27 18:48:25  hy93
 *  Add parameter for the destructor of threadkey_private_create to avoid compiler warning on windows
 *
 *  Revision 1.16  2008/08/21 19:57:14  gbr4
 *  turn off traces in the cred GET/PUT macros and in cuwa_malloc to reduce log noise
 *
 *  Revision 1.15  2008/05/30 18:33:02  hy93
 *  remove debug log messages
 *
 *  Revision 1.14  2008/05/01 17:15:27  hy93
 *  fix cgi error
 *
 *  Revision 1.13  2008/04/28 17:38:26  hy93
 *  fix segfault on solaris
 *
 *  Revision 1.12  2008/04/24 18:12:36  gbr4
 *  fix windows build
 *
 *  Revision 1.11  2008/04/24 13:35:20  pb10
 *  Somebody ripped out the $Log meta so that the log was not longer being
 *  updated in the header files. Log restored.
 *
 *
 *  revision 1.10
 *  date: 2008/04/24 13:23:08;  author: pb10;
 *  Disable cuwa_malloc while because it causes segfault in solaris.
 *
 *  revision 1.9  2008/04/19 14:21:27;  author: pb10;
 *  Convert malloc's to APR allocations.
 *
 *  revision 1.8 2008/04/10 19:51:36;  author: gbr4;
 *  run all the source and other non-html-text through dos2unix. all source should be free of ^M going forward
 *
 *  revision 1.7
 *  date: 2008/04/10 17:08:20;  author: gbr4;
 *  removed the cvs-log keyword from each of these files as it was causing line ending problems.
 *
 *  revision 1.6 2008/04/10 17:02:00;  author: gbr4;
 *  more line ending problems
 *
 *  Revision 1.5  2008/04/10 16:57:11  gbr4
 *  Line endings only. This set of files had mixed line endings which breaks
 *  visual studio (and looks ugly in vim). Each file was converted to the format
 *  that resulted in the fewest line changes (i.e. whichever format it was mostly in).
 *
 *  Revision 1.4  2008/01/25 01:43:48  gbr4
 *  Added an ID string to every file
 *
 *  Revision 1.3  2008/01/13 21:27:10  pb10
 *  Lowercase CUWA2_LOG_DOMAIN setting.
 *
 *  Revision 1.2  2008/01/11 04:22:41  pb10
 *  Integration with logging.
 *
 *  Revision 1.1  2007/11/07 03:33:33  pb10
 *  Initial coding.
 *
 ************************************************************************
 */

//#include <cuwa_malloc.h> -- temporarily removed will we troubleshoot cuwal_malloc, meantime none of these functions get called
#include <stdlib.h>
#include <string.h>
#include <log.h>
#include <cuwa_err.h>
#include <apr_thread_proc.h>

#define CUWA2_LOG_DOMAIN cuwa.malloc

apr_pool_t * cuwa_malloc_get_pool();

static apr_threadkey_t *mempool_key = NULL;

void *cuwa_malloc(size_t size)
{
    void *hdr;
    apr_pool_t *pool = cuwa_malloc_get_pool();
    cuwa_assert(pool);

    hdr = apr_palloc(pool,size);
    cuwa_assert(hdr);
#ifdef CUWA_DEBUG_MALLOC
    cuwa_trace("cuwa_malloc: %p",pool);
#endif
    return hdr;
}


void *cuwa_calloc(size_t count, size_t size)
{
    void *hdr;
    apr_pool_t *pool = cuwa_malloc_get_pool();
    cuwa_assert(pool);

    size = size*count;

    hdr = apr_pcalloc(pool,size);
    cuwa_assert(hdr);

#ifdef CUWA_DEBUG_MALLOC
    cuwa_trace("cuwa_malloc: %p",pool);
#endif
    return hdr;

}


void cuwa_free(void *p)
{
}

apr_pool_t * cuwa_malloc_get_pool()
{
    void *pool = NULL;

    if ( !mempool_key )
    {
        cuwa_warning("Memory pool uninitialized");
        return NULL;
    }

    apr_threadkey_private_get(&pool, mempool_key);

    return (apr_pool_t *)pool;
}

static apr_status_t cuwa_malloc_cleanup( void *pool )
{
    if ( !mempool_key )
    {
        cuwa_warning("Memory pool uninitialized");
        return APR_SUCCESS;
    }
    apr_threadkey_private_set(NULL, mempool_key);
    return APR_SUCCESS;
}

void cuwa_malloc_set_pool( apr_pool_t *pool )
{

    if ( !mempool_key )
    {
        cuwa_warning("Memory pool uninitialized");
        return;
    }
    apr_threadkey_private_set((void *)pool, mempool_key);
    apr_pool_cleanup_register(pool,NULL,cuwa_malloc_cleanup,apr_pool_cleanup_null);

}

static void cuwa_malloc_delete_key(void *p)
{
    if ( mempool_key ) apr_threadkey_private_delete(mempool_key);
}

cuwa_err_t cuwa_malloc_init(apr_pool_t *pool)
{
    apr_status_t apr_err;
    cuwa_err_t status = CUWA_OK;

    apr_err = apr_threadkey_private_create(&mempool_key, cuwa_malloc_delete_key, pool);
    if ( apr_err)
    {
         char buf[512];

         apr_strerror( apr_err, buf, 512 );
         cuwa_warning("thread key creation failed:%s", buf);
         status = CUWA_ERR_THREAD_KEY;
    }
    else
    {
        cuwa_malloc_set_pool(pool);
    }

    return status;
}

const char id_util_cuwa_malloc_c[] = "$Id: cuwa_malloc.c,v 1.19 2008/09/25 15:58:59 hy93 Exp $";
