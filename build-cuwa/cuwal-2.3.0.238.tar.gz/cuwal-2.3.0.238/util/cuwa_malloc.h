/************************************************************************
 * cuwa_malloc.h -- Memory allocation debug code
 *
 * Copyright 2007 Cornell University.
 * All Rights Reserved.
 *
 ************************************************************************
 *  $Log: cuwa_malloc.h,v $
 *  Revision 1.10  2008/09/25 15:59:02  hy93
 *  make cuwa_malloc_get_pool available to other files
 *
 *  Revision 1.9  2008/04/28 17:38:48  hy93
 *  fix segfault on solaris
 *
 *  Revision 1.8  2008/04/24 13:35:20  pb10
 *  Somebody ripped out the $Log meta so that the log was not longer being
 *  updated in the header files. Log restored.
 *
 *
 *  revision 1.7 2008/04/24 13:23:08;  author: pb10;
 *  Disable cuwa_malloc while because it causes segfault in solaris.
 *
 *  revision 1.6 2008/04/19 14:21:27;  author: pb10;
 *  Convert malloc's to APR allocations.
 *
 *  revision 1.5 2008/04/10 19:51:36;  author: gbr4;
 *  run all the source and other non-html-text through dos2unix. all source should be free of ^M going forward
 *
 *  revision 1.4 2008/04/10 17:08:20;  author: gbr4;
 *  removed the cvs-log keyword from each of these files as it was causing line ending problems.
 *
 *  revision 1.3 2008/04/10 17:02:00;  author: gbr4;
 *  more line ending problems
 *  Revision 1.2  2008/04/10 16:57:11  gbr4
 *  Line endings only. This set of files had mixed line endings which breaks visual studio (and looks ugly in vim). Each file was converted to the format that resulted in the fewest line changes (i.e. whichever format it was mostly in).
 *
 *  Revision 1.1  2007/11/07 03:33:33  pb10
 *  Initial coding.
 *
 ************************************************************************
 */
#ifndef _CUWA_MALLOC_H
#define _CUWA_MALLOC_H

#include <stdlib.h>

#ifndef NO_APR

#include <cuwa_err.h>
#include <apr_pools.h>

void cuwa_free(void *it);
void *cuwa_malloc(size_t a);
void *cuwa_calloc(size_t a, size_t b);

cuwa_err_t cuwa_malloc_init(apr_pool_t *pool);
void cuwa_malloc_set_pool( apr_pool_t *pool );
apr_pool_t *cuwa_malloc_get_pool();
#else

#define cuwa_realloc realloc
#define cuwa_malloc malloc
#define cuwa_calloc calloc
#define cuwa_free free
#define cuwa_malloc_init(p)
#define cuwa_malloc_set_pool(p)

#endif

#endif








