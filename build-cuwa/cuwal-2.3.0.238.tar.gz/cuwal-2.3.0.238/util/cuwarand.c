/********************************************************************
 * cuwarand.c -- CUWAL2 random number generator
 * -- validate or replace before production
 * Copyright (c) 2007 Cornell University
 *
 ************************************************************************
 *  $Log: cuwarand.c,v $
 *  Revision 1.1  2008/09/07 19:35:01  gbr4
 *  rename rand.[ch] to cuwarand.[ch]. Too many packages have a rand.h and some versions of libtool grab the wrong one. This fixes builds against debian 4.0r4.
 *
 *  Revision 1.15  2008/07/14 18:30:57  hy93
 *  fix refine compiler error
 *
 *  Revision 1.14  2008/07/14 14:48:25  pb10
 *  Fix annoying compiler warning.
 *
 *  Revision 1.13  2008/05/05 19:13:15  gbr4
 *  fix error introduced in log 1.37 that broke solaris build. also commit conditional code used in klocwork build and add an assert in rand to check that /dev/urandom read succeeded.
 *
 *  Revision 1.12  2008/04/23 19:56:02  gbr4
 *  switch to reading /dev/urandom instead of the apache function to get random bytes. the apache function uses /dev/random and /dev/urandom inconsistantly. this should be revisited but should fix the ubuntu issue
 *
 *  Revision 1.11  2008/04/10 23:08:06  gbr4
 *  fixed all *compile* errors under msvc9.0 (studio 2008). Still has link errors
 *  and tons of warnings. This might cause regressions.
 *
 *  Revision 1.10  2008/04/04 02:30:43  gbr4
 *  quiet some of the warnings. No functional changes
 *
 *  Revision 1.9  2008/01/25 01:43:48  gbr4
 *  Added an ID string to every file
 *
 *  Revision 1.8  2008/01/17 14:01:55  gbr4
 *  fix incorrect passing of thread id
 *
 *  Revision 1.7  2008/01/15 08:22:47  gbr4
 *  some random fixes ... always wanted to say that. Get rid of interlocked (apr_atomic) code as the APR 0.9 version was wrong -- needed atomic increment and get previous. Now getting a threadid and ignoring the race condition -- two racing threads should have different thread ids.
 *
 *  Revision 1.6  2008/01/14 20:12:22  hy93
 *  fix file cvs block so it log check in correctly
 *
 *  Revision 1.5  2008/01/14 20:06:20  hy93
 *  Change code to use different apr based on apr version
 *
 ************************************************************************
 */

#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include <string.h>
#include <apr_file_info.h>
#include <apr_file_io.h>
#include <apr_pools.h>
#include <apr_portable.h>
#include <cuwarand.h>
#include <sha1.h>
#include <cuwa_types.h>


#include <sys/types.h>

#include "../autoconfig.h"
#ifdef HAVE_UNISTD_H
#include <unistd.h>
#endif


/**
 * Global randomness context
 */
static cuwa_rand_t rand_global_ctx;


/** Initialize the given randomness context
 * WARNING: YOU MUST CALL apr_atomic_init first.
 */

//fixme -- reduced to 16 bytes of entropy
//due to startup slowness
//also added a #define to use /dev/urand instead
//since this takes minutes to start on ubuntu
//look for a better way...
void cuwa_rand_init(cuwa_rand_t *r){
#ifndef CUWA_RAND_URAND
  	int st;
	st=apr_generate_random_bytes(r->r1,16);
#ifdef CUWA_RAND_256 //not defined
	st=apr_generate_random_bytes(r->r2,16);
#else  //reduction to 16bytes entropy active
	for(st=0; st<16; st++){
		r->r2[st]=r->r1[15-st];
	}
#endif
#else
	{ //fixme validate this as acceptable
		FILE *f;
		f=fopen("/dev/urandom","r");
		assert(f);
		fread(r->r1,1,16,f);
		fread(r->r2,1,16,f);
		fclose(f);
	}		

#endif
	r->c=0;
}

/**
 * Inits the global randomness context. Not necessary unless cuwa_rand_g is used.
 * Call this function exactly once. It is unsafe to call cuwa_rand_g until this has finished.
 * WARNING: YOU MUST CALL apr_atomic_init first.
 */
void cuwa_rand_init_g(){
	cuwa_rand_init(&rand_global_ctx);

}


apr_uint32_t cuwa_next_rand(cuwa_rand_t *r){
		apr_uint64_t x = cuwa_next_rand64(r);
		return((apr_uint32_t) x);
}



/**
 * Get the next random number from the given randomness context.
 * Algorithim:
 * Randomness context comprises two 16-byte entropy keys and a 32-bit counter
 * Atomically increment the counter and then compute:
 * Compute SHA1(R1 + counter_old + first 32 digits of pi + current time + tid + the PID + R2)
 * For security R1 + counter + R2 suffice.
 * Time is to handle wrapping of the counter. There is no assumption that the time will change between two invocations
 * 32 digits of pi is to increase the compression ratio of SHA1 to reduce any possible seed leakage
 * On non-win32 platforms the PID is to ensure that after a fork the parent and child will not produce collisions
 *
 */
apr_uint64_t cuwa_next_rand64(cuwa_rand_t *r){
	SHA1Context ctx;
	
	apr_uint32_t x;
	apr_time_t now;
	apr_os_thread_t thread;

	r->c++;
    x= r->c;
	
	
	
	SHA1Reset(&ctx);
	SHA1Input(&ctx,r->r1,16);
	SHA1Input(&ctx,(unsigned char*)&x,sizeof(x));
	SHA1Input(&ctx,(unsigned char*)"3.1415926535897932384626433832795",32);
	
	now = apr_time_now();
	thread=apr_os_thread_current();
	
	SHA1Input(&ctx, (unsigned char*)&now,sizeof(now));
	SHA1Input(&ctx, (unsigned char*)&thread,sizeof(apr_os_thread_t));

#ifndef WIN32
	{
		pid_t pid;
		pid=getpid();
		SHA1Input(&ctx, (unsigned char*)&pid,sizeof(pid));
		//FIXME IIS
	}
#endif
	
	SHA1Input(&ctx,r->r2,16);
	if(!SHA1Result(&ctx)) assert(0);
	return((((apr_uint64_t)(ctx.Message_Digest[0])) << 32) | ((apr_uint64_t)(ctx.Message_Digest[1])));
}


/**
 * Get the next 32 random bits from the global randomness context.
 * Must initialize global randomness context with cuwa_rand_init_g first
 * Concurrancy warning: multiple calls to cuwa_rand_g from different threads are ok
 * concurrant calls to cuwa_rand_init_g and cuwa_rand_g are not ok
 */
unsigned int cuwa_rand_g(){
	//fixme iis consider whether global is wise
	return cuwa_next_rand(&rand_global_ctx);
}

apr_uint64_t cuwa_rand64_g()
{
    return( cuwa_next_rand64(&rand_global_ctx) );
}
const char id_util_rand_c[] = "$Id: cuwarand.c,v 1.1 2008/09/07 19:35:01 gbr4 Exp $";
