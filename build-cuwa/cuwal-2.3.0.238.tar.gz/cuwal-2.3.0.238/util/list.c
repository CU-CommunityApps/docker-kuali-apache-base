/************************************************************************
 * list.c -- list operation for CUWebAuth
 *
 * Copyright 2007 Cornell University.
 * All Rights Reserved.
 *
 ************************************************************************
 *  $Log: list.c,v $
 *  Revision 1.23  2009/06/12 16:38:31  pb10
 *  Cleanup: remove relative path includes.
 *
 *  Revision 1.22  2008/05/05 19:51:43  gbr4
 *  assertion was off by a level of indirection
 *
 *  Revision 1.21  2008/04/10 16:57:11  gbr4
 *  Line endings only. This set of files had mixed line endings which breaks visual studio (and looks ugly in vim). Each file was converted to the format that resulted in the fewest line changes (i.e. whichever format it was mostly in).
 *
 *  Revision 1.20  2008/01/25 01:43:48  gbr4
 *  Added an ID string to every file
 *
 *  Revision 1.19  2008/01/13 21:27:10  pb10
 *  Lowercase CUWA2_LOG_DOMAIN setting.
 *
 *  Revision 1.18  2008/01/11 17:41:15  gbr4
 *  random now supports globals
 *
 *  Revision 1.17  2008/01/10 18:04:53  hy93
 *  Removed "" from CUWA2_LOG_DOMAIN
 *
 *  Revision 1.16  2008/01/07 03:16:09  gbr4
 *  minor warning fixes
 *
 *  Revision 1.15  2007/12/20 20:39:22  gbr4
 *  switch to DENULL
 *
 *  Revision 1.14  2007/12/20 20:25:03  hy93
 *  Fix a segmentation fault. Fix a bug in list_del which cause list truncated.
 *
 *
 *  Revision 1.1  2007/10/22 16:48:14  gbr4
 *  Initial commit, to publish API.
 *
 *
 ************************************************************************
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdarg.h>
#include <assert.h>
#include <log.h>
#include <util.h>
#include <list.h>

#define CUWA2_LOG_DOMAIN cuwa.util.list


/**
 * Searches a linkedlist starting with the head and returns the first matching node.
 * @param[in] l the linkedlist
 * @param[in] tar the element sought
 * @param[in] peq the function used to test each element for equality to tar
 * @return from the beginning of the list the first node n of the list for which peq(tar,n->d) returns zero
 */
cuwa_node *cuwa_list_find(cuwa_list *l, void * tar, cuwa_pred_eq peq){
	cuwa_node *p;
	int i;
	cuwa_atrace("searching for %s in %xd",tar,l);
	i=0;
	if(!l) return NULL;

	cuwa_assert(cuwa_list_valid(l));
	p=l->head;
	while(p){
		cuwa_atrace("searching for %s in %xd (%d)",DENULL(tar),l,i);
		if (!peq(tar,p->data)){
			cuwa_trace("found at %d",i);
			return p;
		}
		p=p->next;
		i++;
	}
	cuwa_trace("not found",NULL);
	return NULL;
}

/**
 * Calculates the forward length of the linkedlist
 * @param[in] l the linkedlist
 * @return the number of nodes in the linkedlist starting from the front
 */
static int cuwa_list_flen(cuwa_list *l){
	int len=0;
	cuwa_node *p;
	if(!l) return 0;
	p=l->head;
	while(p){
		len++;
		p=p->next;
	}
	return(len);
}

/**
 * Calculates the reverse length of the linkedlist
 * @param[in] l the linkedlist
 * @return the number of nodes in the linkedlist starting from the back
 */
static int cuwa_list_rlen(cuwa_list *l){
	int len=0;
	cuwa_node *p;
	if(!l) return 0;
	p=l->tail;
	while(p){
		len++;
		p=p->prev;
	}
	return(len);
}

/**
 * list length
 * @param[in] l the linkedlist
 * @return the number of nodes in the linkedlist, asserting if the forward and reverse lengths differ
 */
int cuwa_list_len(cuwa_list *l){
	int len;
	len=cuwa_list_rlen(l);
	cuwa_assert(cuwa_list_flen(l)==len);
	return len;
}

/**
 * allocates and adds a node to a linkedlist with add as the datum
 * @param[in] l the linkedlist
 * @param[in] add the element to add
 * @invariant add must be a pointer to valid memory (not freed) until the node is removed from the list
 */
void cuwa_list_append(cuwa_list **l, void *add){
	cuwa_node *a;
	int startlen;
	cuwa_assert(l);
	startlen=cuwa_list_len(*l);
	if(!(*l)){
		*l=malloc(sizeof(cuwa_list));
		cuwa_assert(*l);
		memset(*l,0,sizeof(cuwa_list));
		(*l)->head=NULL;
		(*l)->tail=NULL;
	}
	cuwa_assert( (NULL==((*l)->head)) == (NULL==((*l)->tail)) ); //headless lists shall not have tails. tailless lists shall not have heads.
	a=malloc(sizeof(cuwa_node));
	cuwa_assert(a);
	a->data=add;
	a->next=NULL;
	a->prev=(*l)->tail;
	if(a->prev) a->prev->next=a;
	(*l)->tail=a;
	if(!(*l)->head){
		(*l)->head=a;
	}
	cuwa_assert(cuwa_list_valid(*l));
	cuwa_assert(startlen+1==cuwa_list_len(*l));
}

/**
 * Performs invariant checking on the passed linkedlist
 * @param[in] l the linkedlist
 * @invariant the list either is empty or has both a head and a tail
 * @invariant the list has the same length in the forwards and reverse directions
 * @invariant except for the tail of the list each node has a next node and the previous pointer of the next node is the node itself
 * @invariant except for the head of the list each node has a previous node and the next pointer of the previous node is the node itself
 * @invariant the list is acyclic -- otherwise this is not guaranteed to return
 * @return true or throws an assertion
 */
int cuwa_list_valid(cuwa_list *l){
	cuwa_node *p=l->head;
	cuwa_assert((l->head?l->tail!=NULL:!(l->tail))); //headless lists shall not have tails. tailless lists shall not have heads.
	cuwa_assert(cuwa_list_flen(l) == cuwa_list_rlen(l));
	while(p){
		cuwa_assert(p->next ? p->next->prev == p : p == l->tail);
		cuwa_assert(p->prev ? p->prev->next == p : p == l->head);
		p=p->next;
	}
	return TRUE;
}


/**
 * removes the specified node from the linkedlist and dealllocates that node
 * @param[in] l the linkedlist
 * @param[in] n the node to remove
 * @return a pointer to the datum carried by n. after return n has been free()'ed and the caller should call free on the return if appropriate
 */

void* cuwa_list_del(cuwa_list *l, cuwa_node *n){ //returns *d -- caller should free
	void *ret;
	cuwa_assert(l);
	cuwa_assert(n);
	ret=n->data;
	
	cuwa_assert(cuwa_list_valid(l));

	//delink n
	if(n->next){
		cuwa_assert(l->tail != n); //tails should not have a next
		n->next->prev = n->prev;
	}
	else{
		cuwa_assert(l->tail == n); //nodes without a next should be the tail
		l->tail=n->prev;
	}
	if(n->prev){
		cuwa_assert(l->head != n); //heads don't have previous nodes
		n->prev->next = n->next;
		n->prev=NULL;
	}
	else{
		cuwa_assert(l->head == n); //nodes without a prev should be the head
		l->head=n->next;
	}
        n->next=NULL;
	n->data=NULL;
	free(n);
	return(ret);
}

/**
 * applies the predicate to each element of the list in order from first to last
 * @param[in] l the linkedlist
 * @param[in] f the predicate
 */
void cuwa_list_apply(cuwa_list *l, cuwa_pfvpv f){ //calls f(p->d) for each p
	cuwa_node *p;
	if(!l) return;
	p=l->head;
	while(p){
		f(p->data);
		p=p->next;
	}
}


/**
 * standard left fold list function.
 * foldl(list,f,a) := empty(l)?a:foldl(tail(list),f,f(head(list),a))
 * head(l) denotes first datum in list
 * tail(l) denotes the list with the first datum removed
 * empty(l) is true when the list contains no elements
 * so foldl [1,2,3,4] f 0 = f(4,f(3,f(2,f(1,0))))
 *
 * @param[in] l the linkedlist
 * @param[in] f the combination predicate
 * @param accum the accumulator (initial argument to the combination predicate)
 */
void* cuwa_list_foldl(cuwa_list *l, cuwa_combine2 f, void * accum){ //calls f(p->d) for each p
	cuwa_node * listleft;
	listleft=l->head;
	while(listleft){
		accum=f(listleft->data,accum);
		listleft=listleft->next;
	}
	return(accum);
}


/**
 * standard right fold list function.
 * foldr(list,f,a) := empty(l)?a:f(head(list),foldr(tail(list),f,accum))
 * head(l) denotes first datum in list
 * tail(l) denotes the list with the first datum removed
 * empty(l) is true when the list contains no elements
 * so foldl [1,2,3,4] f 0 = f(1,f(2,f(3,f(4,0))))
 * @param[in] l the linkedlist
 * @param[in] f the combination predicate
 * @param accum the accumulator (initial argument to the combination predicate)
 */
void* cuwa_list_foldr(cuwa_list *l, cuwa_combine2 f, void * accum){ //calls f(p->d) for each p
	cuwa_node * listright;
	listright=l->tail;
	while(listright){
		accum=f(listright->data,accum);
		listright=listright->next;
	}
	return(accum);
}


/**
 * free()'s all the nodes of the passed linkedlist and the list itself. after return th
 * @note caller should apply free to the list if appropriate as the data is not free()'d by this function
 * @param[in,out] l the linkedlist
 */
void cuwa_list_destroy(cuwa_list *l){
	cuwa_node *p,*p2;
	if(!l) return;
	p=l->head;
	while(p){
		p2=p->next;
		free(p);
		p=p2;
	}
	free(l);
}
const char id_util_list_c[] = "$Id: list.c,v 1.23 2009/06/12 16:38:31 pb10 Exp $";
