/**
 * CUWAL2 random number generator
 * -- validate or replace before production
 * $Id: randtest.c,v 1.6 2008/09/07 19:35:01 gbr4 Exp $
 * Copyright (c) 2007 Cornell University
 */

#include <stdio.h>
#include "cuwarand.h"
#include "cuwa_types.h"
#include <apr_pools.h>

int main(int argc, char **argv){
	int i;
        apr_pool_t *pool;

	printf("init...\n");

	apr_pool_initialize();
        apr_pool_create( &pool, NULL );

        apr_atomic_init( pool );
	cuwa_rand_init_g();
	printf("go...\n");
	for(i=0; i<1000; i++){
		printf("%llX\n",cuwa_rand64_g());
	}
}

const char id_util_randtest_c[] = "$Id: randtest.c,v 1.6 2008/09/07 19:35:01 gbr4 Exp $";
