APR=`which apr-1-config`
test -f core.* && rm core.*
test -f a.out && rm a.out
gcc  randtest.c cuwarand.c ../sha1/sha1.c `$APR --apr-la-file | cut -d \. -f 1`.so  `$APR --includes` -I. -I../sha1 -g -O2 -pthread -DLINUX=2 -D_REENTRANT -D_GNU_SOURCE -D_LARGEFILE64_SOURCE -o randtest 
#export LD_LIBRARY_PATH=/users/gbr4/apr/lib/
#./randtest 
