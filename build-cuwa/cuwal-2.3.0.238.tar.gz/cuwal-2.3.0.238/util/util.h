#ifndef __CUWA2_UTIL_H
#define __CUWA2_UTIL_H
#ifndef TRUE
#define TRUE -1
#define FALSE 0
#endif
#include <stdarg.h>
#include "list.h"

void cuwa_util_replace_char( char *buffer, char remove );
void cuwa_util_replace_char_with( char *buffer, char remove, char newChar );
char *strstr_case_insensitive(char *str1, char *str2);
void cuwa_util_str_to_lower(char *str);
void cuwa_util_str_to_upper(char *str);
char * cuwa_nextword (char **str, char sep);

#endif
