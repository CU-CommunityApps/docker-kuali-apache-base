/************************************************************************
 * auth.c -- Authentication and authorization code.
 *
 * Copyright 2007 Cornell University.
 * All Rights Reserved.
 *
 ************************************************************************
 *  $Log: auth.c,v $
 *  Revision 1.95  2015/10/07 18:33:52  hy93
 *  merge TwoFactor treee to the head
 *
 *  Revision 1.94.2.15  2015/10/01 16:02:06  hy93
 *  add session in cuwa_permit_lookup and cuwa_permit_cache_check
 *
 *  Revision 1.94.2.14  2015/06/30 13:01:42  hy93
 *  apache 2.4 support
 *
 *  Revision 1.94.2.13  2015/05/05 15:45:24  hy93
 *  check in jerry's verion of get_cred_from_args to remove duplicate moving string in previous version
 *
 *  Revision 1.94.2.12  2015/05/04 16:18:12  hy93
 *  fix string not terminated
 *
 *  Revision 1.94.2.11  2015/05/04 13:57:17  hy93
 *  remove log messages
 *
 *  Revision 1.94.2.10  2015/05/04 13:51:25  hy93
 *  add extra checking to prevent read over the buffer
 *
 *  Revision 1.94.2.9  2015/05/04 13:06:51  hy93
 *  fix infinite loop when doing cred decoding
 *
 *  Revision 1.94.2.8  2015/04/29 15:15:42  hy93
 *  add debug message
 *
 *  Revision 1.94.2.7  2015/04/29 13:04:22  hy93
 *  Fix sometimes error page didn't show properly
 *
 *  Revision 1.94.2.6  2015/04/24 17:33:09  hy93
 *  make two trip to weblogin if CUWA2FARequire is defined using permit
 *
 *  Revision 1.94.2.5  2015/04/23 15:02:23  hy93
 *  remove parameter that is not being used
 *
 *  Revision 1.94.2.4  2015/03/17 19:01:43  hy93
 *  support space separated permit name in CUWA2FARequire
 *
 *  Revision 1.94.2.3  2015/01/29 19:25:35  hy93
 *  change CUWAdualAuth to CUWA2FARequire and CUWAdualMethod to CUWA2FAMethod
 *
 *  Revision 1.94.2.2  2015/01/29 17:37:38  hy93
 *  increase verP to 3
 *
 *  Revision 1.94.2.1  2014/10/22 20:00:23  hy93
 *  add two factor support
 *
 *  Revision 1.94  2014/10/22 16:46:22  hy93
 *  remove two factor,Apache 2.4 support
 *
 *  Revision 1.93  2014/10/21 17:56:20  hy93
 *  covert dualMethod to upper case
 *
 *  Revision 1.92  2014/07/25 17:43:35  hy93
 *  Apache 2.4 support
 *
 *  Revision 1.91  2014/07/25 16:16:45  hy93
 *  save weblogin server url to the request
 *
 *  Revision 1.90  2014/01/15 18:41:57  hy93
 *  set cookie to be HttpOnly to mitigate XSS attack
 *
 *  Revision 1.89  2013/08/06 18:31:20  hy93
 *  add DualMethod in url parameter if CUWAdualMethod is defined
 *
 *  Revision 1.88  2013/07/30 19:19:42  hy93
 *  Two factor authentication support
 *
 *  Revision 1.87  2013/02/23 12:54:53  hy93
 *  return server error when updating session failed
 *
 *  Revision 1.86  2011/11/30 15:18:55  hy93
 *  remove realm checking in authz since it might cause infinite loop for site configured with alias in CUWARealm
 *
 *  Revision 1.85  2011/11/30 14:17:56  hy93
 *  remove previous check in for fixing infinite loop when using alias in CUWAwak0Realms
 *
 *  Revision 1.84  2011/11/07 14:00:33  hy93
 *  Fix infinite loop when using alias in CUWAwak0Realms
 *
 *  Revision 1.83  2011/11/04 14:09:16  hy93
 *  Fix using uninitialized variable
 *
 *  Revision 1.82  2010/10/08 20:43:27  pb10
 *  Moved realm authZ from authn to authz stage + new test cases.
 *
 *  Revision 1.81  2010/08/03 15:11:17  pb10
 *  Remove realm validity compare with CUWAwak0realm from CUWL and webauth.
 *
 *  Revision 1.80  2010/04/21 21:27:44  pb10
 *  Fix comments, it was actually a python issue not PHP.
 *  Comments will hopfully prevent a future release from breaking python compat, no promises.
 *
 *  Revision 1.79  2010/04/19 17:53:48  pb10
 *  Comment out trace line for authtype=unknown.  SVN issue investigation.
 *
 *  Revision 1.78  2009/12/02 17:49:13  gbr4
 *  usleep doesnt exist on win32. use apr_sleep
 *
 *  Revision 1.77  2009/12/02 14:09:12  gbr4
 *  re-insert 0.1 second sleep in the weblogin redirect path to throttle any single loop to max 600 logins per minute
 *
 *  Revision 1.76  2009/11/25 20:00:53  pb10
 *  attempt to print NULL string from cuwa_trace call.
 *
 *  Revision 1.75  2009/10/06 16:39:43  pb10
 *  Added support for webauth accepting a WA credential via POST in addition to URL based cred.
 *  This is to support large credentials that exceed 2K browser limit of IE.
 *
 *  Revision 1.74  2009/09/22 19:23:09  pb10
 *  Resolves multiple site cookies present in cookie header due to
 *  overlapping cookie domains (IE).
 *
 *  Revision 1.73  2009/09/18 03:55:14  pb10
 *  Backout site cookie naming scheme that was intended to fix the IE
 *  cookie issue that occurs when multiple distinct sites have overlapping
 *  domain names.
 *
 *  Revision 1.72  2009/09/11 17:16:13  hy93
 *  move common used validator function from mod_cuwebauth.c to auth.c
 *
 *  Revision 1.71  2009/08/13 02:29:02  pb10
 *  Add backward compatability for old upstream proxy portal which depends on old cookie type.
 *
 *  Revision 1.70  2009/07/30 15:54:55  pb10
 *  Change site cookie name from cuweblogin2 to cuweblogin2-N to
 *  accomodate IE behavior with regard to multiple sites that have overlapping
 *  multi-part domain names.
 *
 *  Revision 1.69  2009/06/11 18:50:17  pb10
 *  Add "NETID" header for backward compatability with IIS webauth v1.
 *
 *  Revision 1.68  2009/04/29 04:12:03  gbr4
 *  change redirect to weblogin from
 *
 *  302 https://webx.login.cornell.edu:443?SID=... to
 *  302 https://webx.login.cornell.edu:443/?SID=...
 *
 *  to try to solve google compatibility problem. Review this change before it ends up in a production release
 *
 *  Revision 1.67  2009/02/13 19:25:09  pb10
 *  Added test case for CUWAReturnURL with %p.
 *
 *  Revision 1.66  2009/02/13 16:29:58  pb10
 *  CUWAReturnURL now accepts a %p that will be replaced with the
 *  original path of the URL (without the file).
 *
 *  Revision 1.65  2009/02/12 19:14:17  gbr4
 *  bump VerP=2 and version to 2.1.1
 *
 *  Revision 1.64  2009/02/11 06:26:02  pb10
 *  Removal of cuwal2sid cookie.
 *
 *  Revision 1.63  2009/02/09 17:47:33  pb10
 *  Removed path from return URL.  It's no longer needed and it's causing
 *  weblogin weird message about bad characters in URL.
 *
 *  Revision 1.62  2009/01/23 19:36:26  hy93
 *  fix mis-spelling in the log message
 *
 *  Revision 1.61  2009/01/15 21:35:08  hy93
 *  add log message to assist debugging customer issue
 *
 *  Revision 1.60  2009/01/08 18:24:33  pb10
 *  Support for ErrorDocument
 *
 *  Revision 1.59  2008/12/15 19:00:22  hy93
 *  fix CUWA_GROUPS doens't contain all the permits even though CUWAInquire permit all is used
 *
 *  Revision 1.58  2008/11/24 20:05:18  pb10
 *  Add header CUWA_WAC0 to support proxy portal use.
 *
 *  Revision 1.57  2008/11/21 14:51:45  pb10
 *  Fixed: remove embedded tabs introduced with CUWAauthzFailHTTPCode fix :-)
 *
 *  Revision 1.56  2008/11/21 14:19:13  hy93
 *  Fix a typo that causes CUWAauthzFailHTTPCode doesn't work
 *
 *  Revision 1.55  2008/11/20 21:08:12  gbr4
 *  When CUWAclearCookies directive is present issue cookiediscarded with a past expiration. SRB55 tested against peoplesoft this appears to work on common browsers. cookiediscarded value was causing problems for PS application
 *
 *  Revision 1.54  2008/11/16 19:50:43  pb10
 *  Add headerkey support to CUWA.
 *
 *  Revision 1.53  2008/10/30 13:43:54  hy93
 *  Fix session id string sometimes has \r at the end
 *
 *  Revision 1.52  2008/10/30 13:35:12  hy93
 *  remove a line of code that has no use
 *
 *  Revision 1.51  2008/10/09 16:19:19  hy93
 *  move common code in cuwa_wal_set_cookie to auth.c
 *
 *  Revision 1.50  2008/10/08 16:04:13  hy93
 *  fix redirect loop when keytab missing or keytab corrupted
 *
 *  Revision 1.49  2008/09/19 03:52:25  pb10
 *  Always check CUWACredAge against start_time and auth_time (not just when processing login cred).
 *
 *  Revision 1.48  2008/09/18 18:32:30  hy93
 *  modified error message when ha get login server fails
 *
 *  Revision 1.47  2008/09/13 13:23:53  pb10
 *  Add IIS code and cleanup apache dependency in cuwa_version.c.
 *  Fix naming and positioning of DAV functions in wal.h.
 *
 *  Revision 1.46  2008/09/11 18:06:11  gbr4
 *  CUWAclearCookies directive added. runtests.sh now supports -stop-http intelligently.
 *
 *  Revision 1.45  2008/09/08 16:36:19  hy93
 *  add to include header cred_base64.h to avoid compiler warning
 *
 *  Revision 1.44  2008/09/07 19:35:01  gbr4
 *  rename rand.[ch] to cuwarand.[ch]. Too many packages have a rand.h and some versions of libtool grab the wrong one. This fixes builds against debian 4.0r4.
 *
 *  Revision 1.43  2008/09/06 01:29:02  gbr4
 *  Rename the directive CUWADavAuth to CUWAAuthBasic per Pete's suggestion.
 *
 *  Impliment the cuwa_davlogin handler (built-in page that gives the user their cookie to use with WebDAV). The user is free to impliment a prettier page in whatever they want or add a location block to turn on this handler.
 *
 *  Also split off some of the css into cuwa_page.html and genericize our handler calling (one handler for the portals registered with apache that then delegates to the appropriate core functions instead of one handler per portal).
 *
 *  Revision 1.42  2008/09/05 02:57:25  gbr4
 *  Add experimental support for CUWAAuthBasic on directive. This allows accepting a session cookie via basic auth. "seems to work" but havn't tried many clients
 *
 *  Revision 1.41  2008/08/26 17:53:26  hy93
 *  remove apache dependency in auth.c and portal.c
 *
 *  Revision 1.40  2008/08/25 20:00:14  hy93
 *  move portal proxy code to a new file
 *
 *  Revision 1.39  2008/08/25 14:50:06  pb10
 *  Change CUWA_f1 env/header to CUWA_F1.
 *
 *  Revision 1.38  2008/08/22 20:05:46  gbr4
 *  fix windows crash. apr_psprintf("%d,%d,%s",apr_time_t,int,"") -- apr_time_t is 54-bit and eats both %d,s. the 2nd int is then formatted as a string
 *
 *  Revision 1.37  2008/08/22 18:27:49  pb10
 *  Fix another noprompt issue (weblogin quoted to cuwl_tgt_times cookie).
 *
 *  Revision 1.36  2008/08/22 16:34:10  pb10
 *  Fix another noprompt issue.
 *
 *  Revision 1.35  2008/08/21 23:23:46  gbr4
 *  Remove weblogin warnings. Refactor the find-a-string-in-a-comma-seperated-string check into cuwa_parse. Have weblogin now log the user name on SSO logins. Have weblogin check the realm on SSO logins and prompt the user if a SSO session won't be accepted by webauth. Fix t07authz_simple -- previous commit fixed the todo, however we decided that rather than displaying a 403 the correct response to a wak0realms mismatch was to send the user to weblogin -- this test has been updated to check that that url is a redirect to weblogin
 *
 *  Revision 1.34  2008/08/21 21:59:25  pb10
 *  Cleanup wak0realms support.
 *
 *  Revision 1.33  2008/08/21 19:49:08  pb10
 *  Fix noprompt.  Was wiping out cookies before checking for cuwltgttime.
 *
 *  Revision 1.32  2008/08/21 17:34:24  gbr4
 *  when wak0realm is specified, disallow other credentials
 *
 *  Revision 1.31  2008/08/21 14:18:11  hy93
 *  change %llX to %qX
 *
 *  Revision 1.30  2008/08/21 01:31:15  pb10
 *  Add code to check delegation flag.  Go to weblogin if delegation needed but not requested yet from weblogin.
 *
 *  Revision 1.29  2008/08/20 17:33:56  pb10
 *  Fix a cookie and credential handling in proxy portal and fixed proxy test harness.
 *
 *  Revision 1.28  2008/08/20 14:08:58  gbr4
 *  change all occurances of %llx and %qx to $llX and %qX respectively.
 *
 *  Revision 1.27  2008/08/20 04:12:44  pb10
 *   Some fixes for portal proxy.
 *
 *  Revision 1.26  2008/08/19 20:10:59  pb10
 *  Return a log on portal error.  Move permit portal code to auth.c.
 *
 *  Revision 1.25  2008/08/18 17:37:10  gbr4
 *  Fix some code that microsoft C doesn't like
 *
 *  Revision 1.24  2008/08/18 16:40:38  hy93
 *  support newSession flag in delegation
 *
 *  Revision 1.23  2008/08/17 14:18:03  pb10
 *  Remove unused code from session manager and cred manager.
 *
 *  Revision 1.22  2008/08/16 19:40:44  hy93
 *  send sessionID cookie when HEAD to remote host
 *
 *  Revision 1.21  2008/08/16 12:22:57  hy93
 *  fix bugs in proxy code
 *
 *  Revision 1.20  2008/08/15 20:10:03  pb10
 *  Change auth code to use attributes table.
 *
 *  Revision 1.19  2008/08/15 03:58:48  gbr4
 *  Fix allowInvalidPrincipal=1 in the proxy portal code
 *
 *  Check in the really basic K3 usage test case
 *
 *  Revision 1.18  2008/08/14 18:23:08  hy93
 *  add sending Host and User-Agent along in http request
 *
 *  Revision 1.17  2008/08/14 16:27:52  hy93
 *  Fix requests are saved for noprompt
 *
 *  Revision 1.16  2008/08/14 14:54:53  hy93
 *  Allow multiple valid-user or valid-user@REALM defined in require line
 *
 *  Revision 1.15  2008/08/13 15:12:02  pb10
 *  Fix indenting and replaced tabs.
 *
 *  Revision 1.14  2008/08/11 04:31:22  hy93
 *  release session after we done
 *
 *  Revision 1.13  2008/08/11 04:13:09  hy93
 *  delegation support
 *
 *  Revision 1.12  2008/08/09 01:16:49  pb10
 *  Support listPermit call (CUWAInquire permit all).
 *
 *  Revision 1.11  2008/08/08 02:33:04  hy93
 *  support CUWAwak2Flags
 *
 *  Revision 1.10  2008/08/04 16:05:04  hy93
 *  moved util function from auth.c to cuwa_parse
 *
 *  Revision 1.9  2008/08/04 01:35:12  gbr4
 *  make the code easier for dumb programs to understand. Also stop compiling sha.c, it is both bad and unnecessary.
 *
 *  Revision 1.8  2008/07/31 20:57:35  pb10
 *  Protect against PHP Authorization header dependency (stupidity).
 *
 *  Revision 1.7  2008/07/31 18:28:18  gbr4
 *  spelling fix in error message (priviledges)
 *
 *  Revision 1.6  2008/07/30 00:01:31  hy93
 *  fix bug
 *
 *  Revision 1.5  2008/07/29 03:15:49  pb10
 *  fix function names
 *
 *  Revision 1.4  2008/07/29 02:44:54  pb10
 *  Fix naming for core functions.
 *
 *  Revision 1.3  2008/07/29 02:33:53  pb10
 *  remove ^M's.
 *
 *  Revision 1.2  2008/07/29 01:55:29  pb10
 *  Incomplete mod_cuwebauth surgery.
 *
 *  Revision 1.1  2008/07/24 20:23:40  pb10
 *  Partially complete.
 *
 *
 ************************************************************************
 */
#define CUWA_ERR_STRINGS

#include <apr_buckets.h>
#include <apr_general.h>
#include <apr_lib.h>
#include <apr_strings.h>
#include <apr_atomic.h>

#include "../autoconfig.h"
#ifdef HAVE_UNISTD_H
#include <unistd.h>
#endif
#include <ctype.h>
#include <time.h>
#include <cuwa_err.h>
#include <kutil.h>
#include <cuwa_request.h>
#include <cuwa_version.h>
#include <session.h>
#include <log.h>
#include <cuwarand.h>
#include <cfg.h>
#include <wal.h>
#include <error_page.h>

#include <highAvail.h>
#include <cuwa_malloc.h>
#include <cuwa_parse.h>
#include <permit_cache.h>
#include <cred_base64.h>
#include <headerkey.h>
#include <util.h>

#define CUWA2_LOG_DOMAIN cuwa.auth
#define DEFAULT_FORCE_TIME 60*5 /* 5 minute credential age */
#define MIN_CRED_AGE 10         /* 10 second minimum credential age */

#define CUWA_MAGIC_FILE "cuwal2.c0ntinue"
#define CUWA_MAGIC_ARG "CUWACRED="
#define CUWA_SITE_COOKIE_DISCARDED "cookiediscarded"
#define CUWA_MAGIC_CRED "wa="

#define AUTHN_ERRCODE(c) (CFG_CUWAautheFailHTTPCode((c))!=NULL) ? *CFG_CUWAautheFailHTTPCode((c)) : 403
#define AUTHZ_ERRCODE(c) (CFG_CUWAauthzFailHTTPCode((c))!=NULL) ? *CFG_CUWAauthzFailHTTPCode((c)) : 403
#define REDIRECT_STATUS_CODE 302

#define TWO_FACTOR_REDIRECT_CODE 2

static void cuwa_setup_environment( void *r, cuwa_session_t *session);
static int goto_orig_url(void *r, apr_pool_t *pool, CUWACfg_t *cfg, char *sidstr);
static int goto_weblogin(void *r, apr_pool_t *pool, CUWACfg_t *cfg, int reason);
static int cuwa_auth_type(void *r, apr_pool_t *pool);

int cuwa_core_authn(void *r, apr_pool_t *pool, char *login_cred, char *cookies, char *sidstr)
{
    cuwa_err_t code = CUWA_ERR_CRED_MISSING;
    cuwa_session_t *session = NULL;
    uint64 sid;
    int respCode;
    int sts, cookieLen;
    char *cookie = NULL;
    CUWACfg_t *cfg = cuwa_wal_get_config(r);
    char *req_line;
    int noprompt = 0;
    char *tgt_times;
    int i;
    char *authtype = cuwa_wal_get_authtype(r);
    const apr_array_header_t *requiresList = cuwa_wal_get_requires( r);
    void *reqs;
    char *cookie_state = NULL;

    cuwa_assert(cfg);

    // Get the curauth_typerent configuration info...

    sts = cuwa_auth_type(r,pool);
    if (sts) return sts;

    // Check for requires noprompt
    if ( requiresList )
    {
        reqs = (void *)requiresList->elts;
        for (i=0; i<requiresList->nelts; i++)
        {
            req_line = cuwa_wal_get_require_line( r, reqs, i);
            if (!strcmp(req_line,"noprompt"))
            {
                if ( i == 0 )
                    noprompt = 1;
                else if (!noprompt)
                    return cuwa_core_show_error(r,pool,500, 0, "Server is not properly configured.Require noprompt is defined with other require directive.");
            }
            else if (noprompt)
                return cuwa_core_show_error(r,pool,500, 0, "Server is not properly configured.Require noprompt is defined with other require directive.");

        }
    }
    // Set credential age requirement if force or force-once are used...
    if (!CFG_CUWACredentialAge(cfg) && strstr(authtype,"-force") )
    {
        cfg->CUWACredentialAge.iv = DEFAULT_FORCE_TIME;
        cfg->CUWACredentialAge.v = &cfg->CUWACredentialAge.iv;
        cuwa_warning("Authtype -force and -forceonce obsolete, using CUWACredentialAge %d",DEFAULT_FORCE_TIME);
    }
   
    if ( CFG_CUWACredentialAge(cfg) &&
        *CFG_CUWACredentialAge(cfg)>=0 &&
        *CFG_CUWACredentialAge(cfg)<MIN_CRED_AGE)
    {
        cfg->CUWACredentialAge.iv = MIN_CRED_AGE;
        *CFG_CUWACredentialAge(cfg) = MIN_CRED_AGE;
    }
    
    //// Check configs, clear headers - GENERIC

    if (!CFG_CUWAKerberosPrincipal(cfg)) return cuwa_core_show_error(r,pool, 500, 0, "Server is not properly configured. Check the Kerberos principal." );
    if (!CFG_CUWAKeytab(cfg))            return cuwa_core_show_error(r,pool, 500, 0, "Server is not properly configured. Check the keytab." );
    if (!CFG_CUWAWebLoginURL(cfg))       return cuwa_core_show_error(r,pool, 500, 0, "Server is not properly configured. Check the weblogin URL." );

    // Unset everything that matters...
    cuwa_wal_clear_header_in( r,"REMOTE_USER");
    cuwa_wal_clear_header_in( r,"NETID");
    cuwa_wal_clear_header_in( r,"CUWA_REMOTE_USER");
    cuwa_wal_clear_header_in( r,"CUWA_FULL_USER");
    cuwa_wal_clear_header_in( r,"CUWA_REALM");
    cuwa_wal_clear_header_in( r,"CUWA_MECHANISM");
    cuwa_wal_clear_header_in( r,"CUWA_END_TIME");
    cuwa_wal_clear_header_in( r,"CUWA_AUTH_TIME");
    cuwa_wal_clear_header_in( r,"CUWA_GROUPS");
    cuwa_wal_clear_header_in( r,"CUWA_WAC0");
    cuwa_wal_clear_header_in( r,"CUWA_2F_USER");
    cuwa_wal_clear_header_in( r,"CUWA_2F_METHOD");
    cuwa_wal_clear_header_in( r,"CUWA_2F_TIME");

    //Ideally this would be reworked to always accept a cookie via the Authorization basic header.
    //but always sanitize that header once we were done
    //unfortunately due to subrequest handling, sanitization currently interferes with this, so the header
    //is only allowed when CUWAAuthBasic is on

    if(!CFG_CUWAAuthBasic(cfg) || *CFG_CUWAAuthBasic(cfg) != O_CFG_CUWAAuthBasic_on)
    {
        //normal non-dav mode
        cuwa_trace("COOKIES: %s",cookies?cookies:"NONE");
        if (cookies)
        {
            // Extract our cookie from the rest of the cookies
            cookie = cuwa_core_find_cookie(r, pool, cookies, CUWA_SITE_COOKIE_NAME,&cookie_state);

            // Discarded cookie equivalent to no cookie
            if (cookie && strncmp(cookie,CUWA_SITE_COOKIE_DISCARDED,strlen(CUWA_SITE_COOKIE_DISCARDED))==0)
            {
                cookie = NULL;
            }
        }
    	// Potential PHP security hole.  Clear this so that it can't be hacked :-)
        cuwa_wal_clear_header_in( r,"Authorization");
    }
    else
    {
        //if CUWAAuthBasic on is present, try to read the Authorization header
        char *authorization = (char *)cuwa_wal_get_header_in(r, "Authorization");
        if(authorization)
        {
            if(!strncmp(authorization,"Basic ",6))
            {
                char * user_pass=apr_pcalloc(pool,cuwa_base64_decode_bytes(authorization+6)+1);
                cuwa_base64_decode(authorization+6, user_pass);
                cookie=strchr(user_pass,':');
                if(cookie && !strncmp(cookie,":WA",2) && strlen(cookie) > 30)
                {
                    cuwa_info("Extracted webauth cookie from basic auth header due to CUWAAuthBasic on");
                    cookie++;
                    //is this safe? are there any assumptions that to be in CUWA-Cookies you have to be valid?
                    cuwa_wal_note_set(r, "CUWA-Cookies", apr_psprintf( pool, "%s%s", CUWA_SITE_COOKIE_NAME, cookie));
                }
                else
                {
                    cuwa_info("Found an authorization header but the password wasn't a WA cookie credential:%s",user_pass);
                    cookie=NULL;
                }
            }
            else
            {
                cuwa_info("found an Authorization header but it wasn't Basic");
            }
            
        }
    }

    cuwa_trace("authn: CUWL-Credential: %s",login_cred?login_cred:"<no credential>");
    cuwa_trace("authn: Cookie: %s",cookie?cookie:"<no webauth cookie>");

    // Check the cookie
    if (cookie || login_cred)
    {
        // Get the session from cookie..
        do
        {
            code = cuwa_session_from_credential( r, pool, cfg, cuwa_core_strip_path(pool, cuwa_wal_get_virtual_host(r, cfg, NULL)),
                                             login_cred, login_cred? strlen(login_cred) : 0,
                                             cookie, cookie ? strlen(cookie) : 0,
                                             CFG_CUWAKerberosPrincipal(cfg), CFG_CUWAKeytab(cfg),
                                             &session);
            cuwa_trace("authn: cuwa_session_from_credential %d state=%p",code, cookie_state);

            // If bad session, see if there are any more site cookies - adding CUWA_ERR_BAD_CRED to avoid DOS
            if (cookie_state && (code==CUWA_ERR_SESSION_NOT_FOUND || code==CUWA_ERR_BAD_CRED)) 
            {
                cookie = cuwa_core_find_cookie(r, pool, cookie_state, CUWA_SITE_COOKIE_NAME, &cookie_state);
                cuwa_trace("authn: try another cookie: %s",cookie?cookie:"NULL");
            }
        } while (cookie && cookie_state && (code==CUWA_ERR_SESSION_NOT_FOUND || code==CUWA_ERR_BAD_CRED));

        if (!code && login_cred)
        {
            if (sidstr==NULL) return cuwa_core_show_error(r,pool,AUTHN_ERRCODE(cfg), code, "SessionID missing from URL filename" );
            sscanf( sidstr, "%llX", &sid);
            if (sid!=session->sessionID) 
            {
                cuwa_warning("sid in cookie %llx is different than sid in cred %llx", sid, session->sessionID);
                return cuwa_core_show_error(r,pool,AUTHN_ERRCODE(cfg), code, "SessionID invalid for credential" );
            }

            // Send site cookie to browser...
            cuwa_trace("authn: sending Set-Cookie");
            code = cuwa_session_to_cookie( session, &cookie, &cookieLen );
            if ( code == CUWA_OK )
            {
                cuwa_wal_set_cookie(r,CUWA_SITE_COOKIE_NAME,cookie);

                // Send to ourself, internal redirects and subrequests
                cuwa_wal_note_set(r, "CUWA-Cookies", apr_psprintf( pool, "%s%s", CUWA_SITE_COOKIE_NAME, cookie));

                // Don't process the weblogin cred again on subrequest or internal redirect
                cuwa_wal_note_set( r,"CUWL-Credential",NULL);
            }
            else
            {
                return cuwa_core_show_error(r,pool,500, code, "Server error: sessionid/key gen failed: %d", code);
            }

            // Update session state
            code = cuwa_session_release( session );
            if (code)
                return cuwa_core_show_error(r,pool,500, code, "Server error: update session file failed: %d", code);

            // Now redirect back to original URL
            return goto_orig_url(r, pool, cfg, sidstr);
        }


        if (!code && cookie)
        {
            // Delegation check.  Make sure we have requested delegation if delegation is required by this location.
            int sessionFlags, configFlags;
            char *f1str = cuwa_session_get_attribute(session,"CUWA_F1",0);
            if (f1str)
            {
                sessionFlags = atoi(f1str);
                configFlags = CFG_CUWAwak2Flags(cfg)?(*CFG_CUWAwak2Flags(cfg) == O_CFG_CUWAwak2Flags_1):0;
                cuwa_trace("sessionFlags: 0x%X configFlags:0x%X",sessionFlags,configFlags);
                if ((configFlags & CUWA_WAK2FLAG_DELEGATE)  && !(sessionFlags & CUWA_WAK2FLAG_DELEGATE) )
                {
                    // Fixme: eventually we should retain the existing session and just update with new credential data. too complicated for now.
                    // Fixme: should we delete the session here? For now it will sit around until it expires.
                    code = CUWA_ERR_SESSION_EXPIRED;
                    cuwa_trace("Need delegation credential, going back to weblogin");

                    cuwa_session_release( session );
                    session = NULL;
                }
            }
        }
    }
    
    // The following block is somewhat redundant with the authZ code which checks if either the person is allowed
    // via valid-user@realm or via permit or specific ID.  Removing this block will make it possible for someone 
    // in a foriegn realm to be added to a permit and be granted access to site without the site explicitly granting
    // access to the foriegn realm in general.  This seems like a good thing.  This also makes it possible to have 
    // CUWAwak0Realms only list a subset of acceptable realms or present alias names for the realms in the weblogin popup.
#if 0
    // NOTE: Leaving this code in place for now as a precaution.  It was originally added in version 1.32 by gbr4.
    if (!code && session && CFG_CUWAwak0Realms(cfg))
    {
        // If wak0Realms was specified, only allow credentials for specified realms
        char *goodrealms = CFG_CUWAwak0Realms(cfg);
        char *realm = cuwa_session_get_attribute(session,"CUWA_REALM",0);
        if (realm)
        {
            if(NULL == cuwa_strlist_member(goodrealms,realm,','))
            {
                cuwa_info("The user supplied a credential from realm %s for a page that allows only %s.",realm,goodrealms);
                code=CUWA_ERR_CRED_MISSING;
		//should this session be released as below?
            }
        }
        else //should this be an assert?
        {
            char *baduser = cuwa_session_get_attribute(session,"CUWA_FULL_USER",0);
            cuwa_warning("User has authenticated, but the credential has no realm: %s",baduser?baduser:"NULL");
            cuwa_session_release( session );
            session = NULL;
            code=CUWA_ERR_CRED_MISSING;
        }
    }
#endif

    if (code ==CUWA_ERR_SESSION_NO_DUAL || code==CUWA_ERR_CRED_MISSING || code==CUWA_ERR_CRED_TOO_OLD || code==CUWA_ERR_SESSION_NOT_FOUND || code==CUWA_ERR_SESSION_EXPIRED)
    {
        // look for sign of valid TGT, if none, don't prompt
        // assumptions... the cookie = endtime, cookie name
        if (noprompt)
        {
            tgt_times = cuwa_core_find_cookie(r, pool, cookies, CUWA_WEB_LOGIN_TGT_COOKIE_NAME, NULL);
            if (!tgt_times) cuwa_trace("noprompt: %s not set",CUWA_WEB_LOGIN_TGT_COOKIE_NAME);

            if (!tgt_times || (tgt_times && (atoi(tgt_times) < apr_time_sec( apr_time_now()))))
            {
                if (tgt_times) cuwa_trace("noprompt: %s=%s(%d) < now=%d",CUWA_WEB_LOGIN_TGT_COOKIE_NAME,tgt_times,atoi(tgt_times),apr_time_sec( apr_time_now()) );
                cuwa_wal_set_cookie(r,CUWA_SITE_COOKIE_NAME,NULL);
                return CUWA_OK;
            }

            cuwa_trace("noprompt: login is current, redirect to weblogin OK");
        }

        if( CFG_CUWAAuthBasic(cfg) && *CFG_CUWAAuthBasic(cfg) == O_CFG_CUWAAuthBasic_on)
        {
            //if this is dav, get me out of here
            char *authnheader = apr_psprintf(pool,"Basic realm=\"Do NOT use your password. Get a WebDAV access key from %s/davlogin\"",cuwa_wal_get_virtual_host(r, cfg, NULL));
            respCode=401;
            cuwa_info("Sending CUWAAuthBasic challenge");
            cuwa_wal_set_header_out(r,"WWW-Authenticate",authnheader);
            return 401;
        }

        if ( cookie ) cuwa_wal_set_cookie(r,CUWA_SITE_COOKIE_NAME,NULL);

        if ( code == CUWA_ERR_SESSION_NO_DUAL) return goto_weblogin(r,pool,cfg, TWO_FACTOR_REDIRECT_CODE);
        else return goto_weblogin(r,pool,cfg,1);
    }

    if (session)
        cuwa_trace("Got session from cookie... session: %x sessionid=%llX",session, session->sessionID);

    if (code)
    {
        // Discard the cookie, in case it's bad...
        cuwa_wal_set_cookie(r,CUWA_SITE_COOKIE_NAME,NULL);
        if (session) cuwa_session_release( session );

        if (code==CUWA_ERR) return cuwa_wal_show_error(r);
        return cuwa_core_show_error(r,pool, AUTHN_ERRCODE(cfg), code, "Credential rejected, reason code: %d", code );
        
    }

    cuwa_setup_environment( r, session );

    if( CFG_CUWAHeaderKey(cfg) && *CFG_CUWAHeaderKey(cfg) == O_CFG_CUWAHeaderKey_on)
    {
        cuwa_make_hdr_key(r,0,0);
    }

    cuwa_permit_cache_load( r, session, pool );
    cuwa_session_release( session );

    return CUWA_OK;
}

#if (!defined APACHE_BUILD || AP_SERVER_MINORVERSION_NUMBER <= 2)
int cuwa_core_authz(void *r, apr_pool_t *pool)
{
    int method_restricted = 0;
    int i;
    const char *req_line, *req_word;
    CUWACfg_t *cfg = cuwa_wal_get_config(r);
    char *remote_user = cuwa_wal_get_env( r,"REMOTE_USER");
    char *full_user = cuwa_wal_get_env( r,"CUWA_FULL_USER");
//    char *realm_user = cuwa_wal_get_env( r,"CUWA_REALM");
    char *inquire = CFG_CUWAInquire(cfg);
    int sts;
    const apr_array_header_t *requiresList = cuwa_wal_get_requires(r);
    void *reqs;
    int inquireAllSet = 0;

    sts = cuwa_auth_type(r,pool);
    if (sts)
    {
        return sts;
    }

    // handle the CUWAInquire directive...
    if (inquire && remote_user)
    {
        char *memberships;
        int rc;

        req_word = cuwa_getword(pool, (const char **) &inquire,' ');

        if (!strcmp(req_word, "permit"))
        {
            rc = cuwa_permit_lookup(r, pool, NULL, CFG_CUWAKerberosPrincipal(cfg), CFG_CUWAKeytab(cfg),
                               full_user, inquire, &memberships);
            if (rc) return cuwa_wal_show_error(r);

            if (memberships)
            {
                cuwa_wal_set_header_in(r,"CUWA_GROUPS",memberships);
                cuwa_wal_set_env(r,"CUWA_GROUPS",memberships);
                inquireAllSet = 1;
            }
        }
        else
        {
            return cuwa_core_show_error(r,pool,500, 0, "Server configuration error.  Unsupported CUWAInquire type: %s", req_word);
        }
    }

    // Handle the require directive...
    reqs = (void *) requiresList->elts;
    for (i=0; i<requiresList->nelts; i++)
    {
        req_line = cuwa_wal_get_require_line( r, reqs, i );
        if ( !req_line )
            continue;

        method_restricted = 1;

        req_word = cuwa_getword(pool, &req_line,' ');

        if (!strcmp(req_word, "noprompt"))
        {
            cuwa_info("Authorization granted to %s (noprompt)", full_user?full_user:"anonymous user");

            return CUWA_OK;
        }

        if (!remote_user) continue;


        if (!strncmp(req_word,"valid-user",10))
        {
            do
            {
                char *realm;
                cuwa_trace("check %s", req_word);
                realm = strchr(req_word, '@');

                if (!realm)
                {
                    //require valid-user is defined which only allows user in local realm
                    //if remote_user doesn't contain realm that means it is in local realm
                    if ( !strchr( remote_user, '@' ) )
                    {
                        cuwa_info("Authorization granted to %s (valid-user)", full_user);
                        return CUWA_OK;
                    }
                }
                else
                {
                    //require valid-user@realm is defined. Check if remote_user is in the same realm as defined
                    char *remote_user_realm = strchr(full_user,'@');
                    cuwa_assert(remote_user); //full user always has a @
                    if (!strcmp( remote_user_realm, realm ) )
                    {
                        cuwa_info("Authorization granted to %s (valid-user)", full_user);
                        return CUWA_OK;
                    }
                }
                req_word = cuwa_getword_conf(pool, &req_line);
           }while (req_word && !strncmp(req_word,"valid-user",10));
        }
        else if (!strcmp(req_word,"netid"))
        {
            while (req_line[0])
            {
                req_word = cuwa_getword_conf(pool, &req_line);
                if (!strcmp(remote_user,req_word))
                {
                    cuwa_info("Authorization granted to %s (netid)", full_user);
                    return CUWA_OK;
                }

                if (!strcmp(full_user,req_word))
                {
                    cuwa_info("Authorization granted to %s (netid)", full_user);
                    return CUWA_OK;
                }
            }
        }
        else if (!strcmp(req_word, "permit"))
        {
            char *memberships;
            int rc;

            rc = cuwa_permit_lookup(r, pool, NULL, CFG_CUWAKerberosPrincipal(cfg), CFG_CUWAKeytab(cfg),
                               full_user, (char*) req_line, &memberships);
            if (rc) return cuwa_wal_show_error(r); 

            if (memberships)
            {
                cuwa_info("Authorization granted to %s (permits=%s)", full_user,memberships);
                if ( !inquireAllSet )
                {
                    cuwa_wal_set_header_in(r,"CUWA_GROUPS",memberships);
                    cuwa_wal_set_env(r,"CUWA_GROUPS",memberships);
                }
                return CUWA_OK;
            }
        }
        else
        {
            return cuwa_core_show_error(r,pool,500, 0, "Server error: Unrecognized require directive: %s", req_word);
        }

    }

    if (!method_restricted)
    {
        cuwa_info("Authorization granted to %s (no require rule)", full_user);
        return CUWA_OK;
    }
#if 0
    // Not authorized.  If user realm is not listed in CFG_CUWAwak0Realms go back to weblogin
    if (CFG_CUWAwak0Realms(cfg))
    {
        char *goodrealms = CFG_CUWAwak0Realms(cfg);
        if (!realm_user || NULL == cuwa_strlist_member(goodrealms,realm_user,','))
        {
            cuwa_info("The user supplied a credential from realm %s for a page that allows only %s.",realm_user?realm_user:full_user,goodrealms);
            cuwa_wal_set_cookie(r,CUWA_SITE_COOKIE_NAME,NULL);  // NOTE: might want to destroy session as well
            return goto_weblogin(r,pool,cfg,0);
        }
    }
#endif    

    // If admin defined an ErrorDocument, just returned the error code
    if (cuwa_wal_handle_error(r, AUTHZ_ERRCODE(cfg))) return AUTHZ_ERRCODE(cfg);

    // Otherwise returned CUWebAuth error page
    return cuwa_core_show_error(r,pool, AUTHZ_ERRCODE(cfg), 0, "User %s is not authorized to access %s", remote_user, cuwa_wal_get_uri(r,CUWA_URI_UNPARSED));
}
#endif

void cuwa_setup_environment( void *r, cuwa_session_t *session)
{
    int i, len;
    const apr_array_header_t *arr=NULL;
    const apr_table_entry_t *elts=NULL;
    apr_table_t *attributes;
    char *user, *cookie;

    attributes = cuwa_session_get_attributes( session );
    if (!attributes || apr_is_empty_table(attributes))
    {
        cuwa_info("No cred attributes present");
        return;
    }

    user = (char*) apr_table_get( attributes,"CUWA_FULL_USER");
    if (user) cuwa_info("Authenticated user is: %s", user);
    else cuwa_info("Warning: No user attribute present");

    user = (char*) apr_table_get( attributes,"REMOTE_USER");
    cuwa_wal_set_user(r, user);

    arr = apr_table_elts( attributes );
    elts = (const apr_table_entry_t *)arr->elts;

    for (i=0; i < arr->nelts; i++ )
    {
        cuwa_trace("%s=%s",elts[i].key,elts[i].val);
        cuwa_wal_set_header_in(r,elts[i].key,elts[i].val);
        cuwa_wal_set_env(r,elts[i].key,elts[i].val);
    }

    if (CUWA_OK == cuwa_session_to_cookie( session, &cookie, &len ))
    {
        cuwa_wal_set_header_in(r,"CUWA_WAC0",cookie);
        cuwa_wal_set_env(r,"CUWA_WAC0",cookie);
    }
}

int cuwa_auth_type(void *r, apr_pool_t *pool)
{
    char *authtype;

    authtype = cuwa_wal_get_authtype(r);

    if ( !authtype )
    {
        cuwa_trace("Authtype not defined (declined)");
        return cuwa_wal_return_declined();
    }

    if (!strncasecmp(authtype,"all",3))
    {
    }
    else if (!strncasecmp(authtype,"cuweblogin",10))
    {
        cuwa_warning("Authtype cuweblogin obsolete, using AuthType all");
    }
    else if (!strncasecmp(authtype,"inline",6))
    {
        cuwa_alarm("Authtype inline is obsolete");
        return cuwa_core_show_error(r,pool,500, 0, "Server error.  Details: authtype inline is obsolete.");
    }
    else if (!strncasecmp(authtype,"sidecar",7))
    {
        cuwa_alarm("Authtype sidecar is obsolete");
        return cuwa_core_show_error(r,pool,500, 0, "Server error.  Details: authtype sidecar is obsolete.");
    }
    else
    {
        // !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
        // !! CAUTION adding a trace here will cause python auth to fail.  
        // Python hacks the value of r->main r->prev and r->next between authn and authz stages.
        // !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
        //cuwa_trace("Authtype unknown: %s (declined)",authtype);
        
        return cuwa_wal_return_declined();
    }

    return CUWA_OK;
}

char *cuwa_get_login_server_from_config( CUWACfg_t *cfg )
{
    char *servers = CFG_CUWAWebLoginURL(cfg);
    char *host = NULL, *state;

    host = apr_strtok( servers, " ", &state);
    if ( !host )
        host = servers;

    return host;
}


/*
    ReturnURL = http://server/orig-path/sid.cuweblogin, where sid is the sessionid-base16
    WAK2Name = What text is the K2 known as (NetID)
    WAK0Service = Principal
    SID = session ID
    VerP = protocol version, should be 1.0
    VerC = client version, should be WebAuth/2.0/WebServer/OS
    Accept = K2
    WAK2Flags = Flags for the K2 (???, pass zero)
    WAK0Realms = Kerberos Domains, separated by , (CIT.CORNELL.EDU)   (optional, default use WAK0Service realm)
    WAK2Age = (authtime) based age for K2 in seconds                  (optional)
*/
int goto_weblogin(void *r, apr_pool_t *pool, CUWACfg_t *cfg, int reason)
{
    char *loginurl = NULL;
    char *serviceid = CFG_CUWAKerberosPrincipal(cfg);
    char *ageStr, *path, *p,*dualStr="";
    char *location;
    uint64 sid;
    char *returnAddr;
    char *fmt = "%s/?SID=%qX&WAK0Service=%s&WAK2Name=%s&WAK0Realms=%s&ReturnURL=%s&VerP=3&%s&Accept=K2&WANow=%d&WAK2Flags=%d%s%s&WAreason=%d";
    char *clientVersion = cuwa_get_client_version();
    char *cookie, *newCookie;
    time_t now = apr_time_sec( apr_time_now() );
    int code, flags = CFG_CUWAwak2Flags(cfg)?(*CFG_CUWAwak2Flags(cfg) == O_CFG_CUWAwak2Flags_1):0;
    char *WAK2Name = CFG_CUWAwak2Name(cfg)?CFG_CUWAwak2Name(cfg):"";
    char *WAK0Realms = CFG_CUWAwak0Realms(cfg)? CFG_CUWAwak0Realms(cfg):"";
    char *dualMethod = CFG_CUWA2FAMethod(cfg);
    char *dualAuth =  CFG_CUWA2FARequire(cfg);

    cuwa_trace("goto_weblogin: credage=%d",CFG_CUWACredentialAge(cfg));

    //if dualAuth all is defined, we should ask webLogin to do twofactor in one trip
    if ( dualAuth && !strcmp(dualAuth,"all") ) reason = TWO_FACTOR_REDIRECT_CODE;
    cuwa_trace("reason=%d, dualAuth=%s",reason, dualAuth?dualAuth:"not defined");
 
    //get login server
    if ( CUWA_HA_ENABLED( cfg ) )
    {
         //get cookie
        cookie = (char*) cuwa_wal_get_header_in( r,"Cookie" );
        if ( cookie )
            cookie = cuwa_core_find_cookie(r, pool, cookie, CUWA_WEB_LOGIN_COOKIE_NAME, NULL);

        loginurl = cuwa_ha_get_login_server(cookie, &newCookie, pool);
        if (!loginurl)
        {
            if (cuwa_ha_get_init_status())
                return cuwa_core_show_error(r,pool, 500, 0, "Server error: cuWebAuth failed at initializing high availability. Please make sure outgoing port 443 is NOT blocked by firewall. Then reboot web server.");
            else
                return cuwa_core_show_error(r,pool, 500, 0, "Server error: all web login servers are currently down. You may try again in 5 minutes.");
        }
    }
    else
    {
        loginurl = cuwa_get_login_server_from_config(cfg);
        if (!loginurl)
            return cuwa_core_show_error( r, pool, 500, 0,"Server error: CUWAWebLoginURL is not configured properly");
    }


    if (!serviceid)
    {
        return cuwa_core_show_error(r,pool, 500, 0, "Server error: CUWAKerberosPrincipal directive not specified" );
    }

    // save the request
    code = cuwa_wal_request_save(&sid,r);
    if (code)
    {
        return cuwa_core_show_error(r,pool,500, code, "Server error, reason code: %d", code );
    }

    if ( CUWA_HA_ENABLED( cfg ) )
    {
        //set the cookie returned by high availability
        cuwa_wal_set_cookie(r, CUWA_WEB_LOGIN_COOKIE_NAME, newCookie );
    }
    ageStr = CFG_CUWACredentialAge(cfg) ? apr_psprintf( pool,"&WAK2Age=%d",*CFG_CUWACredentialAge(cfg)) : "";

    if ( dualAuth && strcmp(dualAuth,"none"))
    {
        cuwa_util_replace_char_with(dualAuth,' ',',');
        dualStr = apr_psprintf(pool,"&DualAuth=%s",dualAuth);
    }

    if ( dualMethod && dualStr && strlen(dualStr) > 0 )
    {
        cuwa_util_str_to_upper(dualMethod);
        dualStr = apr_pstrcat(pool,dualStr,"&DualMethod=", dualMethod, NULL);
    } 
    // Get the path from uri
    path = apr_pstrdup(pool, cuwa_wal_get_uri(r,CUWA_URI_ORIGINAL));
    p = strrchr(path,'/');
    if (p) *p = 0;
    else path = "";

    // ReturnURL = http://server/sid/cuwal2.c0ntinue, where sid is the sessionid-base16
    returnAddr = apr_psprintf( pool,"%s/%qX/%s", cuwa_wal_get_virtual_host(r, cfg, path), sid, CUWA_MAGIC_FILE);

    if( CFG_CUWAclearCookies( cfg ) )
    {
        char *toclear = apr_pstrdup(pool,CFG_CUWAclearCookies(cfg));
        char *nextclear;
        cuwa_trace("CUWAclearCookies: %s",toclear);
        while(toclear && *toclear){
            nextclear=strchr(toclear,' ');
            if(nextclear)
            {
                *nextclear='\0';
                nextclear++;
            }
            cuwa_wal_set_cookie(r,apr_psprintf(pool,"%s=",toclear),NULL);
            toclear=nextclear;
        }
    }

    cuwa_trace("ReturnURL: %s",returnAddr);

    location = apr_psprintf( pool, fmt, loginurl, sid, serviceid, cuwa_wal_escape_uri(pool,WAK2Name),WAK0Realms, returnAddr, clientVersion, (int)now, (int)flags, ageStr, dualStr, reason);

    cuwa_wal_dont_cache(r);

    cuwa_info("Redirect to weblogin: %s",location);

    cuwa_wal_set_header_out(r, "Location", location);
    
    apr_sleep(100000); //sleep a tenth of a second to slow down any loops
    
    cuwa_trace("Inbound request redirected: %s %s",cuwa_wal_get_method(r),cuwa_wal_get_uri(r,CUWA_URI_UNPARSED));

    return REDIRECT_STATUS_CODE;
}


int goto_orig_url(void *r, apr_pool_t *pool, CUWACfg_t *cfg, char *sidstr)
{
    char *uri, *sep, *location;

    // Get the path from uri
    uri = apr_pstrdup(pool, cuwa_wal_get_uri(r,CUWA_URI_ORIGINAL|CUWA_URI_UNPARSED));

    sep = strchr(uri,'?') ? "&" : "?" ;

    if(!strcmp(cuwa_wal_get_method(r),"GET"))
    {
        //This is a GET, don't need to restore the request again
        //just 302 to the original URL
        //works around actionless form bug (or 95% of it)
        location = apr_psprintf( pool,"%s%s", cuwa_wal_get_virtual_host(r, cfg, NULL), uri);
    }
    else
    {
        //not a GET, add CUWACRED=y paramater to force a restore
        location = apr_psprintf( pool,"%s%s%s%s%s", cuwa_wal_get_virtual_host(r, cfg, NULL), uri, sep, CUWA_MAGIC_ARG,sidstr);
    }

    cuwa_wal_dont_cache(r);

    cuwa_info("Redirect to orignal uri: %s",location);
    cuwa_wal_set_header_out(r, "Location", location);

    return REDIRECT_STATUS_CODE;

}

char * cuwa_core_find_cookie(void *r, apr_pool_t *pool, char *cookies, char *cookieName, char **state)
{
    char *cookie,*buf = NULL;
    int len;

    if ( !cookies )
        return NULL;

    cuwa_trace("find %s cookie: %s",cookieName, cookies);

    cookie = strstr(cookies, cookieName);
    if (!cookie)
    {
        if (state) *state = NULL;
        return NULL;        
    }

    cookie += strlen(cookieName);

    len = strcspn( cookie, ";?\r\n" );
    //len = token ? (token - cookie) : strlen(cookie);

    buf = apr_palloc( pool, len+1 );
    memcpy(buf,cookie,len);
    buf[len]=0;
    
    if (state) *state = &cookie[len];

    // Take out quotes if there are any
    if (buf[0]=='"')
    {
        buf[len-1]=0;
        buf++;
    }

    return buf;
}

const char *cuwa_core_get_error_string(int code )
{
    return CUWA_ERR_TO_STR(code);
}

/*when CUWAshowError is turned on, display cuwebauth error in web browser*/
int cuwa_core_show_error(void *r, apr_pool_t *pool, short status, int code, const char *fmt, ... )
{
    va_list args;
    char *reason, *text, *title,*loginrpt;
    const char *detail   = cuwa_wal_get_log_error( r );
    const char *emsg     = CUWA_ERR_TO_STR(code);
    char       *host     = cuwa_wal_get_hostname(r)?cuwa_wal_get_hostname(r):"";
    char       *loginurl = NULL;
    char       *html     = NULL;
    char       *newCookie;
    CUWACfg_t *cfg = cuwa_wal_get_config(r);

    cuwa_trace("cuwa_core_show_error: %d %d",status,code);

    if ( CUWA_HA_ENABLED( cfg ) )
        loginurl = cuwa_ha_get_login_server(NULL, &newCookie, pool);
    else
        loginurl = cuwa_get_login_server_from_config(cfg);

    if ( !loginurl )
        loginurl = "";

    if (status>=500)
    {
        text  = "This may be caused by a temporary server or network outage.  "
                "Before reporting a problem please try again.  ";
        title = "Server error";
    }
    else
    {
        text  = "You may not have sufficient privileges to access this page.  ";
        title = "Access Denied";
    }

    va_start(args, fmt);
    reason = apr_pvsprintf(pool,fmt,args);
    va_end(args);

    if (!detail) detail = "";

    loginrpt = apr_psprintf(pool,"%s/error_report?status=%d&error=%d&reason=%s&detail=%s",loginurl,status,code,
                            cuwa_wal_escape_uri(pool,reason),cuwa_wal_escape_uri(pool,(char *)detail));


    html = apr_psprintf(pool,cuwa_error_page,
                loginrpt,loginurl,loginurl,loginurl,
                host,title,status,host,
                text,reason,code,
                emsg?emsg:"no further detail",
                detail?detail:"no further detail",
                cuwa_wal_get_server_signature("",r));

    return cuwa_wal_send_page(r, status, html);
}

char *cuwa_core_make_return_url(apr_pool_t *pool, CUWACfg_t *cfg, char *host, int port, int isSSL, char *path)
{
    char *vhost = NULL;
    char *scheme, *str, *p;

    scheme = isSSL?"https":"http";
    
    if (CFG_CUWAReturnURL(cfg))
    {
        // make sure we have a path and the path starts with /
        if (!path) path = "";
        if (strlen(path) && *path!='/') path = apr_psprintf(pool,"/%s",path);

        str = apr_pstrdup( pool,CFG_CUWAReturnURL(cfg));
        p = strstr(str,"%p");
        if (p) 
        {
            *p = 0;
            p += 2;
            vhost = apr_psprintf(pool,"%s%s%s",str,path,p);
        }
        else
        {
            vhost = str;
        }
    }
    else if ((isSSL && port==443) || (!isSSL && port==80) || !port)
    {
        // use default port
        vhost = apr_psprintf( pool,"%s://%s",scheme,host);
    }
    else
    {
        vhost = apr_psprintf( pool,"%s://%s:%d",scheme,host,port);
    }

    return vhost;
}

int cuwa_permit_lookup(void *r, apr_pool_t *pool, void *session, char *localid, char *keytab, char *remote_user,
                       char *permitlist, char **memberships)
{
    int code;
    char *nonmember;
     char *msg;

    if (!localid)
    {
        msg = "Server is not properly configured. Check the Kerberos principal.";
        cuwa_wal_save_error(r, HTTP_SERVER_ERROR, CUWA_ERR,msg);
        return CUWA_ERR;
    }
    if (!keytab)
    {
        msg = "Server is not properly configured. Check the keytab.";
        cuwa_wal_save_error(r, HTTP_SERVER_ERROR, CUWA_ERR,msg);
        return CUWA_ERR;
    }

    code = cuwa_permit_cache_check((void *)r, pool, session, cuwa_wal_get_config(r),
                                        localid, keytab, remote_user, permitlist, memberships, &nonmember );

    return code;
}

// Pick up SID from returURL path (from weblogin)
char * cuwa_get_sid_from_uri(apr_pool_t *pool, char *url)
{
    char *str,*s;
    str = apr_pstrdup(pool, url);
    s = strstr(str,CUWA_MAGIC_FILE);
    if (!s || s==str) return NULL;
    s--;
    if (*s!='/') return NULL;
    *s-- = 0;
    while (s!=str && *s!='/') s--;
    s++;
    return s;
}

// Pick up SID from magic arg (from redirect to original)
char * cuwa_get_sid_from_arg(apr_pool_t *pool, char *url)
{
    char *str = apr_pstrdup(pool, url);
    char *s;

    str = strstr(str,CUWA_MAGIC_ARG);
    if(!str) return NULL;
    str += strlen(CUWA_MAGIC_ARG);
    s = str;
    while(*s && *s!='&') s++;
    *s = 0;
    return str;
}

int cuwa_ishex( char c ) {
    return( c && ( (c>='0' && c<='9') || (c>='a' && c<='f') || (c>='A' && c<='F') ) );
}

char * cuwa_get_cred_from_args( apr_pool_t *pool, char* post ) {
    char *inpos, *outpos;
    char* cred = cuwa_malloc( strlen(post) ); // this is certainly bigger than 
        // we need, so we don't need to check the length again.
    if(!cred) return NULL;

    //find the wa= paramater
    inpos = strstr(post,CUWA_MAGIC_CRED);
    if(!inpos) return NULL;
    inpos += strlen(CUWA_MAGIC_CRED);
   
    // copy the credential into cred, until we hit an & or we hit the end.
    // un-url-encode as we go, if we see something that looks like it was url-encoded.
    outpos = cred;
    while( *inpos && (*inpos != '&') ) {
        if( *inpos == '%' && cuwa_ishex(*(inpos+1)) && cuwa_ishex(*(inpos+2)) ) {
            unsigned int decoded = 0;
            sscanf(inpos+1,"%2x",&decoded);
            inpos += 2;
            *(outpos++) = decoded;
        } else {
            *(outpos++) = *inpos;
        }
        inpos++;
    }
    *outpos = 0;
    return cred;
}


char * cuwa_get_cred_from_uri(apr_pool_t *pool, char *url)
{
    char *ext = NULL, *cred=NULL;
    char *str;

    str = apr_pstrdup(pool, url);
    ext = strstr(str,CUWA_MAGIC_FILE);
    if (!ext) return NULL;
    cred = ext + strlen(CUWA_MAGIC_FILE);
    *ext = 0;
    return cuwa_get_cred_from_args(pool,cred);
}

// Set cookie in browser, also set inbound cookie for subrequests
char * cuwa_core_set_cookie(void *r, CUWACfg_t *cfg, char *cookieName, char *cookieValue)
{
    char *buf;
    const char *cookie;
    apr_pool_t *pool = cuwa_wal_get_pool( r );

    if (!cookieValue)
    {
        if(CFG_CUWAclearCookies(cfg))
        {
            buf = apr_psprintf( pool, "%s%s;expires=Thu, 01-Jan-1970 00:00:01 GMT;path=/%s", cookieName,CUWA_SITE_COOKIE_DISCARDED,
                  (cuwa_wal_is_ssl(r) ? "; secure" : ""));
        }
        else
        {
            buf = apr_psprintf( pool, "%s%s;path=/%s", cookieName,CUWA_SITE_COOKIE_DISCARDED,
                  (cuwa_wal_is_ssl(r) ? "; secure" : ""));
        }
    }
    else
    {
        cookie = cuwa_wal_get_header_in(r, "Cookie");
        cookie = apr_pstrcat( pool, (cookie?cookie:""), cookieName, cookieValue, ";", NULL);

        // fixme: need to set "secure" cookie if url in cred is https ONLY!  Actually I think this covers it, but should be reviewed
        // Using IS_SSL may expose cookie when non-ssl resources are accessed on ssl secured site.  Need to review.
        buf = apr_psprintf( pool, "%s%s;path=/%s;HttpOnly", cookieName,cookieValue,
                          (cuwa_wal_is_ssl(r) ? "; secure" : "") );

        // protected pages can't be cached
        cuwa_wal_dont_cache( r );

        if ( !strcmp(cookieName, CUWA_SITE_COOKIE_NAME) )
            cuwa_wal_set_header_in(r,"Cookie",(char *)cookie);
    }

    cuwa_trace("Set-Cookie: %s, length %d", cookieName, cookieValue?strlen(cookieValue):0);

    return buf;
}

char * cuwa_core_strip_path(apr_pool_t *pool, char *url)
{
    char *p;
    url = strdup(url);
    cuwa_trace("cuwa_core_strip_path in: %s",url);
    p = strstr(url,"//");
    if (!p) return url;
    p += 2;
    p = strchr(p,'/');
    if (p) *p = 0;
    cuwa_trace("cuwa_core_strip_path out: %s",url);
    return url;
}

char *cuwa_check_kerberosprincipal(void * cmd, void *sInfo, const char *arg, CUWACfg_t* scfg, CUWACfg_t* cfg, apr_pool_t *pool, char *what)
{
        char *principal = CFG_CUWAKerberosPrincipal(cfg);
        if ( !strchr( principal, '@' ) ) return apr_psprintf(pool,"Kerberos principal must have realm specified (such as @CIT.CORNELL.EDU): %s",principal);
        return NULL;
}

char *cuwa_check_returnurl(void * cmd, void *sInfo, const char *arg, CUWACfg_t* scfg, CUWACfg_t* cfg, apr_pool_t *pool,char *what)
{
        char *rurl = CFG_CUWAReturnURL(cfg);
        char * msg = "ReturnURL must be of the form http://host or https://host";
        if( strncmp("https://",rurl,8) && strncmp("http://",rurl,7) ) return(msg);
        if( strrchr(rurl,'/') >(rurl+8)) return(msg);
        return NULL;
}


const char id_session_auth_c[] = "$Id: auth.c,v 1.95 2015/10/07 18:33:52 hy93 Exp $";
