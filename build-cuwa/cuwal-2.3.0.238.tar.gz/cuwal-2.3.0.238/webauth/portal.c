/************************************************************************
 * portal.c -- Support CUWA portal proxy
 *
 * Copyright 2008 Cornell University.
 * All Rights Reserved.
 *
 ************************************************************************
 *  $Log: portal.c,v $
 *  Revision 1.31  2016/08/24 20:51:02  hy93
 *  increase the inital content size to 11k
 *
 *  Revision 1.30  2016/08/24 20:09:08  hy93
 *  allocate larger buffer using information returned by ssl_send_request
 *
 *  Revision 1.29  2016/08/24 17:32:02  hy93
 *  retry with bigger buffer when the content returned by weblogin is larger than the initial buffer size
 *
 *  Revision 1.28  2015/10/07 18:33:44  hy93
 *  merge TwoFactor treee to the head
 *
 *  Revision 1.27.2.5  2015/09/24 16:35:03  hy93
 *  Fix portal proxy failed when backend is still old webAuth
 *
 *  Revision 1.27.2.4  2015/04/15 14:39:36  hy93
 *  fix compiler error in Windows build
 *
 *  Revision 1.27.2.3  2015/02/03 15:08:02  hy93
 *  get cred from content instead of uri
 *
 *  Revision 1.27.2.2  2015/01/29 18:23:50  hy93
 *  remove changeds for 2F
 *
 *  Revision 1.27.2.1  2014/10/22 20:00:36  hy93
 *  add two factor support
 *
 *  Revision 1.27  2014/10/22 16:46:13  hy93
 *  remove two factor
 *
 *  Revision 1.26  2014/07/25 17:44:55  hy93
 *  interface change for cuwa_ssl_send_request
 *
 *  Revision 1.25  2011/08/02 16:20:32  hy93
 *  fix header get truncated after calling cuwa_core_portal_get_cookie
 *
 *  Revision 1.24  2011/08/01 04:18:06  pb10
 *  Add allCookies feature to proxy portal.
 *
 *  Revision 1.23  2009/09/18 03:55:14  pb10
 *  Backout site cookie naming scheme that was intended to fix the IE
 *  cookie issue that occurs when multiple distinct sites have overlapping
 *  domain names.
 *
 *  Revision 1.22  2009/08/12 17:36:22  hy93
 *  Add display of remote host's error message in portal
 *
 *  Revision 1.21  2009/08/07 18:13:57  hy93
 *  add checking if there is any value provided for netid or permits
 *
 *  Revision 1.20  2009/08/06 17:59:00  hy93
 *  remove showing log in trace
 *
 *  Revision 1.19  2009/08/06 17:28:06  hy93
 *  fix missing argument when call cuwa_trace
 *
 *  Revision 1.18  2009/07/30 15:54:55  pb10
 *  Change site cookie name from cuweblogin2 to cuweblogin2-N to
 *  accomodate IE behavior with regard to multiple sites that have overlapping
 *  multi-part domain names.
 *
 *  Revision 1.17  2009/06/23 15:47:04  hy93
 *  Implement listnetds in permit
 *
 *  Revision 1.16  2009/03/02 18:35:22  pb10
 *  - Add new credential attributes CUWA_KEYTAB, CUWA_SERVICEID
 *  - Change misnamed attribute CUWA_LOCAL_SERVICEID to CUWA_AUTH_HOST
 *  - Use new attributes in proxy portal instead of VH config
 *
 *  Revision 1.15  2009/02/13 19:53:46  pb10
 *  Need to change the ordering of fields in URL for proxy portal
 *  to accomodate changes for CUWAReturnURL.
 *
 *  Revision 1.14  2009/02/13 16:29:58  pb10
 *  CUWAReturnURL now accepts a %p that will be replaced with the
 *  original path of the URL (without the file).
 *
 *  Revision 1.13  2009/02/12 19:57:21  pb10
 *  Modify portal code so that it detects an old backend server
 *  that is using cuwal2sid cookie.  If found it generates an
 *  error in the portal log.
 *
 *  Revision 1.12  2009/02/11 06:26:02  pb10
 *  Removal of cuwal2sid cookie.
 *
 *  Revision 1.11  2008/10/23 17:02:27  hy93
 *  proxy failed when remote host is on default ssl port(443)
 *
 *  Revision 1.10  2008/09/19 03:52:25  pb10
 *  Always check CUWACredAge against start_time and auth_time (not just when processing login cred).
 *
 *  Revision 1.9  2008/09/16 19:19:04  hy93
 *  add static to functions that are internal in the file
 *
 *  Revision 1.8  2008/09/13 13:23:53  pb10
 *  Add IIS code and cleanup apache dependency in cuwa_version.c.
 *  Fix naming and positioning of DAV functions in wal.h.
 *
 *  Revision 1.7  2008/09/08 16:14:36  hy93
 *  change include file because of the rename ssl.h to cuwa_ssl.h
 *
 *  Revision 1.6  2008/09/06 01:38:19  gbr4
 *  fix crash in davlogin_handler on some platforms.
 *
 *  Revision 1.5  2008/09/06 01:29:02  gbr4
 *  Rename the directive CUWADavAuth to CUWAAuthBasic per Pete's suggestion.
 *
 *  Impliment the cuwa_davlogin handler (built-in page that gives the user their cookie to use with WebDAV). The user is free to impliment a prettier page in whatever they want or add a location block to turn on this handler.
 *
 *  Also split off some of the css into cuwa_page.html and genericize our handler calling (one handler for the portals registered with apache that then delegates to the appropriate core functions instead of one handler per portal).
 *
 *  Revision 1.4  2008/08/26 17:53:22  hy93
 *  remove apache dependency in auth.c and portal.c
 *
 *  Revision 1.3  2008/08/25 21:13:23  gbr4
 *  make portal.c include log_apache.h (WRONG). needs to be revisited. neither this nor the auth.c from which it is descended should include log_apache.h
 *
 *  Revision 1.2  2008/08/25 21:00:44  gbr4
 *  try to fix windows build
 *
 *  Revision 1.1  2008/08/25 20:01:13  hy93
 *  Move portal code to new file
 *
 *
 ************************************************************************
 */
#include <wal.h>
#include <cfg.h>
#include <apr_pools.h>
#include <cuwa_err.h>
#include <log.h>
#include <apr_strings.h>
#include <session.h>
#include <cred.h>
#include <cuwa_ssl.h>
#include <cuwa_parse.h>
#include <cuwa_version.h>
#include <highAvail.h>
#include <permit_ha.h>
#include <portal_error_page.h>
#include <cuwa_page.h>
#include <portal_davlogin.h>
#define CUWA2_LOG_DOMAIN cuwa.portal

#define CUWA_PROXY_SESSION                    "session="
#define CUWA_PROXY_REMOTE_HOST                "remoteURL="
#define CUWA_PROXY_NEW_SESSION                "newSession="
#define CUWA_PROXY_ALL_COOKIES                "allCookies="
#define CUWA_PROXY_ALLOW_INVALID_CERT         "allowInvalidCert="
#define CUWA_PROXY_ALLOW_INVALID_PRINCIPAL    "allowInvalidPrincipal="

#define CUWA_PROXY_ERROR_START  "<!-- ++++++++++ -->"

char * cuwa_core_portal_get_cookies(apr_pool_t *pool, char *headers);
char *cuwa_core_portal_term_string(char *in, char *c);


char *cuwa_portal_extract_error( char *content )
{
    char *p = strstr(content,CUWA_PROXY_ERROR_START);

   if ( p )
   {
       char *p1 = NULL;
       p += strlen(CUWA_PROXY_ERROR_START);
       p1 = strstr( p, CUWA_PROXY_ERROR_START);
       if ( p1 )
           *p1 = 0;
   }
   else
       p = content;
   return p;
}

static void cuwa_portal_log(void *r, apr_pool_t *pool, const char *fmt, ... )
{
    va_list va;
    char *msg;
    char *log;

    va_start(va,fmt);
    msg = apr_pvsprintf(pool,fmt,va);
    va_end(va);

    cuwa_trace("PORTAL: %s",msg);

    log = cuwa_wal_note_get(r, "PORTAL_LOG");
    if (log)
    {
        msg = apr_pstrcat(pool,log,"\n",msg,NULL);
    }

    cuwa_wal_note_set(r,"PORTAL_LOG",msg);
}

static int cuwa_portal_error_response(void *r, apr_pool_t *pool, short status, int code, const char *fmt, ... )
{
    va_list args;
    char *reason, *log = cuwa_wal_note_get(r, "PORTAL_LOG");
    const char *detail = cuwa_wal_get_log_error( r );
    const char *emsg   = cuwa_core_get_error_string(code);
    char       *html   = NULL;

    va_start(args, fmt);
    reason = apr_pvsprintf(pool,fmt,args);
    va_end(args);

    if (!detail) detail = "no further detail";
    if (!emsg)   emsg   = "no further detail";
    if (!log)    log   = "";

    cuwa_trace("PORTAL Error: %d--%s--%d--%s--%s",status,reason,code,emsg,detail);
    html = apr_psprintf(pool,cuwa_portal_error_page,status,reason,code,emsg,detail,log);
    return cuwa_wal_send_page(r, status, html);
}

// FIXME: read SetCookie headers and build a Cookie string for use in subsequent calls to server
static cuwa_err_t cuwa_portal_parse_header(void *r, apr_pool_t *pool,char *headerStr, char **locationBack, char **host, int *responseCode,char **queryStr,int checkQueryStr )
{
    char *location,*p,*responseStr,*query;
    int response = 0;
    cuwa_err_t rc = CUWA_OK;
    char *buf;
    char *header = apr_pstrdup(pool, headerStr);

    location = strstr( header, "Location: " );
    FAIL_IF(!location, CUWA_ERR_PROXY);
    location += strlen("Location: ");

    //find the end of location 
   p = strstr(location,"\r\n");
   if ( p )
       *p = '\0';

   *locationBack = apr_pstrdup( pool, location );

    //find the query string
    query = strchr( location, '?' );
    if ( checkQueryStr )
    {
        FAIL_IF(!query, CUWA_ERR_PROXY);

        query++;
        *queryStr = apr_pstrdup( pool, query);

        p = strchr( location, '?' );
        if ( p )
            *p ='\0';
   } 
    cuwa_portal_log(r, pool, "PORTAL: location:%s",location);
    
    //remove path from remoteHost
    buf = strstr( location,"://");
    if ( buf )
        buf +=3;
    else
        buf = location;

    buf = strchr(buf,'/');
    if ( buf )
    {
        *buf = '\0';
    }
 
    *host = cuwa_build_ssl_domain( location, pool );
    cuwa_portal_log(r, pool, "PORTAL: host:%s", *host);
 
    //check response code
    p = strstr( header, "\r\n");
    if ( p )
        *p = '\0';
    cuwa_portal_log(r, pool, "PORTAL: header now:%s",header);

    responseStr = strchr( header, ' ');
    responseStr++;
    p = strchr(responseStr,' ');
    if ( p )
        *p = '\0';

    sscanf(responseStr,"%d",&response);
    *responseCode = response;

    cuwa_portal_log(r, pool, "PORTAL: parse response:%d",response);
    cuwa_portal_log(r, pool, "PORTAL: parse host: %s",*host);
    cuwa_portal_log(r, pool, "PORTAL: parse queryStr:%s",checkQueryStr?*queryStr:"");

cleanup:
    return rc;
}

static cuwa_err_t cuwa_portal_request_cookie(void *r,apr_pool_t *pool, cuwa_session_t *session, char *k3,char *host, char *reqDoc,int allowInvalidCert, int allowInvalidPrincipal, char **cookie, char **cookies)
{
    cuwa_err_t rc = CUWA_OK;
    char *buffer;
    char header[8192];
    char content[11264];
    char *queryStr, *p, *loginurl,*newCookie,*server, *location;
    char *siteCookie ="Set-Cookie: cuweblogin2=";
    char *principal = "WAK0Service=";
    char *sessionID = "SID=";
    int response = 0,newCredLen;
    CUWACfg_t *cfg =  cuwa_wal_get_config(r);
    char *cred = NULL, *newCred;
    char *remoteCookie,*remotePrincipal,*remoteSessionIDStr,*remoteVersionStr;
    uint64 remoteSessionID;
    char *keytab, *princ;
    int remoteVersion;
    char *resultBuffer = NULL;
    int extraBufSize = 0;
    int needFree = 0;

    buffer = apr_psprintf(pool, "GET %s HTTP/1.0%sHost: %s%sUser-Agent: %s" CRLF CRLF,reqDoc,CRLF,&host[strlen("https://")],CRLF,cuwa_version_get_full());

    keytab = cuwa_session_get_attribute(session,"CUWA_KEYTAB",0);
    if (!keytab) keytab = CFG_CUWAKeytab(cfg);        
    princ = cuwa_session_get_attribute(session,"CUWA_SERVICEID",0);
    if (!princ) princ = CFG_CUWAKerberosPrincipal(cfg);   

    cuwa_portal_log(r, pool, "PORTAL: Initial handshake with remote webauth");
    rc = cuwa_ssl_send_request(host, buffer, strlen(buffer), allowInvalidCert, header,sizeof(header), NULL, 0);
    FAIL_IF(rc, CUWA_ERR_PROXY);

    cuwa_portal_log(r, pool, "PORTAL: Stage1 response: %s",header);

    //loosely check if location is correct
    rc = cuwa_portal_parse_header( r, pool, header,&location, &server, &response,&queryStr,1 );
    FAIL_IF(rc, rc);

    cuwa_portal_log(r, pool, "PORTAL: get server:%s,response=%d",server,response);
    cuwa_portal_log(r, pool, "PORTAL: get query string:%s", queryStr);

    if ( response <300 || response > 400)
    {
        cuwa_portal_log(r, pool, "PORTAL: Proxy error:response %d back from host %s is not correct",response,host);
        return CUWA_ERR_PROXY;
    }

    if (strstr(header,"cuwal2sid="))
    {
        cuwa_portal_log(r, pool, "PORTAL: Old cuwal2sid cookie detected.  The backend server is running compatible version of webauth.");
        cuwa_portal_log(r, pool, "PORTAL: Upgrade CUWebAuth on the backend server.");
        return CUWA_ERR_PROXY;
    }

    //get remote principal
    p = strstr( queryStr, principal );
    if (!p)
        cuwa_portal_log(r, pool, "PORTAL: Proxy error: query string doesn't have remote principal");
    FAIL_IF(!p, CUWA_ERR_PROXY);

    p += strlen(principal);
    remotePrincipal = apr_pstrdup( pool, p);
    p = strchr( remotePrincipal, '&');
    FAIL_IF(!p, CUWA_ERR_PROXY);
    if (p ) *p = 0;

    //get sessionID
    p = strstr( queryStr, sessionID);
    if (!p)
        cuwa_portal_log(r, pool, "PORTAL: Proxy error: query string doesn't have sessionID");
    FAIL_IF(!p, CUWA_ERR_PROXY);

    p += strlen(sessionID);
    remoteSessionIDStr = apr_pstrdup( pool, p);
    p = strchr( remoteSessionIDStr, '&');
    FAIL_IF(!p, CUWA_ERR_PROXY);
    if (p ) *p = 0;
    sscanf(remoteSessionIDStr,"%llX",&remoteSessionID);

    //get VerP so we know if backend is still old webAuth
    p = strstr( queryStr, "VerP=");
    if (!p)
        cuwa_portal_log(r, pool, "PORTAL: Proxy error: query string doesn't have VerP"); 
    FAIL_IF(!p, CUWA_ERR_PROXY);

    p += strlen("VerP=");
    remoteVersionStr = apr_pstrdup( pool, p);
    p = strchr( remoteVersionStr, '&');
    FAIL_IF(!p, CUWA_ERR_PROXY);
    if (p ) *p = 0;
    sscanf(remoteVersionStr,"%d",&remoteVersion);

    //Step2:login

    cuwa_portal_log(r, pool, "PORTAL: Get K2 from weblogin");
    if ( CUWA_HA_ENABLED( cfg ) )
        loginurl = cuwa_ha_get_login_server(NULL, &newCookie, pool);
    else
        loginurl = cuwa_get_login_server_from_config(cfg);

    buffer = apr_psprintf(pool,"GET ?%s&WAK3=%s&allowInvalidPrincipal=%d HTTP/1.0%sHost: %s%sUser-Agent: %s" CRLF CRLF,
                          queryStr,k3,allowInvalidPrincipal,CRLF,&loginurl[strlen("https://")],CRLF,cuwa_version_get_full());

    rc = cuwa_ssl_send_request_extra_check(loginurl, buffer, strlen(buffer),0,header,sizeof(header),content,sizeof(content),&extraBufSize);
    if ( rc == CUWA_ERR_BUFFER_SMALL )
    {
        int bufferSize = sizeof(content)+extraBufSize+1024;

        resultBuffer = calloc( bufferSize,1);
        FAIL_IF(!resultBuffer, CUWA_ERR_PROXY);

        needFree = 1;
        cuwa_trace("buf is small, send ssl request again with increased buffer-%d",bufferSize);
        rc = cuwa_ssl_send_request(loginurl, buffer, strlen(buffer),0,header,sizeof(header),resultBuffer,bufferSize);
    }

    FAIL_IF(rc, CUWA_ERR_PROXY);
    
    if ( !resultBuffer)
        resultBuffer = content;

    cuwa_portal_log(r, pool, "PORTAL: Stage2 response: %s",header);

    rc = cuwa_portal_parse_header( r, pool, header, &location, &server, &response,&queryStr,0 );
    if ( rc )
    {
        cuwa_portal_log(r, pool,"Response from weblogin:%s", cuwa_portal_extract_error(resultBuffer));
    }

    FAIL_IF(rc, rc);


    if ( strncmp( server, host,strlen(host) ))
    {
        cuwa_portal_log(r, pool, "wrong location in proxy");
        rc = CUWA_ERR_PROXY;
        FAIL_IF(rc,rc);
    }

    if (remoteVersion < 3) {
        //backend is still using old webAuth
        if ( response <300 || response > 400)
        {   
            if(response == 200 && allowInvalidPrincipal)
            {
                cuwa_portal_log(r, pool,"PORTAL: Remote proxy host is using a principal that doesn't match the hostname. allowInvalidPrincipal was passed");
                cuwa_notice("Remote proxy host is using a principal that doesn't match the hostname. allowInvalidPrincipal was passed");
            }
            else
            {
                cuwa_portal_log(r, pool,"PORTAL: Proxy error:response %d back from host %s is not correct",response,loginurl);
                cuwa_warning("Proxy error:response %d back from host %s is not correct",response,loginurl);
                return CUWA_ERR_PROXY;
            }
        }
    
        cuwa_portal_log(r, pool, "PORTAL: location=%s",location);
        cred = cuwa_get_cred_from_uri( pool, location);
        FAIL_IF(!cred, CUWA_ERR_PROXY);
    }
    else {
        if ( response == 200)
        {
            char *p=NULL, *k2=NULL,*end=NULL;
            //get k2 from content
            FAIL_IF(!strstr(resultBuffer,"Login OK"), CUWA_ERR_PROXY);

            p = strstr(resultBuffer, "name=\"wa\"");
            FAIL_IF(!p, CUWA_ERR_PROXY);

            k2 = strstr(p, "value=\"");

            FAIL_IF(!k2, CUWA_ERR_PROXY);
            k2 += strlen("value=\"");
        
            end = strstr(k2,"\"/>");
            FAIL_IF(!end, CUWA_ERR_PROXY);

            *end ='\0';
            cred = k2; 

            
        }
        else
        {
            cuwa_portal_log(r, pool,"PORTAL: Proxy error:response %d back from host %s is not correct",response,loginurl);
            cuwa_warning("Proxy error:response %d back from host %s is not correct",response,loginurl);
            return CUWA_ERR_PROXY;
        }
    }
    //extend credential
    rc = cuwa_cred_make_proxy( princ, keytab, host, remotePrincipal, &remoteSessionID,
                               cred, strlen(cred), &newCred, &newCredLen);
    cuwa_portal_log(r, pool,"PORTAL: make proxy finished with sts=%d",rc);
    FAIL_IF(rc, rc );

    cuwa_portal_log(r, pool, "PORTAL: Send K2s to remote website");
    //HTTP GET newRemoteURL
    p = apr_pstrdup(pool,reqDoc);
    if ( p[strlen(reqDoc)-1] == '/') p[strlen(reqDoc)-1] = 0;
    if (*p=='/') p++;

    cuwa_portal_log(r, pool,"PORTAL: remoteSessionIDStr %s",remoteSessionIDStr);
    cuwa_portal_log(r, pool,"PORTAL: reqDoc %s",p);

    buffer = apr_psprintf(pool,
                          "GET /%s/%s/%s?%s%s HTTP/1.0%sHost: %s%sUser-Agent: %s" CRLF CRLF,
                          p,remoteSessionIDStr,CUWA_MAGIC_FILE,CUWA_MAGIC_CRED,newCred,CRLF,&host[strlen("https://")],CRLF,cuwa_version_get_full());

    cuwa_portal_log(r, pool,"PORTAL: Sending request: %s",buffer);

    rc = cuwa_ssl_send_request(host, buffer, strlen(buffer),allowInvalidCert,header,sizeof(header),content,sizeof(content));
    FAIL_IF(rc, CUWA_ERR_PROXY);

    cuwa_portal_log(r, pool, "PORTAL: Stage3 response: %s",header);

    rc = cuwa_portal_parse_header( r, pool, header, &location, &server, &response,&queryStr,0 );
    if ( rc )
    {
        cuwa_portal_log(r,pool,"Response from %s: %s",host,cuwa_portal_extract_error(content));
    }
    FAIL_IF(rc, rc);

    if ( response <300 || response > 400)
    {
        cuwa_portal_log(r, pool,"PORTAL: Proxy error:response %d back from host %s is not correct",response,host);
        cuwa_warning("Proxy error:response %d back from host %s is not correct",response,host);

        cuwa_portal_log(r,pool,"Response from %s: %s",host,cuwa_portal_extract_error(content));
        return CUWA_ERR_PROXY;
    }

    //get remote site cookie
    
    // Get entire cookie string...
    *cookies = cuwa_core_portal_get_cookies(pool, header);
    remoteCookie = strstr( header, siteCookie);
    if (!remoteCookie)
    {
        cuwa_portal_log(r, pool,"PORTAL: Proxy error:No site cookie in header");
    }
    FAIL_IF(!remoteCookie, CUWA_ERR_PROXY);

    remoteCookie += strlen(siteCookie);
    p = strchr(remoteCookie,';');
    if ( p )
        *p = 0;

    *cookie = apr_pstrdup(pool, remoteCookie);
cleanup:

    if (needFree) free(resultBuffer);
    return rc;
}

// Convert Set-Cookie headers to a value suitable for a Cookie header
char * cuwa_core_portal_get_cookies(apr_pool_t *pool, char *headersIn)
{
    char *cookie;
    char *cookies = apr_pstrdup(pool,"");
    char *sep = "";
    char *headers = apr_pstrdup(pool,headersIn);
 
    cookie = strstr( headers, "Set-Cookie: ");
    while (cookie)
    {
        headers = cuwa_core_portal_term_string(cookie,"\n\r");  // Move header to next line
        cookie += 12;                                            // get past the Set-Cookie label
        cuwa_core_portal_term_string(cookie,"; \n\r");           // Terminate string at cookie key=value
        cookies = apr_pstrcat(pool,cookies,sep,cookie,NULL);     // Add key=value to cookie string
        cookie = strstr( headers, "Set-Cookie: ");
        sep = "; ";
    }
    return cookies;
}

// Given an input string in and string with possible terminator characters c, NULL terminate the string.
// Returns the next character after the string, or empty string if end of string is reached.
char *cuwa_core_portal_term_string(char *in, char *c)
{
    char *term;

    while (*c)
    {
        term = strchr(in,*c);
        if (term)
        {
            *term++ = 0;
            in = term;
            return in;
        }
        c++;
    }
    in += strlen(in); // move to end of string
    return in;
}




// Function returns OK or HTTP status code
int cuwa_core_portal_proxy_handler(void *r, apr_pool_t *pool )
{
    char *uri = apr_pstrdup( pool, cuwa_wal_get_uri(r,CUWA_URI_UNPARSED) );
    char *remoteHost = NULL, *remotePath=NULL, *allCookies=NULL;
    char *WAC0 = NULL,*k3;
    char *buf;
    cuwa_err_t sts = CUWA_OK;
    int allowInvalidCert = 0, allowInvalidPrincipal = 0, newSession=0;
    cuwa_session_t *session = NULL;
    CUWACfg_t *cfg = cuwa_wal_get_config(r);
    char *proxyCookie = NULL, *proxyCookies = NULL;

    cuwa_portal_log(r, pool, "PORTAL: ENTER core_get_proxy_cookie,uri=%s",uri);

    uri = strchr( uri, '?');
    if (!uri)
        return cuwa_portal_error_response(r,pool,500,CUWA_ERR_PORTAL,"No query string present in URL.");

    //find WAC0
    WAC0 = cuwa_get_query_string_val( pool, uri,CUWA_PROXY_SESSION );
    if ( !WAC0 )
        return cuwa_portal_error_response(r,pool,500,CUWA_ERR_PORTAL,"Expecting arg: %s",CUWA_PROXY_SESSION);

    cuwa_portal_log(r, pool, "got WAC0=%s", WAC0);

    //find remote host
    remoteHost = cuwa_get_query_string_val( pool, uri, CUWA_PROXY_REMOTE_HOST);
    if (!remoteHost)
        return cuwa_portal_error_response(r,pool,500,CUWA_ERR_PORTAL,"Expecting arg: %s",CUWA_PROXY_REMOTE_HOST);

    allCookies = cuwa_get_query_string_val( pool, uri, CUWA_PROXY_ALL_COOKIES);

    cuwa_portal_log(r, pool,"got remote host=%s", remoteHost);

    if ( !strlen(remoteHost) || !strlen(WAC0) )
    {
        cuwa_portal_log(r, pool, "Missing arg(s), %s%s %s%s",
                        CUWA_PROXY_REMOTE_HOST,remoteHost,CUWA_PROXY_SESSION,WAC0);
        return cuwa_portal_error_response(r,pool,500,CUWA_ERR_PORTAL,"Missing value in URL arguments");
    }

    //remove path from remoteHost
    buf = strstr( remoteHost,"://");
    if ( buf )
        buf +=3;
    else
        buf = remoteHost;

    buf = strchr(buf,'/');
    if ( buf )
    {
        remotePath = apr_psprintf( pool, "%s",buf );
        *buf = '\0';
    }
    else
        remotePath = "/";

    remoteHost = cuwa_build_ssl_domain( remoteHost, pool );
    if ( !remoteHost )
        return cuwa_portal_error_response(r,pool,500,CUWA_ERR_PORTAL,"Invalid https URL (%s)",CUWA_PROXY_REMOTE_HOST);

    //find allowInvalidCert flag
    buf = cuwa_get_query_string_val( pool, uri,CUWA_PROXY_ALLOW_INVALID_CERT );
    if ( buf )
    {
        sscanf(buf,"%d",&allowInvalidCert);
        cuwa_portal_log(r, pool, "got allowInvalidCert=%d", allowInvalidCert);
    }

    //find allowInvalidPrincipal flag
    buf = cuwa_get_query_string_val( pool, uri, CUWA_PROXY_ALLOW_INVALID_PRINCIPAL );
    if ( buf)
    {
        sscanf(buf,"%d",&allowInvalidPrincipal);
        cuwa_portal_log(r, pool, "got allowInvalidPrincipal=%d", allowInvalidPrincipal);
    }

    //find newSession flag
    buf = cuwa_get_query_string_val( pool, uri, CUWA_PROXY_NEW_SESSION );
    if ( buf)
    {
        sscanf(buf,"%d",&newSession);
        cuwa_trace("got newSession=%d", newSession);
    }

    sts = cuwa_session_from_credential( r, pool, cfg, cuwa_core_strip_path(pool, cuwa_wal_get_virtual_host(r, cfg, NULL)),
                                        NULL, 0,  WAC0, strlen(WAC0),
                                        CFG_CUWAKerberosPrincipal(cfg), CFG_CUWAKeytab(cfg),
                                        &session);
    if (sts)
        return cuwa_portal_error_response(r,pool,400,sts,"Invalid credential (%s%s)",CUWA_PROXY_SESSION,WAC0);

    if ( !newSession )
    {
        proxyCookie = (char *)cuwa_session_get_proxy_cookie(session, remoteHost);
        proxyCookies = (char *)cuwa_session_get_proxy_cookies(session, remoteHost);
    }


    if ( !proxyCookie)
    {
        //if proxyCookie is not in the cache,contact remote host to create a new session
        k3 = cuwa_session_get_attribute(session,"CUWA_K3",0);
        if ( !k3 )
        {
            cuwa_portal_log(r, pool,"Delegation attribute is missing (CUWA_K3). It could be that CUWAwak2Flags is not set to 1 in conf or the serviceID is not a member of permit cit.weblogin.getk3");
            return cuwa_portal_error_response(r,pool,500,CUWA_ERR_PROXY_NO_K3,"Delegation credential is unavailable");
        }     

        sts = cuwa_portal_request_cookie(r,pool,session,k3,remoteHost,remotePath,allowInvalidCert,allowInvalidPrincipal,&proxyCookie,&proxyCookies);
        if (sts || !proxyCookie) return cuwa_portal_error_response(r,pool,500,CUWA_ERR_PORTAL,"cuwa_portal_request_cookie failed: %d",sts);

        cuwa_session_save_proxy_cookie( session, remoteHost, proxyCookie );
        cuwa_session_save_proxy_cookies( session, remoteHost, proxyCookies );
    }

    cuwa_portal_log(r, pool,"PORTAL: EXIT (%d) proxy cookie: %s",sts,proxyCookie?proxyCookie:"N/A");

    if ( session ) cuwa_session_release( session);

    if (!sts) return cuwa_wal_send_page(r, 200,  (allCookies && *allCookies=='1') ? proxyCookies : proxyCookie);

    return sts;
}

//handler for CUWebAuth get permit portal
//takes query arguments netid= and permits=
//returns line 1
// Function returns OK or HTTP status code
int cuwa_core_portal_permit_handler(void *r, apr_pool_t *pool)
{
    char *uri = apr_pstrdup( pool, cuwa_wal_get_uri(r,CUWA_URI_UNPARSED) );
    char *arg=NULL, *args=NULL, *value=NULL, *resp;
    char *netid=NULL, *permits=NULL, *memberships=NULL, *nonmember=NULL;
    CUWACfg_t *cfg;
    cuwa_err_t code;

    cfg = cuwa_wal_get_config(r);
    arg = strchr( uri, '?');
    if (!arg)
        return cuwa_portal_error_response(r,pool,500,CUWA_ERR_PORTAL,"No query string present in URL.");

    cuwa_portal_log(r, pool,"cuwa_permit handler, args are: %s",arg);

    arg++;
    while (arg)
    {
        args = strchr(arg,'&');
        if (args) *args++='\0';

        //parse arg
        value=strchr(arg,'=');
        cuwa_trace("arg=%s val=%s",arg,value?value:"NULL");
        if (value)
        {
            *value++ = '\0';
            if (!strcmp(arg,"netid"))
            {
                netid = value;
                cuwa_portal_log(r, pool,"netid: %s",netid);
            }
            if (!strcmp(arg,"permits"))
            {
                permits = value;
                cuwa_decode_spaces(permits);
                cuwa_portal_log(r, pool,"space decoded permits: %s",permits);
                //cuwl_sanitize(permits); fixme
            }
        }
        arg=args;
    }

    if (!netid || !permits || !strlen(netid) || !strlen(permits))
        return cuwa_portal_error_response(r,pool,500,CUWA_ERR_PORTAL,"Missing permit or netid in lookup request.");

    code = cuwa_permit_ha_check( pool, cfg, CFG_CUWAKerberosPrincipal(cfg),
                                 CFG_CUWAKeytab(cfg), netid , permits, &memberships, &nonmember);
    cuwa_portal_log(r, pool,"cuwa_permit netid: %s, permits: %s, code: %u, memberships: %s",netid,permits,code,DENULL(memberships));
    if (code)
        return cuwa_portal_error_response(r,pool,500,code,"Permit server error.");

    if ( strcmp(netid,"all") )
        resp = apr_psprintf(pool,"%s\n%s",netid,memberships?memberships:"");
    else
        resp = apr_psprintf(pool,"%s\n%s", permits, memberships?memberships:"");

    return cuwa_wal_send_page(r, 200, resp);
}


// handles the /davlogin path, printing the user's cookie
int cuwa_core_portal_davlogin_handler(void *r, apr_pool_t *pool)
{
    apr_time_exp_t tm;
    apr_size_t junk;
    unsigned long etime;
    char *host=cuwa_wal_get_hostname(r);
    char *netid=(char*)cuwa_wal_get_header_in(r,"REMOTE_USER");
    char *cookie=(char*)cuwa_wal_get_header_in(r,"Cookie");
    char *expires=(char*)cuwa_wal_get_header_in(r,"CUWA_END_TIME");
    char *tmp;
    char *html;
    char *loginurl;
    CUWACfg_t *cfg = cuwa_wal_get_config(r);

    if ( CUWA_HA_ENABLED( cfg ) )
        loginurl = cuwa_ha_get_login_server(NULL, &tmp, pool);
    else
        loginurl = cuwa_get_login_server_from_config(cfg);
    if(!loginurl) loginurl="";


    //replace this junk with the cred exposed cookie ... once that is added
    if(cookie) cookie=strstr(cookie,"weblogin2=");  
    if(cookie) cookie=strstr(cookie,"WA");
    if(cookie) cookie=apr_pstrdup(pool,cookie);
    tmp=strstr(cookie,";"); if(tmp) *tmp=0;
    tmp=strstr(cookie,"\""); if(tmp) *tmp=0;
    tmp=strstr(cookie,"'"); if(tmp) *tmp=0;
    tmp=strstr(cookie," "); if(tmp) *tmp=0;


    host=host?host:"NOT.LOGGED.IN";
    netid=netid?netid:"NOT_LOGGED_IN";
    cookie=cookie?cookie:"NOT_LOGGED_IN";
    expires=expires?expires:"0";

    etime=strtol(expires,NULL,10);
    apr_time_exp_lt(&tm,apr_time_from_sec(etime));
    expires=apr_pcalloc(pool,100);
    apr_strftime(expires,&junk,100,"%I:%M:%p on %D",&tm);

    html = apr_psprintf(pool,cuwa_page,loginurl,loginurl,loginurl,host,cuwa_portal_davlogin);
    html = apr_psprintf(pool,html,netid,host,cookie,expires);
    return cuwa_wal_send_page(r, 200, html);
}


const char id_portal_c[] = "$Id: portal.c,v 1.31 2016/08/24 20:51:02 hy93 Exp $";
