/*
 * apache_2_2.c -- Interface with Apache 2.2
 *
 *
 ************************************************************************
 *  $Log$
 *  Revision 1.2.4.2  2015/06/30 12:56:23  hy93
 *  apache 2.4 support
 *
 *  Revision 1.2.2.2  2014/10/23 15:27:14  hy93
 *  Add Apache 2.4 support
 *
 *  Revision 1.1  2014/07/25 17:28:26  hy93
 *  for Apache 2.2
 *
 ************************************************************************/                                                                        

char *cuwa_wal_get_remote_IP(void *req)
{
    request_rec *r = (request_rec *)req;

   return r->connection->remote_ip;
}

void cuwa_wal_log_error(void *rec,int logLevel, char *file, int line, int severity, char *logdomain, char *msg )
{
    ap_log_error(NULL,line, logLevel,0,(server_rec *)rec,"%s(%d)|%d|%s %s",file,line,severity,logdomain,msg);
}

void cuwa_wal_log_rerror(void *rec,int logLevel, char *file, int line, int severity, char *logdomain, char *msg,char *cuwaTest,char *sidStr )
{
    ap_log_rerror(NULL,line, logLevel,0,(request_rec *)rec,"%s,%s,%s(%d)|%d|%s %s",cuwaTest?cuwaTest:"-",sidStr?sidStr:"-",file,line,severity,logdomain, msg);
}
                                                                                                                                                 
void cuwa_wal_log_cerror(void *rec,int logLevel, char *file, int line, int severity, char *logdomain, char *msg )                      
{                                                                                                                                                
    ap_log_cerror(NULL,line, logLevel,0,(conn_rec *)rec,"%s(%d)|%d|%s %s",file,line,severity,logdomain,msg);                                                 
}                                                                                                                                                
                                                                                                                                                 
void cuwa_wal_log_perror(apr_pool_t *p,int logLevel, char *file, int line, int severity, char *logdomain, char *msg )                             
{                                                                                                                                                
    ap_log_perror(NULL,line, logLevel,0,p,"%s(%d)|%d|%s %s",file,line,severity,logdomain,msg);                                                   
}                 

const apr_array_header_t *cuwa_wal_get_requires(void *req)
{       
    return ap_requires((request_rec *)req);
}   


