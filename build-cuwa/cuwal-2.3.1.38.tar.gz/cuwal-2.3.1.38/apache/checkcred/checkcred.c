#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <kutil.h>
#include <cuwa_types.h>
#include <cred_krb.h>
#include <cred_base64.h>
#include <log.h>

#define CUWA2_LOG_DOMAIN cuwa.apache

#define syntax_check(c) do {if(argc<c){ printf("syntax: checkcred host|0 service-id keytab\n  NOTE: host=0 converts to host=NULL. USE FULL REALM FOR service-id\n"); return 0;}} while (0)

int main(int argc, char* argv[])
{
    char wa[4096];
    int rc;
    cuwa_cred_t *cred;


    syntax_check(3);
    fgets(wa,4096,stdin);
    //printf("cuwa_cred_parse(\n&cred, \n%s, \n%d, \n%s, \n%s, \n%s,\nNULL)",wa,strlen(wa),argv[2],argv[3],argv[1]);
    rc = cuwa_cred_parse(&cred, wa, strlen(wa),argv[2], argv[3],argv[1],NULL);

    if (rc)
    {
        fprintf(stderr,"ERROR: %d\n",rc);
    }
    else
    {
    	printf("remoteid:%s\n", cred->remoteid);
	printf("realm:%s\n", cred->realm);
	printf("netid:%s\n",cred->netid);
	printf("targethost:%s\n",cred->targethost);
	printf("auth_time:%u\n",cred->auth_time);
	printf("end_time:%u\n",cred->end_time);
	printf("session_id:%qX\n",cred->sessionid);
	printf("mechanism:%d\n",cred->mechanism);
	printf("session_key:%qX\n",cred->sessionkey);
	printf("hasSession:%d\n",cred->hasSession);
	printf("requestid:%qX\n",cred->requestid);
     }

    return 0;
}

const char id_apache_checkcred_checkcred_c[] = "$Id$";
