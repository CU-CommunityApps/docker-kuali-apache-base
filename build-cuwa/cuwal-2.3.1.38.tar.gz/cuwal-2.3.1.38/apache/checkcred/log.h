#include <stdio.h>
#include <cuwa_err.h>

#define cuwa_trace(x, ...)
#define cuwa_assert(x)

