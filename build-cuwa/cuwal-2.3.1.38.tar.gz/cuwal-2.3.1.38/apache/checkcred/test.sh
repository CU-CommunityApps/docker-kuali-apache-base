#!/bin/sh
../sid2cred/sid2cred localhost 1234 ns10-demo '$tester' web-agent/gbr4-test  | egrep '^WA' | ./checkcred localhost web-agent/gbr4-test@CIT.CORNELL.EDU /home/gbr4/web-agent-gbr4-test 2>/dev/null
