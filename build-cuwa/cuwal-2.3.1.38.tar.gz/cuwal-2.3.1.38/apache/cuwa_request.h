/************************************************************************
 * cuwa_request -- Save a request for replay after credentials are aquired.
 *
 * Copyright 2007 Cornell University.
 * All Rights Reserved.
 *
 ************************************************************************
 *  $Log$
 *  Revision 1.4  2008/02/22 20:27:40  hy93
 *  remove line feed
 *
 *  Revision 1.3  2008/01/11 04:18:47  pb10
 *  Integrate with logging and config.  Compiles, but isn't tested yet.
 *
 *  Revision 1.2  2008/01/02 04:33:23  pb10
 *  Changes for integration with session manager, cred manager, apache mod.
 *
 *  Revision 1.1  2007/12/12 18:27:07  pb10
 *  Initial
 *
 *
 *
 ************************************************************************
 */

#ifndef _CUWA_REQUEST_H
#define _CUWA_REQUEST_H

#include <wal.h>
#include <cuwa_types.h>

/* keeping this interface abstract may be pointless, TBD */

int cuwa_request_save(uint64 *sessionid, void *arg1, void *arg2, void *arg3);

#endif
