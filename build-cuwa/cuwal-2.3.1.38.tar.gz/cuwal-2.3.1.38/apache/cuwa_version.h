/************************************************************************
 * cuwa_version.h -- Get the module's version number
 *
 * Copyright 2008 Cornell University.
 * All Rights Reserved.
 *
 ************************************************************************
 *  $Log$
 *  Revision 1.2  2008/02/28 20:49:50  hy93
 *  fix compiler warning
 *
 *  Revision 1.1  2008/01/11 04:19:48  pb10
 *  Initial code.  Not compiled into the module yet.
 *
 *
 ************************************************************************
 */

#ifndef _CUWA_VERSION_H_
#define _CUWA_VERSION_H_

#include <apr_pools.h>

char *cuwa_version_get();
char *cuwa_version_get_full();
char *cuwa_get_client_version();
void cuwa_build_client_version(apr_pool_t *);

#endif
