/************************************************************************
 * mod_cuwebauth.c -- Apache module code for CUWA.
 *
 * Copyright 2007 Cornell University.
 * All Rights Reserved.
 *
 ************************************************************************
 *  $Log$
 *  Revision 1.141.2.3  2015/09/25 13:57:51  hy93
 *  fix Apache 2.3 doesn't support ap_get_server_banner
 *
 *  Revision 1.141.2.2  2015/06/30 12:57:37  hy93
 *  apache 2.4 support
 *
 *  Revision 1.141.2.1  2015/04/29 13:07:27  hy93
 *  Fix sometimes error page didn't show properly. Use permitServer string from HA.
 *
 *  Revision 1.141  2014/10/22 15:56:32  hy93
 *  remove Apache 2.4 support
 *
 *  Revision 1.140  2014/08/05 18:05:31  hy93
 *  move functions from apache_wal.c to mod_cuwebauth.c so mod_weblogin can compile
 *
 *  Revision 1.139  2014/08/05 17:31:42  hy93
 *  move functions from apache_wal.c to mod_cuwebauth.c so mod_weblogin can compile
 *
 *  Revision 1.138  2014/07/25 17:27:49  hy93
 *  Apache 2.4 support
 *
 *  Revision 1.137  2010/04/21 21:27:44  pb10
 *  Fix comments, it was actually a python issue not PHP.
 *  Comments will hopfully prevent a future release from breaking python compat, no promises.
 *
 *  Revision 1.136  2010/04/19 18:36:53  pb10
 *  Comment out logging, diagnosing PHP bug in SVN.
 *
 *  Revision 1.135  2010/04/09 20:12:35  hy93
 *  move wal functions that needed in mod_permit to this file
 *
 *  Revision 1.134  2009/09/11 17:17:03  hy93
 *  move common used validator function from mod_cuwebauth.c to auth.c
 *
 *  Revision 1.133  2009/09/10 15:30:03  hy93
 *  remove call to cuwa_session_check_session_path because checking session file path is now done by cuwa_check_sessionfilepath
 *
 *  Revision 1.132  2009/07/30 15:54:55  pb10
 *  Change site cookie name from cuweblogin2 to cuweblogin2-N to
 *  accomodate IE behavior with regard to multiple sites that have overlapping
 *  multi-part domain names.
 *
 *  Revision 1.131  2009/06/10 18:35:31  hy93
 *  fix compile error
 *
 *  Revision 1.130  2009/06/10 15:55:01  hy93
 *  Add checking if environment variable KRB5RCACHETYPE is set for WINDOWs
 *
 *  Revision 1.129  2009/02/13 16:29:58  pb10
 *  CUWAReturnURL now accepts a %p that will be replaced with the
 *  original path of the URL (without the file).
 *
 *  Revision 1.128  2009/02/09 18:58:08  gbr4
 *  Fix startup permissions checks, apr returns bit fields in hex rather than octal.
 *
 *  Revision 1.127  2009/02/06 23:04:48  gbr4
 *  Add validators that print errors to the console in addition to the log file for:
 *
 *  1. Keytab doesn't exist or is unreadable
 *  2. SessionFilePath doesn't exist or is unwritable
 *  3. KerberosPrincipal Realm missing
 *  4. ReturnURL malformed
 *  5. KRB5_CONFIG file missing
 *
 *  Additionally there are some warnings added if the SessionFilePath or Keytab are too readable
 *
 *  Revision 1.126  2009/01/20 18:01:34  pb10
 *  ErrorDocument feature had symbol problem on win32.
 *
 *  Revision 1.125  2009/01/08 18:24:33  pb10
 *  Support for ErrorDocument
 *
 *  Revision 1.124  2008/10/16 14:38:02  hy93
 *  remove previous check in that try to fix permission deny in replay cache error on Windows
 *
 *  Revision 1.123  2008/10/14 16:01:11  hy93
 *  try to fix permission deny in replay cache error on Windows
 *
 *  Revision 1.122  2008/10/09 16:19:37  hy93
 *  move common code in cuwa_wal_set_cookie to auth.c
 *
 *  Revision 1.121  2008/10/09 12:30:09  hy93
 *  fix wrong apache version was sent to cuWebLogin
 *
 *  Revision 1.120  2008/10/07 19:31:41  hy93
 *  implement cuwa_wal_get_pool
 *
 *  Revision 1.119  2008/09/13 13:23:53  pb10
 *  Add IIS code and cleanup apache dependency in cuwa_version.c.
 *  Fix naming and positioning of DAV functions in wal.h.
 *
 *  Revision 1.118  2008/09/11 18:06:11  gbr4
 *  CUWAclearCookies directive added. runtests.sh now supports -stop-http intelligently.
 *
 *  Revision 1.117  2008/09/07 19:35:01  gbr4
 *  rename rand.[ch] to cuwarand.[ch]. Too many packages have a rand.h and some versions of libtool grab the wrong one. This fixes builds against debian 4.0r4.
 *
 *  Revision 1.116  2008/09/06 01:29:02  gbr4
 *  Rename the directive CUWADavAuth to CUWAAuthBasic per Pete's suggestion.
 *
 *  Impliment the cuwa_davlogin handler (built-in page that gives the user their cookie to use with WebDAV). The user is free to impliment a prettier page in whatever they want or add a location block to turn on this handler.
 *
 *  Also split off some of the css into cuwa_page.html and genericize our handler calling (one handler for the portals registered with apache that then delegates to the appropriate core functions instead of one handler per portal).
 *
 *  Revision 1.115  2008/08/27 03:26:41  gbr4
 *  use ap_auth_type(r) instead of r->ap_auth_type -- the latter seems to always be NULL
 *
 *  Revision 1.114  2008/08/27 02:11:45  gbr4
 *  add support for CUWA_DUMPCFG header, which dumps the request configuration to the log.
 *
 *  Revision 1.113  2008/08/26 17:53:11  hy93
 *  remove apache dependency in auth.c and portal.c
 *
 *  Revision 1.112  2008/08/25 20:00:26  hy93
 *  move portal proxy code to a new file
 *
 *  Revision 1.111  2008/08/25 15:31:55  hy93
 *  move code from mod_cuwebauth to ha
 *
 *  Revision 1.110  2008/08/25 13:52:55  hy93
 *  Add error message for CUWAsessionFilePath
 *
 *  Revision 1.109  2008/08/20 04:12:44  pb10
 *   Some fixes for portal proxy.
 *
 *  Revision 1.108  2008/08/19 20:10:59  pb10
 *  Return a log on portal error.  Move permit portal code to auth.c.
 *
 *  Revision 1.107  2008/08/18 18:01:13  gbr4
 *  typo in previous commit
 *
 *  Revision 1.106  2008/08/18 17:37:10  gbr4
 *  Fix some code that microsoft C doesn't like
 *
 *  Revision 1.105  2008/08/16 11:48:09  hy93
 *  add wal functions
 *
 *  Revision 1.104  2008/08/13 17:44:36  gbr4
 *  remove intentional crash from portal permit now that hudson core tracing works
 *
 *  Revision 1.103  2008/08/13 16:28:43  gbr4
 *  fix t06subreq.t (re-mark 4 as a todo)
 *  intentionally introduce a crash in portal permit for lookups of exactly cuwa-test.unreadable-no to test the hudson core extraction. This will be backed out shortly.
 *
 *  Revision 1.102  2008/08/13 15:12:02  pb10
 *  Fix indenting and replaced tabs.
 *
 *  Revision 1.101  2008/08/11 23:04:15  gbr4
 *  fix CUWAPortalPermit intermittant failure (primarily OpenBSD). Also add more helpful text for permit -4008 errors.
 *
 *  Revision 1.100  2008/08/11 04:13:51  hy93
 *  delegation support
 *
 *  Revision 1.99  2008/08/09 01:16:49  pb10
 *  Support listPermit call (CUWAInquire permit all).
 *
 *  Revision 1.98  2008/08/07 18:37:37  hy93
 *  put back r 1.85 checkin that we lost during surgery
 *
 *  Revision 1.97  2008/08/05 13:50:38  gbr4
 *  fix crash on solaris when permit portal would log the lack of any permits to return
 *
 *  Revision 1.96  2008/08/04 20:03:12  gbr4
 *  fix failure to decode %20. Also remove acceptance of (null)
 *
 *  Revision 1.95  2008/08/04 19:48:05  gbr4
 *  return the empty string instead of (null) when a user has none of the requested permits in CUWAPortalPermit
 *
 *  Revision 1.94  2008/08/04 18:18:41  gbr4
 *  CUWAPortal for permits is now working. handler is cuwa_permit, see t10portal_permit.t test case.
 *
 *  autoconf infrastructure now supports APR_INSTALLBUILDDIR and APR_VERSION to support permit makefile. permit makefile modified to remove hard coded path.
 *
 *  Revision 1.93  2008/07/30 20:44:12  pb10
 *  Fix REMOTE_USER bug.
 *
 *  Revision 1.92  2008/07/30 19:01:16  gbr4
 *  Webauth now searches for notes recursively in both parent and main requests. remove log dependancy on WAL (weblogin wouldn't load).
 *
 *  Revision 1.91  2008/07/30 00:01:01  hy93
 *  Moved core code to auth.c
 *
 *  Revision 1.3  2008/07/29 03:15:49  pb10
 *  fix function names
 *
 *  Revision 1.2  2008/07/29 02:44:54  pb10
 *  Fix naming for core functions.
 *
 *  Revision 1.1  2008/07/29 01:55:29  pb10
 *  Incomplete mod_cuwebauth surgery.
 *
 *  Revision 1.90  2008/07/28 18:26:43  hy93
 *  check if notes field is NULL before call apr function
 *
 *  Revision 1.89  2008/07/28 17:19:37  hy93
 *  move setting CUWA_SID to session
 *
 *  Revision 1.88  2008/07/25 18:57:36  hy93
 *  permit cache support
 *
 *  Revision 1.87  2008/07/25 17:52:11  gbr4
 *  the notes field CUWA_SID now contains a sessionID. It is now possible to pull out the session ID in the accesslog via LogFormat %{CUWA_SID}n
 *
 *  Revision 1.86  2008/07/22 19:04:10  gbr4
 *  1. In response to bug report regarding <form>'s that have no Action, do not append CUWACRED=Y to the final redirect back to the original URL for GET methods.
 *
 *  This leaves undesirable behaviour if the request method to get the form in the first place was POST. The new test cases t09actionlessforms_* check this case. The _post one is fixed and the get one is marked as a TODO.
 *
 *  This causes most test cases that looked for CUWACRED=Y in the final URL to need changes.
 *
 *  2. When building the ReturnURL for cuweblogin, use the original request if this is an internal redirect. This fixes the TODO's in t05redir
 *
 *  3. Since the dev permit server has been down a lot lately due to work on a production issue, add a check for the availability of that server to t07authz_permit.t. Now the permit tests will be skipped if the dev permit server is unresponsive.
 *
 *  Revision 1.85  2008/07/22 15:01:05  hy93
 *  send all principals to webLogin server in HA
 *
 *  Revision 1.84  2008/06/30 22:16:44  pb10
 *  Use fully qualified kerberos name on permit calls.
 *
 *  Revision 1.83  2008/06/28 02:21:01  gbr4
 *  revert %s expansion for 2.0
 *
 *  Revision 1.80  2008/06/19 00:56:31  pb10
 *  Implement 3-phase filter...
 *    1) redir to weblogin
 *    2) process cred and redir to orig url
 *    3) process request
 *
 *  Revision 1.79  2008/06/17 14:44:12  pb10
 *  Prevent SID comparison if cuwa_session_from_credential gets an error.
 *
 *  Revision 1.78  2008/06/16 14:42:34  hy93
 *  fix site cookie can not be discarded in safari
 *
 *  Revision 1.77  2008/06/13 14:51:21  hy93
 *  fix expired cookie problem
 *
 *  Revision 1.76  2008/06/12 19:59:53  pb10
 *  More fixes for subrequest.
 *
 *  Revision 1.75  2008/06/12 06:45:22  pb10
 *  Subrequests and internal redirects:
 *    - Make sure to search main and prev for notes table entries.
 *    - Allow subrequests to call cuwa_request_save.
 *
 *  Revision 1.74  2008/06/10 18:30:33  pb10
 *  Remove SID from return URL.
 *
 *  Revision 1.73  2008/06/05 13:00:19  hy93
 *  modify error message
 *
 *  Revision 1.72  2008/06/04 16:01:38  pb10
 *  Add comparison of URL based SID to SID aquired from credential.
 *
 *  Revision 1.71  2008/06/03 06:14:00  pb10
 *  Disable cache when handling cred from weblogin (to avoid browser URL confusion).
 *
 *  Revision 1.70  2008/06/02 13:26:37  hy93
 *  allow server to start when ha init fails
 *
 *  Revision 1.69  2008/05/30 20:04:01  pb10
 *  Put back in code that remembers current cookies even thought he rest of the request
 *  is being replaced by the original request (from session file).  This gets around
 *  issue where expired WA cred is sent in a refresh.  Now the session will be restored
 *  from the session file based on sid/key in cookie.
 *
 *  Revision 1.68  2008/05/29 14:47:23  hy93
 *  add checking if noprompt is defined with other require directive
 *
 *  Revision 1.67  2008/05/28 18:52:24  gbr4
 *  change all instances of WAK0Domain to WAK0Realms
 *
 *  Revision 1.66  2008/05/28 16:45:32  gbr4
 *  add multi-realm (guest id) support in weblogin. currently webauth calls the paramater WAK0Realms and the config WAK0Realms, this should be made consistant
 *
 *  Revision 1.65  2008/05/07 19:02:21  hy93
 *  guestID support
 *
 *  Revision 1.64  2008/05/06 14:25:09  hy93
 *  checking the status before call send_cookie
 *
 *  Revision 1.63  2008/05/06 13:09:40  hy93
 *  add apache version and OS version to the redirect URL
 *
 *  Revision 1.62  2008/05/05 16:10:32  hy93
 *  replace assert session with if statement
 *
 *  Revision 1.61  2008/05/03 04:11:43  gbr4
 *  make sure session can't be null on the way into cuwa_trace
 *
 *  Revision 1.60  2008/05/02 19:57:50  hy93
 *  fix configuraiton error causes segfault
 *
 *  Revision 1.59  2008/05/02 03:00:22  pb10
 *  Fixed the require noprompt feature.
 *
 *  Revision 1.58  2008/05/01 18:31:47  pb10
 *  Removed extra redirect to orig URL.  To get same functionality put entire
 *  orig. path into returnURL given to weblogin. Filter now searches for the
 *  following in the URI to detect CUWL return: .cuweblogin?wa=
 *  The return URL format is http://host/path/sid.cuweblogin?wa=cred
 *
 *  Revision 1.57  2008/04/29 13:28:38  hy93
 *  fix warning regarding assignment differ in signedness
 *
 *  Revision 1.56  2008/04/24 20:06:18  gbr4
 *  win32 warning cleanup pass.
 *
 *  Revision 1.55  2008/04/24 14:09:49  hy93
 *  Permit support
 *
 *  Revision 1.54  2008/04/24 13:22:06  pb10
 *  Fix problem with authz using the old header names.
 *
 *  Revision 1.53  2008/04/21 21:26:20  pb10
 *  Now sending environment variables as well as header variables to CGI.
 *  Also fixed a segfault caused by recent commit -  orig URL redirect.
 *
 *  Revision 1.52  2008/04/19 14:21:27  pb10
 *  Convert malloc's to APR allocations.
 *
 *  Revision 1.51  2008/04/19 05:16:28  pb10
 *  Redirect to original URL, feature added.  This is being done so that
 *  path relative objects such as images will be displayed properly after
 *  login.
 *
 *  Revision 1.50  2008/04/17 15:20:26  hy93
 *  Greb any CUWAWebLoginURL define for HA init
 *
 *  Revision 1.49  2008/04/16 14:21:59  hy93
 *  replace CUWAPermitService to CUWAPermitServer
 *
 *  Revision 1.48  2008/04/15 22:58:46  gbr4
 *  convert more %ll's to %q's for win32
 *
 *  Revision 1.47  2008/04/15 19:18:43  pb10
 *  Remove explicit domain in Set-Cookie.
 *
 *  Revision 1.46  2008/04/15 17:23:38  hy93
 *  Add checking if cookie exist in find_cookie to avoid segfault
 *
 *  Revision 1.45  2008/04/14 18:19:56  hy93
 *  add checking if sessionFilPath exist or not
 *
 *  Revision 1.44  2008/04/14 04:12:36  pb10
 *  Fix CUWACredentialAge to only check age on initial website page hit.  CUWACrentialDefaultAge obsolete.
 *
 *  Revision 1.43  2008/04/11 20:15:20  hy93
 *  Remove <> because anything inside the <> is considered to be html tag
 *
 *  Revision 1.42  2008/04/10 23:08:06  gbr4
 *  fixed all *compile* errors under msvc9.0 (studio 2008). Still has link errors
 *  and tons of warnings. This might cause regressions.
 *
 *  Revision 1.41  2008/04/09 18:01:40  hy93
 *  remove parameter in cuwa_ha_child_init
 *
 *  Revision 1.40  2008/04/08 15:28:22  hy93
 *  Set HA default to be enabled
 *
 *  Revision 1.39  2008/04/07 20:39:22  hy93
 *  Add directive to shut down high availability. The default is off
 *
 *  Revision 1.38  2008/04/06 17:26:15  pb10
 *  Changed CUWAPermitServerSRL directive to CUWAPermitServer directive, with
 *  new format.  Also added support for multiple permit servers.
 *
 *  Revision 1.37  2008/04/06 05:23:17  pb10
 *  Add CUWAReturnURL, and requires noprompt.  Moved several directives to the
 *  deprecated and obsolete lists.
 *
 *  Revision 1.36  2008/04/04 07:46:26  pb10
 *  Support for CUWAInquire.
 *
 *  Revision 1.35  2008/04/03 20:21:53  pb10
 *  Changes to credential age checking.  Also added the WANow arg to weblogin.
 *
 *  Revision 1.34  2008/04/03 19:12:25  hy93
 *  add high availability back
 *
 *  Revision 1.33  2008/04/03 17:37:55  hy93
 *  back out high availability
 *
 *  Revision 1.32  2008/04/02 20:18:15  hy93
 *  one more place need to change to use the login server returned by ha
 *
 *  Revision 1.31  2008/04/02 18:53:20  hy93
 *  high availability support
 *
 *  Revision 1.30  2008/03/30 15:50:39  pb10
 *  Make the age check consistent. The weblogin parameter didn't include
 *  implied CUWACredentialAge setting from old -force and -force-once settings.
 *
 *  Revision 1.29  2008/03/28 16:31:33  hy93
 *  Changing CUWAKeytabPath to CUWAKeytab
 *
 *  Revision 1.28  2008/03/28 15:54:23  hy93
 *  caller doesn't need to do session release if session_from_credential failed
 *
 *  Revision 1.27  2008/03/26 21:06:34  pb10
 *  Enable host checking in webauth. Fix minor log sanitizing glitch.
 *
 *  Revision 1.26  2008/03/25 15:57:03  pb10
 *  Added "phone home" to weblogin mechanism, via fake stylesheet link in the error page.
 *  Weblogin will return 404 (Not Found) so that it doesn't affect page presentation.
 *
 *  Revision 1.25  2008/03/24 21:30:28  pb10
 *  Better error page support.
 *
 *  Revision 1.24  2008/03/24 19:09:54  hy93
 *  clear cookie and release session before redirect to login
 *
 *  Revision 1.23  2008/03/19 20:30:12  pb10
 *  Moved weblogin credential parsing from the filter to mod_cuwebauth.c so that
 *  kerberos directives could be based on virtual host.
 *
 *  Revision 1.22  2008/03/18 13:54:19  pb10
 *  Add check for cookie NULL, causing segfault.
 *
 *  Revision 1.21  2008/03/18 13:20:06  pb10
 *  Completed support for CUWACredentialAge directive, the webauth part.
 *
 *  Revision 1.20  2008/03/14 19:48:47  hy93
 *  Return DECLINED instead of displaying error message in browser for the authType that we don't know.Otherwise virtual that uses other module to do authentication and authorization won't have a chance to run if it is loaded after cuwebauth
 *
 *  Revision 1.19  2008/03/13 20:11:17  pb10
 *  Changed pools from connection based to request based.
 *  Improved message passing between filter and mod_cuwebauth (Using notes field).
 *
 *  Revision 1.18  2008/03/13 18:59:09  pb10
 *  Added code to redirect to weblogin when session not found or timeout, per Hong's request.
 *  Added human readable messages to err_codes.  Not being displayed yet.
 *
 *  Revision 1.17  2008/03/06 16:56:07  hy93
 *  Make sure cookie is set
 *
 *  Revision 1.16  2008/02/22 18:34:17  hy93
 *  support CUWApermitServerSRL
 *
 *  Revision 1.15  2008/02/12 16:51:11  hy93
 *  remove \n when call cuwa_trace
 *
 *  Revision 1.14  2008/02/06 15:20:46  hy93
 *  change site cookie name to cuweblogin2 so cuwebauth 2 won't get cookie from cuwebauth 1 and generate error
 *
 *  Revision 1.13  2008/02/05 15:40:07  hy93
 *  move set_keys before calling cuwa_trace
 *
 *  Revision 1.12  2008/01/30 04:19:28  pb10
 *  Fix cookie handling.
 *
 *  Revision 1.11  2008/01/28 16:53:01  gbr4
 *  experimental change to apache version detection
 *
 *  Revision 1.10  2008/01/25 01:43:47  gbr4
 *  Added an ID string to every file
 *
 *  Revision 1.9  2008/01/22 17:06:50  pb10
 *  Support for CUWAforceSSL, CUWAautheFailHTTPCode, CUWAauthzFailHTTPCode, CUWACookieDomain
 *
 *  Revision 1.8  2008/01/19 16:26:45  pb10
 *  Fixed cookie bug, needed to close session before returning from authn.
 *
 *  Revision 1.7  2008/01/18 05:02:19  pb10
 *  solaris
 *
 *  Revision 1.6  2008/01/16 04:42:34  pb10
 *  Fixed incorrect port in returnURL.
 *
 *  Revision 1.5  2008/01/15 18:02:59  pb10
 *  Fixed problem with ReturnURL
 *
 *  Revision 1.4  2008/01/15 16:39:15  pb10
 *  Initialize log targets.
 *
 *  Revision 1.3  2008/01/14 16:12:42  pb10
 *  Fix issue with module struct naming conflict.  For some reason it worked
 *  OK on one version of apache but not another.  Now the module name coincides
 *  with the struct name.
 *
 *  Revision 1.2  2008/01/14 14:23:38  pb10
 *  Intermediate checkin.
 *
 *  Revision 1.1  2008/01/14 13:31:13  pb10
 *  Initial.
 *
 *
 ************************************************************************
 */

#include <apr_buckets.h>
#include <apr_general.h>
#include <apr_lib.h>
#include <apr_strings.h>
#include <apr_atomic.h>
#include <ap_compat.h>
#include <util_filter.h>
#include <http_request.h>
#include <httpd.h>
#include <http_config.h>
#include <http_protocol.h>
#include <http_connection.h>
#include <http_log.h>
#include <http_core.h>
#include <mod_core.h>

#include "../autoconfig.h"
#ifdef HAVE_UNISTD_H
#include <unistd.h>
#endif

#include <wal.h>
#include <ctype.h>
#include <time.h>
#include <cuwa_err.h>
#include <cuwa_request.h>
#include <cuwa_version.h>
#include <cuwa_parse.h>
#include <apache_request.h>
#include <log.h>
#include <cuwarand.h>
#include <log_apache.h>
#include <cuwa_types.h>
#include <cfg.h>
#include <cfg-dump.h>
#include <highAvail.h>
#include <cuwa_malloc.h>
#include <permit_ha.h>
#include <util.h>

#define CUWA2_LOG_DOMAIN cuwa.apache

#define CUWA_SITE_COOKIE_DISCARDED "cookiediscarded"

module AP_MODULE_DECLARE_DATA cuwebauth_module;
module AP_MODULE_DECLARE_DATA *cuwa_module = &cuwebauth_module;

// Include auto-generated functions and table for apache directives, depends on cuwa_module defined above :-)

char *cuwa_check_keytab(void * cmd, void *sInfo, const char *arg, CUWACfg_t* scfg, CUWACfg_t* cfg, apr_pool_t *pool, char *what)
{
	apr_finfo_t finfo;
	apr_status_t result;
	char *krb5cfg; 
	result=apr_stat(&finfo,CFG_CUWAKeytab(cfg),APR_FINFO_OWNER|APR_FINFO_PROT,pool);
	if(!result){
		if(finfo.protection & 0x66){
			fprintf(stderr,"\n[WEBAUTH WARNING] The keytab %s has overly permissive filesystem permissions. A future version of mod_webauth will block apache startup (%x)\n", CFG_CUWAKeytab(cfg),finfo.protection);
		}
		if(!(finfo.protection & 0x400)){
			return apr_psprintf(pool,"I can't read %s (%x)",cfg->CUWAKeytab.s,finfo.protection);
		}
        }
	else{
		return apr_psprintf(pool,"The keytab %s doesn't exist or is unreadable (stat failed)",cfg->CUWAKeytab.s);
	}
	
#ifndef WIN32
	krb5cfg=getenv("KRB5_CONFIG");
	krb5cfg=krb5cfg?krb5cfg:"/etc/krb5.cfg";
	result=apr_stat(&finfo,CFG_CUWAKeytab(cfg),APR_FINFO_OWNER|APR_FINFO_PROT,pool);
	if(result) return apr_psprintf(pool,"Unable to read the krb5config %s",cfg->CUWAKeytab.s);
#endif
	return NULL;
}

char *cuwa_check_sessionfilepath(void * cmd, void *sInfo, const char *arg, CUWACfg_t* scfg, CUWACfg_t* cfg, apr_pool_t *pool,char *what)
{
	apr_finfo_t finfo;
	apr_status_t result;
	result=apr_stat(&finfo,CFG_CUWAsessionFilePath(cfg),APR_FINFO_OWNER|APR_FINFO_PROT|APR_FINFO_TYPE,pool);
	if(!result){
		if(finfo.protection & 0x66){
			fprintf(stderr,"\n[WEBAUTH WARNING] The sessionfilepath %s has overly permissive filesystem permissions. A future version of mod_webauth will block apache startup.\n", CFG_CUWAsessionFilePath(cfg));
		}
		if(!(finfo.protection & 0x0700)){
			return apr_psprintf(pool,"I need to be able to read and write %s",CFG_CUWAsessionFilePath(cfg));
		}
		if(finfo.filetype != APR_DIR){
			return apr_psprintf(pool,"CUWAsessionFilePath %s must be a directory",CFG_CUWAsessionFilePath(cfg));
		}
        }
	else{
		return apr_psprintf(pool,"The CUWAsessionFilePath %s doesn't exist or is unreadable (stat failed)",CFG_CUWAsessionFilePath(cfg));
	}
	return NULL;
}


#include <cfg-apache-incl.c>

#include <ap_release.h>
#if AP_SERVER_MAJORVERSION_NUMBER >=2
#if AP_SERVER_MINORVERSION_NUMBER >=2
    #define CUWA_HTTP_SCHEME(r,c)   (CFG_CUWAforceSSL((c)) && *CFG_CUWAforceSSL((c))==O_CFG_CUWAforceSSL_on) ? "https" : ap_http_scheme((r))
#else
    #define CUWA_HTTP_SCHEME(r,c)   (CFG_CUWAforceSSL((c)) && *CFG_CUWAforceSSL((c))==O_CFG_CUWAforceSSL_on) ? "https" : ap_http_method((r))
#endif
#endif

#define IS_SSL(r,c) ( !strcmp(CUWA_HTTP_SCHEME(r,c),"https") )

static const char *cuwa_table_get(request_rec *r, char *name);
static void *cuwa_create_dir_config(apr_pool_t *p, char *dir);
static void *cuwa_merge_dir_config(apr_pool_t *p, void *base_conf, void *new_conf);
static void *cuwa_create_server_config(apr_pool_t *p, server_rec *s);
static void *cuwa_merge_server_config(apr_pool_t *p, void *base_conf, void *new_conf);
static void cuwa_init_child(apr_pool_t *p, server_rec *s);
static int cuwa_post_config(apr_pool_t *p, apr_pool_t *plog, apr_pool_t *ptemp, server_rec *s);

#include <apache_wal.c>

//////////////////////////////////////////////
// WAL Callback functions
//////////////////////////////////////////////
int cuwa_wal_show_error(void *request)
{
    request_rec *r = (request_rec *)request;
    char *codeStr, *statusStr, *msg;
    int status = 500, code = 0;

    statusStr = (char*) cuwa_table_get( r,"CUWL-error-status");
    codeStr = (char*) cuwa_table_get( r,"CUWL-error-code");
    msg = (char*) cuwa_table_get( r,"CUWL-error-msg");

    if (statusStr) status = atoi(statusStr);
    if (codeStr) code = atoi(codeStr);
    if (!msg) msg = "";

    return cuwa_core_show_error(r, r->pool, status, code, "%s", msg );
}

int cuwa_wal_is_ssl( void *req )
{
    request_rec *r = (request_rec *)req;

    return IS_SSL( r, cuwa_wal_get_config(req) );
}

int cuwa_wal_return_declined()
{
    return DECLINED;
}

const char *cuwa_wal_get_server_signature( const char *str, void *r)
{
    return ap_psignature(str,r);
}

const char *cuwa_wal_get_server_version()
{
#if AP_SERVER_MINORVERSION_NUMBER > 2
    return ap_get_server_banner();
#else
    return ap_get_server_version();
#endif
}

char * cuwa_wal_escape_uri( apr_pool_t *pool, char *uri)
{
    return (ap_escape_uri(pool,uri));
}

char * cuwa_wal_get_require_line(void *request,void *requires, int i )
{
    require_line *reqs = (require_line *)requires;
    request_rec *r = (request_rec *)request;

    if (! (reqs[i].method_mask & (((apr_int64_t)1) << r->method_number)))
            return NULL;
    else
        return reqs[i].requirement;
}

CUWACfg_t *cuwa_wal_get_config_from_server(void *server)
{
    server_rec *s = (server_rec *)server;

    return ap_get_module_config(s->module_config, cuwa_module);
}

void *cuwa_wal_get_next_server(void *server)
{
    server_rec *s = (server_rec *)server;

    return (s->next);
}

char *cuwa_wal_get_authtype(void * request)
{
    request_rec *r = (request_rec *) request;
    return (char *)ap_auth_type(r);
}

int cuwa_wal_handle_error(void * request, int error)
{
#ifndef WIN32
    // The ap_response_code_string symbol isn't exported in Win32, so the feature only applies to *nix.  If the symbol goes away in future
    // versions of Apache we may need to add a directive to signal to webauth that the ErrorDocument has been set.
    request_rec *r = (request_rec *) request;
    int error_index = ap_index_of_response(error);
    char * errordoc = ap_response_code_string(r, error_index);

    if (errordoc)
    {
        cuwa_trace("*** ErrorDocument is defined, returning error code only: %d (idx=%d) %s",error, error_index, errordoc);
        r->status = error;
        return 1;
    }
#endif
    return 0;
}


char *cuwa_wal_get_virtual_host(void * request, CUWACfg_t *cfg, char *path)
{
    request_rec *r = (request_rec *) request;
    int port = (r->connection && r->connection->local_addr) ? r->connection->local_addr->port : r->server->port;
    return cuwa_core_make_return_url(r->pool, cfg, r->server->server_hostname, port, IS_SSL(r,cfg), path);
}

const char *cuwa_wal_get_method(void * request)
{
    request_rec *r = (request_rec *) request;
    return r->method;
}

void cuwa_wal_dont_cache(void * request)
{
    request_rec *r = (request_rec *) request;
    r->no_cache = 1;
    r->no_local_copy = 1;
}

void cuwa_wal_set_user(void * request, char *user)
{
    request_rec *r = (request_rec *) request;
    r->user = apr_pstrdup(r->pool, user);
}

char *cuwa_wal_get_uri(void * request, int uri_flags)
{
    request_rec *r = (request_rec *) request;
    if (uri_flags & CUWA_URI_ORIGINAL)
    {
        while (r->prev) r = r->prev;
    }
    if (uri_flags & CUWA_URI_UNPARSED)
    {
        return r->unparsed_uri;
    }
    return r->uri;
}

char *cuwa_wal_get_hostname(void * request)
{
    request_rec *r = (request_rec *) request;
    return r->server->server_hostname;
}

const char *cuwa_wal_get_header_in(void * request, char *name)
{
    request_rec *r = (request_rec *) request;
    return apr_table_get(r->headers_in, name);
}

void cuwa_wal_set_header_in(void * request, char *name, char *value)
{
    request_rec *r = (request_rec *) request;
    apr_table_set(r->headers_in,name,value);

#if AP_SERVER_MINORVERSION_NUMBER > 2 
    //Apache 2.4 doesn't pupoulate cuWebAuth variables in HTTP header because our name has underscore in it

    char *tmp = apr_pstrdup(r->pool, name);
    cuwa_util_replace_char_with(tmp,'_','-');
    apr_table_set(r->headers_in,tmp,value);
#endif
}

void cuwa_wal_clear_header_in(void * request, char *name)
{
    request_rec *r = (request_rec *) request;
    apr_table_unset( r->headers_in,name);
}

void cuwa_wal_set_header_out(void * request, char *name, char *value)
{
    request_rec *r = (request_rec *) request;
    apr_table_set(r->headers_out,name,value);
    apr_table_set(r->err_headers_out,name,value);
}

void cuwa_wal_set_env(void * request, char *name, char *value)
{
    request_rec *r = (request_rec *) request;
    apr_table_set(r->subprocess_env,name,value);
}

char * cuwa_wal_get_env(void * request, char *name)
{
    request_rec *r = (request_rec *) request;
    return (char*) apr_table_get( r->subprocess_env, name);
}

void cuwa_wal_set_cookie(void * request, char *name, char *value)
{
    request_rec *r = (request_rec *) request;
    char *buf;

    buf = cuwa_core_set_cookie(request, cuwa_wal_get_config(request), name, value);

    apr_table_add(r->headers_out,"Set-Cookie",buf);     // Send to browser, normal case
    apr_table_add(r->err_headers_out,"Set-Cookie",buf); // Send to browser with errors
}


///////////////////////////////////////////////////////
// Apache hooks....
///////////////////////////////////////////////////////


int cuwa_apache_authn(request_rec *r)
{
    int rc;
    char *sidstr, *cookie, *login_cred;

    cuwa_log_apache_set_keys(r,r->server,r->connection);
    cuwa_malloc_set_pool(r->pool);

    cuwa_trace("Inbound request: %s %s",r->method,r->unparsed_uri);

    // Check for cookie from weblogin...
    login_cred = (char*) cuwa_table_get( r,"CUWL-Credential");
    if (login_cred)
    {
        // Don't use browser cache. Browser has no idea what the actual target document filename is.
        r->no_cache = 1;
        r->no_local_copy = 1;
    }

    // Check for site cookie...
    // Current cookies overrides cookies from original request
    cookie = (char*) cuwa_table_get(r,"CUWA-Cookies");
    if (!cookie) cookie = (char*) apr_table_get( r->headers_in,"Cookie");


    sidstr = (char*) cuwa_table_get(r,"CUWA-SID");

    rc = cuwa_core_authn(r, r->pool, login_cred, cookie, sidstr);

    if (!rc) rc = OK;

    return rc;
}

#if AP_SERVER_MINORVERSION_NUMBER <=2
int cuwa_apache_authz(request_rec *r)
{
    int rc = cuwa_core_authz(r,r->pool);

    if (!rc) rc = OK;

    return rc;
}
#endif

void *cuwa_create_dir_config(apr_pool_t *p, char *dir)
{
    return(CUWACfg_t *) apr_pcalloc(p, sizeof(CUWACfg_t));
}

void *cuwa_create_server_config(apr_pool_t *p, server_rec *s)
{
    return(CUWACfg_t *) apr_pcalloc(p, sizeof(CUWACfg_t));
}


void *cuwa_merge_dir_config(apr_pool_t *p, void *base_conf, void *new_conf)
{
    return cuwa_merge_config(p,(CUWACfg_t *)base_conf,(CUWACfg_t *)new_conf);
}


void *cuwa_merge_server_config(apr_pool_t *p, void *base_conf, void *new_conf)
{
    return cuwa_merge_config(p,(CUWACfg_t *)base_conf,(CUWACfg_t *)new_conf);
}

int cuwa_post_config(apr_pool_t *p, apr_pool_t *plog, apr_pool_t *ptemp, server_rec *s)
{
    char *cuwa_version;
    void *data = NULL;
    CUWACfg_t *cfg;
    const char *userdata_key = "shm_cuwa_post_config";
    int foundPrinc=0, foundURL=0, foundKeytab=0;
    int rc = OK;
    server_rec *base = s;
#ifdef WIN32
    char *strValue = NULL;
#endif

    cuwa_log_apache_init(p);
    cuwa_malloc_init(p);
    cuwa_log_apache_set_keys(NULL,base,NULL);

    // First pass, check checking the configuration.
    // Second pass, announce the module.
    apr_pool_userdata_get(&data, userdata_key, s->process->pool);
    if (data == NULL)
    {
        /* First Pass */
        apr_pool_userdata_set((const void *)1, userdata_key, apr_pool_cleanup_null, s->process->pool);

#ifdef WIN32
	//check if environment KRB5RCACHETYPE is set
	strValue =  getenv("KRB5RCACHETYPE");

	if (!strValue || stricmp(strValue,"none"))
	{
		ap_log_error(APLOG_MARK, APLOG_NOERRNO|APLOG_WARNING,0,base,"CUWA Error: Environment variable KRB5RCACHETYPE is not set. Please add KRB5RCACHETYPE as system environment on your server. Set its value to none. Then reboot Windows server.");
        	rc = HTTP_INTERNAL_SERVER_ERROR;
	}
#endif

        // Validate the config here.  Look at each VH, check for required directives...
        while (s)
        {
            cfg = ap_get_module_config(s->module_config, cuwa_module);
            if (!cfg) break;

            if (CFG_CUWAKerberosPrincipal(cfg))
            {
                char *principal = CFG_CUWAKerberosPrincipal(cfg);
                if ( !strchr( principal, '@' ) )
                {
                    ap_log_error(APLOG_MARK, APLOG_NOERRNO|APLOG_WARNING,0,base,"Error: Realm is not specified in CUWAKerberosPrincipal %s", principal );
                    rc = HTTP_INTERNAL_SERVER_ERROR;
                }
                foundPrinc = 1;

            }
            else
            {
                ap_log_error(APLOG_MARK, APLOG_NOERRNO|APLOG_WARNING,0,base,"Warning: CUWAKerberosPrincipal not set for %s",s->server_hostname);
            }

            if (CFG_CUWAKeytab(cfg))
            {
		foundKeytab = 1;
            }
            else
            {
                ap_log_error(APLOG_MARK, APLOG_NOERRNO|APLOG_WARNING,0,base,"Warning: CUWAKeytab not set for %s",s->server_hostname);
            }

            if (CFG_CUWAWebLoginURL(cfg))
            {
                foundURL = 1;
            }
            else
            {
                ap_log_error(APLOG_MARK, APLOG_NOERRNO|APLOG_WARNING,0,base,"Warning: CUWAWebLoginURL not set for %s",s->server_hostname);
            }

            s = s->next;
        }

        if (!foundPrinc)
        {
            ap_log_error(APLOG_MARK, APLOG_NOERRNO|APLOG_EMERG,0,base,"Error: CUWAKerberosPrincipal not set");
            rc = HTTP_INTERNAL_SERVER_ERROR;
        }

        if (!foundKeytab)
        {
            ap_log_error(APLOG_MARK, APLOG_NOERRNO|APLOG_EMERG,0,base,"Error: CUWAKeytab not set");
            rc = HTTP_INTERNAL_SERVER_ERROR;
        }

        if (!foundURL)
        {
            ap_log_error(APLOG_MARK, APLOG_NOERRNO|APLOG_EMERG,0,base,"Error: CUWAWebLoginURL not set");
            rc = HTTP_INTERNAL_SERVER_ERROR;
        }

        // NOTE: Unfortunately HTTP_INTERNAL_SERVER_ERROR doesn't cause the startup to terminate, at least not in apache 2.0
        //       Instead it prints a message and terminates the current process.  This doesn't kill the server though.
        //       I think this is an Apache bug.
        return rc;
    }

    // We're up and running, announce CUWA version...
    cuwa_version = cuwa_version_get_full();

    ap_log_error(APLOG_MARK, APLOG_NOERRNO|APLOG_EMERG,0,s,"CUWebAuth/%s",cuwa_version);

    if (strcmp(&cuwa_version[strlen(cuwa_version)-4],"Exp)")==0)
    {
        ap_log_error(APLOG_MARK, APLOG_NOERRNO|APLOG_EMERG,0,s,"Experimental CUWebAuth Version - Do not use on production services");
    }


    cfg = ap_get_module_config(s->module_config, cuwa_module);

    cuwa_build_client_version( p );

    if ( CUWA_HA_ENABLED(cfg) )
    {
        if ( cuwa_ha_init(s, p) != CUWA_OK )
        {
             cuwa_warning("High availability failed at initialization. Please reboot web server to initialize it.");
             rc = HTTP_INTERNAL_SERVER_ERROR;
        }
        if ( !cuwa_ha_get_permit_server_string() )
        {
            cuwa_warning("Get permit servers failed at initialization. Please reboot web server to initialize it.");
            rc = HTTP_INTERNAL_SERVER_ERROR;
        }else
            cuwa_permit_ha_add_servers( cuwa_ha_get_permit_server_string(), p );
    }

    if (!rc) {
        s = base;
        while (s)
        {
            cfg = ap_get_module_config(s->module_config, cuwa_module);
            if (!cfg) break;

            if (CFG_CUWAKerberosPrincipal(cfg))
            {
               //check if server is configured with wak2Flag 
               if (CFG_CUWAwak2Flags(cfg) && (*CFG_CUWAwak2Flags(cfg) == O_CFG_CUWAwak2Flags_1))
               {
                   char *lookupYes,*lookupNo;

                   cuwa_trace("check if %s is allowed for k3",CFG_CUWAKerberosPrincipal(cfg));
                   rc = cuwa_permit_ha_check( p, CFG_CUWAKerberosPrincipal(cfg), CFG_CUWAKeytab(cfg), CFG_CUWAKerberosPrincipal(cfg),"cit.weblogin.getk3", &lookupYes, &lookupNo);
                   if (!rc && lookupNo)
                   {
                       cuwa_warning("ServiceID %s is not enabled for delegation. Remove 'CUWAWAK2Flags 1' from cuwebauth configuration for this virtual host",CFG_CUWAKerberosPrincipal(cfg));
                   }
               }
            }

            s = s->next;
        }


    }

    return rc;
}

void cuwa_init_child(apr_pool_t *p, server_rec *s)
{
    cuwa_err_t  rc;
    CUWACfg_t *cfg;
    char *permitStr = cuwa_ha_get_permit_server_string();
    int overwritePermitStr = 0 ;
    server_rec *ptr = s;

    cuwa_rand_init_g();

    rc = cuwa_log_apache_init(p);
    if (rc)
    {
        ap_log_error(APLOG_MARK, APLOG_NOERRNO|APLOG_INFO,0,s,"Error initializing logging: %d",rc);
    }

    cuwa_log_apache_set_keys(NULL,s,NULL);
    cuwa_malloc_set_pool(p);

    cfg = ap_get_module_config(s->module_config, cuwa_module);

    if ( CUWA_HA_ENABLED(cfg) )
        cuwa_ha_child_init( );

     //check if server wants to use its own permit server define
    while (s)
    {
        cfg = ap_get_module_config(s->module_config, cuwa_module);

        if ( cfg && CFG_CUWApermitServerOverride(cfg) )
        {
            overwritePermitStr = *CFG_CUWApermitServerOverride((cfg))==O_CFG_CUWApermitServerOverride_on ? 1:0;

            break;
        }
        s = s->next;
   }
   cuwa_trace("overwritePermitStr=%d", overwritePermitStr);

   if ( !permitStr || overwritePermitStr)
   {
       s = ptr;
       while (s)
       {
           cfg = ap_get_module_config(s->module_config, cuwa_module);
           if (cfg) permitStr = CFG_CUWApermitServer(cfg);

           if ( CFG_CUWApermitServer(cfg) )
           {
               permitStr = CFG_CUWApermitServer(cfg);
               break;
           }
           s = s->next;
       }
   }

   if ( permitStr ) 
   {
       cuwa_permit_ha_add_servers( permitStr, p );
       if (overwritePermitStr) 
           cuwa_permit_random_server_to_use();
   }
   else cuwa_warning("No permit server string defined");
}

// Handle deferred errors from the filter
static int cuwa_error_handler(request_rec *r)
{
    char *codeStr, *statusStr, *msg;
    int status = 500, code = 0;

    // !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
    // !! CAUTION adding a trace here will cause python auth to fail.  
    // Python hacks the value of r->main r->prev and r->next between authn and authz stages.
    // !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!    
    // cuwa_trace("cuwa_error_handler handler==%s",r->handler);

    if (strcmp(r->handler, "cuwa-error-handler"))
    {
        return DECLINED;
    }

    statusStr = (char*) cuwa_table_get( r,"CUWL-error-status");
    codeStr = (char*) cuwa_table_get( r,"CUWL-error-code");
    msg = (char*) cuwa_table_get( r,"CUWL-error-msg");

    // If CUWA didn't set an error status earlier, then don't handle the
    // error here. CUWAAuthBasic for instance relies on a 401 being returned
    // to the browser.
    if (!statusStr)
    {
        return DECLINED;
    }

    if (statusStr) status = atoi(statusStr);
    if (codeStr) code = atoi(codeStr);
    if (!msg) msg = "";

    return cuwa_core_show_error(r, r->pool, status, code, "%s", msg );
}


// these two are somewhat unstable but are useful for debugging r->user stuff
// they are not registered
/*
static int cuwa_trace_user_handler(request_rec *r)
{
    cuwa_trace("r->user is %s, r is %p, r->prev is %p, r->main is %p, ap_auth_type(r) is %s",r->user,r,r->prev,r->main, ap_auth_type(r));
    return DECLINED;
}
static int cuwa_trace_user_handler2(request_rec *r)
{
    cuwa_trace("r->user is %s, r is %p, r->prev is %p, r->main is %p, ap_auth_type(r) is %s",r->user,r,r->prev,r->main, ap_auth_type(r));
    return DECLINED;
}
*/

static int cuwa_apache_portal_handler(request_rec *r)
{
    if ( !r->handler || strncmp(r->handler, "cuwa_",5) )
        return DECLINED;

    if ( r->method_number != M_GET )
        return HTTP_METHOD_NOT_ALLOWED;

    if ( !strcmp(r->handler, "cuwa_permit") ) return cuwa_core_portal_permit_handler( r, r->pool);
    if ( !strcmp(r->handler, "cuwa_proxy") ) return cuwa_core_portal_proxy_handler( r, r->pool);
    if ( !strcmp(r->handler, "cuwa_davlogin") ) return cuwa_core_portal_davlogin_handler( r, r->pool);
    return DECLINED;
}

static int cuwa_apache_header_parser(request_rec *r){
#undef CUWA2_LOG_DOMAIN
#define CUWA2_LOG_DOMAIN cuwa.dumpcfg
    CUWACfg_t *cfg = NULL;
    char *req_line;
    int i=0;
    const apr_array_header_t *requiresList = NULL;
    char *header=NULL;

    if(r && r->headers_in){
	header=(char *)apr_table_get(r->headers_in,"CUWA_DUMPCFG");
    }
    if(!header) return DECLINED;

    requiresList = cuwa_wal_get_requires( r);
    cfg = cuwa_wal_get_config(r);
    cuwa_trace("in header_parser");
    cuwa_trace("[%s] r->uri: %s",header,DENULL(r->uri));
    cuwa_trace("[%s] r->server->server_hostname: %s",header,DENULL(r->server->server_hostname));
    cuwa_trace("[%s] r->ap_auth_type: %s",header,DENULL(ap_auth_type(r)));
    cuwa_trace("[%s] r->handler: %s",header,DENULL(r->handler));
    cuwa_trace("[%s] r->filename: %s",header,DENULL(r->filename));
    if(requiresList)
    {
	    for (i=0; i<requiresList->nelts; i++)
	    {
		    req_line = cuwa_wal_get_require_line( r, requiresList->elts, i);
		    cuwa_trace("[%s] require: %s",header,DENULL(req_line));
	    }
    }
    cuwa_dump_cfg(cfg,header);
    return DECLINED;
#undef CUWA2_LOG_DOMAIN
#define CUWA2_LOG_DOMAIN cuwa.apache
}

#if AP_SERVER_MINORVERSION_NUMBER > 2
static const authz_provider cuwa_apache_authz_netid  =
{
    &cuwa_core_authz_check_netid,
    NULL,
};

static const authz_provider cuwa_apache_authz_permit  =
{
    &cuwa_core_authz_check_permit,
    NULL,
};

static const authz_provider cuwa_apache_authz_valid_user  =
{
    &cuwa_core_authz_check_user,
    NULL,
};

static const authz_provider cuwa_apache_authz_noprompt  =
{
    &cuwa_core_authz_check_noprompt,
    NULL,
};

#endif

static void cuwa_register_hooks(apr_pool_t *p)
{
    ap_hook_handler(cuwa_error_handler, NULL, NULL, APR_HOOK_REALLY_FIRST);
//    ap_hook_handler(cuwa_trace_user_handler, NULL, NULL, APR_HOOK_REALLY_FIRST);
//    ap_hook_log_transaction(cuwa_trace_user_handler2, NULL, NULL, APR_HOOK_REALLY_LAST);
    ap_hook_header_parser(cuwa_apache_header_parser, NULL, NULL, APR_HOOK_FIRST);
    ap_hook_handler(cuwa_apache_portal_handler, NULL, NULL, APR_HOOK_MIDDLE);
    ap_hook_post_config(cuwa_post_config,NULL,NULL,APR_HOOK_MIDDLE);
    ap_hook_check_user_id(cuwa_apache_authn,NULL,NULL,APR_HOOK_FIRST);

#if AP_SERVER_MINORVERSION_NUMBER > 2                                                                                

    ap_register_auth_provider(p, AUTHZ_PROVIDER_GROUP, "netid",
                              AUTHZ_PROVIDER_VERSION,
                              &cuwa_apache_authz_netid, AP_AUTH_INTERNAL_PER_CONF);
    ap_register_auth_provider(p, AUTHZ_PROVIDER_GROUP, "permit",
                              AUTHZ_PROVIDER_VERSION,
                              &cuwa_apache_authz_permit, AP_AUTH_INTERNAL_PER_CONF);
    ap_register_auth_provider(p, AUTHZ_PROVIDER_GROUP, "valid-user",
                              AUTHZ_PROVIDER_VERSION,
                              &cuwa_apache_authz_valid_user, AP_AUTH_INTERNAL_PER_CONF);
    ap_register_auth_provider(p, AUTHZ_PROVIDER_GROUP, "noprompt",                                                                                         
                              AUTHZ_PROVIDER_VERSION,                                                                                                      
                              &cuwa_apache_authz_noprompt, AP_AUTH_INTERNAL_PER_CONF);
#else
    ap_hook_auth_checker(cuwa_apache_authz,NULL,NULL,APR_HOOK_FIRST);
#endif
    ap_hook_child_init(cuwa_init_child,NULL,NULL,APR_HOOK_MIDDLE);

    cuwa_request_apache_init(NULL,NULL);
}

module AP_MODULE_DECLARE_DATA cuwebauth_module =
{
    STANDARD20_MODULE_STUFF,

    cuwa_create_dir_config,
    cuwa_merge_dir_config,
    cuwa_create_server_config,
    cuwa_merge_server_config,
    cuwa2_cmds,
    cuwa_register_hooks
};

const char id_apache_mod_cuwebauth_c[] = "$Id$";

