#include <apr.h>
#include <apr_general.h>
#include <apr_buckets.h>
#include <session_bucket.h>
#include <session.h>
#include <log.h>

#define CUWA2_LOG_DOMAIN cuwa.apache

typedef struct session_bucket {
    /** Number of buckets using this memory */
    apr_bucket_refcount  refcount;
    cuwa_session_t *sess;
    apr_pool_t *pool;

} session_bucket_t;

static void session_bucket_destroy(void *data)
{
    session_bucket_t *b = (session_bucket_t *) data;

    if (apr_bucket_shared_destroy(b))
    {
        cuwa_trace("SESSION_BUCKET_DESTROY: s: %x, sid: %llX b: %x",b->sess,b->sess->sessionID,b);
        cuwa_session_close_request( b->sess );
//        cuwa_session_release( b->sess );  // bucket brigade is still using this (apache_request.c)
        apr_bucket_free(b);
    }
}


static apr_status_t session_bucket_read(apr_bucket *e, const char **str,
                                     apr_size_t *len, apr_read_type_e block)
{
    session_bucket_t *a = (session_bucket_t*) e->data;
    cuwa_session_t *sess = a->sess;
    apr_bucket *b = NULL;
    char *buf;
    apr_status_t rv;
    apr_size_t length = e->length;
    apr_off_t offset = e->start;

    *len = (length > APR_BUCKET_BUFF_SIZE) ? APR_BUCKET_BUFF_SIZE : length;
    *str = NULL;
    buf = apr_bucket_alloc(*len+1, e->list);

    rv = cuwa_session_read_request( sess, buf, len);

    cuwa_trace("SESSION_BUCKET_READ: %d bytes, %d",*len,rv);
    // fixme, should check to make sure error codes align with reality
    if (rv != CUWA_OK && rv != CUWA_ERR_SESSION_EOF)
    {
        apr_bucket_free(buf);
        return rv;
    }
    length -= *len;

    // Change current bucket to heap with read data in it.
    apr_bucket_heap_make(e, buf, *len, apr_bucket_free);

    // More to read? create another bucket
    if (length > 0 && rv != CUWA_ERR_SESSION_EOF)
    {
        // keep the session bucket, just create a new apr_bucket
        b = apr_bucket_alloc(sizeof(*b), e->list);
        b->start  = offset + (*len);
        b->length = length;
        b->data   = a;
        b->type   = &cuwa_session_bucket_type;
        b->free   = apr_bucket_free;
        b->list   = e->list;
        APR_BUCKET_INSERT_AFTER(e, b);
    }
    else
    {
        cuwa_trace("SESSION_BUCKET: nothing left to read: %d %d(EOF=%d)",length, rv, CUWA_ERR_SESSION_EOF);
        session_bucket_destroy(a);
    }

    *str = buf;
    return rv;
}

//fixme APU_DECLARE removed by gbr4 due to win32 error
apr_bucket * session_bucket_make(apr_bucket *b, cuwa_session_t *sess,
                                               apr_off_t offset,
                                               apr_size_t len, apr_pool_t *p)
{
    session_bucket_t *sb;

    sb = apr_bucket_alloc(sizeof(*sess), b->list);
    sb->sess = sess;
    sb->pool = p;

    b = apr_bucket_shared_make(b, sb, offset, len);
    b->type = &cuwa_session_bucket_type;

    cuwa_trace("SESSION_BUKET_MAKE s: %x, sid: %llX b: %x",sb->sess,sb->sess->sessionID,sb);

    return b;
}

//fixme APU_DECLARE removed by gbr4 due to win32 error
apr_bucket * session_bucket_create(cuwa_session_t *sess,
                                                 apr_off_t offset,
                                                 apr_size_t len, apr_pool_t *p,
                                                 apr_bucket_alloc_t *list)
{
    apr_bucket *b = apr_bucket_alloc(sizeof(*b), list);

    APR_BUCKET_INIT(b);
    b->free = apr_bucket_free;
    b->list = list;
    return session_bucket_make(b, sess, offset, len, p);
}

//fixme APU_DECLARE removed by gbr4 due to win32 error
const apr_bucket_type_t cuwa_session_bucket_type = {
    "CUWASession", 5, APR_BUCKET_DATA,
    session_bucket_destroy,
    session_bucket_read,
    apr_bucket_setaside_noop,
    apr_bucket_shared_split,
    apr_bucket_shared_copy
};
const char id_apache_session_bucket_c[] = "$Id$";
