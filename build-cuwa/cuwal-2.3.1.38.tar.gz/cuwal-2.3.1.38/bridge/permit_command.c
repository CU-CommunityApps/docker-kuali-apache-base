/************************************************************************
 * permit_command.c -- Handle permit request command received from cuWebauth
 *
 * Copyright 2010 Cornell University.
 * All Rights Reserved.
 *
 ************************************************************************
 *  $Log$
 *  Revision 1.11  2010/05/24 18:24:14  hy93
 *  Fix permit creation problem for serviceidmanager. Add ways to return unlimited list group and list member
 *
 *  Revision 1.10  2010/05/21 20:59:37  hy93
 *  permit create support
 *
 *  Revision 1.9  2010/05/21 16:35:56  hy93
 *  use aspx for updating permit
 *
 *  Revision 1.8  2010/05/20 18:52:26  hy93
 *  permit update support
 *
 *  Revision 1.7  2010/05/19 20:13:24  hy93
 *  permit update support
 *
 *  Revision 1.6  2010/05/19 17:00:29  hy93
 *  permit update support
 *
 *  Revision 1.5  2010/05/04 15:43:26  hy93
 *  enable permit update commands
 *
 *  Revision 1.4  2010/04/09 20:09:22  hy93
 *  add correct realm to the end of the netid in request
 *
 *  Revision 1.3  2010/03/25 19:47:35  hy93
 *  change to use upn when search for netid
 *
 *  Revision 1.2  2010/03/19 17:49:48  hy93
 *  improve the efficiency of the code
 *
 *  Revision 1.1  2010/03/12 14:08:00  hy93
 *  Initial checkin
 *
 ************************************************************************
 */ 

#include <stdlib.h>
#include <cuwa_malloc.h>
#include <log.h>
#include <apr_strings.h>
#include <bridge.h>
#include <permit_command.h>
#include <wal.h>
#include <update_permit.h>
#include <sha1.h>
#include <impersonate.h>

#define CUWA2_LOG_DOMAIN cuwa.bridge

#define PERMIT_RETURN_BUF_LEN   4194304  //4 meg
#define TOTAL_MEMBER_LIMIT      6000  //when the total member in a group is more than 6000, we return error.
#define PERMIT_NAME_MAX         59

char permit_return_buf[PERMIT_RETURN_BUF_LEN+1];

static char *g_ars_url = NULL;                                                                                             
static char *g_aspx_url = NULL;
static char *g_ars_create_cred = NULL;                                                                                           
static char *g_ars_reset_cred = NULL;
static char *g_password_key = NULL;  
static char *g_ad_group_ou = NULL;
static char *g_ad_admin_ou = NULL;
static char *g_IPSN_ou = NULL;

static int getpermit (request_rec *r, permit_request_t *req, char **args_out);
static int listpermits (request_rec *r, permit_request_t *req, char **args_out, int excludeAdminGroups);
static int listnetids (request_rec *r, permit_request_t *req, char **args_out, int limit);
static int updatepermits( request_rec *r, char *requester, permit_request_t *req, char **args_out);
static char *normalize_id( request_rec *r, char *netid);
static int checkIPSN(request_rec *r, char *requester, permit_request_t *req, char **args_out);

int permit_command(request_rec *r, char *requester, char *requesterFullid, permit_request_t *req, char **args_out)
{
    const char *cmd = req->cmd;
    int rc = CUWA_OK;

    if (!cmd) return CUWA_ERR_PERMIT_CMD;

    if (!strcmp(cmd,"getpermit")) return getpermit(r,req,args_out);

    if (!strcmp(cmd,"checkIPSN")) return checkIPSN(r,requesterFullid, req,args_out);

    if (!strcmp(cmd,"listpermits")) return listpermits(r,req,args_out, 1);   //exclude admin and upd groups
    
    if (!strcmp(cmd,"listallpermits")) return listpermits(r, req, args_out, 0);

    if (!strcmp(cmd,"listnetids")) return listnetids(r,req,args_out, TOTAL_MEMBER_LIMIT);
    
    if (!strcmp(cmd,"listallnetids")) return listnetids(r,req,args_out, -1);

    if ( !strcmp(cmd,"addpermit") || !strcmp(cmd,"deletepermit") )
        return updatepermits( r, requester, req, args_out );
    else 
   {
        cuwa_warning("Unsupported command:%s", cmd);
        rc = CUWA_ERR_PERMIT_CMD;
   }

  return rc;
}

//check if delegate can impersonate as netid 
//cmd: checkIPSN&netid=xx&delegate=xx
static int checkIPSN(request_rec *r, char *requester, permit_request_t *req, char **args_out)
{
    char *delegate = req->delegate;
    char *delegator = req->netid;
    int rc = OK;
    char *ipsnGroup = NULL, *ipsnGroupDN=NULL;
    int inGroup = 0;
    char *returnStr = permit_return_buf;
    int dataLen = 0;
    int result;

    if (!delegate || !delegator || !strlen(delegate) || !strlen(delegator) ) return CUWA_ERR_PERMIT_CMD;

    permit_return_buf[0] = 0;

    ipsnGroup = cuwa_get_impersonate_group_name( r->pool, requester, delegate );
    FAIL_IF( !ipsnGroup, CUWA_ERR_MEM);

    rc = bridge_is_user_in_group( r->pool, normalize_id( r, delegate), "CIT-IDM-IPSN", &inGroup );
    FAIL_IF( rc, rc );

    if ( inGroup == 0 )
    {
        cuwa_info("%s is not in CIT-IDM-IPSN group",delegate);
        result = MEMBER_NOT_IN_GROUP ;
    }
    else 
    {
        ipsnGroupDN = apr_psprintf(r->pool,"CN=%s,%s",ipsnGroup,g_IPSN_ou);
        FAIL_IF( !ipsnGroupDN, CUWA_ERR_MEM);
 
        rc = bridge_is_user_in_group( r->pool, normalize_id( r, delegator), ipsnGroupDN, &inGroup );
        FAIL_IF( rc, rc );

        if ( inGroup )   result = MEMBER_IN_GROUP ;
        else result = MEMBER_NOT_IN_GROUP ;
    }
    rc = addToReturnBuf(&returnStr, &dataLen, delegator, ipsnGroup,result );
    FAIL_IF( rc, rc );
 
    rc = addToReturnBuf( &returnStr, &dataLen, NULL, NULL, 0 );

    *args_out = permit_return_buf;

cleanup:

    return rc;
}

static int getpermit(request_rec *r, permit_request_t *req, char **args_out)
{
    char *permits = req->permits;
    char *lookupid = req->netid;
    int rc = OK;

    if (!lookupid || !permits || !strlen(lookupid) || !strlen(permits) ) return CUWA_ERR_PERMIT_CMD;

    permit_return_buf[0] = 0;

    rc = bridge_check_membership( r->pool, lookupid, normalize_id(r, lookupid),  permits, permit_return_buf );
    FAIL_IF( rc, rc ); 

    cuwa_trace("permit_return_buf:%s", permit_return_buf);
    *args_out = permit_return_buf;

cleanup:

    return rc;
}


static int listpermits(request_rec *r, permit_request_t *req, char **args_out, int excludeAdminGroup)
{
    char *lookupid = req->netid;
    int rc;

    if (!lookupid) return CUWA_ERR_PERMIT_CMD;

    permit_return_buf[0] = 0;

    rc = bridge_list_groups( r->pool, lookupid, normalize_id( r, lookupid), permit_return_buf, excludeAdminGroup );
    FAIL_IF( rc, rc );

    *args_out = permit_return_buf;

cleanup:

    return rc;
}

static int listnetids(request_rec *r, permit_request_t *req, char **args_out, int limit)
{
    char *permits = req->permits;
    char *permit;
    int rc = 0;

    if (!permits) return CUWA_ERR_PERMIT_CMD;

    permit_return_buf[0] = 0;

    permit = nextword(&permits,' ');
    if ( nextword(&permits,' ') )
    {
        cuwa_warning("more than one permit requested in listnetids command");
        return CUWA_ERR_PERMIT_CMD;
    }
    if (permit)
        rc = bridge_list_members( r->pool, permit, permit_return_buf, limit );

    FAIL_IF( rc, rc );
   
    *args_out = permit_return_buf;

cleanup:

    return rc;
}

static int getPassword(apr_pool_t *pool, char *requester, char **passwd)
{
    SHA1Context ctx;
    int rc = CUWA_OK;

    //calculate password                                                 
    SHA1Reset(&ctx);                                                    
                                                                                         
    SHA1Input(&ctx,(unsigned char*)g_password_key,strlen(g_password_key)); 
    SHA1Input(&ctx,(unsigned char*)requester, strlen(requester));

    if (!SHA1Result(&ctx))
    {
        cuwa_warning("sha1 faied to generate the password for %s",requester);
        rc = CUWA_ERR;
    }                      
    FAIL_IF( rc, rc );

   //get hash result
   *passwd = apr_psprintf(pool,"%xM%x%x%x%x#",ctx.Message_Digest[0], 
                                            ctx.Message_Digest[1],
                                            ctx.Message_Digest[2],
                                            ctx.Message_Digest[3],
                                            ctx.Message_Digest[4]);
cleanup:

    return rc;
}

static int getCred( request_rec *r, char *requester, char **credOut )
{
    char *samA = NULL;
    int rc = CUWA_OK;
    char *password = NULL;

    rc = getPassword( r->pool, requester, &password);
    FAIL_IF( rc, rc );

   //get the samaccountname of requester
   rc = bridge_get_user_samaccountname( r->pool, normalize_id(r, requester), &samA);
   FAIL_IF(rc, rc);

   *credOut = apr_psprintf(r->pool,"%s:%s",samA,password);

cleanup:

   return rc;

} 
      

static int resetpassword( request_rec *r, char *requester )
{
    char *passwd = NULL;
    char *requesterDN = NULL;
    int rc = CUWA_OK;

    cuwa_trace("reset password for %s", requester);
    rc = getPassword( r->pool, requester, &passwd );
    FAIL_IF( rc, rc );

    rc = bridge_get_DN(r->pool, normalize_id(r,requester), &requesterDN, 0);

    FAIL_IF( rc, rc );

   rc = cuwa_bridge_qars_force_passwd( r->pool, g_ars_url, g_ars_reset_cred, passwd, requesterDN);

cleanup:
   if (requesterDN ) free( requesterDN );

   cuwa_trace("resetpassword return %d", rc);

   return rc;
} 

static int addMember( request_rec *r, char *requester, char *netid, char *groups, char *outBuf)
{
    int rc = CUWA_OK;
    char *returnStr = outBuf;
    int dataLen = 0;
    char *group = NULL;
    char *netidDN = NULL;
    char *groupDN = NULL;
    char *requesterCred = NULL;
 
    cuwa_trace("addpermit:get DN of netid %s",netid);
    rc = bridge_get_DN( r->pool, normalize_id(r,netid), &netidDN, 0);
    FAIL_IF( rc, rc);

    rc = getCred( r, requester, &requesterCred);
    FAIL_IF( rc, rc);

    while (NULL != (group=nextword(&groups,' ')))                                                   
    {
        rc = bridge_group_white_list_scan( group );
        if (!rc)
        { 
            cuwa_trace("getDN of group:%s", group);
            rc = bridge_get_DN( r->pool, group, &groupDN, 1 );
            if (!rc)
            {
                cuwa_trace("call ars to add member,netidDN=%s, groupDN=%s",netidDN,groupDN);
                rc = cuwa_bridge_qars_add_member( r->pool, g_aspx_url, requesterCred, groupDN, netidDN );   
                cuwa_trace("call ars add return rc=%d", rc);
                if ( rc== CUWA_ERR_ARS_LOGIN )   
                {
                    cuwa_trace("ars add member failed:rc=%d", rc);
                    rc = resetpassword( r, requester); 
                    if (!rc) 
                    {
                        cuwa_trace("call ars again to add member,netidDN=%s, groupDN=%s",netidDN,groupDN);
                        rc = cuwa_bridge_qars_add_member( r->pool, g_aspx_url, requesterCred, groupDN, netidDN ); 
                        cuwa_trace("ars add return %d",rc);
                    }
                }
           }
           if ( groupDN ) 
           {
                free( groupDN );
                groupDN = NULL;
           }
       }    
       rc = addToReturnBuf( &returnStr, &dataLen, netid, group, rc );
       FAIL_IF(rc, rc);
   }
   rc = addToReturnBuf( &returnStr, &dataLen, NULL, NULL, 0 );
   
cleanup:
   if (netidDN) free(netidDN);

    return rc;
}


static int deleteMember( request_rec *r, char *requester, char *netid, char *groups, char *outBuf)
{
    int rc = CUWA_OK;
    char *returnStr = outBuf;
    int dataLen = 0;
    char *netidDN = NULL;
    char *groupDN = NULL;
    char *requesterCred=NULL;
    char *group = NULL;

    cuwa_trace("delete member:get DN of netid %s",netid);
    rc = bridge_get_DN( r->pool, normalize_id(r,netid), &netidDN, 0);
    FAIL_IF( rc, rc);

    rc = getCred( r, requester,&requesterCred );
    FAIL_IF( rc, rc);

    while (NULL != (group=nextword(&groups,' ')))
    {
        rc = bridge_group_white_list_scan( group );
        if (!rc)
        {
            rc = bridge_get_DN( r->pool, group, &groupDN, 1 );
            if (!rc)
            {
                cuwa_trace("call ars to delete member,netidDN=%s, groupDN=%s",netidDN, groupDN);
                rc = cuwa_bridge_qars_del_member( r->pool, g_aspx_url, requesterCred, groupDN, netidDN );
                if ( rc == CUWA_ERR_ARS_LOGIN )          
                {                                                                        
                    cuwa_trace("reset password for %s", requester);
                    rc = resetpassword( r, requester );                                     
                    if (!rc)   rc = cuwa_bridge_qars_del_member( r->pool,g_aspx_url, requesterCred, groupDN, netidDN );
                 }
            }                                                                            
            if ( groupDN )                                                               
            {                                                                            
                free( groupDN );                                                         
                groupDN = NULL;                                                          
            }                                                                            
       }                                                                                 
       //if delete successfully, return status 3 means that netid doesn't have such permit anymore
       rc = addToReturnBuf( &returnStr, &dataLen, netid, group, rc?rc:3 );                   
       FAIL_IF(rc, rc);                                                                  
   }                                                                                     
   rc = addToReturnBuf( &returnStr, &dataLen, NULL, NULL, 0 );                           
                                                                                         
cleanup:                                                                                 
   if (netidDN) free(netidDN);
                                                                                         
    return rc;                                                                           
}                   

#define WEB_LOGIN_GET_K2_GROUP "cit.weblogin.getk2"
#define WEB_LOGIN_GET_K2_ADM_GROUP  "cit.weblogin.getk2_adm"
#define WEB_LOGIN_GET_K2_ADM_GROUP_HACK  "cit.weblogin.getk2 adm"

static int createPermit(request_rec *r, char *requester, char *permits, char *permit_return_buf)
{
    int rc = CUWA_OK;
    char *permit = NULL;
    char *parent = NULL;
    int inGroup = 0;
    char *permitCN = NULL;
    char *tmp = NULL;
    int dataLen = 0;
    char *returnStr = permit_return_buf;
    char  *requesterDN= NULL;

    rc = bridge_group_white_list_scan( permits );
    FAIL_IF( rc, rc );

   if ( !strncmp( permits, WEB_LOGIN_GET_K2_GROUP, strlen(WEB_LOGIN_GET_K2_GROUP) ) )
   {
       rc = bridge_is_user_in_group( r->pool, normalize_id( r, requester), WEB_LOGIN_GET_K2_ADM_GROUP, &inGroup );
       if ( rc )
       {
           rc = bridge_is_user_in_group( r->pool, normalize_id( r, requester), WEB_LOGIN_GET_K2_ADM_GROUP_HACK, &inGroup );
       }
   }
   else
   {
       cuwa_trace("make a copy of group %s", permits);
       parent = apr_pstrdup( r->pool, permits );
       FAIL_IF( !parent, CUWA_ERR_MEM);

       //check whether client is in parent_adm 
       tmp = strrchr( parent,'.' );
       if (!tmp)
       {
            cuwa_warning("No parent permit:%s", permits);
            return CUWA_ERR_UPDATE_DENY;
       }
       *tmp = '\0';

       permit = apr_psprintf( r->pool, "%s_adm", parent);
       FAIL_IF( !permit, CUWA_ERR_MEM);
   
       cuwa_trace("check if %s is in %s", requester, permit);
       rc = bridge_is_user_in_group( r->pool, normalize_id( r, requester), permit, &inGroup ); 
   } 

   FAIL_IF( rc, rc );

   if ( inGroup == 0 )
   {
        cuwa_warning("%s is not in group %s", requester, permit);
        return CUWA_ERR_UPDATE_DENY;
   }

    //construct permit cn
   if ( strlen(permits) < PERMIT_NAME_MAX )
       permitCN = permits;
   else
   {
       SHA1Context ctx;

       permit = apr_pstrdup(r->pool, permits);
       permit[15] = 0;       

       SHA1Reset(&ctx);
       SHA1Input(&ctx,(unsigned char*)permits,strlen(permits));

       if (!SHA1Result(&ctx))
       {
            cuwa_warning("sha1 faied to generate the cn");
            rc = CUWA_ERR;
       }
       FAIL_IF( rc, rc );

       permitCN = apr_psprintf(r->pool, "%s_SHA1%x%x",permit,ctx.Message_Digest[0], ctx.Message_Digest[1]);
       cuwa_trace("permitSamAccount= %s, permitCN=%s", permits, permitCN);
   }

   cuwa_trace("call ars create group,samAccountName=%s, cn=%s", permits, permitCN);
  
   rc = bridge_get_DN( r->pool, normalize_id(r,requester), &requesterDN, 0);
   FAIL_IF( rc, rc);

   rc = cuwa_bridge_qars_create_group( r->pool,g_ars_url, g_ars_create_cred, permits, permitCN, g_ad_group_ou, g_ad_admin_ou,requesterDN );
   if (rc) 
   {
       cuwa_warning("create group %s failed", permits);
       rc = CUWA_ERR_CREATE;
   }
cleanup:

   if ( requesterDN ) free(requesterDN);
   if (!rc ) rc = addToReturnBuf( &returnStr, &dataLen, NULL, NULL, 0 );

   return rc;
}

static int updatepermits(request_rec *r, char *requester, permit_request_t *req, char **args_out) 
{
    int rc = CUWA_OK;
    char *permits = req->permits;
    char *lookupid = req->netid;
    const char *cmd = req->cmd;  
    int inGroup = 0;

    if (!requester || !lookupid || !permits || !strlen(lookupid) || !strlen(permits) || !strlen(requester) ) return CUWA_ERR_PERMIT_CMD;

    //check if requester is in permit_update group
    rc = bridge_is_user_in_group( r->pool, normalize_id(r, requester), "permit-update", &inGroup );
    FAIL_IF(rc, rc); 

    if ( !inGroup ) 
    {                                                                                                               
     cuwa_warning("%s is not allowed to update permit",requester);                                                                        
     return CUWA_ERR_UPDATE_DENY;
    }                                                                                                         
    permit_return_buf[0] = 0;

   if (!strcmp(cmd,"addpermit") )
   { 
       if (!strcmp( lookupid, "all") )
           rc = createPermit(r, requester, permits, permit_return_buf);
       else
           rc = addMember(r, requester, lookupid, permits, permit_return_buf);
  }
  else  
       rc = deleteMember(r,requester,lookupid,permits,permit_return_buf);

  FAIL_IF( rc, rc );

  *args_out = permit_return_buf;

cleanup:

   return rc;

}

int addToReturnBuf( char **returnStr, int *dataInBuf, char *netid, char *permit,int rv )
{
    char *temp;
    char *p;
    int dataNow = 0;
    int rc = OK;
    int len = 0;

    if ( !netid )
        temp = cuwa_sprintf( "%s","\r\n");
    else
        temp = cuwa_sprintf( "permit:%s,%s,%d ", netid, permit, rv);

    p = *returnStr;

    len = strlen( temp );

    dataNow = *dataInBuf + len;
    //cuwa_trace("addToReturnBuf:dataNow=%d,afterAdd:%d", *dataInBuf, dataNow);
    FAIL_IF( dataNow > PERMIT_RETURN_BUF_LEN, CUWA_ERR_MEM );

    //cuwa_trace("addToReturnBuf:%s", temp);
    strcpy( p, temp );
    p += len;

    *returnStr = p;
    *dataInBuf = dataNow;

cleanup:

    free(temp);

    return rc;
}

static char *normalize_id ( request_rec *r, char *netid)
{
    char *at = NULL;
    char *newid = NULL;
    CUWACfg_t *cfg = cuwa_wal_get_config((void *)r);
    char *realm = CFG_CUWARealm(cfg);
    char *copyOfNetid = NULL;

    copyOfNetid = apr_pstrdup( r->pool, netid);
    cuwa_assert(copyOfNetid);

    at = strchr(copyOfNetid,'@');
    if ( at )
    {
        cuwa_trace("compare %s with %s", at, realm);
        if ( !strcasecmp(at, realm) )
            *at = 0;
        else
            newid = netid;
    }

    if ( !newid ) 
        newid = apr_psprintf( r->pool, "%s@%s", copyOfNetid,CFG_LdapURL(cfg));

    return newid;
}

char *nextword( char **str, char sep)
{
    char *cur, *next;
    char *startStr = *str;

    if ( *str == NULL ) return NULL;

    while (startStr)
    { 
        if ( *startStr == sep )
            startStr++;
        else
            break;
   }

   if (!startStr || !strlen(startStr)) 
   {
       *str = NULL;
       return NULL;
   }

   cur = startStr;
   
    next = strchr( startStr, sep);
    if (!next) *str = NULL;
    else
    {
        *next++ = 0;
        *str = next;
    }
    return cur;
}


void permit_cmd_init( char *arsURL, char *aspxURL, char *createCred, char *resetCred, char *passwdKey, char *groupOU,char *adminOU, char *IPSNou)
{

 g_ars_url = arsURL;
 g_aspx_url = aspxURL;
 g_ad_group_ou = groupOU;
 g_ad_admin_ou = adminOU;
 g_ars_create_cred = createCred;
 g_ars_reset_cred = resetCred;
 g_password_key = passwdKey;

 g_IPSN_ou = IPSNou;
}

