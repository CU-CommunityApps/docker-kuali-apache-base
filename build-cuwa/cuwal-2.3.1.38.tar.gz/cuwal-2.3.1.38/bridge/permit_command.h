/************************************************************************
 * permit_command.h -- Handle permit commands
 *
 * Copyright 2010 Cornell University.
 * All Rights Reserved.
 *
 ************************************************************************
 *  $Log$
 *  Revision 1.4  2010/05/21 16:36:04  hy93
 *  use aspx for updating permit
 *
 *  Revision 1.3  2010/05/19 20:16:20  hy93
 *  permit update support
 *
 *  Revision 1.2  2010/05/04 15:43:48  hy93
 *  enable permit update commands
 *
 *  Revision 1.1  2010/03/12 14:08:00  hy93
 *  Initial checkin
 *
 *  Revision 1.7  2010/01/22 16:09:07  hy93
 *  fix huge memory consumption when there are many entries in return result
 *
 *  Revision 1.6  2008/10/01 14:35:14  pb10
 *  removed wal dependency.
 *
 *  Revision 1.5  2008/10/01 14:19:50  pb10
 *  Add listpermit support.
 *
 *  Revision 1.4  2008/09/23 09:05:53  pb10
 *  Fixed config.  Added initialization and DB path.
 *
 *  Revision 1.3  2008/09/23 03:12:32  pb10
 *  Fix indenting and lineend.
 *
 *  Revision 1.2  2008/09/22 19:45:56  pb10
 *  Adding support for getpermit function.
 *
 ************************************************************************
 */

#ifndef _PERMIT_COMMAND_H
#define _PERMIT_COMMAND_H

#include <http_request.h>
#include <apr_tables.h>
#include <apr_pools.h>

#define MEMBER_IN_GROUP     0
#define GROUP_NOT_EXIST     2
#define MEMBER_NOT_IN_GROUP 3

typedef struct permit_request
{
    char *cmd;
    char *netid;
    char *permits;
    char *delegate;
} permit_request_t;

int permit_command(request_rec *r, char *requester, char *requesterFullid, permit_request_t *req, char **args_out);
int addToReturnBuf( char **returnStr, int *dataInBuf, char *netid, char *permit,int rc );
char * nextword (char **str, char sep);
void permit_cmd_init( char *arsURL, char *aspxURL,char *createCred, char *resetCred, char *passwdKey,char *groupOU, char *adminOU, char *IPSNou);

 #endif
