#!/bin/sh
#setup directory structure for permit bridge in /app
today=`date +%Y%m%d`
bridgeDir=`pwd`
cp bridge.tgz /app
cd /app
mkdir log/bridge 
mkdir debug/bridge
tar zxvf bridge.tgz
mv idm-apache.service /etc/systemd/system/
cp $bridgeDir/.libs/mod_permit.so /app/bridge/modules/mod_permit.so.$today
cp $bridgeDir/adMonitor.pl /app/bridge/bin/
cd bridge/modules
ln -s mod_permit.so.$today mod_permit.so
cd /app/bridge/conf
ln -s permit.conf.$1 permit.conf
cd /app/bridge/conf/certs
ln -s cacert_comodo.pem `openssl x509 -hash -noout<cacert_comodo.pem`.0  
cd /app/share/openldap/etc/openldap
mv ldap.conf ldap.conf.origin
ln -s /app/bridge/conf/ldap.conf ldap.conf
#setup auto start apache
sudo systemctl daemon-reload 
sudo systemctl enable idm-apache
#setup cron job
sudo mv bridge_gzip_yesterday /etc/cron.d/
sudo mv bridge_ad_monitor.$2 /et/cron.d/
