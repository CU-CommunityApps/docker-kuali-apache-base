#!/bin/sh
echo $NOW
echo `whoami`@`hostname`
uname -a
echo `gcc --version | head -1` `which gcc`
echo `$MAKE --version 2>/dev/null | head -1` `which $MAKE`
echo krb5=$KRBPATH
echo ssl=$OPENSSL
echo apache=$APACHE
$KRBPATH/bin/krb5-config --version
