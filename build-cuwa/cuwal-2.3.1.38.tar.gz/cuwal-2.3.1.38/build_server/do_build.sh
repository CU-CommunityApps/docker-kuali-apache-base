#!/bin/sh
DIR=`dirname $0`
. $DIR/config.sh

CVS_RSH=ssh
export CVS_RSH

cd $CUWA_TOP
ln -s build_server/test.cfg test.cfg
test -f depend.rules && rm depend.rules
test -f build.log && rm build.log
make clean > /dev/null 2>/dev/null
cvs -fq up -APd 2>/dev/null | grep -v 'checkcvs.log$' > checkcvs.log
set | grep '[A-Za-z_]PATH' > $CUWA_TOP/depend.rules
APVER=`echo $APACHE | sed -e 's/^.*\/\([^/]*\)$/\1/'`

echo --- Tree Information --- > build.log
if [ -s checkcvs.log ]; then
mv checkcvs.log checkcvs.log2
echo 'cvs -fq up -APd says: (maybe make clean is broken?)' > checkcvs.log
cat checkcvs.log2 >> checkcvs.log
rm checkcvs.log2
else
echo sandbox matches tree >>build.log
fi
cat checkcvs.log >> build.log
echo >> build.log

echo --- Build Server Information --- >> build.log
$DIR/build_info.sh >> build.log
echo >> build.log

echo --- Apache information --- >> build.log
$APACHE/bin/httpd -V  | sed -e 's/^/APACHE: /' >> build.log
echo >> build.log
echo --- Make output --- >> build.log

echo 
echo Building for $APVER...

make >> build.log 2>&1
make clean > /dev/null 2>/dev/null

STAR=cuwal2-src-$NOW
OUT=$RELEASEDIR/$NOW
mkdir -p $OUT
if [ ! -f "$OUT/$STAR.tgz" ]; then
	cd ..
	echo Creating $STAR
	tar cf $OUT/$STAR.tar cuwal2
	gzip $OUT/$STAR.tar
	mv $OUT/$STAR.tar.gz $OUT/$STAR.tgz
	cd $CUWA_TOP
fi


BUILT=cuwal2-$APVER-`uname`-`uname -r | cut -d \- -f 1`-`hostname | cut -d \. -f 1`-$NOW
mkdir $OUT/$BUILT
mv checkcvs.log $OUT/warnings-$BUILT.txt
cat build.log | egrep -v '^APACHE:' | grep ':' | grep -v 'Entering directory' | grep -v 'Leaving directory' | grep -v '^In file included from' | grep -v '^Libraries have been installed in' | grep -v '^flag during linking' >> $OUT/warnings-$BUILT.txt

if [ -s $OUT/warnings-$BUILT.txt ]; then
echo --- Warnings building against $APVER --- >> $OUT/warnings.txt
cat $OUT/warnings-$BUILT.txt >> $OUT/warnings.txt
echo >> $OUT/warnings.txt
fi

echo --- Packaging $BUILT ---
cp build.log $OUT/$BUILT-log.txt
cp build.log $OUT/$BUILT/
mkdir $OUT/$BUILT/modules
cp $APACHE/modules/mod_cuwebauth.so $OUT/$BUILT/modules/
for i in `ldd $APACHE/modules/mod_cuwebauth.so  | sed -e 's/^.*\(lib.*\) =>.*$/\1/g' | grep -v '/'`; do
	find $KRBPATH -name "$i" -exec cp {} $OUT/$BUILT/modules/ \;
done


echo Creating $BUILT.tgz
tar cf $OUT/$BUILT.tar -C $OUT $BUILT 
gzip $OUT/$BUILT.tar
rm -rf $OUT/$BUILT
mv $OUT/$BUILT.tar.gz $OUT/$BUILT.tgz
