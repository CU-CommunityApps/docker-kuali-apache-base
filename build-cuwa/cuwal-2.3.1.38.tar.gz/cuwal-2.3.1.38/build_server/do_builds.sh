#!/bin/sh
DIR=`dirname $0`
. $DIR/config.sh

export NOW
mkdir -p $RELEASEDIR/$NOW

for ap in `ls $BIN_ROOT | grep apache`; do
	APACHE=$BIN_ROOT/$ap
	export APACHE
	echo Starting build for $ap >>$RELEASEDIR/$NOW/do_builds.txt
	time $DIR/do_build.sh 2>>$RELEASEDIR/$NOW/do_builds.txt
done
#rm $RELEASEDIR/current
cd $RELEASEDIR
#ln -s $NOW current
