apt-get install sudo
apt-get install build-essential
apt-get install libssl-dev libkrb5-dev openssh-server cvs apache2-prefork-dev


