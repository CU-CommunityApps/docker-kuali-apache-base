#!/bin/sh

# last tested on OpenSUSE 11 x64
sudo zypper install apache2 apache2-prefork apache2-devel apache2-mod_perl perl-Crypt-SSLeay libopenssl-devel krb5-devel gcc make cvs
