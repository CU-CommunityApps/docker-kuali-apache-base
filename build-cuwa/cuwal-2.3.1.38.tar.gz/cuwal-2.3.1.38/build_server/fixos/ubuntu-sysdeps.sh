#this is based on Ubuntu 8.04.1 (LTS) configured with LAMP Server selected during install
sudo apt-get install openssh-server build-essential apache2-prefork-dev libapache2-mod-perl2 libcrypt-ssleay-perl libssl-dev cvs openntpd ca-certificates rdate

#debugging stuff
sudo apt-get install  gdb libapr1-dbg  libaprutil1-dbg libpcre3-dbg ccache
sudo a2enmod ssl
