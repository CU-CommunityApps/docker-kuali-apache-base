gcc  -Wall -g -fpic -c $1
