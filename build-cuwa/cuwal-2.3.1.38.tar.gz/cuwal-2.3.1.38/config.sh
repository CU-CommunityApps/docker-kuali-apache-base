#./bin/sh

if [ "gbr4" = `whoami` ] 
then
	export TEST_KEYTAB=~/web-agent-gbr4-test
	export TEST_SERVICE="web-agent/gbr4-test"
fi
if [ "pb10" = `whoami` ] 
then
	export TEST_KEYTAB=~/bosanko.keytab
	export TEST_SERVICE="web-agent/bosanko"
fi
export WEBLOGIN_TARGET=http://localhost:8004
export TEST_UID="ns10-demo"
export TEST_PW='$tester'

