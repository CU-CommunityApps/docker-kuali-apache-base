/**
 * CUWAL2 Configuration Subsystem.
 * Copyright (c) 2007 Cornell University
 */
#ifndef __CUWA2_CONFIG_H
#define __CUWA2_CONFIG_H
#include "../util/util.h"

#define CUWA2_CONFIG_CACHE 1024


/**
 * A single name/value pair and a linked list of refinements. An attribute contains a 
 * linked list of name/value pairs. Values may be null in which case the attribute is 
 * ignored (and exists as a node to allow access to its children). 
 * For example, log.CUWA.CredMgr=5 would have log in the top-level attribute list, 
 * CUWA in the child list of log, and CredMgr in the child list of CUWA. 
 * 
 * @see cuwa_config_import|cuwa_config_read
 */
typedef struct cuwa_attrib_t
{
	char *name; /**< Attribute name.
			* @invariant name is non-null
			* @invariant name does not contain '.'
			* @invariant strlen(n) > 0
			*/
	char *value; /**< Attribute value. Current value of the attribute or NULL.*/
	struct cuwa_config_t *block;	 /**< Child configuration iff this attribute is a block.*/
	cuwa_list *kids;	/**< Attribute children. 
				  This is a linked list of cuwa_attrib_t elements or NULL. 
				  Each element is a direct child of the current attribute.
				  If the current attribute is CUWA then the child Log would
				  be accessed as CUWA.Log
				  
				  @invariant ch is either null or has at least one element*/
} cuwa_attrib;


/**
 * Base configuration "context". A cuwa_config_t pointer serves as 
 * a configuration context handle.
 * 
 * @see cuwa_config_import|cuwa_config_read
 */
typedef struct cuwa_config_t
{
	cuwa_list *attribs;	  /**< A linked list cuwa_attrib_t at the current level */
	struct cuwa_config_t *parent;	  /**< A pointer to a parent configuration from which settings are inherited. */
	char *type;		 /**< The block type, one of NULL for the global scope, Directory Location etc for sub-blocks. */
	char *cache_names[CUWA2_CONFIG_CACHE];
	cuwa_attrib *cache_attribs[CUWA2_CONFIG_CACHE];
} cuwa_config;


cuwa_config *cuwa_config_import (cuwa_config * basecfg, char *filename,
								 cuwa_config * meta);

cuwa_attrib *cuwa_config_read (cuwa_config * cfg, const char *attrib);
cuwa_attrib *cuwa_config_read2 (cuwa_config * cfg, const char *attrib, int nullok);

char *cuwa_config_str (cuwa_attrib * a);
cuwa_config *cuwa_config_get_active ();
cuwa_config *cuwa_config_release (cuwa_config * c);
void cuwa_config_set_active (cuwa_config * c);
int cuwa_config_int (cuwa_attrib * a);
cuwa_attrib *cuwa_config_read_literal (cuwa_config * cfg, const char *attrib,
									   int allowslow);
void cuwa_config_walk(cuwa_config *c,char * name, int name_size, void * accum, void (*f)(char*,cuwa_attrib*,void*));
#endif
