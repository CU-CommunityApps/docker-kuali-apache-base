#include "../log/log.h"
#include "config.h"
#ifdef _MSVC_VER
#include <conio.h>
#endif
#include <stdio.h>
#include <string.h>

#define CUWA2_LOG_DOMAIN cuwa.config.test

static void printaconfig(cuwa_config *c,int indent);
static void printalist(cuwa_list *l, int indent){
	char buf[1024];
	cuwa_node *n=l->head;
	cuwa_attrib *a;
	int i;
	buf[0]='\0';
	while(n){
		a=n->data;
		for(i=1; i<indent; i++){
			printf("\t");
		}
		if(indent>1) printf(".");
		if(a->block){
			printf("<%s>\n",a->name);
			printaconfig(a->block,indent+1);
			for(i=1; i<indent; i++){
				printf("\t");
			}
			if(indent>1) printf(".");
			printf("</%s>\n",a->name);
		}
		else printf("%s %s\n",a->name,a->value);
		if(a->kids) printalist(a->kids,indent+1);
		n=n->next;
	}
}
static void printaconfig(cuwa_config *c,int indent){
	printalist(c->attribs,indent+1);
}

int main(int argc, char ** argv){
	cuwa_config *c;
	cuwa_config *m;
	cuwa_attrib *a;
	char buf[1024];
	c=cuwa_config_import(NULL,NULL,NULL);
	strncpy(buf,"CUWA 20",1024);
	cuwa_config_setattr(c,buf," ",".",0,0);
	cuwa_config_set_active(c);	
	m=cuwa_config_import(0,"meta.cfg",NULL);
	strncpy(buf,"CUWA 10",1024);
	cuwa_config_setattr(c,buf," ",".",0,0);
	
	c=cuwa_config_import(c,"test1.cfg",m);

	printaconfig(c,0);
	

	while(gets(buf)){
		if(!strcmp(buf,"..")){
			c=c->parent;
			continue;
		}
		a=cuwa_config_read(c,buf);
		if(a){
			cuwa_info("Found %s=%s",a->name,a->value);
			if(a->block){
				cuwa_info("and it is a block of type %s, entering context %s",a->block->type, buf);
				c=a->block;
			}
		}else{
			cuwa_info("Did not find %s", buf);
		}

	}
}
const char id_config_test_c[] = "$Id$";
