#include <stdlib.h>
#include <stdio.h>
#include "cfg.h"


int main()
{
    printf("cfg.h compiled!\n");
    return 0;
}
const char id_config2_testcfg_c[] = "$Id$";
