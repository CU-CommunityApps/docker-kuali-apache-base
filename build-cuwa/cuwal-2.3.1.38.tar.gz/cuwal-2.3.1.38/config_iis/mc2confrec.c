/***********************************
 * $Id$
 * Code to generate parts of the apache wal
 * and the config structures
 *
 * This code is a total mess and is generally insecure and not very robust
 * the code it generates is simple, and secure
 * DO NOT copy code from this file, it is of sufficient quality to be run during the
 * compilation process with a trustworthy metaconf as input
 * IT IS NOT INTENDED TO BE RUN ON A PRODUCTION SERVER AS PART OF ANY PRODUCT
 *
 * This produces a binary with a main that takes a metaconf as its only paramater
 * it produces several files on standard output multiplexed based on a single pass through the parsed metaconf
 * There is a prefix of <num>@ on each line
 *
 * Intended use is:
 *
 * ./mc2config ../meta.cfg | egrep [1-9]@ > stage1.out
 * cat stage1.out | egrep n@ | cut -d @ -f 2 > somefile.[ch]
 *
 * current mappings:
 *
 * 1@= macro accessors
 * 3@= struct
 * 0@= header
 * 2@= cmd table
 * 4@= set functions
 */

#ifdef _MSVC_VER
    #include <conio.h>
#endif

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include "../log/log.h"
#include "../config/config.h"
#include "../util/list.h"

#define CUWA2_LOG_DOMAIN cuwa.config.mc2apache

typedef struct mc_accum
{
    cuwa_config *meta;
    int prev_depth;
    cuwa_list *stack;
} mc_accum_t;


static void replace_char(char *str, char from, char to)
{
    int i,len=strlen(str);
    for (i=0;i<len;i++,str++)
    {
        if (*str==from) *str = to;
    }
}

//pass the metaconf as the accumulator
static void print_mc_cmd(char *basename,  cuwa_attrib *a, void * ref)
{
    //this code is total garbage
    //the struct output is built only when the full name (basename+a->name) doesn't contain a $
    //the other output is built when a->name contains a datatype
    mc_accum_t * accum = (mc_accum_t *) ref;
    char *usagen; //tmp
    cuwa_attrib *usage; //will contain usage text for this directive
    char *symbol_name;
    int i;
    char *padding; // "\t" for each indentation level
    int depth=0;
    char *fullname; //fullname of the current directive



    cuwa_trace("%s,%s",basename,(a?a->name:"(null)"));
    cuwa_trace("bn: %s, an: %s",basename,(a?(a->name):"0x0"));
    padding=strdup("");


    if (basename && basename[0])
    {
        if (a && a->name && a->name[0]) fullname=cuwa_sprintf("%s.%s",basename,a->name);
        else fullname=basename;
    }
    else
    {
        if (a && a->name) fullname=a->name;
        else fullname="";
    }


    //-----------------------------
    //fill in the usage text
    usagen=cuwa_sprintf("%s.%s",basename,"$usage");
    cuwa_trace("checking for usage: %s", usagen);
    usage=cuwa_config_read(accum->meta,usagen);
    free(usagen);
    if (usage && usage->name && strcmp(usage->name,"$usage"))
    { //don't accept approximationsxx {
        usagen=strdup(cuwa_config_str(usage));
        cuwa_trace("found usage: %s", usage);
    }
    else
    {
        usagen=cuwa_sprintf("Error processing directive %s.",basename);
        cuwa_trace("default usage message: %s", usagen);
    }

    //-----------------------------
    //bass ackwards, first generate a symbol_name from the full name (base+name)
    //build a name for this, substituting .'s for _ for use in a #define
    cuwa_assert(a && a->name); //fixme not clearly right but ... code generator
    if (basename && basename[0]) symbol_name=cuwa_sprintf("CFG_%s.%s",basename,a->name);
    else symbol_name=cuwa_sprintf("CFG_%s",a->name);
    for (i=0; i<strlen(symbol_name); i++)
    {
        if (symbol_name[i]=='.')
        {
            char *tmp;
            symbol_name[i]='_';
            tmp=cuwa_sprintf("%s\t",padding); //add a \t to padding
            free(padding);
            padding=tmp;
            depth++;
        }

    }
    cuwa_warning("symbol_name: %s",symbol_name);


    printf("6@%s,%s:%d/%d(%s)\n",basename,(a?(a->name):"0x0"),accum->prev_depth,depth,symbol_name);


    //-----------------------------
    //build name

    //do this stuff only for nodes that don't include a $
    if (!strchr(symbol_name,'$'))
    {
        int j;
        char *typen;
        cuwa_attrib *typea;
        printf("5@%s,%s:%d/%d\n",basename,(a?(a->name):"0x0"),accum->prev_depth,depth);

        //"creative" logic
        //if the depth hasn't increased from the lastdepth we need to close structs
        //close  1+ the decrease in depth structs
        for (j=accum->prev_depth; j >= depth; j--)
        {
            printf("3@");
            for (i=0; i<j; i++) printf("\t"); //indent
            //printf("};//\t\t%s.%s %d,%d\n",basename,a->name,depth,accum->prev_depth);
            if (accum->stack && accum->stack->tail)
            {
                printf("} %s;\n3@\n",(char*)(accum->stack->tail->data));
                cuwa_list_del(accum->stack, accum->stack->tail);
            }
            else
            {
                printf("\n");
            }
        }


        printf("3@%sstruct \n3@\%s{ //%s\n",padding,padding,a->name);
        accum->prev_depth=depth;
        cuwa_list_append(&(accum->stack),a->name);


        cuwa_trace("checking for (%s).$int",fullname);
        typen=cuwa_sprintf("%s.$int",fullname);
        typea=cuwa_config_read2(accum->meta,typen,1);
        if (typea && !strcmp(typea->name,"$int"))
        {
            cuwa_trace("%s is an integer, emitting .i and .iv lines",fullname);
            printf("3@%s\tint iv; //%s\n",padding, fullname);
            printf("3@%s\tint *v; //%s\n",padding, fullname);

        }
        free(typen); typen=NULL;

        cuwa_trace("checking for (%s).$enum",fullname);
        typen=cuwa_sprintf("%s.$enum",fullname);
        typea=cuwa_config_read2(accum->meta,typen,1);
        if (typea && !strcmp(typea->name,"$enum"))
        {
            cuwa_trace("%s is an enum, emitting .i and .iv lines",fullname);
            printf("3@%s\tint iv; //%s\n",padding, fullname);
            printf("3@%s\tint *v; //%s\n",padding, fullname);

        }
        free(typen); typen=NULL;

        cuwa_trace("checking for (%s).$string",fullname);
        typen=cuwa_sprintf("%s.$string",fullname);
        typea=cuwa_config_read2(accum->meta,typen,1);
        if (typea && !strcmp(typea->name,"$string"))
        {
            cuwa_trace("%s is a string, emitting .s line",fullname);
            printf("3@%s\tchar *s; //%s\n",padding, fullname);

        }
        free(typen);
        typen=NULL;

        cuwa_trace("checking for (%s).$error",fullname);
        typen=cuwa_sprintf("%s.$error",fullname);
        typea=cuwa_config_read2(accum->meta,typen,1);
        if (typea && !strcmp(typea->name,"$error"))
        {
            cuwa_trace("%s is an error, emitting .err line",fullname);
            printf("3@%s\tchar *error; //%s\n",padding, fullname);

        }
        free(typen);
        typen=NULL;
    }


    //does this node have a $int or $enum member? if so, need to add .iv struct members

    //-----------------------------
    //ok, now we don't want the $crap in the symbol name
    //truncate symbol_name
    {
        char *tmp;
        tmp=strchr(symbol_name,'$');
        if (tmp) *(tmp-1)='\0';
    }

    if (!strcmp("$int",a->name))
    { // this is an integer		
        /*cuwa_attrib *a;
        char *name;
        char *v;
        name=cuwa_sprintf("%s.$int.$min",basename);
        a=cuw
        */
        printf("2@IIS_INIT_TAKE1(\"%s\",cmd_set_%s,OR_ALL,CUWA_IIS_CMD,\"%s\"),\n",basename,symbol_name,usagen);
        printf("1@#define %s(x) (((x)!=NULL)?((x)->%s.v):NULL) \n",symbol_name,basename);
        printf("3a@%s\tint iv;\n",padding); //junk
        printf("3a@%s\tint *v;\n",padding);
        printf("4@static const char *cmd_set_%s(cuwa_iis_cmd_parms *cmd, CUWACfg_t *cfg, const char *arg){\n",symbol_name);
        printf("4@\tlong val=atoi(arg);\n");
        printf("4@\tcfg->%s.iv=val;\n",basename);
        printf("4@\tcfg->%s.v=&(cfg->%s.iv);\n",basename,basename);
        printf("4@\t//FIXME: add range check code;\n");
        printf("4@\treturn(NULL);\n");
        printf("4@}\n");
        printf("4@\n");
        printf("4@\n");

        printf("7@\tif(!overrides->%s.v)overrides->%s.v = base->%s.v;\n",basename,basename,basename);
    }
    else if (!strcmp("$enum",a->name))
    {
        cuwa_node *n; cuwa_attrib *e; char * ev;
        i=0;
        printf("2@IIS_INIT_TAKE1(\"%s\",cmd_set_%s,OR_ALL,CUWA_IIS_CMD,\"%s\"),\n",basename,symbol_name,usagen);
        printf("1@#define %s(x) (((x)!=NULL)?((x)->%s.v):NULL) \n",symbol_name,basename);
        printf("3a@%s\tint iv;\n",padding); //junk
        printf("3a@%s\tint *v;\n",padding);
        printf("4@static const char *cmd_set_%s(cuwa_iis_cmd_parms *cmd, CUWACfg_t *cfg, const char *arg){\n",symbol_name);

        //iterate through the children of $enum -- i.e. values
        n=(cuwa_node *)(a->kids->head);
        printf("4@\tcfg->%s.v=NULL;\n",basename);
        while (n)
        {
            i++;
            e=n->data;
            ev=e->name;
            printf("1@#define O_%s_%s %d\n",symbol_name,ev,i);
            printf("4@\t%sif(!strcmp(arg,\"%s\")) {cfg->%s.iv=%d; cfg->%s.v=&(cfg->%s.iv);}\n",i>1?"else ":"",ev,basename,i,basename,basename);
            n=n->next;
        }
        printf("4@\t//FIXME: add obsolete value checks;\n");

        printf("4@\tif (!cfg->%s.v) return \"Error: %s parameter is not valid.\";\n",basename,basename);
        printf("4@\treturn(NULL);\n");
        printf("4@}\n");
        printf("4@\n");
        printf("4@\n");

        printf("7@\tif(!overrides->%s.v)overrides->%s.v = base->%s.v;\n",basename,basename,basename);
    }
    else if (!strcmp("$string",a->name))
    {
        int hasvalidator=0;
        printf("2@IIS_INIT_TAKE1(\"%s\",cmd_set_%s,OR_ALL,CUWA_IIS_CMD,\"%s\"),\n",basename,symbol_name,usagen);
        printf("1@#define %s(x) (((x)!=NULL)?((x)->%s.s):NULL)\n",symbol_name,basename);
        printf("3a@%s\tchar *s;\n",padding); //junk
        printf("4@static const char *cmd_set_%s(cuwa_iis_cmd_parms *cmd, CUWACfg_t *cfg, const char *arg){\n",symbol_name);
        printf("4@\tcfg->%s.s=apr_pstrdup( cmd->pool, arg);\n",basename);
        cuwa_node* chn=a->kids?(cuwa_node *)(a->kids->head):NULL;
        while (chn)
        {
            cuwa_attrib *chne=chn->data;
            printf("4@\t//%s, %s, %s\n",chne->name,chne->value,basename);
            if(!strcmp("validator",chne->name)){
                 printf("4@\treturn %s((void *)cmd,NULL,arg,NULL,cfg,cmd->pool,\"%s\");\n",chne->value,basename);
                 hasvalidator=1;
            }
            chn=chn->next;
        }
        if(!hasvalidator){
           printf("4@\treturn(NULL);\n");
        } 
        printf("4@}\n");
        printf("4@\n");
        printf("4@\n");
        
        printf("7@\tif(!overrides->%s.s)overrides->%s.s = base->%s.s;\n",basename,basename,basename);
    }
    else if (!strcmp("$error",a->name))
    {
        printf("2@IIS_INIT_TAKE1(\"%s\",cmd_set_%s,OR_ALL,CUWA_IIS_CMD,\"%s\"),\n",basename,symbol_name,usagen);

        printf("4@static const char *cmd_set_%s(cuwa_iis_cmd_parms *cmd, void *sInfo, const char *arg){\n",symbol_name);
        printf("4@\treturn(\"Error: %s\");\n",a->value);
        printf("4@}\n");
        printf("4@\n");
        printf("4@\n");
    }
    else if (!strcmp("$warning",a->name))
    {
        printf("2@IIS_INIT_TAKE1(\"%s\",cmd_set_%s,OR_ALL,CUWA_IIS_CMD,\"%s\"),\n",basename,symbol_name,usagen);
        printf("1@#define %s(x) (((x)!=NULL)?((x)->%s.s)\n",symbol_name,basename);
        printf("3@%s\tchar *s;\n",padding);
        printf("4@static const char *cmd_set_%s(cuwa_iis_cmd_parms *cmd, CUWACfg_t *cfg, const char *arg){\n",symbol_name);
        printf("4@\tcfg->%s.s=apr_pstrdup( cmd->pool, arg);\n",basename);
        printf("4@\tcuwa_warning( \"Warning: %%s\", \"%s\");\n",a->value);
        printf("4@\treturn(NULL);\n");
        printf("4@}\n");
        printf("4@\n");
        printf("4@\n");

        printf("7@\tif(!overrides->%s.s)overrides->%s.s = base->%s.s;\n",basename,basename,basename);
    }
    else
    {
        cuwa_trace("unknown paramater type %s",a->name);
    }
    free(usagen);
}


int main(int argc, char ** argv)
{
    cuwa_config *c;
    mc_accum_t accum;
    cuwa_assert(argc==2);
    cuwa_assert(argv[1]);
    c=cuwa_config_import(NULL,NULL,NULL);

    accum.meta=cuwa_config_import(0,argv[1],NULL);

    printf("0@//DO NOT EDIT -- GENERATED CODE from $Id$\n");

    printf("1@//definitions to be used in other code to access configuration data\n");
    printf("3@//configuration record structure\n");

    printf("command_rec[] mod_cuwa2_cmds={\n");
    printf("3@typedef struct CUWACfg{\n");

    printf("7@void cuwa_merge_config( CUWACfg_t *base, CUWACfg_t *overrides){\n");
    accum.prev_depth=0;
    accum.stack=malloc(sizeof(cuwa_list));
    cuwa_assert(accum.stack);
    accum.stack->head=NULL;
    accum.stack->tail=NULL;
    cuwa_config_walk(accum.meta,NULL,0,&accum,print_mc_cmd);
    while (accum.stack && accum.stack->tail)
    {
        printf("3@} %s;\n3@\n",(char*)accum.stack->tail->data);
        cuwa_list_del(accum.stack, accum.stack->tail);
    }

    printf("7@}\n");
    printf("7@\n");
    printf("7@\n");
    printf("3@} CUWACfg_t;\n");

    printf("(NULL)};");

    return 0;
}

const char id_config2_mc2confrec_c[] = "$Id$";
