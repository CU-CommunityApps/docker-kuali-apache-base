
/************************************************************************
 * cred_base64.h -- Base64 class credentials.  The WA credential is a
 * a Base64 wrapping around one or more credentials, so it acts as a
 * means of treating multiple credentials as one.
 *
 * Copyright 2007 Cornell University.
 * All Rights Reserved.
 *
 ************************************************************************
 *
 *  Revision 1.4  2008/04/10 16:57:11  gbr4
 *  Line endings only. This set of files had mixed line endings which breaks visual studio (and looks ugly in vim). Each file was converted to the format that resulted in the fewest line changes (i.e. whichever format it was mostly in).
 *
 *  Revision 1.3  2007/11/07 03:49:40  pb10
 *  Simplified the make_wa function. Exposed the raw base64 functions so that we can call from test harness.
 *
 *  Revision 1.2  2007/10/23 21:28:57  pb10
 *  Add support for cred manager.
 *
 *  Revision 1.1  2007/10/22 16:48:14  pb10
 *  Initial commit, to publish API.
 *
 *
 ************************************************************************
 */

#ifndef _CRED_BASE64_H
#define _CRED_BASE64_H

#include <cred.h>

typedef struct cuwa_base64
{
    char *data;         /** Pointer to the binary version (de-base64'd) of the credential */
    int length;         /** Length of the binary data in bytes */
} cuwa_base64_t;


int cuwa_base64_parse( cuwa_cred_t *cred, char *credBytes, int credByteLen );

void cuwa_base64_release(cuwa_cred_t *cred, cuwa_cred_context_t *context);

int cuwa_base64_make_wa(char **retCred, int *retLen, int totLen, int numCreds, ...);

int cuwa_base64_extract_wa( char *wa, int walen, char **creds, int *credsLen, int *credsCnt );

int cuwa_base64_rebuild_wa(char **wa, int *waLen, char *creds, int credsLen, int credsCnt, int newLen, int newCnt, ...);

/* Raw base64 functions... */

int cuwa_base64_decode(char *inBytes, char *outBytes);
int cuwa_base64_decode_bytes( char *inBytes );
int cuwa_base64_encode_bytes( int inLen );
void cuwa_base64_encode( char *in, int inLen, char *encodedBytes);


#endif /* _CRED_BASE64_H */





