/************************************************************************
 * cred_getput.h -- Macroes to move data in and out of a credential buffer.
 *
 * Copyright 2007 Cornell University.
 * All Rights Reserved.
 *
 ************************************************************************
 *  $Log$
 *  Revision 1.13  2008/05/19 19:34:45  pb10
 *  Change creation of K1 (restore SSO cookie) to use malloc instead of cuwa_malloc.
 *  This is because krb_ functions are used to cleanup and those functions will
 *  call free.
 *
 *  Revision 1.12  2008/04/19 14:21:27  pb10
 *  Convert malloc's to APR allocations.
 *
 *  Revision 1.11  2008/04/13 18:29:27  pb10
 *  Hacked the GSS ICT so that we can get real authtime when accepting tokens.
 *
 *  Revision 1.10  2008/04/11 03:51:09  gbr4
 *  More ugly hacks to support Win32. Actually I think CVS's acronym is more descriptive (woe).
 *  It actually fully compiles now. I am sure that it doesn't run yet without even testing it :-)
 *
 *  In the very least permit.c needs its ioctl call changed to something more portable.
 *
 *  Revision 1.9  2008/04/10 23:08:06  gbr4
 *  fixed all *compile* errors under msvc9.0 (studio 2008). Still has link errors
 *  and tons of warnings. This might cause regressions.
 *
 *  Revision 1.8  2008/02/12 17:15:24  hy93
 *  remove \n when call buffer_cuwa_trace
 *
 *  Revision 1.7  2008/01/18 05:09:20  pb10
 *  Better diagnostics or reading and writing creds.
 *
 *  Revision 1.6  2008/01/14 15:56:50  hy93
 *  modified GET_64 to return uint64
 *
 *  Revision 1.5  2007/12/28 16:18:14  pb10
 *  linefeed removal
 *
 *  Revision 1.4  2007/12/21 19:38:37  hy93
 *  Fix bug in PUT_64
 *
 *  Revision 1.3  2007/11/07 03:46:44  pb10
 *  Minor fixes.
 *
 *  Revision 1.2  2007/10/23 21:28:57  pb10
 *  Add support for cred manager.
 *
 *  Revision 1.1  2007/10/22 16:48:14  pb10
 *  Initial commit, to publish API.
 *
 *
 ************************************************************************
 */

#ifndef _CRED_GETPUT_H
#define _CRED_GETPUT_H

#include <cuwa_types.h>
#include <autoconfig.h>

#ifdef HAVE_NETINET_IN_H
#include <netinet/in.h>
#endif

#ifdef WIN32
#define APR_WANT_STRFUNC
#define APR_WANT_MEMFUNC
#define APR_WANT_STDIO
#define APR_WANT_IOVEC
#define APR_WANT_BYTEFYNC
#include <apr_want.h>
#endif

#ifdef CRED_DEBUG_BUFFER
#define buffer_cuwa_trace cuwa_trace
#else
#define buffer_cuwa_trace(x,...) (void)0
#endif

#include <cuwa_malloc.h>

/**
 * PEEK_BYTES is use to verify bytes from a serialized credential.  PEEK_BYTES
 * checks that there are at least cpylen bytes left in the cred. It can be used interchangebly with GET_BYTES wherever
 * the bytes don't need to be NULL terminated.  However, PEEK_BYTES doesn't copy the bytes.
 * @param[out] dst is set to the current pointer in the cred (src).
 * @param[out] cpylen number of bytes to be accessed.
 * @param[in/out] src this is a pointer to the input stream.  The pointer is moved past the bytes that are being copied
 * @param[in/out] slen this is the number of bytes remaining in the stream.  GET_BYTE ensures that it will only succeed if
 *  sufficient bytes are present to fulfill the request.
 *  slen is decremented by number of bytes copied.
 */
#define PEEK_BYTES(dst,cpylen,src,slen)     do     \
{                                                  \
    buffer_cuwa_trace("PEEK_BUFFER: slen=%d cpylen=%d",(slen),(cpylen));\
    FAIL_IF((slen)<(cpylen), CUWA_ERR_BAD_CRED);   \
    FAIL_IF(0>(cpylen), CUWA_ERR_BAD_CRED);        \
    (dst)   = (src);                               \
    (slen) -= (cpylen);                            \
    (src)  += (cpylen);                            \
}  while(0)

/**
 * PEEK_BUFFER macro is use to read a tagged buffer from a serialized credential.  PEEK_BUFFER first reads a 32 bit length, then it verifies
 * that at least length bytes remain in the stream.  If all is successful, dst will point to the buffer and cpylen is set to the size
 * of the buffer.  This function can be used to safely peek at buffer without allocating new space for the buffer or copying buffer contents. Care
 * should be taken not to use resulting pointer out of context.
 * @param[out] dst pointer to memory allocated by this function. Bytes are read into the newly allocated buffer.  This must be freed by the calling function.
 * @param[out] cpylen this is set the the size of the new buffer.
 * @param[in/out] src this is a pointer to the input stream.  The pointer is moved past the bytes that are being copied
 * @param[in/out] slen this is the number of bytes remaining in the stream.  GET_BYTE ensures that it will only succeed if
 *                sufficient bytes are present to fulfill the request.
 *                slen is decremented by number of bytes copied.
 */
#define PEEK_BUFFER(dst,cpylen,src,slen)      do \
{                                                \
    buffer_cuwa_trace("PEEK_BUFFER: slen=%d cpylen=%d",(slen),(cpylen));\
    GET_16((cpylen),(src),(slen));              \
    buffer_cuwa_trace("  PEEK_BUFFER: len=%d",(cpylen));\
    FAIL_IF((0>(cpylen)), CUWA_ERR_BAD_CRED);    \
    ((dst)) = (src);                             \
    PEEK_BYTES((dst),(cpylen),(src),(slen));     \
} while(0)


/**
 * GET_BYTES macro is use to read bytes from a serialized credential.  GET_BYTES
 * copies from the input buffer while verifying that it does not read past the end of stream.
 * @param[out] dst where the bits will end up.
 * @param[out] cpylen number of bytes to copy.
 * @param[in/out] src this is a pointer to the input stream.  The pointer is moved past the bytes that are being copied
 * @param[in/out] slen this is the number of bytes remaining in the stream.  GET_BYTE ensures that it will only succeed if
 *  sufficient bytes are present to fulfill the request.
 *  slen is decremented by number of bytes copied.
 */
#define GET_BYTES(dst,cpylen,src,slen)     do      \
{                                                  \
    buffer_cuwa_trace("GET_BYTES: slen=%d cpylen=%d",(slen),(cpylen));\
    FAIL_IF((slen)<(cpylen), CUWA_ERR_BAD_CRED);   \
    FAIL_IF(0>(cpylen), CUWA_ERR_BAD_CRED);        \
    if ((cpylen))                                  \
        memcpy((dst),(src),(cpylen));              \
    (slen) -= (cpylen);                            \
    (src)  += (cpylen);                            \
}  while(0)

/**
 * GET_64 macro is use to read a 64 bit signed integer from a serialized credential.  GET_64
 * copies from the input buffer while verifying that it does not read past the end of stream.
 * @param[out] num where the bits will end up.
 * @param[in/out] src this is a pointer to the input stream.  The pointer is moved past the bytes that are being copied
 * @param[in/out] slen this is the number of bytes remaining in the stream.  GET_BYTE ensures that it will only succeed if
 *  sufficient bytes are present to fulfill the request.
 *  slen is decremented by number of bytes copied.
 */
#define GET_64(num,src,slen)           do         \
{                                                 \
    uint64 ___GET64_tmp___;                        \
    GET_BYTES(&(___GET64_tmp___),8,(src),(slen)); \
    (num) = (uint64)ntohll((___GET64_tmp___));      \
    buffer_cuwa_trace("GET_64: GET64_tmp=%llx num=%llx",(___GET64_tmp___),(num));\
} while(0)

/**
 * GET_32 macro is use to read a 32 bit signed integer from a serialized credential.  GET_32
 * copies from the input buffer while verifying that it does not read past the end of stream.
 * @param[out] num where the bits will end up.
 * @param[in/out] src this is a pointer to the input stream.  The pointer is moved past the bytes that are being copied
 * @param[in/out] slen this is the number of bytes remaining in the stream.  GET_BYTE ensures that it will only succeed if
 *  sufficient bytes are present to fulfill the request.
 *  slen is decremented by number of bytes copied.
 */
#define GET_32(num,src,slen)           do         \
{                                                 \
    int32 ___GET32_tmp___;                        \
    GET_BYTES(&(___GET32_tmp___),4,(src),(slen)); \
    (num) = (int) ntohl((___GET32_tmp___));       \
    buffer_cuwa_trace("GET_32: GET32_tmp=%d num=%d",(___GET32_tmp___),(num));\
} while(0)

/**
 * GET_16 macro is use to read a 16 bit signed integer from a serialized credential.  GET_16
 * copies from the input buffer while verifying that it does not read past the end of stream.
 * @param[out] num where the bits will end up.
 * @param[in/out] src this is a pointer to the input stream.  The pointer is moved past the bytes that are being copied
 * @param[in/out] slen this is the number of bytes remaining in the stream.  GET_BYTE ensures that it will only succeed if
 *  sufficient bytes are present to fulfill the request.
 *  slen is decremented by number of bytes copied.
 */
#define GET_16(num,src,slen)           do         \
{                                                 \
    int16 ___GET16_tmp___;                        \
    GET_BYTES(&(___GET16_tmp___),2,(src),(slen)); \
    (num) = (int) ntohs((___GET16_tmp___));       \
    buffer_cuwa_trace("GET_16: GET16_tmp=%d num=%d",(___GET16_tmp___),(num));\
} while(0)


/**
 * GET_BUFFER macro is use to read a tagged buffer from a serialized credential.  GET_BUFFER first reads a 32 bit length then allocates
 * a length byte buffer and copies length bytes into the buffer.  It does this while verifying that it does not read past the end of stream.
 * @param[out] dst pointer to memory allocated by this function. Bytes are read into the newly allocated buffer.  This must be freed by the calling function.
 * @param[out] cpylen this is set the the size of the new buffer.
 * @param[in/out] src this is a pointer to the input stream.  The pointer is moved past the bytes that are being copied
 * @param[in/out] slen this is the number of bytes remaining in the stream.  GET_BYTE ensures that it will only succeed if
 *                sufficient bytes are present to fulfill the request.
 *                slen is decremented by number of bytes copied.
 */
#define GET_BUFFER(dst,cpylen,src,slen,malloc_func)      do \
{                                               \
    buffer_cuwa_trace("GET_BUFFER: slen=%d cpylen=%d",(slen),(cpylen));\
    GET_16((cpylen),(src),(slen));              \
    buffer_cuwa_trace("  GET_BUFFER: len=%d",(cpylen));\
    FAIL_IF((0>(cpylen)), CUWA_ERR_BAD_CRED);   \
    ((dst)) = (malloc_func)((cpylen)+1);          \
    FAIL_IF((NULL==(dst)), CUWA_ERR_BAD_CRED);  \
    GET_BYTES((dst),(cpylen),(src),(slen));     \
    ((char *)(dst))[(cpylen)] = 0;              \
} while(0)

/**
 * PUT_BYTES macro is use to copy bytes to a serialized credential.  PUT_BYTES assumes that sufficient space remains
 * in the output stream to copy the bytes.  Caller must ensure that this is so.  By handing PUT_BYTES
 * a NULL output buffer pointer, PUT_BYTES will increment outlen without copying data.  The is used to calculate
 * the size required by the serialized credential for allocation purposes.
 * @param[in] ptr pointer to buffer to copy into the outbuf.
 * @param[in] len number of bytes to copy.
 * @param[in/out] outbuf this is a pointer to the output stream.  The pointer is moved past the bytes that are being copied.  If
 *                this pointer is NULL, no bytes are copied.
 * @param[in/out] outlen this is the number of bytes copied to the stream so far.  outlen is incremented by number of bytes
 *                to be copied during this macro call (even if the bytes weren't actually copied).
 */
#define PUT_BYTES(ptr, len, outbuf, outlen) do \
{                                              \
    buffer_cuwa_trace("PUT_BYTES: len=%d outlen=%d",(len),(outlen));\
    if ((outbuf))                              \
    {                                          \
        memcpy((outbuf),(ptr),(len));          \
        (outbuf)+=(len);                       \
    }                                          \
    (outlen) += (len);                         \
} while(0)

/**
 * PUT_64 macro is use to copy a 64 bit signed integer to a serialized credential.  PUT_64 assumes that sufficient space
 * remains in the output stream to copy the bytes.  Caller must ensure that this is so.  By handing PUT_64
 * a NULL output buffer pointer, PUT_64 will increment outlen without copying data.  The is used to calculate
 * the size required by the serialized credential for allocation purposes.
 * @param[in] num the integer value to be serialized.
 * @param[in/out] outbuf this is a pointer to the output stream.  The pointer is moved past the bytes that are being copied.  If
 *                this pointer is NULL, no bytes are copied.
 * @param[in/out] outlen this is the number of bytes copied to the stream so far.  outlen is incremented by number of bytes
 *                to be copied during this macro call (even if the bytes weren't actually copied).
 */
#define PUT_64(num, outbuf, outlen)     do         \
{                                                  \
    uint64 ___PUT64_tmp___ = htonll(num);             \
    PUT_BYTES(&___PUT64_tmp___,8,outbuf,outlen);   \
    buffer_cuwa_trace("PUT_64: num=%llx PUT_64_tmp=%llx",(num),(___PUT64_tmp___));\
} while(0)


/**
 * PUT_32 macro is use to copy a 32 bit signed integer to a serialized credential.  PUT_32 assumes that sufficient space remains
 * in the output stream to copy the bytes.  Caller must ensure that this is so.  By handing PUT_32
 * a NULL output buffer pointer, PUT_32 will increment outlen without copying data.  The is used to calculate
 * the size required by the serialized credential for allocation purposes.
 * @param[in] num the integer value to be serialized.
 * @param[in/out] outbuf this is a pointer to the output stream.  The pointer is moved past the bytes that are being copied.  If
 *                this pointer is NULL, no bytes are copied.
 * @param[in/out] outlen this is the number of bytes copied to the stream so far.  outlen is incremented by number of bytes
 *                to be copied during this macro call (even if the bytes weren't actually copied).
 */
#define PUT_32(num, outbuf, outlen)     do         \
{                                                  \
    int32 ___PUT32_tmp___ = htonl(num);              \
    PUT_BYTES(&___PUT32_tmp___,4,outbuf,outlen);   \
    buffer_cuwa_trace("PUT_32: num=%d PUT32_tmp=%d",(num),(___PUT32_tmp___));\
} while(0)

/**
 * PUT_16 macro is use to copy a 16 bit signed integer to a serialized credential.  PUT_16 assumes that sufficient space remains
 * in the output stream to copy the bytes.  Caller must ensure that this is so.  By handing PUT_16
 * a NULL output buffer pointer, PUT_16 will increment outlen without copying data.  The is used to calculate
 * the size required by the serialized credential for allocation purposes.
 * @param[in] num the integer value to be serialized.
 * @param[in/out] outbuf this is a pointer to the output stream.  The pointer is moved past the bytes that are being copied.  If
 *                this pointer is NULL, no bytes are copied.
 * @param[in/out] outlen this is the number of bytes copied to the stream so far.  outlen is incremented by number of bytes
 *                to be copied during this macro call (even if the bytes weren't actually copied).
 */
#define PUT_16(num, outbuf, outlen)     do         \
{                                                  \
    int16 ___PUT16_tmp___ = htons(num);              \
    PUT_BYTES(&___PUT16_tmp___,2,outbuf,outlen);   \
    buffer_cuwa_trace("PUT_16: num=%d PUT16_tmp=%d",(num),(___PUT16_tmp___));\
} while(0)


/**
 * PUT_BUFFER macro is write a tagged buffer to a serialized credential.  PUT_BUFFER assumes that sufficient space remains
 * in the output stream to copy the bytes.  Caller must ensure that this is so.  By handing PUT_BUFFER
 * a NULL output buffer pointer, PUT_BUFFER will increment outlen without copying data.  The is used to calculate
 * the size required by the serialized credential for allocation purposes.
 * @param[in] ptr pointer to buffer to copy into the outbuf.
 * @param[in] len number of bytes to copy.  PUT_BUFFER always write the 32 bit integer representation of this number to the stream
 *             first, then the bytes copied from the ptr buffer follow.
 * @param[in/out] outbuf this is a pointer to the output stream.  The pointer is moved past the bytes that are being copied.  If
 *                this pointer is NULL, no bytes are copied.
 * @param[in/out] outlen this is the number of bytes copied to the stream so far.  outlen is incremented by number of bytes
 *                to be copied during this macro call (even if the bytes weren't actually copied).
 */
#define PUT_BUFFER(ptr, len, outbuf, outlen) do \
{                                               \
    buffer_cuwa_trace("PUT_BUFFER: len=%d outlen=%d",(len),(outlen));\
    PUT_16(len, outbuf, outlen);                \
    PUT_BYTES(ptr, len, outbuf, outlen);        \
} while(0)

#endif /* _CRED_GETPUT_H */
