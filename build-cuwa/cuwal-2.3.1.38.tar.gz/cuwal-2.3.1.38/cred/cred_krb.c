/************************************************************************
 * cred_krb.c -- Kerberos credentials for CUWebAuth
 *
 * Copyright 2007 Cornell University.
 * All Rights Reserved.
 *
 ************************************************************************
 *  $Log$
 *  Revision 1.48.2.7  2015/10/01 16:03:49  hy93
 *  remove function not used
 *
 *  Revision 1.48.2.6  2015/03/20 15:33:15  hy93
 *  add verify two factor auth time
 *
 *  Revision 1.48.2.5  2015/03/16 16:40:16  hy93
 *  remove debug level log
 *
 *  Revision 1.48.2.4  2015/03/13 19:44:05  hy93
 *  fix make_auth failed sometimes
 *
 *  Revision 1.48.2.3  2015/03/13 18:17:11  hy93
 *  add 2FA credential token support
 *
 *  Revision 1.48.2.2  2015/01/29 18:32:04  hy93
 *  modify 2F cred handling(not complete)
 *
 *  Revision 1.48.2.1  2014/10/22 19:33:42  hy93
 *  add two factor support
 *
 *  Revision 1.48  2014/10/22 16:09:53  hy93
 *  Remove two factor support
 *
 *  Revision 1.47  2014/07/25 17:35:35  hy93
 *  d1 signature
 *
 *  Revision 1.46  2013/11/12 19:06:01  hy93
 *  remove dual start time in d1 credential
 *
 *  Revision 1.45  2013/08/06 18:29:34  hy93
 *  add the vendor that user authenticated with in credential
 *
 *  Revision 1.44  2013/07/30 19:14:11  hy93
 *  Two factor authentication support
 *
 *  Revision 1.43  2009/06/11 18:50:17  pb10
 *  Add "NETID" header for backward compatability with IIS webauth v1.
 *
 *  Revision 1.42  2009/06/10 18:54:25  pb10
 *  Fix windows.
 *
 *  Revision 1.41  2009/06/10 17:09:12  pb10
 *  Make host compare case insensitive.
 *
 *  Revision 1.40  2009/06/09 22:06:23  pb10
 *  Cannonicalize host URL before diff.
 *
 *  Revision 1.39  2009/04/29 06:12:12  pb10
 *  Initial.
 *
 *  Revision 1.38  2009/04/01 21:02:11  pb10
 *  experimental code from interop for exchange.
 *
 *  Revision 1.37  2009/03/02 18:35:22  pb10
 *  - Add new credential attributes CUWA_KEYTAB, CUWA_SERVICEID
 *  - Change misnamed attribute CUWA_LOCAL_SERVICEID to CUWA_AUTH_HOST
 *  - Use new attributes in proxy portal instead of VH config
 *
 *  Revision 1.36  2008/10/23 19:15:17  hy93
 *  fix REMOTE_USER was overwrtten by a wrong code
 *
 *  Revision 1.35  2008/10/01 20:57:47  pb10
 *  Changes to support new (non CUSSP) permit code.
 *
 *  Revision 1.34  2008/09/24 15:47:23  pb10
 *  Added T1 authenticator attribute.  Used by mod_permit.
 *
 *  Revision 1.33  2008/09/19 03:52:25  pb10
 *  Always check CUWACredAge against start_time and auth_time (not just when processing login cred).
 *
 *  Revision 1.32  2008/09/16 19:23:14  hy93
 *  add static to functions that are internal in the file
 *
 *  Revision 1.31  2008/09/07 19:35:01  gbr4
 *  rename rand.[ch] to cuwarand.[ch]. Too many packages have a rand.h and some versions of libtool grab the wrong one. This fixes builds against debian 4.0r4.
 *
 *  Revision 1.30  2008/08/25 14:50:06  pb10
 *  Change CUWA_f1 env/header to CUWA_F1.
 *
 *  Revision 1.29  2008/08/21 17:22:46  hy93
 *  fix segfault on 64 bits
 *
 *  Revision 1.28  2008/08/20 14:08:58  gbr4
 *  change all occurances of %llx and %qx to $llX and %qX respectively.
 *
 *  Revision 1.27  2008/08/17 15:08:07  pb10
 *  Add CUWA_LOGIN_USER attribute when parsing K1.
 *
 *  Revision 1.26  2008/08/15 20:10:03  pb10
 *  Change auth code to use attributes table.
 *
 *  Revision 1.25  2008/08/12 20:34:40  pb10
 *  Convert cred manager interface to use apr_table to transfer credential attributes.
 *  Also supporting the old interface to keep things working while I update  session
 *  manager and auth code.
 *
 *  Revision 1.24  2008/07/24 19:25:39  pb10
 *  K3 embedded in K2 is in raw for instead of WAK3.
 *   - cuwa_krb_make_k2 adds to length parameter to each authenticator argument set.
 *   - cuwa_krb_parse_k2 converts raw k3 to WAK3 for use by session manager
 *
 *  Revision 1.23  2008/07/14 14:47:44  pb10
 *  Modified cred mgr to allow access to f1 and k3 from k2 authenticator.
 *  Modified make_k2 to allow caller to insert arbitrary keyword/value pairs
 *  into authenticator.
 *
 *  Revision 1.22  2008/06/02 01:44:20  pb10
 *  Add starttime and endtime to fields being hacked out of GSS credential with
 *  KRB5 calls.  The starttime is being used by session manager to support
 *  cred age test... too old = starttime-authtime > CUWACredentialAge
 *
 *  Revision 1.21  2008/05/19 19:34:45  pb10
 *  Change creation of K1 (restore SSO cookie) to use malloc instead of cuwa_malloc.
 *  This is because krb_ functions are used to cleanup and those functions will
 *  call free.
 *
 *  Revision 1.20  2008/04/22 22:16:28  gbr4
 *  don't unconditionally include a header windows doesn't have
 *
 *  Revision 1.19  2008/04/19 14:21:27  pb10
 *  Convert malloc's to APR allocations.
 *
 *  Revision 1.17  2008/04/02 18:53:54  pb10
 *  Add cuwarand.c to mod_weblogin build to support using better random gen in cred mgr.
 *
 *  Revision 1.16  2008/04/02 14:35:10  pb10
 *  Temporarily remove the good random generation until I resolve mod_weblogin make issues.
 *
 *  Revision 1.15  2008/04/02 14:12:24  gbr4
 *  Bring endianness under autoconf control
 *  Fix the build
 *
 *  Revision 1.14  2008/04/02 06:22:09  pb10
 *  New code to support delegation.  Some new functions have been added that
 *  support serializing the delegated TGT as a K1 token.
 *
 *  Revision 1.13  2008/02/27 19:11:33  hy93
 *  fix compiler warning
 *
 *  Revision 1.12  2008/02/22 16:23:43  pb10
 *  Added authtime and endtime to K1 parse so that weblogin can examine.
 *
 *  Revision 1.11  2008/02/12 17:11:26  hy93
 *  remove \n when call cuwa_trace
 *
 *  Revision 1.10  2008/01/25 01:43:47  gbr4
 *  Added an ID string to every file
 *
 *  Revision 1.9  2008/01/17 14:45:43  gbr4
 *  possibly incorrect -- be more tolerant of cred lengths -- review me
 *
 *  Revision 1.8  2008/01/14 16:02:22  hy93
 *  Changed int64 to uint64 for sessionID
 *
 *  Revision 1.7  2008/01/13 21:20:31  pb10
 *  Lowercase CUWA2_LOG_DOMAIN setting.
 *
 *  Revision 1.6  2008/01/11 03:53:39  pb10
 *  Integration with logging.
 *
 *  Revision 1.5  2008/01/02 04:40:19  pb10
 *  Added host URL to K2 token.
 *  Minor bugs fix.
 *  Makefile mods to adapt to webauth.
 *
 *  Revision 1.4  2007/12/20 02:48:24  pb10
 *  Integration with session manager.
 *
 *  Revision 1.3  2007/11/07 03:43:38  pb10
 *  Fixed delegated cred support.  Other fixes.
 *
 *  Revision 1.2  2007/10/23 21:28:57  pb10
 *  Add support for cred manager.
 *
 *  Revision 1.1  2007/10/22 16:48:14  pb10
 *  Initial commit, to publish API.
 *
 *
 ************************************************************************
 */
#include <stdlib.h>
#include <string.h>
#include <stdarg.h>
#include <time.h>
#include <autoconfig.h>
#ifdef HAVE_NETINET_IN_H
#include <netinet/in.h>
#endif
#include <log.h>
#include <cred_krb.h>
#include <cred.h>
#include <cred_getput.h>
#include <cred_base64.h>
#include <kutil.h>
#include <cuwa_malloc.h>
#include <apr_strings.h>
//#include <strings.h>
#include <sspiutil.h>

//#define NO_APR // temporary hack, until I fix mod_weblogin's makefile
#ifndef NO_APR
#include <apr_file_io.h>
#include <cuwarand.h>
#endif

#define CUWA2_LOG_DOMAIN cuwa.cred

static void cuwa_krb_make_auth( char *credType, char *initiator, char *target, uint64 *sessionID, char *host, char *auth, int *authLen, va_list args);
static int cuwa_krb_glue(char *credType, char *part1, int part1_len, char *part2, int part2_len, char **cred_out, int *cred_out_len);
static char * cuwa_krb_url_canonical( apr_pool_t *pool, char *h1 );
static int cuwa_krb_make_service_token( char *credType, kutil_sec_ctx_t *save_ctx, char *host, char *remoteService, uint64 *sessionID,
                      int delegate, char **token, int *tokenLen, va_list args );

char *cuwa_get_local_realm(char *principal)
{
    char *realm = NULL;

    if (principal)
    {
        realm = strchr( principal, '@' );
        if (realm)
            realm++;
    }
    //in case realm point to NULL, although it should never happen
    if ( !realm)
    {
        realm = "unknown";
    }
    return realm;
}


/**
 * cuwa_krb_make_k1 makes a K1 token for use as a SSO cookie in CUWebLogin.
 *
 * @param[in] ksess login session, established with previous call to kutil_login.
 * @param[out] k1 pointer to newly allocated memory containing the K1.  Caller must free.
 * @param[out] k1len length of the K1 (in bytes).
 */
int cuwa_krb_make_k1( kutil_session_t ksess, char **k1, int *k1len)
{
    cuwa_err_t code;
    cuwa_err_t rc = CUWA_OK;
    char *sso = NULL,*cred = NULL;
    int credLen = 0, length = 0;

    code = kutil_save_session( ksess, &sso, &length);
    FAIL_IF(code,code);

    code = cuwa_krb_glue("K1", sso, length, NULL, 0, &cred, &credLen);
    FAIL_IF(code,code);

    *k1    = cred;
    *k1len = credLen;

    cuwa_trace("cuwa_krb_make_k1: %p",cred);

cleanup:

    if (rc && cred)
    {
        cuwa_free(cred);
    }

    return rc;
}


int cuwa_krb_make_service_token( char *credType, kutil_sec_ctx_t *save_ctx, char *host, char *remoteService, uint64 *sessionID,
                      int delegate, char **token, int *tokenLen, va_list args )
{
    kutil_sec_ctx_t delegate_ctx = NULL;
    kutil_sec_ctx_t ctx = NULL;
    cuwa_err_t code;
    cuwa_err_t rc = CUWA_OK;
    char *ict;
    int ictLen;
    char *auth = NULL, *wrap = NULL;
    int authLen = 0, wrapLen = 0;
    char *remoteid, *localid;
    va_list argsCopy;

    /* Get the ICT */
    code = kutil_init_sec_context(&ctx, delegate_ctx, remoteService, delegate, &ict, &ictLen);
    FAIL_IF(code,code);

    cuwa_trace("cuwa_krb_make_service_token ict: %p, %d bytes",ict, ictLen);

    code = kutil_inquire_context(ctx, &localid, &remoteid, NULL, NULL, NULL);
    FAIL_IF(code,code);

    cuwa_trace("cuwa_krb_make_service_token local: %s, remote: %s",localid,remoteid);

    va_copy(argsCopy,args);

    /* Build the authenticator */
    cuwa_krb_make_auth( credType, localid, remoteid, sessionID, host, NULL, &authLen, args);
    auth = cuwa_malloc(authLen);
    FAIL_IF(!auth,CUWA_ERR_MEM);

    cuwa_krb_make_auth( credType, localid, remoteid, sessionID, host, auth, &authLen, argsCopy);
    cuwa_trace("cuwa_krb_make_service_token auth: %d bytes",authLen);

    va_end(argsCopy);

    /* Encrypt the authenticator */
    code = kutil_wrap(ctx, auth, authLen, &wrap, &wrapLen);
    FAIL_IF(code,code);

    cuwa_trace("cuwa_krb_make_service_token wrapped: %d bytes",wrapLen);

    /* Put it all together */
    code = cuwa_krb_glue(credType, ict, ictLen, wrap, wrapLen, token, tokenLen);
    FAIL_IF(code,code);

    cuwa_trace("cuwa_krb_make_service_token %s: %d bytes",credType, *tokenLen);

cleanup:

    if (ctx)
    {
        if (!rc && save_ctx) *save_ctx = ctx;
        else kutil_end_sec_context(ctx);
    }
    if (auth) cuwa_free(auth);
    if (wrap) kutil_release_buffer(wrap,wrapLen);

    return rc;
}
/**
 * cuwa_krb_make_k2 makes a K2 token, to be used to establish a session with a webauth
 * instance.
 *
 * @param[in/out] save_ctx... if NULL the GSS context is destroyed before returning to caller.  Otherwise
 *                the context is returned to the caller.  The caller must call kutil_end_sec_context to
 *                release the context.
 * @param[in] host the virtual host expected to receive this token.
 * @param[in] remoteService the kerberos name of the service to establish a context with.
 * @param[in] sessionID webauth sessionID.
 * @param[in] delegate flag, if set, delegation is enabled, meaning the recipient may proxy for the user.
 * @param[out] k2 pointer to newly allocated memory containing the K2.  Caller must free.
 * @param[out] k2len length of the K2 (in bytes).
 * @param[out] ... additional authenticator elements.  Each element consists of three arguments.  The
 *             last authenticator element must be followed by NULL.
 *             Each authenticator element has these arguments...
 *               char *keyword -- two byte identifier
 *               void *value   -- pointer to the contents
 *               int length    -- length of the contents
 */
int cuwa_krb_make_k2( kutil_sec_ctx_t *save_ctx, char *host, char *remoteService, uint64 *sessionID,
                      int delegate, char **k2, int *k2Len, ... )
{
    va_list args;
    cuwa_err_t rc = CUWA_OK;

    va_start(args, k2Len);

    /* Build the authenticator */
    rc = cuwa_krb_make_service_token( "K2", save_ctx, host, remoteService, sessionID, delegate, k2, k2Len, args);

    va_end(args);

    return rc;
}

/**
 * cuwa_krb_release releases kerberos and gss credentials created during parse operation.
 * This function is called by cuwa_cred_release, and should never get called otherwise
 * except for testing purposes.
 *
 * @param[in] cred the credential.
 */
void cuwa_krb_release( cuwa_cred_t *cred, cuwa_cred_context_t *context )
{
    kutil_sec_ctx_t ctx;
    kutil_session_t ksess;

    cuwa_assert(cred);

    if (context->type==CUWA_CRED_CTX_GSS)
    {
        ctx = (kutil_sec_ctx_t) context->ctx;
        if (ctx) kutil_end_sec_context(ctx);
    }
    else
    {
        ksess = (kutil_session_t) context->ctx;
        if (ksess) kutil_end_session(ksess);
    }
}

/**
 * cuwa_krb_parse_k1 parses a K1 token.  This function is called from cuwa_cred_parse and
 * should never get called otherwise except for testing purposes.  Note that this function
 * assumes that the "K1" bytes that identify the token type have already been stripped off.
 *
 * @param[in] cred the credential which is created by cuwa_cred_parse.
 * @param[in] credBytes pointer to the beginning of the token.
 * @param[in] credByteLen length of the token.
 */
int cuwa_krb_parse_k1(cuwa_cred_t *cred, char *credBytes, int credByteLen )
{
    cuwa_err_t code;
    cuwa_err_t rc = CUWA_OK;
    kutil_session_t ksess;
    int k1Len;
    int authtime, endtime;
    char *user;

    GET_16(k1Len,credBytes,credByteLen);
    cuwa_trace("K1 length is %d",k1Len);

    code = kutil_restore_session( &ksess, credBytes, credByteLen, &authtime, &endtime);
    FAIL_IF(code,code);

    user = kutil_get_session_user(ksess);
    if (user) cuwa_cred_set_attribute( cred, "CUWA_LOGIN_USER", user);

    cuwa_cred_set_context( cred, CUWA_CRED_CTX_KERBEROS, ksess );

    cuwa_cred_set_attribute( cred, "CUWA_MECHANISM", "kerberos");
    cuwa_cred_set_attribute( cred, "CUWA_END_TIME", apr_itoa(cred->pool,endtime));
    cuwa_cred_set_attribute( cred, "CUWA_AUTH_TIME", apr_itoa(cred->pool,authtime));

    cuwa_cred_attributes_complete(cred);

    cuwa_trace("K1 authtime = %d, endtime = %d",authtime,endtime);

cleanup:

    return rc;
}

char * cuwa_krb_url_canonical( apr_pool_t *pool, char *h1 )
{
    int len = strlen(h1);
    h1 = apr_pstrdup(pool,h1);
    if (!strncmp(h1,"https:",6))
    {
        if (len>9 && !strcmp(&h1[len-4],":443")) h1[len-4] = 0; 
    }
    else
    {
        if (len>7 && !strcmp(&h1[len-3],":80")) h1[len-3] = 0; 
    }
    
    return h1;
}

/**
 * cuwa_krb_parse_k2 parses a K2 token.  This function is called from cuwa_cred_parse and
 * should never get called otherwise except for testing purposes.  Note that this function
 * assumes that the "K2" bytes that identify the token type have already been stripped off.
 *
 * @param[in] cred the credential which is created by cuwa_cred_parse.
 * @param[in] credBytes pointer to the beginning of the token.
 * @param[in] credByteLen length of the token.
 * @param[in] serviceName kerberos name of the local service.  FIXME NOTE: currently this parameter must include
 * a fully qualified name (including @realm).  GSS functions choke on partial name because the gss_name_compare
 * function won't see a name with a realm and a name without as being equivalent.  We need to do some research here.
 * @param[in] keyTabName path to the keytab file.  Note that in windows this parameter is ignored
 * by kutils and you must set the environment variable KRB5_KTNAME to control the keytab path.
 * @param[in] host the URL of this virtual host.
 */

int cuwa_krb_parse_service_token(char *credType, cuwa_cred_t *cred, char *credBytes, int credByteLen, char *serviceName, char *keyTabName, char *host)
{
    cuwa_err_t code;
    cuwa_err_t rc = CUWA_OK;
    kutil_sec_ctx_t ctx = NULL;
    char *block=NULL, *auth=NULL, *target=NULL, *initiator=NULL, *ahost=NULL, *f1=NULL, *t1=NULL, *k3=NULL;
    int blockLen = 0, authLen, targetLen=0, initiatorLen=0, hostLen=0, f1Len=0, t1Len=0, k3Len=0;
    time_t credTime;
    int auth_time, end_time, start_time;
    uint64 sessionid=0LL, requestid=0LL, sessionidInPrimary=0LL;
    int equal,hasSession;
    char *remoteid,*netid,*realm,*fullid;
    int blocksize;
    char *dualAuthUser=NULL, *dualAuthMethod=NULL, *dualAuthTime=NULL;
    int dualAuthUserLen=0, dualAuthMethodLen=0, dualAuthTimeLen;
    char *impersonateNetID = NULL;
    int impersonateNetIDLen = 0;

    cuwa_assert(cred);
    cuwa_assert(credBytes);
    cuwa_assert(credByteLen);
    cuwa_assert(serviceName);
    cuwa_assert(keyTabName);

    /* Get the ICT */
    PEEK_BUFFER(block,blockLen,credBytes,credByteLen);
    sspiutil_accept_sec_context(cred, block, blockLen, serviceName);
    code = kutil_accept_sec_context(&ctx, block, blockLen, serviceName, keyTabName, &remoteid);
    FAIL_IF(code,code);

    cuwa_cred_set_context( cred, CUWA_CRED_CTX_GSS, ctx);

    /* Authenticator */
    cuwa_trace("nextblock: %x %x %d",credBytes[0],credBytes[1],credByteLen);
    PEEK_BUFFER(block,blockLen,credBytes,credByteLen);
    code = kutil_unwrap(ctx, block, blockLen, &auth, &authLen);
    FAIL_IF(code,code);

    credBytes   = auth;
    credByteLen = authLen;

    PEEK_BYTES(block,2,credBytes,credByteLen);
    FAIL_IF((*block!=credType[0] && block[1]!=credType[1]),CUWA_ERR_CRED_INVALID);

    GET_BUFFER(initiator,initiatorLen,credBytes,credByteLen,cuwa_malloc);
    GET_BUFFER(target,targetLen,credBytes,credByteLen,cuwa_malloc);

    /* Get sessionid and requestid blocks */
    GET_16(blocksize,credBytes,credByteLen);
    if (blocksize)
    {
        FAIL_IF(blocksize!=sizeof(sessionid),CUWA_ERR_CRED_INVALID);
        GET_64(sessionid,credBytes,credByteLen);
        GET_16(blocksize,credBytes,credByteLen);
        FAIL_IF(blocksize,CUWA_ERR_CRED_INVALID);
        hasSession = 1;
    }
    else
    {
        GET_16(blocksize,credBytes,credByteLen);
        FAIL_IF(blocksize!=sizeof(requestid),CUWA_ERR_CRED_INVALID);
        GET_64(requestid,credBytes,credByteLen);
        hasSession = 0;
    }

    GET_32(credTime,credBytes,credByteLen);

    PEEK_BYTES(block,2,credBytes,credByteLen);
    FAIL_IF((*block!='H' && block[1]!='1'),CUWA_ERR_CRED_INVALID);

    GET_BUFFER(ahost,hostLen,credBytes,credByteLen,cuwa_malloc);
    cuwa_trace("HOST check: %s==%s",ahost,host?host:"NULL (ignored)");
    FAIL_IF((host && strcasecmp(cuwa_krb_url_canonical(cred->pool,host),cuwa_krb_url_canonical(cred->pool,ahost))!=0),CUWA_ERR_CRED_WRONG_HOST);

    // This last part is open ended so we could add some additional authentication data later on

    cuwa_trace("cuwa_krb_parse_k2 %d extra auth bytes",credByteLen);
    while(credByteLen)
    {
        PEEK_BYTES(block,2,credBytes,credByteLen);
        if ((*block=='f' && block[1]=='1'))
        {
            GET_BUFFER(f1,f1Len,credBytes,credByteLen,cuwa_malloc);
        }
        else if ((*block=='t' && block[1]=='1'))
        {
            GET_BUFFER(t1,t1Len,credBytes,credByteLen,cuwa_malloc);
        }
        else if ((*block=='k' && block[1]=='3'))
        {
            GET_BUFFER(k3,k3Len,credBytes,credByteLen,cuwa_malloc);

            // Convert raw K3 to WA credential
            code = cuwa_base64_make_wa(&k3,&k3Len,k3Len,1,k3,k3Len);
            FAIL_IF(code,code);
        }
        else if ((*block=='2' && block[1]=='u'))
        {
            GET_BUFFER(dualAuthUser,dualAuthUserLen,credBytes,credByteLen,cuwa_malloc);
            cuwa_trace("dualAuthUser:%s",dualAuthUser);
        }
        else if ((*block=='2' && block[1]=='m'))
        {
            GET_BUFFER(dualAuthMethod, dualAuthMethodLen,credBytes,credByteLen,cuwa_malloc);
            cuwa_trace("dualAuthMethod:%s",dualAuthMethod);
        }
        else if ((*block=='2' && block[1]=='t'))
        {
            GET_BUFFER(dualAuthTime, dualAuthTimeLen,credBytes,credByteLen,cuwa_malloc);
            cuwa_trace("dualAuthTime:%s",dualAuthTime);
        }
         else if ((*block=='2' && block[1]=='i'))
        {
            GET_BUFFER( impersonateNetID,impersonateNetIDLen,credBytes,credByteLen,cuwa_malloc);
            cuwa_trace("impersonateNetID:%s",impersonateNetID);
        }
        else
        {
            // skip unknown auth data
            cuwa_trace("cuwa_krb_parse_k2 skip unknown type: %c%c",*block,block[1]);
            GET_16(blocksize,credBytes,credByteLen);
            credBytes += blocksize;
            credByteLen -= blocksize;
        }
    }

    /* Check if target is me...  */
    code = kutil_compare_names(serviceName,target,&equal);
    FAIL_IF(code,code);
    FAIL_IF(!equal, CUWA_ERR_CRED_INVALID);

    /* Check if initiator in authenticator matches ict. .. */
    code = kutil_compare_names(initiator,remoteid,&equal);
    FAIL_IF(code,code);
    FAIL_IF(!equal, CUWA_ERR_CRED_INVALID);

    code = kutil_inquire_context(ctx, NULL, &fullid, &auth_time, &end_time, &start_time);
    FAIL_IF(code,code);

    /* Separate ID and realm, maybe this belongs in kutil? */
    netid = cuwa_malloc(strlen(fullid)+1);
    FAIL_IF(!netid,CUWA_ERR_MEM);
    strcpy(netid,fullid);
    realm = strchr( netid, '@' );
    if (realm)
    {
        realm[0] = 0;
        realm++;
    }
    else
    {
        /* Empty string - TBD... should this generate an error? */
        realm = &netid[strlen(netid)];
    }

    // if using the local realm REMOTE_USER doesn't have @realm attached (for backward compatability)
    if (!strcmp(credType, "K2"))
    {
        if ( !strcmp( realm, cuwa_get_local_realm(serviceName) ) )
        {
            cuwa_cred_set_attribute( cred, "REMOTE_USER", netid);
            cuwa_cred_set_attribute( cred, "NETID", netid);
        }
        else
        {
            cuwa_cred_set_attribute( cred, "REMOTE_USER", fullid);
            cuwa_cred_set_attribute( cred, "NETID", fullid);
        }
    
        cuwa_cred_set_attribute( cred, "CUWA_MECHANISM", "kerberos");
        cuwa_cred_set_attribute( cred, "CUWA_REMOTE_USER", netid);
        cuwa_cred_set_attribute( cred, "CUWA_REALM", realm);
        cuwa_cred_set_attribute( cred, "CUWA_AUTH_HOST", ahost);
        if (k3) cuwa_cred_set_attribute( cred, "CUWA_K3", k3);
        if (f1) cuwa_cred_set_attribute( cred, "CUWA_F1", f1);
        if (t1) cuwa_cred_set_attribute( cred, "CUWA_T1", t1);
        cuwa_cred_set_attribute( cred, "CUWA_END_TIME", apr_itoa(cred->pool,end_time));
        cuwa_cred_set_attribute( cred, "CUWA_AUTH_TIME", apr_itoa(cred->pool,auth_time));
        cuwa_cred_set_attribute( cred, "CUWA_START_TIME", apr_itoa(cred->pool,start_time));
        cuwa_cred_set_attribute( cred, "CUWA_FULL_USER", fullid);
        cuwa_cred_set_attribute( cred, "CUWA_KEYTAB",keyTabName);
        cuwa_cred_set_attribute( cred, "CUWA_SERVICEID",serviceName);
        if (sessionid) cuwa_cred_set_attribute( cred, "CUWA_SESSIONID", apr_psprintf(cred->pool,"%qX",sessionid));
        if (requestid) cuwa_cred_set_attribute( cred, "CUWA_REQUESTID", apr_psprintf(cred->pool,"%qX",requestid));

        cuwa_cred_attributes_complete(cred);

        cuwa_trace("cuwa_krb_parse_k2 remote: %s authT: %d endT: %d",netid, auth_time, end_time);
        cuwa_trace("cuwa_krb_parse_k2 netid: %s realm: %s",netid, realm);
        cuwa_trace("cuwa_krb_parse_k2 %s... sid: %llX rid: %llX",hasSession?"sess":"req",sessionid, requestid);
    }
    else if (!strcmp(credType, "2F"))
    {
        FAIL_IF( !dualAuthUser, CUWA_ERR_CRED_INVALID );
        FAIL_IF( !dualAuthMethod, CUWA_ERR_CRED_INVALID );
        FAIL_IF( !dualAuthTime, CUWA_ERR_CRED_INVALID );
        FAIL_IF( atoi(dualAuthTime) == 0, CUWA_ERR_CRED_INVALID );

        //make sure remote user is correct
        FAIL_IF( strcmp(netid, CUWL_TWOFACTOR_PRINCIPAL), CUWA_ERR_CRED_INVALID );

        //make sure sessionID matches primary authentication sessionID
        cuwa_cred_get_sessionid( cred, &sessionidInPrimary);
        FAIL_IF( sessionidInPrimary!=sessionid , CUWA_ERR_CRED_INVALID);

        //make sure 2FA user is the same as primary logged in user
        FAIL_IF( strcmp(dualAuthUser,cuwa_cred_get_attribute(cred, "CUWA_FULL_USER",0)), CUWA_ERR_CRED_INVALID);

        cuwa_cred_set_attribute_at( cred, "CUWA_2FA_USER", dualAuthUser, 0);
        cuwa_cred_set_attribute_at( cred, "CUWA_2FA_METHOD", dualAuthMethod, 0);
        cuwa_cred_set_attribute_at( cred, "CUWA_2FA_TIME", dualAuthTime, 0);

       if ( impersonateNetID )
       {
           char *impersonateFullid = NULL;
           char *copyOfImpersonateNetID = apr_pstrdup(cred->pool,impersonateNetID );

           realm = strchr( impersonateNetID, '@' );
           if (realm)
               impersonateFullid = copyOfImpersonateNetID;
           else
               impersonateFullid = apr_psprintf(cred->pool,"%s@%s",impersonateNetID,cuwa_cred_get_attribute( cred, "CUWA_REALM", 0) );

           if ( realm )
           {
               realm[0] = 0;
               realm++;

               if (!strcmp( realm, cuwa_get_local_realm(serviceName) ) )
                   cuwa_cred_set_attribute_at( cred, "CUWA_IMPERSONATE_NETID", impersonateNetID, 0);
               else
                   cuwa_cred_set_attribute_at( cred, "CUWA_IMPERSONATE_NETID", copyOfImpersonateNetID, 0);
          } else 
              cuwa_cred_set_attribute_at( cred, "CUWA_IMPERSONATE_NETID", impersonateNetID, 0);

          cuwa_cred_set_attribute_at( cred, "CUWA_IMPERSONATE_FULLID", impersonateFullid, 0);
 
          cuwa_trace("set impersonate netid %s, impersonate full id %s", impersonateNetID,impersonateFullid);
       }
    }
    else cuwa_warning("unknown credType:%s",credType);

cleanup:

    if (auth) kutil_release_buffer(auth,authLen);
    if (target) cuwa_free(target);

    if (rc && initiator)
    {
        cuwa_free(initiator);
    }

    return rc;

}


/**
 * cuwa_krb_glue glues together the pieces of a token, allocating memory to copy the result.
 *
 * @param[in] credType string, either K1 or K2.
 * @param[in] part1 first set of bytes.
 * @param[in] part1_len length of first set of bytes.
 * @param[in] part2 second set of bytes, this could be NULL.
 * @param[in] part2_len length of second set (could be zero)
 * @param[out] cred_out pointer to newly allocated token.  Caller must free.
 * @param[out] cred_out_len length of output token.
 */
int cuwa_krb_glue(char *credType, char *part1, int part1_len, char *part2, int part2_len, char **cred_out, int *cred_out_len)
{
    cuwa_err_t rc = CUWA_OK;
    char *cred,*cp;
    int credLen = 0;
    int length = part1_len + part2_len;
    int p2add = (part2_len?2:0);

    /* add 8 bytes for 3 16-bit length fields, and 2 byte type field */
    cred = cuwa_malloc(length+2+2+2+p2add);
    FAIL_IF(!cred,CUWA_ERR_MEM);

    cp = cred;

    PUT_BYTES(credType, 2, cp, credLen);

    /* Token Length */
    /* add 4 bytes for 2 16-bit length fields for content blocks */
    PUT_16(length+2+p2add, cp, credLen);

    /* Token Contents */
    PUT_BUFFER(part1,part1_len, cp, credLen);
    if (part2_len)
    {
        PUT_BUFFER(part2,part2_len, cp, credLen);
    }

    *cred_out     = cred;
    *cred_out_len = credLen;

    cuwa_trace("cuwa_krb_glue complete %d==%d?",credLen,(length+8));
    cuwa_assert((credLen-length)==(part2_len?8:6)); //gbr4: FIXME not sure if this is correct
cleanup:

    if (rc && cred) cuwa_free(cred);

    return rc;
}

static uint64 cuwa_krb_random()
{
    uint64 random;

#ifdef NO_APR
    random=rand();
#else
    random=cuwa_rand64_g();
#endif

    cuwa_trace("random number generated 0x%llX", random);
    return random;
}


/**
 * cuwa_krb_make_auth builds the authenticator component of the K2 or 2F.  This is done in two stages, by calling this
 * function twice.  the first time it is called the output pointer (auth) is NULL and no data will be copied by the
 * size needed will be returned.  the caller then allocates a buffer, calls cuwa_krb_make_k2_auth again and this
 * time the authenticator is built.
 *
 * @param[in] credential type of a service token
 * @param[in] initiator the kerberos name of the initiator.
 * @param[in] target the kerberos name of the target.
 * @param[in] sessionID the sessionId.
 * @param[in] auth where to copy the authenticator, or NULL means don't copy.
 * @param[in] host the URL of the virtual host expected to receive this token.
 * @param[in] args variable arg list of keyword value pairs terminated by NULL arg
 * @param[out] authLen size of the authenticator.
 */
void cuwa_krb_make_auth( char *credType, char *initiator, char *target, uint64 *sessionID, char *host, char *auth, int *authLen, va_list args)
{
    time_t now = time(NULL);
    int len = 0;

    PUT_BYTES(credType,strlen(credType),auth,len);
    PUT_BUFFER(initiator,strlen(initiator),auth,len);
    PUT_BUFFER(target,strlen(target),auth,len);
    if (sessionID)
    {
        PUT_16(sizeof(uint64), auth, len);
        PUT_64(*sessionID,auth,len);
        PUT_16(0, auth, len);
    }
    else
    {
        PUT_16(0, auth, len);
        PUT_16(sizeof(uint64), auth, len);
        PUT_64(cuwa_krb_random(),auth,len);
    }

    PUT_32(now,auth,len);

    PUT_BYTES("H1",2,auth,len);
    PUT_BUFFER(host,strlen(host),auth,len);

    // Add variable number of keyword/value pairs to authenticator
    {
        char *id;
        char *val;
        int vlen;
        id = va_arg(args, char *);

        while(id)
        {
            val  = va_arg(args, char *);
            vlen = va_arg(args, int);

            cuwa_assert(val);

            PUT_BYTES(id,2,auth,len);
            PUT_BUFFER(val,vlen,auth,len);

            id = va_arg(args, char *);
        }
    }

    *authLen = len;
}

int cuwa_krb_make_2F( char *host, char *remoteService, uint64 *sessionID, char **tokenOut, int *tokenLen, ... )
{
    cuwa_err_t rc = CUWA_OK;
    va_list args;

    va_start(args, tokenLen);

    /* Build the authenticator */
    rc = cuwa_krb_make_service_token( "2F", NULL, host, remoteService, sessionID, 0, tokenOut, tokenLen, args);

    va_end(args);

    return rc;
}


const char id_cred_cred_krb_c[] = "$Id$";
