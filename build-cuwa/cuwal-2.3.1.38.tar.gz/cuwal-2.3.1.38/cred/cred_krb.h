/************************************************************************
 * cred_krb.h -- Kerberos class credentials
 *
 * Copyright 2007 Cornell University.
 * All Rights Reserved.
 *
 ************************************************************************
 *  $Log$
 *  Revision 1.20.2.3  2015/03/13 18:18:11  hy93
 *  add 2FA credential token support
 *
 *  Revision 1.20.2.2  2015/01/29 18:33:01  hy93
 *  modify 2F cred handling(not complete)
 *
 *  Revision 1.20.2.1  2014/10/22 19:34:44  hy93
 *  add two factor support
 *
 *  Revision 1.7  2008/04/10 16:57:11  gbr4
 *  Line endings only. This set of files had mixed line endings which breaks visual studio (and looks ugly in vim). Each file was converted to the format that resulted in the fewest line changes (i.e. whichever format it was mostly in).
 *
 *  Revision 1.6  2008/04/02 06:22:09  pb10
 *  New code to support delegation.  Some new functions have been added that
 *  support serializing the delegated TGT as a K1 token.
 *
 *  Revision 1.5  2008/01/14 15:54:51  hy93
 *  change function prototype cuwa_krb_make_k2 to use uint64 for sessionID
 *
 *  Revision 1.4  2008/01/02 04:40:19  pb10
 *  Added host URL to K2 token.
 *  Minor bugs fix.
 *  Makefile mods to adapt to webauth.
 *
 *  Revision 1.3  2007/11/07 03:42:13  pb10
 *  trivial comment cleanup.
 *
 *  Revision 1.2  2007/10/23 21:28:57  pb10
 *  Add support for cred manager.
 *
 *  Revision 1.1  2007/10/22 16:48:14  pb10
 *  Initial commit, to publish API.
 *
 ************************************************************************
 */

#ifndef _CRED_KRB_H
#define _CRED_KRB_H

#include "cred.h"
#include "kutil.h"

#define CUWL_TWOFACTOR_PRINCIPAL "twostep/login"

/* Parse tokens */

int cuwa_krb_parse_k1( cuwa_cred_t *cred, char *credBytes, int credByteLen );

int cuwa_krb_parse_service_token( char *credType, cuwa_cred_t *cred, char *credBytes, int credByteLen, char *serviceName, char *keytabName, char *host);

void cuwa_krb_release( cuwa_cred_t *cred, cuwa_cred_context_t *context );


/* Make tokens */

int cuwa_krb_make_k1( kutil_session_t ksess, char **k1bits, int *k1len);

int cuwa_krb_make_k2( kutil_sec_ctx_t *save_ctx, char *host, char *remoteService, uint64 *sessionID,
                      int delegate, char **k2, int *k2Len, ... );

int cuwa_krb_make_2F( char *host, char *remoteService, uint64 *sessionID, char **tokenOut, int *tokenLen, ... );

//////////////////////////////////////////////////////////////////////////////////////////////////
// Some rough notes, eventually will be removed from this file and put into some documentation...
//////////////////////////////////////////////////////////////////////////////////////////////////
// making a K1
// Built from kutil_save_session call, requires a kutil_session_t
// Only weblogin creates on of these.
// Steps...
//  - call kutil_login
//  - call cuwa_krb_make_k1(kutil_session_t ksess, char **k1bits, int *k1len)
//      - calls kutil_save_session
//  - call cuwa_cred_base64_wrap(char **wa, int *cred_length, k1bits, k1len, NULL);
//
// making a K2
// Built from kutil_init_sec_context, requires kutil_sec_ctx_t
// who uses it?
// webauth       input= remoteService (session TGT with localid/keytab)
// fat client    input= remoteService (assumes TGT local default credentials established)
// weblogin,     input= remoteService (session TGT with netid/password, or restore_session call)
// midtier java  input= remoteService (session TGT with localid/keytab)
//
// Steps...
//  - get TGT somehow (out of scope)
//  - call cuwa_krb_make_k2( cuwa_cred_t *existingCred, char *remoteService, char **k2bits, int *k2Len );
//     - calls kutil_init_sec_context(kutil_sec_ctx_t *ctx, char *service, char **bits, int *length);
//  - call cuwa_cred_base64_wrap(char **wa, int *waLen, k2bits, k2len, NULL);
//
// JavaAPI...
//  cuwa_cred_parse( cuwa_cred_t **cred, char *credBytes, int credByteLen, char *serviceName, char *keytabName, void *reserved );
//  cuwa_krb_make_k2( cuwa_cred_t *existingCred, char *remoteService, char **k2bits, int *k2Len );
//  cuwa_cred_base64_wrap(char **wa, int *waLen, k2bits, k2len, NULL);
//
// Steps for Java middle tier
// - call cuwa_cred_parse,         get cuwa_cred_t, user info
//
// Steps for Java middle tier to proxy...
// - call cuwa_krb_make_k2,        make proky authenticator, pass in existing cuwa_cred_t
// - call cuwa_cred_base64_wrap    wrap and ship!
//
// Steps for Java fat client...
// - call cuwa_krb_make_k2,        make proky authenticator, use existing login credentials (TGT)
// - call cuwa_cred_base64_wrap    wrap and ship!

#endif /* _CRED_KRB_H */








