/************************************************************************
 * kutil.h -- Kerberos utilities for cuwebauth
 *
 * Copyright 2007 Cornell University.
 * All Rights Reserved.
 *
 ************************************************************************
 *  $Log$
 *  Revision 1.13  2008/10/14 16:00:55  hy93
 *  try to fix permission deny in replay cache error on Windows
 *
 *  Revision 1.12  2008/08/17 15:08:07  pb10
 *  Add CUWA_LOGIN_USER attribute when parsing K1.
 *
 *  Revision 1.11  2008/06/02 01:44:20  pb10
 *  Add starttime and endtime to fields being hacked out of GSS credential with
 *  KRB5 calls.  The starttime is being used by session manager to support
 *  cred age test... too old = starttime-authtime > CUWACredentialAge
 *
 *  Revision 1.10  2008/04/13 18:29:27  pb10
 *  Hacked the GSS ICT so that we can get real authtime when accepting tokens.
 *
 *  Revision 1.9  2008/04/07 14:40:07  pb10
 *  Add function kutil_get_times.
 *
 *  Revision 1.8  2008/04/04 02:58:30  gbr4
 *  added sys/types to try to fix openbsd build
 *
 *  Revision 1.7  2008/04/04 02:50:03  gbr4
 *  added sys/socket and sys/types to try to fix openbsd build
 *
 *  Revision 1.6  2008/04/02 06:22:09  pb10
 *  New code to support delegation.  Some new functions have been added that
 *  support serializing the delegated TGT as a K1 token.
 *
 *  Revision 1.5  2008/02/22 16:23:43  pb10
 *  Added authtime and endtime to K1 parse so that weblogin can examine.
 *
 *  Revision 1.4  2007/11/07 03:39:26  pb10
 *  Changed API to kutil_init_sec_context.  Added Win32 support.
 *
 *  Revision 1.3  2007/10/23 21:28:57  pb10
 *  Add support for cred manager.
 *
 *  Revision 1.2  2007/10/18 20:12:02  pb10
 *  Added Kerberos API support.
 *
 *  Revision 1.1  2007/09/07 11:24:42  pb10
 *  Initial
 *
 ************************************************************************
 */

#ifndef _KUTIL_H
#define _KUTIL_H

#include <cuwa_err.h>

/**
 * Opaque kerberos session object, associated to a thread global
 * memory based ticket cache, which is used by gssapi.
 */
typedef void * kutil_session_t;

/**
 * Opaque GSS security context object, associated with a client/server context.
 */
typedef void * kutil_sec_ctx_t;

/**
 * Opaque Kerberos5 security context object, associated with a client/server context.
 */
typedef void * kutil_krb_ctx_t;


/************************************************************************
 * kutil_session: this is a kerberos session, a TGT and associated ticket cache.
 * This set of functions performs "kinit" style client login.
 * CUWL calls login, if the user has no SSO cookie to establish a session.
 * If the user has a SSO cookie, CUWL calls restore_session.  The session
 * is associated with GSS via thread global so once a session is estaqblished
 * init_sec_context can be called to get a service authenticator.
 *
 * At the end of a processing a login request, CUWL will call save_session
 * to serialize the TGT and set the SSO cookie.  Finally, CUWL calls
 * end_session to destroy the currest session and associated ticket cache.
 *
 * CUWA does not need to call kutil_session functions??
 *
 ************************************************************************
 */
cuwa_err_t kutil_login(kutil_session_t *ksess, char *netid, char *password);

cuwa_err_t kutil_login_key(kutil_session_t *ksess, char *serviceid, char *keytab);

cuwa_err_t kutil_save_session( kutil_session_t ksess, char **bits, int *length);

cuwa_err_t kutil_restore_session( kutil_session_t *ksess, char *bits, int length, int *authtime, int *endtime );

cuwa_err_t kutil_get_times( kutil_session_t ksess, int *authtime, int *starttime, int *endtime, int *renew_til);

char * kutil_get_session_user(kutil_session_t ksess);

void kutil_end_session(kutil_session_t ksess);

/************************************************************************
 * kutil_sec_ctx: this is the security context between a client and server.
 * Functions that use kutil_sec_ctx are wrapping GSSAPI calls and
 * adding high-level functionality.
 *
 * Before using this set of calls a login context needs to be established
 * via kutil_login or kutil_login_key.
 *
 * init_sec_context calls gss_init_sec_context returning an authenticator
 * as a series of bytes.  It assumes that a kerberos session has already
 * been established via login or restore_session.  (called by CUWL)
 *
 * accept_sec_context calls gss_accept_sec_context, returning the identity
 * of the remote user.
 *
 * end_sec_context is called to destroy the context and release resources
 * associated with the context.
 *
 ************************************************************************
 */
cuwa_err_t kutil_init_sec_context(kutil_sec_ctx_t *ctx, kutil_sec_ctx_t ctx_delegate, char *service, int delegate, char **bits, int *length);

cuwa_err_t kutil_accept_sec_context(kutil_sec_ctx_t *ctx, char *bits, int bitLen, char *serviceName, char *keytabName, char **remoteid);

cuwa_err_t kutil_unwrap(kutil_sec_ctx_t ctx, char *in, int inLen, char **out, int *outLen);

cuwa_err_t kutil_wrap(kutil_sec_ctx_t ctx, char *in, int inLen, char **out, int *outLen);

void kutil_end_sec_context(kutil_sec_ctx_t ctx);

void kutil_release_buffer(char *buf, int len);

cuwa_err_t kutil_inquire_context(kutil_sec_ctx_t ctx, char **localid, char **remoteid, int *authtime, int *endtime, int *starttime);

cuwa_err_t kutil_compare_names(char *name1, char *name2, int *equal);

cuwa_err_t kutil_stow_gss_cred(kutil_session_t *ksess, kutil_sec_ctx_t ctx);

/************************************************************************
 * kutil_krb_ctx: this is the security context between a client and server.
 * All calls that use kutil_krb_ctx make direct kerberos5 calls instead
 * of GSSAPI.  Thus far only client side calls are supported, but that may
 * be all we need.
 *
 * Before using this set of calls a login context needs to be established
 * via kutil_login or kutil_login_key.
 *
 * kutil_make_req creates the context and returns a token to be passed
 * to the server. The context is essentially a krb5_auth_context which
 * establishes a shared session key between client<->server.
 *
 * kutil_rd_rep processes the response token from the server for mutual
 * authentication.
 *
 * kutil_mk_priv will encrypt bytes using the session key.
 *
 * kutil_rd_priv will decrypt bytes using the session key.
 *
 * kutil_end_krb_context will destroy the session context.
 *
 ************************************************************************
 */
cuwa_err_t kutil_make_req( kutil_krb_ctx_t *ctx, kutil_session_t ksess, char *remoteid, char **req, int *req_len );

cuwa_err_t kutil_rd_req(kutil_krb_ctx_t *ctx, char *req, int req_len, char *localid, char *keytab, char **remoteid );

cuwa_err_t kutil_rd_rep( kutil_krb_ctx_t ctx, char *rep, int rep_len );

cuwa_err_t kutil_mk_priv( kutil_krb_ctx_t ctx, char *in, int in_len, char **out, int *out_len );

cuwa_err_t kutil_rd_priv( kutil_krb_ctx_t ctx, char *in, int in_len, char **out, int *out_len );

void kutil_end_krb_context(kutil_krb_ctx_t ctx);

#endif /* _kutil_H */





