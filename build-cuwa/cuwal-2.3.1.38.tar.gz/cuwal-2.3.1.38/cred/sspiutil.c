/************************************************************************
 * sspiutil.c -- Support for microsoft's SSPI
 *
 * Copyright 2009 Cornell University.
 * All Rights Reserved.
 *
 ************************************************************************
 */
#include <cred.h>
#include <cuwa_err.h>
#include <log.h>
#include <sspiutil.h>
#define SECURITY_WIN32
#include <Rpc.h>
#include <Windows.h>
#include <Sspi.h>
#include <Ntsecapi.h>
#include <Security.h>
#include <Ntsecpkg.h>
#include <apr_strings.h>
#include <cred_base64.h>
#include <apr_thread_proc.h>
#include <apr_pools.h>
#include <process.h>

#define CUWA2_LOG_DOMAIN cuwa.cred

static apr_threadkey_t *sspiutil_key = NULL;
static char *sspiutil_get_user( EXTENDED_NAME_FORMAT type, char *pool );
static void sspiutil_save_sec_context(cuwa_cred_t *cred, SecHandle *winctx);
static void sspiutil_set_ctx( SecHandle *ctx );
static void sspiutil_gauntlet(cuwa_cred_t *cred, SecHandle *winctx);
static SecHandle * sspiutil_get_ctx();

void sspiutil_dump(char *msg)
{
	char bigbuffer[512]; // fixme buffer overflow potential

	cuwa_trace("sspiutil_dump: %s ...",msg);
    sspiutil_get_user(NameServicePrincipal,bigbuffer);
    sspiutil_get_user(NameUserPrincipal,bigbuffer);
    sspiutil_get_user(NameDisplay,bigbuffer);
    sspiutil_get_user(NameUniqueId,bigbuffer);
}

void sspiutil_begin_ctx()
{
	sspiutil_set_ctx(NULL);
}

void sspiutil_revert_ctx()
{
	SECURITY_STATUS st;
	SecHandle *ctx = sspiutil_get_ctx();
	if (ctx)
	{
		st = RevertSecurityContext(ctx);
		cuwa_trace("RevertSecurityContext: %X",st);
		sspiutil_set_ctx(NULL);
	}
}

static void sspiutil_test_delegation()
{
    int rc = 0;
    HANDLE f = CreateFile("\\\\Win2k332r2sp2\\test\\hello.htm",GENERIC_READ,FILE_SHARE_READ,NULL,OPEN_EXISTING,FILE_ATTRIBUTE_NORMAL,NULL);
    if (f==INVALID_HANDLE_VALUE)
    {
        rc = GetLastError();
    } else
    {
        CloseHandle(f);
    }
    cuwa_trace("Delegation hack test, returned: %d",rc);
}

void sspiutil_accept_sec_context(cuwa_cred_t *cred, char *bits, int bitLen, char *serviceName)
{
    SECURITY_STATUS st;
    SecBufferDesc gss_desc, outbuf;
    CredHandle gcred;
    SecBuffer gss_buf[2];
    SecHandle *winctx;
    ULONG OutputFlags;
    int rc;
    ULONG bufsize = 0;
    char *spn;
	DWORD pid = GetCurrentProcessId( );
    char bigbuffer[512]; // fixme buffer overflow potential
//	SECPKG_CLIENT_INFO info;

    cuwa_assert(serviceName);

    cuwa_trace("********* sspiutil_accept_sec_context enter Process=(%X) *****",pid);
    cuwa_trace("Service is %s",serviceName);

//	GetClientInfo(&info);
//	cuwa_trace("tcb: %s imper: %s pid:%X tid:%X logon: %s",info.HasTcbPrivilege?"Y":"N", info.Impersonating?"Y":"N", info.ProcessID, info.ThreadID, info.LogonId);

    sspiutil_dump("initial state");
    spn = sspiutil_get_user(NameUserPrincipal,bigbuffer);

    cuwa_trace("SPN is %s",spn);
    if (stricmp(spn,serviceName)) return;

    st = AcquireCredentialsHandle(NULL,"Negotiate",SECPKG_CRED_BOTH, /* was SECPKG_CRED_INBOUND */
                                           NULL, NULL, NULL, NULL, &gcred, NULL);
    cuwa_trace("AcquireCredentialsHandle response code: %X",st);
    // Fixme: convert error to message
    if (st) return;

    memset(&gss_desc,0,sizeof(gss_desc));
    memset(&gss_buf,0,sizeof(gss_buf));
    memset(&outbuf,0,sizeof(outbuf));

    outbuf.cBuffers = 0;
    outbuf.pBuffers = NULL;
    outbuf.ulVersion = SECBUFFER_VERSION;
    gss_desc.ulVersion = SECBUFFER_VERSION;
    gss_desc.cBuffers = 1;
    gss_desc.pBuffers = gss_buf;
    gss_buf[0].cbBuffer = bitLen;
    gss_buf[0].BufferType = SECBUFFER_TOKEN;
    gss_buf[0].pvBuffer = bits;
    
	winctx = apr_pcalloc(cred->pool,sizeof(SecHandle));
    
    rc = AcceptSecurityContext( &gcred,NULL,&gss_desc, ASC_REQ_DELEGATE, SECURITY_NATIVE_DREP, winctx, 
                                &outbuf,&OutputFlags,NULL);
    cuwa_trace("AcceptSecurityContext response code: %X",rc);
    // Fixme: convert error to message
    if (rc) return;

    st = ImpersonateSecurityContext(winctx);
    cuwa_trace("ImpersonateSecurityContext response: %X",st);
    // Fixme: convert error to message
    if (st) return;

	sspiutil_set_ctx(winctx);
    sspiutil_dump("impersonation complete");

	// Save the context into the session for later use...
	sspiutil_save_sec_context(cred, winctx);
	cuwa_trace("Done with SSPIUTIL");

//	cuwa_trace("Test gauntlet...");
//	sspiutil_gauntlet(cred,winctx);
}

void sspiutil_gauntlet(cuwa_cred_t *cred, SecHandle *winctx)
{
	HANDLE token = NULL;
	SecBuffer sbuf;
	SECURITY_STATUS sst;
	SecHandle ctx;

	sspiutil_revert_ctx();
	sst = ImpersonateSecurityContext(winctx);
    cuwa_trace("do over ImpersonateSecurityContext response: %X",sst);

    sst = QuerySecurityContextToken(winctx,&token);
    cuwa_trace("QuerySecurityContextToken response: %X",sst);
	
	sbuf.BufferType = SECBUFFER_EMPTY;
	sbuf.cbBuffer = 0;
	sbuf.pvBuffer = NULL;
	sst = ExportSecurityContext(winctx,0,&sbuf,NULL);
	cuwa_trace("ExportSecurityContext: %X, type: %X, len: %d",sst,sbuf.BufferType,sbuf.cbBuffer);
	if (sst != SEC_E_OK) return;

	sspiutil_revert_ctx();
    sspiutil_dump("Begin restore");

	sst = ImportSecurityContext(MICROSOFT_KERBEROS_NAME_A, &sbuf, token, &ctx);
	cuwa_trace("ImportSecurityContext: %X",sst);
	if (sst) return;

    sst = ImpersonateSecurityContext(&ctx);
    cuwa_trace("Imported ImpersonateSecurityContext gave me: %X",sst);
}

void sspiutil_save_sec_context(cuwa_cred_t *cred, SecHandle *winctx)
{
    HANDLE token = NULL;
	SecBuffer sbuf;
	char *ctxstr, *tokenStr, *pidStr;
	SECURITY_STATUS sst;
    int pid;
    
    sst = QuerySecurityContextToken(winctx,&token);
    cuwa_trace("QuerySecurityContextToken response: %X",sst);
    if (sst != SEC_E_OK) return;
	
	sbuf.BufferType = SECBUFFER_EMPTY;
	sbuf.cbBuffer = 0;
	sbuf.pvBuffer = NULL;

	sst = ExportSecurityContext(winctx,0,&sbuf,NULL);
	cuwa_trace("ExportSecurityContext: %X, type: %X, len: %d",sst,sbuf.BufferType,sbuf.cbBuffer);
	if (sst != SEC_E_OK) return;

	// base64
	ctxstr = apr_pcalloc(cred->pool,cuwa_base64_encode_bytes(sbuf.cbBuffer));
	cuwa_base64_encode( sbuf.pvBuffer, sbuf.cbBuffer, ctxstr);
    tokenStr = apr_psprintf(cred->pool,"%X",token);
    pid = GetCurrentProcessId( );
    pidStr = apr_psprintf(cred->pool,"%X",pid);
	cuwa_trace("ExportSecurityContext: %s",ctxstr);
	cuwa_trace("Security token: 0x%s",tokenStr);
	cuwa_trace("Security PID: 0x%s",pidStr);

	cuwa_cred_set_attribute( cred, "CUWA_WIN_CTX", ctxstr);
	cuwa_cred_set_attribute( cred, "CUWA_WIN_TOKEN", tokenStr);
	cuwa_cred_set_attribute( cred, "CUWA_WIN_PID", pidStr);
    
    sst = FreeContextBuffer(sbuf.pvBuffer);
	cuwa_trace("FreeContextBuffer: %X",sst);   
}

int sspiutil_restore_sec_context(cuwa_cred_t *cred)
{
    HANDLE token, proc;
    SECURITY_STATUS st;
    SecHandle *winctx;
    char *ctxstr, *tokenStr, *pidStr;
	SecBuffer sbuf;
	int oldpid, pid = GetCurrentProcessId( );

    ctxstr = cuwa_cred_get_attribute( cred, "CUWA_WIN_CTX", 0);
    if (!ctxstr)
    {
        cuwa_trace("ImpersonateSecurityContext no attribute present");
        return CUWA_OK;
    }
    
    tokenStr = cuwa_cred_get_attribute( cred, "CUWA_WIN_TOKEN", 0);
    pidStr = cuwa_cred_get_attribute( cred, "CUWA_WIN_PID", 0);
    if (!tokenStr || !pidStr) 
    {
        cuwa_trace("Missing attributes");
        return CUWA_ERR_SESSION_INVALID;
    }
    
	sbuf.cbBuffer = cuwa_base64_decode_bytes(ctxstr);
	sbuf.pvBuffer = apr_pcalloc(cred->pool,sbuf.cbBuffer);
    sbuf.cbBuffer = cuwa_base64_decode(ctxstr, sbuf.pvBuffer);
	cuwa_trace("sspiutil_restore_sec_context, base64decode: %d bytes",sbuf.cbBuffer);
	sbuf.BufferType = SECBUFFER_EMPTY;
	winctx = apr_pcalloc(cred->pool,sizeof(SecHandle));
    
    sscanf(pidStr,"%X",&oldpid);
    if (sizeof(token)==4) sscanf(tokenStr,"%X",&token); 
    else if (sizeof(token) == 8) token = (HANDLE) apr_strtoi64(tokenStr,NULL,16);
    else {
        cuwa_trace("ARCH: Unsupported pointer size!");
        token = 0;
    }
    
    if (oldpid != pid)
    {
        proc = OpenProcess(READ_CONTROL|PROCESS_DUP_HANDLE,FALSE,oldpid);
        if (!proc)
        {
            st = GetLastError();
            cuwa_trace("OpenProcess: err=%X",st);
            return CUWA_ERR_SESSION_INVALID; 
        }
        
        if (!DuplicateHandle(proc,token,GetCurrentProcess(),&token,0,FALSE,DUPLICATE_SAME_ACCESS))  // FYI... set to FALSE - don't need to make handle inheritable by processes
        {
            st = GetLastError();
            cuwa_trace("DuplicateHandle: err=%X",st);
            return CUWA_ERR_SESSION_INVALID; 
        }
        cuwa_trace("Token handle dup'd for proc");
    }

	st = ImportSecurityContext(MICROSOFT_KERBEROS_NAME_A, &sbuf, token, winctx);
	cuwa_trace("ImportSecurityContext: %X",st);
	if (st) return CUWA_ERR_SESSION_INVALID;

    st = ImpersonateSecurityContext(winctx);
    cuwa_trace("ImpersonateSecurityContext gave me: %X",st);
	if (st) return CUWA_ERR_SESSION_INVALID;
    
	sspiutil_set_ctx(winctx);

    sspiutil_dump("Impersonation complete");
    
    return CUWA_OK;
}

char *sspiutil_get_user( EXTENDED_NAME_FORMAT type, char *buf )
{
    ULONG bufsize = 0;
//    char *name;
    static char *nogood = "not good";
    int rc;

    *buf = 'a';
    buf[1] = 0;

    cuwa_trace("sspiutil_get_user enter");
    bufsize = 255;
    if (!GetUserNameEx( type, buf, &bufsize)) {
        rc = GetLastError();
        cuwa_trace("getlasterror: %d (%d,%d,%d)",rc,ERROR_NO_SUCH_DOMAIN,ERROR_MORE_DATA,ERROR_NONE_MAPPED);
        cuwa_trace("buf: %s",buf);
        return nogood;
    }
    cuwa_trace("GetUserNameEx: type %d, %s",type,buf);
    return buf;
}

SecHandle * sspiutil_get_ctx()
{
    SecHandle *ctx = NULL;

    if ( !sspiutil_key )
    {
        cuwa_warning("sspiutil uninitialized");
        return NULL;
    }

    apr_threadkey_private_get(&ctx, sspiutil_key);
    return ctx;
}

void sspiutil_set_ctx( SecHandle *ctx )
{

    if ( !sspiutil_key )
    {
        cuwa_warning("sspiutil uninitialized");
        return;
    }
    apr_threadkey_private_set((void *)ctx, sspiutil_key);
}

static void sspiutil_delete_key(apr_pool_t *pool)
{
    if ( sspiutil_key ) apr_threadkey_private_delete(sspiutil_key);
}

cuwa_err_t sspiutil_init(apr_pool_t *pool)
{
    apr_status_t apr_err;
    cuwa_err_t status = CUWA_OK;

    apr_err = apr_threadkey_private_create(&sspiutil_key, sspiutil_delete_key, pool);
    if ( apr_err)
    {
         char buf[512];

         apr_strerror( apr_err, buf, 512 );
         cuwa_warning("thread key creation failed:%s", buf);
         status = CUWA_ERR_THREAD_KEY;
    }
    else
    {
        sspiutil_set_ctx(NULL);
    }

    return status;
}

int sspi_logon_impersonate(char *user, char *domain, char *password)
{
    HANDLE token;
    int rc;
    char buffer[256];
    *buffer = 0;

    if ( ! LogonUser(user,domain,password,LOGON32_LOGON_NETWORK_CLEARTEXT,LOGON32_PROVIDER_DEFAULT,&token))
    {
        rc = GetLastError();
        cuwa_trace("LogonUser failed: %X",rc);
        return rc;
    }

    if ( ! ImpersonateLoggedOnUser(token))
    {
        rc = GetLastError();
        cuwa_trace("ImpersonateLoggedOnUser failed: %X",rc);
        return rc;
    }

    return 0;
}

