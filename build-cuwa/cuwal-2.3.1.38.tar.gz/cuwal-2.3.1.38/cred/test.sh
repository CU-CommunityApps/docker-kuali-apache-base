#!/bin/sh


LD_LIBRARY_PATH=/home/pb10/authbuild/krb5-1.6.2/lib:$LD_LIBRARY_PATH
export LD_LIBRARY_PATH

. ../config.sh
./test_kutil -l ns10-demo "\$tester" "$TEST_SERVICE" $TEST_KEYTAB
