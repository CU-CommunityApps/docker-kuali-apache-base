#!/bin/perl

my $arg = @ARGV[0];
if (substr($arg,0,9) ne "apache13=")
{
    print "$fred Syntax error, need to specify apache13 option.\n";
    exit 1;
}

my $apache13 = substr($arg,9);

my $hkrules = `cat ../cuwa.rules`;
$hkrules =~ s/\$\(CUWA_SRC_TOP\)\/depend.rules/headerkey.depend.rules/g;
open (RULES, ">headerkey.rules");
print RULES "$hkrules\n";
print RULES "CUWA_INCLUDES += -I\$(CUWA_SRC_TOP)/headerkey/compat";
close RULES;

my $apache2 = trim(substr(`grep APACHE_HTTPD_ROOT ../depend.rules`,18));
my $hkrules = `cat ../depend.rules`;
$hkrules =~ s/$apache2/$apache13/g;
open (RULES, ">headerkey.depend.rules");
print RULES $hkrules;
close RULES;

open (RULES, ">config.log");
print RULES "# perl config.pl apache13=$apache13\n";
close RULES;


sub trim($)
{
    my $string = shift;
    $string =~ s/^\s+//;
    $string =~ s/\s+$//;
    return $string;
}


