#ifdef IIS_BUILD
int cuwa_make_hdr_key( void *request, int verify, int skew) { return 0; }
#else

#include <stdlib.h>
#include <openssl/sha.h>
#include <openssl/hmac.h>

#ifdef MODHEADERKEY
#include <compat13.h>
#else
#include <apr_time.h>
#include <apr_tables.h>
#include <apr_pools.h>
#include <apr_strings.h>
#include <log.h>
#include <wal.h>
#include <cred_base64.h>
#define CUWA_USER user
#endif

#include <cuwa_err.h>
#include <http_request.h>

#define CUWA2_LOG_DOMAIN cuwa.auth

static void cuwa_hk_write_header(request_rec *r, apr_table_t *mac_headers, HMAC_CTX *ctx, const char *key);
static int cuwa_hk_delete(void *p, const char *key, const char *value);

#define FAIL(m) do {fail++;cuwa_trace("Error at: %s",(m));} while (0)

static const char *cuwa_hk_header_names[] = { 
    "CUWA_AUTH_TIME","CUWA_END_TIME","CUWA_F1","CUWA_FULL_USER","CUWA_AUTH_HOST",
    "CUWA_MECHANISM","CUWA_REALM","CUWA_REMOTE_USER","CUWA_SESSIONID","CUWA_SESSIONKEY",
    "CUWA_START_TIME","CUWA_KEYTAB","CUWA_SERVICEID",NULL };


// Called from mod_cuwebauth (cuwa_authn) if configured for CUWA_HEADER_KEY on
// Called from mod_headerkey (cuwa_read_hdr_key) to validate key
int cuwa_make_hdr_key( void *request, int verify, int skew)
{
    unsigned char sha1[SHA_DIGEST_LENGTH];
    unsigned char hmac[EVP_MAX_MD_SIZE];
    request_rec *r = (request_rec *) request;
    CUWACfg_t *cfg = cuwa_wal_get_config(r);
    HMAC_CTX ctx;
    SHA_CTX sha_ctx;
    unsigned int len, size;
    int fail = 0;
    int buflen,i;
    apr_status_t rv;
    apr_file_t *file = NULL;
    char buf[512], *thekey;
    const char *nowstr, *thenstr;
    apr_size_t nbytes;
    apr_time_t now, then;
    apr_table_t *mac_headers;
    const char *expect_key  = apr_table_get( r->headers_in,"CUWA_HEADER_KEY");

    if (!CFG_CUWAKeytab(cfg))
    {
        cuwa_warning("Warning: CUWAKeytab directive not set.");
        return CUWA_ERR;
    }

    // Get SHA-1 of keytab file

    if (!SHA1_Init(&sha_ctx)) FAIL("SHA1_Init");
    rv = apr_file_open( &file, CFG_CUWAKeytab(cfg), APR_READ, APR_UREAD, r->pool );
    while ( rv == APR_SUCCESS )
    {
        nbytes = sizeof(buf);
        rv = apr_file_read( file, buf, &nbytes);
        if (rv == APR_SUCCESS)
        {
            buflen = nbytes;
            if (!SHA1_Update(&sha_ctx, buf, buflen)) FAIL("SHA1_Update");
        }
	}
    apr_file_close(file);

    if (rv != APR_EOF)
    {
        cuwa_warning("Warning: Can't read keytab, apr file error %d",rv);
        return CUWA_ERR;
    }

    if (!SHA1_Final(sha1, &sha_ctx)) FAIL("SHA1_Final");

    // Get the time value

    now = apr_time_now();
    if (verify)
    {
        // For verify, use the same time that sender used...

        thenstr = apr_table_get( r->headers_in,"CUWA_HEADER_KEY_TIME");
        if (!thenstr)
        {
            cuwa_warning("Warning: Missing CUWA_HEADER_KEY_TIME header");
            return CUWA_ERR;
        }

        then = apr_atoi64( thenstr);

        // Make sure the time is within clock skew though...

        if (now > (then+skew) || now < (then-skew))
        {
            cuwa_warning("Warning: time out of bounds %d usec.",(int)(now-then));
            return CUWA_ERR;
        }
        now = then;
        nowstr = thenstr;
    }
    else nowstr = apr_psprintf(r->pool,"%qi",now);

    // Create HMAC of headers + time using key==sha1-of-keytab
    mac_headers = apr_table_make(r->pool, 20);
    HMAC_CTX_init(&ctx);
    HMAC_Init_ex(&ctx, sha1, SHA_DIGEST_LENGTH, EVP_sha1(), NULL);
    HMAC_Update(&ctx, (unsigned char *) nowstr, strlen(nowstr));
    for (i=0;cuwa_hk_header_names[i];i++) cuwa_hk_write_header( r,mac_headers,&ctx,cuwa_hk_header_names[i]);
    HMAC_Final(&ctx, hmac, &len);
    HMAC_CTX_cleanup(&ctx);

    if (fail)
    {
        cuwa_warning("Warning: Unable to generate header key.");
        return CUWA_ERR;
    }
    
    // Base64
    size = cuwa_base64_encode_bytes( len );
    thekey = apr_pcalloc(r->pool,size+1);
    cuwa_base64_encode( (char*) hmac, len, thekey );

    cuwa_trace("Generated key: %s",thekey);

    if (verify)
    {
        if (!expect_key)
        {
            cuwa_warning("Warning: Missing CUWA_HEADER_KEY header.");
            return CUWA_ERR;
        }

        cuwa_trace("Header key: %s",expect_key);

        if (strcmp(thekey,expect_key))
        {
            cuwa_warning("Warning: header key doesn't match inbound headers.");
            return CUWA_ERR;
        }
        
        // Wipe the CUWA headers out of headers_in, just allow ones in that are part of HMAC
        apr_table_do(cuwa_hk_delete,r->headers_in,r->headers_in,NULL);
    }
    else
    {
        // drop header into table
        apr_table_set( r->headers_in,"CUWA_HEADER_KEY",thekey);
        apr_table_set( r->headers_in,"CUWA_HEADER_KEY_TIME",nowstr);
    }


    return CUWA_OK;
}

int cuwa_hk_delete(void *p, const char *key, const char *value)
{
    int i;
    
    if (strncmp("CUWA_",key,5)) return 1;

    for (i=0;cuwa_hk_header_names[i];i++)
    {
        if (!strcmp(cuwa_hk_header_names[i],key)) return 1;
    }

    apr_table_unset((apr_table_t *) p,	key);	 
    
    return 1;
}

void cuwa_hk_write_header(request_rec *r, apr_table_t *mac_headers, HMAC_CTX *ctx, const char *key)
{
    if (!strncmp(key,"CUWA_",5) && strncmp(key,"CUWA_HEADER_KEY",15))
    {
        const char *val = apr_table_get(r->headers_in,key);
        char *trunc;
        
        if (!val) val = "";
        val = apr_pstrdup(r->pool,val);
        cuwa_trace("Add HMAC data (before)... key: %s val: %s",key,val);

        
        // Truncate in case there are multiple values separated by comma
        trunc = strchr(val,',');
        if (trunc) *trunc = 0;
        
        cuwa_trace("Add HMAC data (after)... key: %s val: %s",key,val);
        HMAC_Update(ctx, (const unsigned char *) key, strlen(key));
        HMAC_Update(ctx, (const unsigned char *) val, strlen(val));
        apr_table_set(mac_headers,key,val);
    }
}



#endif
