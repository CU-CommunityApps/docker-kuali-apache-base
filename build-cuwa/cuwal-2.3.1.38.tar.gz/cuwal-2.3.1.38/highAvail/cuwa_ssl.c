/************************************************************************
 * ssl.c -- Support connection to server through SSL. Most of the
 *          code are copied from Apache source /support/ab.c
 *
 * Copyright 2008 Cornell University.
 * All Rights Reserved.
 *
 ************************************************************************
 *  $Log: cuwa_ssl.c,v $
 *  Revision 1.21  2016/11/28 17:21:31  hy93
 *  buffer size checking should include terminator
 *
 *  Revision 1.20  2016/11/23 17:19:17  hy93
 *  clear buffer before copy the data
 *
 *  Revision 1.19  2016/11/23 16:01:34  hy93
 *  fix incorrect content length
 *
 *  Revision 1.18  2016/11/14 16:36:47  hy93
 *  fix ssl_send_request can't handle situation when remote server send header and content together
 *
 *  Revision 1.17  2016/08/25 15:01:08  hy93
 *  add comment
 *
 *  Revision 1.16  2016/08/24 20:10:39  hy93
 *  add new function that calculate extra buffer size needed
 *
 *  Revision 1.15  2016/08/24 17:33:36  hy93
 *  repeatly call SSL_read until we receive 0 bytes
 *
 *  Revision 1.14  2015/10/07 17:42:02  hy93
 *  merge TwoFactor treee to the head
 *
 *  Revision 1.13.2.5  2015/06/11 14:59:08  hy93
 *  remove CUWA_CA_VERSION_LEN
 *
 *  Revision 1.13.2.4  2015/06/09 19:01:09  hy93
 *  fix windows can not compile
 *
 *  Revision 1.13.2.3  2015/06/09 18:05:24  hy93
 *  do not update cacerts file on file system if its version number is higer than the ca file provided by cuwebauth module which allow us distribute new ca bundle file without new cuwebauth build
 *
 *  Revision 1.13.2.2  2015/01/29 15:26:48  hy93
 *  remove twofactor changes
 *
 *  Revision 1.13.2.1  2014/10/22 19:38:03  hy93
 *  add two factor support
 *
 *  Revision 1.13  2014/10/22 16:20:51  hy93
 *  remove two factor support
 *
 *  Revision 1.12  2014/08/07 15:24:26  hy93
 *  use different openssl functions to verify signature so it also works in openssl 0.9.8
 *
 *  Revision 1.11  2014/07/25 17:33:22  hy93
 *  get weblogin server certificate. verify server signature
 *
 *  Revision 1.10  2012/02/22 15:09:02  hy93
 *  add more error info
 *
 *  Revision 1.9  2010/06/22 20:25:00  hy93
 *  On the safe side when no pool,skip using socket to check if server is available.
 *
 *  Revision 1.8  2010/06/22 14:36:13  hy93
 *  fix build problem introduced by previous check in
 *
 *  Revision 1.7  2010/06/22 14:00:33  hy93
 *  Fix cuwebauth hang during restart when a weblogin server is down
 *
 *  Revision 1.6  2010/06/22 13:53:52  hy93
 *  Fix cuwebauth hang during restart when a weblogin server is down
 *
 *  Revision 1.5  2009/10/06 16:39:43  pb10
 *  Added support for webauth accepting a WA credential via POST in addition to URL based cred.
 *  This is to support large credentials that exceed 2K browser limit of IE.
 *
 *  Revision 1.4  2009/09/24 17:48:53  hy93
 *  write ca certs to cacerts.pem in sessionFilePath
 *
 *  Revision 1.3  2009/09/23 20:06:30  hy93
 *  Fix certificate verification
 *
 *  Revision 1.2  2008/09/16 19:22:58  hy93
 *  add static to functions that are internal in the file
 *
 *  Revision 1.1  2008/09/08 16:03:31  hy93
 *  rename ssl.c to cuwa_ssl.c
 *
 *  Revision 1.8  2008/08/20 18:29:49  hy93
 *  fix buffer might overflow
 *
 *  Revision 1.7  2008/08/16 12:25:12  hy93
 *  remove unneeded trace
 *
 *  Revision 1.6  2008/08/11 04:11:51  hy93
 *  add new function
 *
 *  Revision 1.5  2008/06/03 15:18:05  hy93
 *  remove retry of SSL_do_handshake
 *
 *  Revision 1.4  2008/04/11 03:51:09  gbr4
 *  More ugly hacks to support Win32. Actually I think CVS's acronym is more descriptive (woe).
 *  It actually fully compiles now. I am sure that it doesn't run yet without even testing it :-)
 *
 *  In the very least permit.c needs its ioctl call changed to something more portable.
 *
 *  Revision 1.3  2008/04/10 23:08:06  gbr4
 *  fixed all *compile* errors under msvc9.0 (studio 2008). Still has link errors
 *  and tons of warnings. This might cause regressions.
 *
 *  Revision 1.2  2008/04/03 19:08:07  hy93
 *  change function names
 *
 *  Revision 1.1  2008/04/02 19:46:12  hy93
 *  high availability support
 *
 *
 ************************************************************************
 */
#include <stdlib.h>
#include <cuwa_err.h>
#include <log.h>
#include <apr_strings.h>
#include <apr_time.h>
#include <apr.h>
#include <cuwa_ssl.h>
#include <apr_pools.h>
#include <apr_network_io.h>
#include <apr_version.h>
#include <cuwa_malloc.h>

#include <util.h>
#include <openssl/conf.h>
#include <openssl/x509v3.h>

#include <sys/types.h>
#include "../autoconfig.h"
#ifdef HAVE_UNISTD_H
#include <unistd.h>
#endif

#define CUWA2_LOG_DOMAIN cuwa.ssl

static SSL_CTX *ssl_ctx = NULL;

#if APR_MAJOR_VERSION > 0
#define apr_socket_create_ex   apr_socket_create
#endif

#include  <cacerts.h>

#define CUWA_CA_VERSION "CUWA CA Version:"

int cuwa_ssl_get_ca_version(char *caFileName, apr_pool_t *pool)
{
    int version = 0;   //if no version number found, return 0
    apr_file_t *file = NULL;
    apr_status_t rv;
    int verStrLen = strlen(CUWA_CA_VERSION);

    rv =apr_file_open( &file, caFileName, APR_READ, APR_UREAD|APR_UWRITE, pool );
    if ( rv == APR_SUCCESS )
    {
        char verStr[20];
        apr_size_t len =  sizeof(verStr)-1;

        //read the CA version number on the disk
        rv = apr_file_read(file, verStr, &len);
        if (rv == APR_SUCCESS )
        {
            char *p = strchr(verStr,'\n');
            if (p) *p=0;
            if (strlen(verStr) > verStrLen && !strncmp(verStr, CUWA_CA_VERSION, verStrLen))
            {
                char *p = verStr;

                p += verStrLen;

                version = atoi(p);
                cuwa_trace("ca file version:%d", version);
            }
            else cuwa_trace("no valid version string found %s", verStr);
        }
    }
    if (file) apr_file_close(file);

    return version;
}

void cuwa_ssl_save_ca_certs(char *cakeys, apr_pool_t *pool)
{
  apr_file_t *file = NULL;
  apr_status_t rv;
  char *tmpCAFileName = apr_psprintf(pool,"%s.new", cakeys);

  rv = apr_file_open(&file, tmpCAFileName,APR_WRITE|APR_CREATE, APR_UREAD|APR_UWRITE, pool);
  if (!rv)
  {
      rv = apr_file_puts( (char*)cacerts_u, file);
      apr_file_close( file );
  }
  else
     cuwa_warning("Open cacerts.pem to write failed"); 

 if ( rv )
    CUWA_SHOW_APR_ERROR( rv );

 if (!rv)
 {
     int ver1 = cuwa_ssl_get_ca_version(tmpCAFileName,pool);
     int ver2 = cuwa_ssl_get_ca_version(cakeys,pool);

     cuwa_trace("existing CA file verion=%d, cuwa build CA version=%d",ver2, ver1);
     if ( ver1 >= ver2 )
     {
         //rename the new CA file
         cuwa_trace("updating CA file");
         apr_file_rename( tmpCAFileName, cakeys, pool );
     }
     else apr_file_remove( tmpCAFileName, pool );
 }
}

/**
 * cuwa_ssl_init_context Create and initialize a ssl context
 */
cuwa_err_t cuwa_ssl_init_context(char *caKeys, apr_pool_t *pool)
{
    if (!(ssl_ctx = SSL_CTX_new(SSLv23_client_method()))) {
	cuwa_warning("Could not init SSL CTX");
	return CUWA_ERR_SSL_CONTEXT;
    }
    SSL_CTX_set_options(ssl_ctx, SSL_OP_ALL);
    cuwa_ssl_save_ca_certs(caKeys, pool);

   if ( !SSL_CTX_load_verify_locations(ssl_ctx, caKeys,NULL) ) 
   {
       cuwa_warning("load ca certs failed");
       return CUWA_ERR_SSL_CONTEXT;                                                                            
   }                           
    
   cuwa_trace("load ca certs succeed");

  return CUWA_OK;
}

static int ssl_rand_choosenum(int l, int h)
{
    int i;
    char buf[50];
    srand((unsigned int)time(NULL));
    apr_snprintf(buf, sizeof(buf), "%.0f",
                 (((double)(rand()%RAND_MAX)/RAND_MAX)*(h-l)));
    i = atoi(buf)+1;
    if (i < l) i = l;
    if (i > h) i = h;
    return i;
}

static void ssl_rand_seed()
{
    int nDone = 0;
    int n, l;
    time_t t;
    pid_t pid;
    unsigned char stackdata[256];
    /*
     * seed in the current time (usually just 4 bytes)
     */
    t = time(NULL);
    l = sizeof(time_t);
    RAND_seed((unsigned char *)&t, l);
    nDone += l;

    /*
     * seed in the current process id (usually just 4 bytes)
     */
    pid = getpid();
    l = sizeof(pid_t);
    RAND_seed((unsigned char *)&pid, l);
    nDone += l;
    /*
     * seed in some current state of the run-time stack (128 bytes)
     */
    n = ssl_rand_choosenum(0, sizeof(stackdata)-128-1);
    RAND_seed(stackdata+n, 128);
    nDone += 128;
}

#define HOST_MATCH   1
#define HOST_NOMATCH 0

/* Portable, consistent toupper (remember EBCDIC). Do not use toupper() because
   its behavior is altered by the current locale. */
char cuwa_raw_toupper(char in)
{
  switch (in) {
  case 'a':
    return 'A';
  case 'b':
    return 'B';
  case 'c':
    return 'C';
  case 'd':
    return 'D';
  case 'e':
    return 'E';
  case 'f':
    return 'F';
  case 'g':
    return 'G';
  case 'h':
    return 'H';
  case 'i':
    return 'I';
  case 'j':
    return 'J';
  case 'k':
    return 'K';
  case 'l':
    return 'L';
  case 'm':
    return 'M';
  case 'n':
    return 'N';
  case 'o':
    return 'O';
  case 'p':
    return 'P';
  case 'q':
    return 'Q';
  case 'r':
    return 'R';
  case 's':
    return 'S';
  case 't':
    return 'T';
  case 'u':
    return 'U';
  case 'v':
    return 'V';
  case 'w':
    return 'W';
  case 'x':
    return 'X';
  case 'y':
    return 'Y';
  case 'z':
    return 'Z';
  }
  return in;
}

/*check if cert is wildcard */
static int cuwa_hostmatch(const char *hostname, const char *pattern)
{
  while(1) {
    char c = *pattern++;

    if(c == '\0')
      return (*hostname ? HOST_NOMATCH : HOST_MATCH);

    if(c == '*') {
      c = *pattern;
      if(c == '\0')      /* "*\0" matches anything remaining */
        return HOST_MATCH;

      while(*hostname) {
        /* The only recursive function in libcurl! */
        if(cuwa_hostmatch(hostname++,pattern) == HOST_MATCH)
          return HOST_MATCH;
      }
      break;
    }

    if(cuwa_raw_toupper(c) != cuwa_raw_toupper(*hostname++))
      break;
  }
  return HOST_NOMATCH;
}

static int
cuwa_cert_hostcheck(const char *match_pattern, const char *hostname)
{
  cuwa_trace("hostcheck:%s - %s", match_pattern, hostname);
 
  if(!match_pattern || !*match_pattern ||
      !hostname || !*hostname) /* sanity check */
    return 0;

  if ( !strcasecmp( match_pattern, hostname ) )
      return HOST_MATCH;

  if(cuwa_hostmatch(hostname,match_pattern) == HOST_MATCH)
    return HOST_MATCH;

  cuwa_trace("cuwa_cert_host_check return 0");
  return 0;
}

static int cuwa_ssl_verify_peer_cert( SSL *ssl, char *host)
{
    int certValid = 1;
    X509 *cert;
    long vrc;
    char *p = NULL;

    cuwa_trace("verify peer cert, host=%s", host);
    p = strchr( host, ':' );
    if ( p )
        *p=0;
 
    //verify certificate;
    vrc = SSL_get_verify_result( ssl );
    cert = SSL_get_peer_certificate(ssl);

    cuwa_trace("SSL_get_verify_result return %d", vrc);

    if (  (vrc != X509_V_OK) ||  (!cert) )
        certValid = 0;
    else
    {
        char peer_CN[256];
        int matched = 0;
        STACK_OF(GENERAL_NAME) *altnames;
        int target = GEN_DNS;

        /* get a "list" of alternative names */
        altnames = X509_get_ext_d2i(cert, NID_subject_alt_name, NULL, NULL);
        if ( altnames )
        {
            int numalts;
            int i;

            /* get amount of alternatives, RFC2459 claims there MUST be at least
               one, but we don't depend on it... */
            numalts = sk_GENERAL_NAME_num(altnames);

            /* loop through all alternatives while none has matched */
           for (i=0; (i<numalts) && !matched; i++) 
           {
               /* get a handle to alternative name number i */
               const GENERAL_NAME *check = sk_GENERAL_NAME_value(altnames, i);

              /* only check alternatives of the same type the target is */
              if(check->type == target) 
              {
                  /* get data and length */
                  const char *altptr = (char *)ASN1_STRING_data(check->d.ia5);
                  size_t altlen = (size_t) ASN1_STRING_length(check->d.ia5);

                  switch(target) {
                      case GEN_DNS: /* name/pattern comparison */
                          /* The OpenSSL man page explicitly says: "In general it cannot be
                             assumed that the data returned by ASN1_STRING_data() is null
                             terminated or does not contain embedded nulls." But also that
                             "The actual format of the data will depend on the actual string
                             type itself: for example for and IA5String the data will be ASCII"

                             Gisle researched the OpenSSL sources:
                             "I checked the 0.9.6 and 0.9.8 sources before my patch and
                             it always 0-terminates an IA5String."
                           */
                          if((altlen == strlen(altptr)) &&
                            /* if this isn't true, there was an embedded zero in the name
                               string and we cannot match it. */
                             cuwa_cert_hostcheck(altptr, host))
                             matched = 1;
                             break;
                 }
             }
         }
         GENERAL_NAMES_free(altnames);
       }

       if (!matched ) 
       {
#ifdef WIN32
           char *subj;
#else
           X509_NAME *subj;
#endif
           cuwa_trace("cannot match in alternate names, try CN");
           subj = X509_get_subject_name(cert);
           if ( subj && X509_NAME_get_text_by_NID( subj, NID_commonName, peer_CN, 256) > 0)
           {
               if ( !cuwa_cert_hostcheck( peer_CN, host ) )
                   certValid = 0; 
           }
           else
               certValid = 0;
       }
    }

   X509_free( cert );

   if ( p )
       *p = ':';

   cuwa_trace("verify peer cert return %d, host=%s",certValid, host);

   return certValid;
}

static int cuwa_try_socket_connect(char *serverName, int timeout)
{                           
    cuwa_err_t rc = CUWA_OK;                                                                                      
    int port;
    char *hostName, *host = NULL, *portStr=NULL;
    apr_status_t rv;                                                                                              
    apr_socket_t *sock;
    apr_sockaddr_t *server;                                                                                 
    apr_pool_t *pool = cuwa_malloc_get_pool();                                                                                                                 
    if ( !pool )
    {
        cuwa_warning("no pool. Skip trying socket connect");
        return rc;
    }
    hostName = apr_pstrdup( pool, serverName);

    host = strstr(hostName, "https://");
    FAIL_IF(!host, CUWA_ERR);

    if (host) host+= 8;
         
    portStr = strrchr(host,':');
    if (portStr) 
    {
        *portStr = 0;
        portStr++;
        port = atoi(portStr);
    }
    else
        port = 443;
 
    cuwa_trace("try to connect to %s:%d",host,port);
    rv = apr_socket_create_ex( &sock,  APR_INET, SOCK_STREAM, APR_PROTO_TCP,  pool );                             
    FAIL_IF_APR_SOCK_ERR(rv);                                                                                     
    
    rv = apr_socket_timeout_set( sock, apr_time_from_sec(timeout));                                               
    FAIL_IF_APR_SOCK_ERR(rv);                                                                                     
                                                                                                                  
    rv = apr_sockaddr_info_get(&server,host, APR_INET,port, 0, pool);                      
    FAIL_IF_APR_SOCK_ERR(rv);                                                                                     
                                                                                                                  
    rv = apr_socket_connect(sock, server);                                                                  
    FAIL_IF_APR_SOCK_ERR(rv);                                                                                     
                                                                                                                  
cleanup:                                                                                                          
                                                                                                                  
    if (sock ) apr_socket_close( sock );
    return rc;                                                                                                    
}        
/**
 * cuwa_ssl_connect Connect to loginServer via SSL
 * @param[in] loginServer Server to connect to
 * @param[in] allowInvalidCert When it's true, we don't verify cert
 * @param[in/out] ssl_new Newly created SSL 
 *
 */
static cuwa_err_t cuwa_ssl_connect( char *loginServer, int allowInvalidCert, SSL **ssl_new )
{
    cuwa_err_t rc = CUWA_OK;
    SSL *ssl;
    BIO *bio;
    int i,hDone = 0;
    char *ptr, *host;
    int value;
    char buf[1000]="";

    if (!ssl_ctx)
    {
        cuwa_warning("ssl context is not initialized.");
       return CUWA_ERR_SSL;
    }

    //remove https://
    ptr = strstr( loginServer ,"https://" );
    if ( ptr )
    {
        host = &ptr[8];
    }
    else
        host = loginServer;

    if ((ssl=SSL_new(ssl_ctx)) == NULL)
    {
        cuwa_notice("SSL_new failed");
        return CUWA_ERR_SSL;
    }
    ssl_rand_seed();

    if ((bio = BIO_new_connect(host)) == NULL)
    {
        cuwa_notice("BIO_new_connect failed:%s",host);
        SSL_free(ssl);
        return CUWA_ERR_SSL;
    }
    SSL_set_bio(ssl,bio,bio);

    SSL_set_connect_state(ssl);

    while (!hDone)
    {
        i = SSL_do_handshake(ssl);
        switch (SSL_get_error(ssl,i))
        {
            case SSL_ERROR_NONE:
                hDone=1;
                break;
            case SSL_ERROR_SSL:
            case SSL_ERROR_SYSCALL:
                value = ERR_get_error();
                ERR_error_string_n(value, buf, sizeof(buf)) ;
                cuwa_notice("SSL connection failed:%s. Error:%s", host,buf);
                SSL_free( ssl );
                return CUWA_ERR_HIGH_AVAILABILITY;
                break;
            case SSL_ERROR_WANT_READ:
            case SSL_ERROR_WANT_WRITE:
            case SSL_ERROR_WANT_CONNECT:
                cuwa_trace("Waiting .. sleep(1)");
                apr_sleep(apr_time_from_sec(1));
                break;
            case SSL_ERROR_ZERO_RETURN:
                cuwa_trace("socket closed");
                break;
        }
    }

    if (!allowInvalidCert)
    {

        if ( !cuwa_ssl_verify_peer_cert(ssl, host)  ) 
        {
            cuwa_warning("Invalid SSL certificate on host %s", host);
            rc = CUWA_ERR_SSL_CERT_INVALID;
            SSL_free( ssl );
            ssl = NULL;
        }
        else
            cuwa_trace("certificate verification succeed");

    }
    *ssl_new = ssl;
    return rc;
}

#define CONNECT_TIMEOUT 8

/**
 * cuwa_ssl_send_request Connect to remote host via SSL,then send request and get header and content back
 * @param[in]  host remote host to connect to
 * @param[in]  request Request to send
 * @param[in]  nbytes Size of request buffer
 * @param[in]  allowInvalidCert
 * @param[in/out] rHead Returned Header from remote host
 * @param[in]  len1 length of buffer rHead
 * @param[in/out] rContent returned Content from remote host
 * @param[in]  len2 length of buffer rContent
 *
 */
cuwa_err_t cuwa_ssl_send_request( char *host, char *request, int nbytes, int allowInvalidCert, char *rHead, int len1, char *rContent ,int len2)
{
    int extraBuf = 0;
 
    return cuwa_ssl_send_request_extra_check(host, request, nbytes, NULL,0,allowInvalidCert, rHead, len1, rContent, len2,&extraBuf);
}

cuwa_err_t cuwa_ssl_send_post_request(char *host, char *request, int nbytes, char *postData, int dataLen,int allowInvalidCert, char *rHead, int len1, char *rContent ,int len2)
{
    int extraBuf = 0;

    return cuwa_ssl_send_request_extra_check(host, request, nbytes, postData, dataLen,allowInvalidCert, rHead, len1, rContent, len2,&extraBuf);
}

/****
  send request using OPENSSL library. When output buffer rContent size is smaller than the actual content length,CUWA_ERR_BUFFER_SMALL error is returned and
  extra buffer size needed is returned. Caller should alloclate a larger buffer according to the extraBufSize and try again
****/
cuwa_err_t cuwa_ssl_send_request_extra_check( char *host, char *request, int nbytes, char *postData, int dataLen,int allowInvalidCert, char *rHead, int len1, char *rContent ,int len2, int *extraBufSize) 
{
    SSL *ssl = NULL;
    cuwa_err_t rc = CUWA_OK;
    apr_size_t size;
    apr_status_t rv;
    int extraNeed  = 0;
    char *buffer = NULL;
    int last_bytes_read = 1;
    int total_bytes_read = 0;
    int max_for_this_read = 0;
    char *p = NULL;

    cuwa_assert(request);
    cuwa_assert(host);

    cuwa_trace("ssl_send_request:host=%s,request=%s",host,request);

    //first check if server is available via socket
    rc = cuwa_try_socket_connect(host, CONNECT_TIMEOUT);
    if ( rc )
    {
        cuwa_warning("server %s is not available", host);
        return CUWA_ERR_SOCKET;
    }
    rc = cuwa_ssl_connect( host, allowInvalidCert, &ssl);
    FAIL_IF( rc, CUWA_ERR_SSL);
   
    //send the rquest
    size = SSL_write(ssl,request, nbytes );
    FAIL_IF( size!=nbytes, CUWA_ERR_SSL);

    if (!strncmp(request,"POST",4) && dataLen > 0)
    {
        cuwa_trace("request sent via POST, sending postData=%d",dataLen);
        size = SSL_write(ssl,postData, dataLen );
        FAIL_IF( size!=dataLen, CUWA_ERR_SSL);
        
    }
    //Get response: response can be header and body together
    rv = 0;

    buffer = calloc(len1+len2,1);
    FAIL_IF(!buffer, CUWA_ERR_MEM);

    p = buffer;
    //continue read until we receive 0 byte
    while( last_bytes_read > 0 )
    {
           max_for_this_read = len1 + len2 - 1 - total_bytes_read;
           if ( max_for_this_read < 1 )
                break;
           rv = SSL_read( ssl , p , max_for_this_read );
           FAIL_IF( rv < 0 , CUWA_ERR_SSL );
           cuwa_trace("ssl read return %d,max_for_this_read=%d,total_bytes_read=%d",rv,max_for_this_read,total_bytes_read);
           last_bytes_read = rv;
           total_bytes_read = total_bytes_read + rv;
           p += rv;
    }
 
    if ( total_bytes_read == len1 + len2 -1 )
    {
           char tempBuf[10241];

           cuwa_trace("content buffer may be too small");

           //content buffer might not be large enough for the content received.
           //lets calcuate how many more data need to be read
           do {
               rv = SSL_read( ssl , tempBuf, sizeof(tempBuf)-1 );
               FAIL_IF( rv < 0 , CUWA_ERR_SSL );

               extraNeed += rv;
            }while (rv > 0);

           if ( extraNeed > 0 )
           {
               rc = CUWA_ERR_BUFFER_SMALL;
               *extraBufSize = extraNeed;
           }
      }

      nbytes = total_bytes_read;
      buffer[nbytes] = '\0';
      cuwa_trace("received: %s", buffer);

       if (!rc) 
       {
           char hdEnd[]="\r\n\r\n";
           int headerLen = 0;
           int contentLen = 0;

           //copy the header to rHead and copy the content to rContent
           p = strstr( buffer, hdEnd );
           if ( p )
           {

               *p ='\0';
               headerLen = strlen(buffer);
               if (rHead != NULL) {
                   if ( headerLen >= len1 ) {
                       rc = CUWA_ERR_BUFFER_HEADER_SMALL;
                       *extraBufSize = headerLen - len1 + 1;
                   }
                   else {
                       strcpy(rHead, buffer);
                       cuwa_trace("header %s", rHead);
                   }
               }

               //copy the content to content buffer
               if (!rc && rContent != NULL) {
                   contentLen = nbytes - headerLen - strlen(hdEnd);
                   cuwa_trace("contentLen=%d, returnBufLen=%d", contentLen, len2);    

                   //copy content
                   p += strlen(hdEnd);
                   if ( contentLen >= len2)
                   {
                       rc = CUWA_ERR_BUFFER_SMALL;
                       *extraBufSize = contentLen - len2 + 1; 
                   }else {
                       strcpy(rContent,p);
                       cuwa_trace("content %s",rContent);
                   }
               }
           }else {
                 cuwa_trace("no header");
                  rc = CUWA_ERR_SSL;
           }
      }

    
cleanup:
    if ( ssl )
    {
        SSL_shutdown(ssl);
        SSL_free( ssl );
    }
    if ( buffer ) free(buffer);
    cuwa_trace("return rc=%d", rc);

   return rc;
}
const char id_highAvail_ssl_c[] = "$Id: cuwa_ssl.c,v 1.21 2016/11/28 17:21:31 hy93 Exp $";
