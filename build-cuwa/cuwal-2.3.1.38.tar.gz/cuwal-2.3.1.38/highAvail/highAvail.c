/************************************************************************
 * highAvail.c -- Support cuWebLogin server high availability
 *
 * Copyright 2008 Cornell University.
 * All Rights Reserved.
 *
 ************************************************************************
 *  $Log$
 *  Revision 1.51.2.4  2015/06/30 13:02:40  hy93
 *  apache 2.4 support
 *
 *  Revision 1.51.2.3  2015/04/29 12:58:05  hy93
 *  Add HA get permit server string from weblogin server
 *
 *  Revision 1.51.2.2  2015/01/29 15:21:19  hy93
 *  remove changes for two factor
 *
 *  Revision 1.51.2.1  2014/10/22 19:36:58  hy93
 *  add two factor support
 *
 *  Revision 1.51  2014/10/22 16:19:24  hy93
 *  remove two factor and Apache 2.4 support
 *
 *  Revision 1.50  2014/07/25 17:32:22  hy93
 *  get weblogin server certificate. verify server signature
 *
 *  Revision 1.49  2014/07/23 20:16:47  hy93
 *  Apache 2.4 support
 *
 *  $Log$
 *  Revision 1.51.2.4  2015/06/30 13:02:40  hy93
 *  apache 2.4 support
 *
 *  Revision 1.51.2.3  2015/04/29 12:58:05  hy93
 *  Add HA get permit server string from weblogin server
 *
 *  Revision 1.51.2.2  2015/01/29 15:21:19  hy93
 *  remove changes for two factor
 *
 *  Revision 1.51.2.1  2014/10/22 19:36:58  hy93
 *  add two factor support
 *
 *  Revision 1.50  2014/07/25 17:32:22  hy93
 *  get weblogin server certificate. verify server signature
 *
 *  Revision 1.48  2011/06/02 15:48:07  hy93
 *  Fix memory access violation in IIS
 *
 *  Revision 1.47  2010/07/13 19:43:09  hy93
 *  support self-recovery when HA can't contact weblogin server during initialization
 *
 *  Revision 1.46  2010/06/22 19:49:44  hy93
 *  Fix cuwebauth hang during restart when a weblogin server is down
 *
 *  Revision 1.45  2010/05/06 18:01:10  hy93
 *  remove log rotation feature and checkins that tried to fix log rotation problem
 *
 *  Revision 1.44  2010/03/02 22:15:04  pb10
 *  Changed terminateextension behavior.
 *
 *  Revision 1.43  2010/03/02 15:55:10  hy93
 *  terminate ha thread in IIS when parent terminates
 *
 *  Revision 1.42  2010/02/04 15:19:30  hy93
 *  fix some IIS server didn't send serverVersion and osVersion to weblogin
 *
 *  Revision 1.41  2009/12/10 19:03:49  hy93
 *  use /tmp for saving cacerts when sessionFilePath is not defined
 *
 *  Revision 1.40  2009/09/24 17:48:32  hy93
 *  write ca certs to cacerts.pem in sessionFilePath
 *
 *  Revision 1.39  2009/09/24 13:37:51  hy93
 *  check if process exist before kill it
 *
 *  Revision 1.38  2009/05/18 15:55:28  hy93
 *  fix segfault when login server not available
 *
 *  Revision 1.37  2009/03/11 15:13:09  hy93
 *  bounce some error message to crit level
 *
 *  Revision 1.36  2009/02/11 17:42:18  hy93
 *  fix wrong computing about how long it takes to build WLL
 *
 *  Revision 1.35  2009/02/11 03:50:58  gbr4
 *  Compute the time taken by a HA loop iteration and deduct that from the sleep time at the end of the loop. This is to mitigate the excessive timeout in the SSL library when a server is down. Ideally we would also make the timeout much faster.
 *
 *  Revision 1.34  2009/01/30 18:16:59  hy93
 *  fix ha process is not terminated when user uses gracefull to restart Apache
 *
 *  Revision 1.33  2009/01/30 18:08:16  hy93
 *  fix ha process is not terminated when user uses gracefull to restart Apache
 *
 *  Revision 1.32  2008/10/17 14:25:44  hy93
 *  Rebuild parameter that passed to cuWebLogin at the second time when we build WLL for IIS.Because we can only get IIS version after the first request
 *
 *  Revision 1.31  2008/10/08 15:26:03  hy93
 *  fix variable defined but not used compiler warning
 *
 *  Revision 1.30  2008/10/07 19:32:21  hy93
 *  set log keys in child so log can be written
 *
 *  Revision 1.28  2008/09/08 16:14:58  hy93
 *  change include file because of the rename ssl.h to cuwa_ssl.h
 *
 *  Revision 1.27  2008/09/07 19:35:01  gbr4
 *  rename rand.[ch] to cuwarand.[ch]. Too many packages have a rand.h and some versions of libtool grab the wrong one. This fixes builds against debian 4.0r4.
 *
 *  Revision 1.26  2008/08/27 18:49:25  hy93
 *  Add parameter to the cleanup function that register to pool cleanup to avoid compiler warning on windows
 *
 *  Revision 1.25  2008/08/25 15:32:07  hy93
 *  move code from mod_cuwebauth to ha
 *
 *  Revision 1.24  2008/08/22 18:42:03  hy93
 *  get rid of apache dependency
 *
 *  Revision 1.23  2008/08/14 17:47:44  hy93
 *  add passing Host and User-Agent when sending http request
 *
 *  Revision 1.22  2008/08/11 04:12:15  hy93
 *  move code to ssl.c
 *
 *  Revision 1.21  2008/08/07 22:56:25  hy93
 *  fix my previous check in cause cgi error
 *
 *  Revision 1.20  2008/08/07 15:13:46  hy93
 *  release shm when pool goes away.Increased the max of server string len
 *
 *  Revision 1.19  2008/07/31 03:19:31  gbr4
 *  general paranoia
 *
 *  Revision 1.18  2008/06/03 19:29:41  hy93
 *  initialize WLL to the web login server that we get /HA/servers
 *
 *  Revision 1.17  2008/06/03 17:17:28  hy93
 *  move build WLR to forked child process. Add init WLL to configured weblogin server list
 *
 *  Revision 1.16  2008/06/02 13:25:05  hy93
 *  add ha initializaiton status
 *
 *  Revision 1.15  2008/05/21 18:43:58  hy93
 *  support ha on windows
 *
 *  Revision 1.14  2008/05/06 13:19:28  hy93
 *  pass client version to login server
 *
 *  Revision 1.13  2008/04/24 14:15:47  hy93
 *  move replace_char function to util
 *
 *  Revision 1.12  2008/04/17 15:18:08  hy93
 *  return error if ha init fail
 *
 *  Revision 1.11  2008/04/14 19:21:00  hy93
 *  fix compiler warning
 *
 *  Revision 1.10  2008/04/14 18:08:45  hy93
 *  changed some variable define
 *
 *  Revision 1.9  2008/04/11 03:51:09  gbr4
 *  More ugly hacks to support Win32. Actually I think CVS's acronym is more descriptive (woe).
 *  It actually fully compiles now. I am sure that it doesn't run yet without even testing it :-)
 *
 *  In the very least permit.c needs its ioctl call changed to something more portable.
 *
 *  Revision 1.8  2008/04/10 23:08:06  gbr4
 *  fixed all *compile* errors under msvc9.0 (studio 2008). Still has link errors
 *  and tons of warnings. This might cause regressions.
 *
 *  Revision 1.7  2008/04/09 18:01:09  hy93
 *  remove parameter in cuwa_ha_child_init
 *
 *  Revision 1.6  2008/04/08 15:37:41  hy93
 *  remove unused variable
 *
 *  Revision 1.5  2008/04/08 15:25:28  hy93
 *  Change to use anonymous shm
 *
 *  Revision 1.4  2008/04/08 02:14:34  hy93
 *  Move shm creation to child. Changed the uid of our created child process so all the other children can attach to shm. Add register pool cleanup
so destory shm
 *
 *  Revision 1.3  2008/04/03 23:09:22  pb10
 *  Fixed it to run w/o mod_ssl and so that it could run in single process mode (-X).
 *
 *  Revision 1.2  2008/04/03 19:07:42  hy93
 *  change function names
 *
 *  Revision 1.1  2008/04/02 19:46:18  hy93
 *  high availability support
 *
 *
 ************************************************************************
 */
#include <stdlib.h>
#include <apr_strings.h>
#include <cuwa_err.h>
#include <log.h>
#include <cuwa_ssl.h>
#include <apr_thread_proc.h>
#include <apr_proc_mutex.h>
#include <apr_shm.h>
#include <highAvail.h>
#include <list.h>
#include <cuwarand.h>
#include <wal.h>
#include <cfg.h>
#include <util.h>
#include <cuwa_parse.h>
#include <cuwa_version.h>

#include <sys/types.h>
#include <cuwa_types.h>
#include "../autoconfig.h"


#ifdef HAVE_UNISTD_H
#include <unistd.h>
#if (!defined APACHE_BUILD || AP_SERVER_MINORVERSION_NUMBER <= 2)
#include <unixd.h> //fixme - seperate autoconf test 
#else
#include <mod_unixd.h>
#endif
#endif


#define CUWA2_LOG_DOMAIN cuwa.highavail

#define CUWA_BUILD_WLL_INTERVAL 300      //5 minutes
#define CUWA_LOGIN_SERVER_MAX  8
#define CUWA_LOGIN_SERVER_STRING_MAX 256 

//pointer to shared memory
static  apr_shm_t *cuwa_high_avail_shm;

static uint64 cuwa_high_avail_server_to_use = 0;
static int cuwa_ha_status;   //high availability initialization status;
static char *cuwa_weblogin_config = NULL;

static char *permitServers = NULL;

#ifndef WIN32
  apr_proc_t *cuwa_ha_task_p = NULL;
#else
  HANDLE cuwa_ha_thread = NULL;
#endif

typedef struct cuwa_WLL
{
   int totalServers;
   char servers[CUWA_LOGIN_SERVER_MAX][CUWA_LOGIN_SERVER_STRING_MAX];
}cuwa_WLL_t;

typedef struct cuwa_ha
{
   unsigned int whichWLL;
   cuwa_WLL_t WLLs[2];
   int ha_WLR_status;
}cuwa_ha_t;

#ifdef WIN32
typedef struct cuwa_child_param
{
    cuwa_list *WLR;
    char *passParam;
    void *server;
    apr_pool_t *pool;
}cuwa_child_param_t;
#endif

static int cuwa_ha_build_WLR(char *configServerList, char *passParam, apr_pool_t *pool, cuwa_list **WLR);

static void cuwa_ha_show_WLL(cuwa_WLL_t *WLL )
{
   int index;

   cuwa_trace("Total servers:%d", WLL->totalServers);
   for ( index=0; index< WLL->totalServers; index++)
   {
       cuwa_trace("Server %s", WLL->servers[index]);
       
   }
}

/**
 * cuwa_ha_build_WLR_from_host Build cuWeb login servers list
 * @param[in] server The server we are going to query /HA/servers.
 * @param[in/out] WLR Newly created login servers list
 * @param[in] pool The pool to use
 * @param[out] status
 */
static cuwa_err_t cuwa_ha_build_WLR_from_host( char *server, cuwa_list **WLR, apr_pool_t *pool, char *passParam)
{
    int nbytes;
    char *ptr, *state;
    cuwa_err_t rc = CUWA_OK;
    char buffer[CUWA_HUGE_STRING_LEN];
    char *host, *newServer;
    int total = 0;
    char header[CUWA_HUGE_STRING_LEN];

    host = cuwa_build_ssl_domain( server, pool);

    cuwa_trace("Build WLR, cuwal host:%s", host);

    //request page /HA/servers
    nbytes = apr_snprintf(buffer, sizeof(buffer), "GET /HA/servers?%s HTTP/1.0%sHost: %s%sUser-Agent: %s" CRLF CRLF,passParam,CRLF,&host[strlen("https://")],CRLF,cuwa_version_get_full());

    cuwa_trace("about to send:%s",buffer);

    rc = cuwa_ssl_send_request(server, buffer, nbytes, 0, header, sizeof(header), buffer, sizeof(buffer));

    
    if ( rc == CUWA_OK)
    {
        ptr = strstr(header,"200 OK\r\n");
        FAIL_IF( !ptr,  CUWA_ERR_HIGH_AVAILABILITY );

        //put all the server listed in the content into list
        //first replace line feed with space
        cuwa_util_replace_char( buffer,'\n');
        cuwa_util_replace_char( buffer,'\r');

        ptr = apr_strtok( buffer," ", &state );
        while ( ptr )
        {
            ptr = cuwa_build_ssl_domain( ptr, pool );

            if ( strlen(ptr) > CUWA_LOGIN_SERVER_STRING_MAX )
            {
               //the URL for this login server is too long, we couldn't take it
               cuwa_warning("Web login server URL is too long,%d", strlen(ptr));
            }
            else
            {
                newServer = apr_pstrdup( pool, ptr);
                cuwa_list_append( WLR, newServer );
                total++;
            }
            ptr = apr_strtok( NULL, " ", &state );
        }
    }

cleanup:

    if ( total == 0 )
    {
        cuwa_warning("build WLR failed via server %s: ", host);
        rc = CUWA_ERR_HIGH_AVAILABILITY;
    }
    cuwa_trace("cuwa_ha_get_servers return %d",rc);
    return rc;
}

/**
 * cuwa_ha_get_server_status Query server status
 * @param[in] host The server we are going to query /HA/status.
 * @param[in] passParam parameters to pass to login server
 * @param[out] status
 */
static cuwa_err_t cuwa_ha_get_server_status( char *host ,char *passParam )
{
    int nbytes;
    char buffer[CUWA_HUGE_STRING_LEN];
    char *ptr;
    cuwa_err_t rc = CUWA_OK;
    char header[CUWA_HUGE_STRING_LEN];

    cuwa_trace("get server status:%s", host);

    //request page /HA/status
    nbytes = apr_snprintf(buffer, sizeof(buffer),
                  "GET /HA/status?%s HTTP/1.0%sHost: %s%sUser-Agent: %s" CRLF CRLF,passParam,CRLF,&host[strlen("https://")],CRLF,cuwa_version_get_full());

    rc = cuwa_ssl_send_request( host, buffer, nbytes, 0, header, sizeof(header),buffer,sizeof(buffer) );
    if ( rc == CUWA_OK )
    {
        ptr = strstr(header,"200 OK\r\n");
        FAIL_IF( !ptr,  CUWA_ERR_HIGH_AVAILABILITY );

        ptr = strstr(buffer,"available");
        FAIL_IF( !ptr,  CUWA_ERR_HIGH_AVAILABILITY );

    }
cleanup:
    cuwa_trace("cuwa_ha_get_server_status return %d",rc);
    return rc;

}

/**
 * cuwa_ha_get_permit_servers Query permit servers to use
 * @param[in] host The server we are going to query /HA/permitServers.
 * @param[in] passParam parameters to pass to login server
 * @param[out] permitServers listed in weblogin server
 * @param[out] status
 */
static cuwa_err_t cuwa_ha_get_permit_servers( apr_pool_t *pool, char *host ,char *passParam )
{
    int nbytes;
    char buffer[CUWA_HUGE_STRING_LEN];
    char *ptr;
    cuwa_err_t rc = CUWA_OK;
    char header[CUWA_HUGE_STRING_LEN];

    cuwa_trace("get permit servers:%s", host);

    //request page /HA/permitServers
    nbytes = apr_snprintf(buffer, sizeof(buffer),
                  "GET /HA/permitServers?%s HTTP/1.0%sHost: %s%sUser-Agent: %s" CRLF CRLF,passParam,CRLF,&host[strlen("https://")],CRLF,cuwa_version_get_full());

    rc = cuwa_ssl_send_request( host, buffer, nbytes, 0, header, sizeof(header),buffer,sizeof(buffer) );
    if ( rc == CUWA_OK )
    {
        int bufferLen =0;
        ptr = strstr(header,"200 OK\r\n");
        FAIL_IF( !ptr,  CUWA_ERR_HIGH_AVAILABILITY );

        bufferLen = strlen(buffer);
        if (bufferLen>0 ) 
            permitServers = apr_pstrdup( pool, buffer);
        else cuwa_warning("permit servers string is not correct on %s", host);
    }
cleanup:
    cuwa_trace("cuwa_ha_get_permit_servers return %d",rc);
    return rc;

}

/**
 * cuwa_ha_build_WLL Build live login server list
 * @param[in] WLR CuWeb login servers list.
 * @param[in/out] new_WLL Newly created live Cuweb login servers list.
 * @param[in] passParam parameter pass to login server when doing Get request.
 */
static void cuwa_ha_build_WLL( cuwa_list *WLR, cuwa_WLL_t *new_WLL, char *passParam )
{
    char *serverName = NULL;
    cuwa_err_t rc = CUWA_OK;
    cuwa_node *node = WLR->head;
    int total = 0;

    cuwa_trace("going to build WLL...");

    memset( new_WLL, 0, sizeof(cuwa_WLL_t) );
    while ( node )
    {

        serverName = (char *)node->data;

        rc = cuwa_ha_get_server_status( serverName, passParam );
        if ( rc == CUWA_OK )
        {
            cuwa_trace("server:%s is OK", serverName);
            if ( total > CUWA_LOGIN_SERVER_MAX )
            {
                //we exceed the maximum live server we can hold, just return
                cuwa_warning("There are more live webLogin servers than we can use");
                break;
            }
            strcpy(new_WLL->servers[total], serverName);
            total++;
        }
        else
        {
            cuwa_trace("server:%s is down", serverName);
        }
        node = node->next;
    }
    new_WLL->totalServers = total;

    if ( total == 0 )
    {
        cuwa_warning("build WLL fail: no live weblogin server");
    }
    else
    {
        cuwa_ha_show_WLL( new_WLL);
    }
}

/**
 * cuwa_ha_run build a new WLL every 5 minutes
 * @param[in] configServerList The Cuweb login servers list defined in CUWAWebLoginURL.
 * @param[in] passParam Parameter pass to login server when getting server status
 * @param[in] pool Pool to use.
 */
static void cuwa_ha_run( cuwa_list *WLR ,char *passParam, apr_pool_t *pool)
{
    cuwa_ha_t *cuwa_ha;
    cuwa_WLL_t *WLL;
    unsigned int whichWLL = 0;

#ifdef WIN32
#ifndef APACHE_BUILD
    char *newParam = cuwa_get_client_version();
    char *p = NULL;
#endif
#endif

#ifdef HAVE_UNISTD_H
#if (!defined APACHE_BUILD || AP_SERVER_MINORVERSION_NUMBER <= 2)
    unixd_setup_child();
#else
    ap_unixd_setup_child();
#endif
#endif

    cuwa_ha = apr_shm_baseaddr_get( cuwa_high_avail_shm );
    if ( !cuwa_ha)
    {
       cuwa_warning("Shared memory error");
       return;
    }

    while (1)
    {
	apr_time_t loopstart = apr_time_now();

        if ( !WLR )  
        {
            cuwa_ha_build_WLR( cuwa_weblogin_config, passParam, pool, &WLR );
            if (WLR) 
                cuwa_ha->ha_WLR_status = CUWA_OK;
        }

        if (WLR)
        {
            whichWLL = (cuwa_ha->whichWLL + 1)%2;
            WLL = &cuwa_ha->WLLs[whichWLL];
        
#ifdef WIN32
#ifndef APACHE_BUILD
            //this is just for IIS build. we can't get IIS server version during initialization. 
            //so we have to build server version again
            newParam = cuwa_get_client_version();

            //if we have updated server version and we haven't rebuilt yet, let's rebuild
            if (strstr(passParam,"VerC=unknown&VerS=unknown") &&
                strcmp(newParam, "VerC=unknown&VerS=unknown&VerO=unknown") )
            {
                p = strstr( passParam, "&WAK0Service=" );
                newParam = apr_pstrcat( pool, newParam, p, NULL );
                passParam = newParam;

                cuwa_trace("IIS server version rebuilt, %s", passParam);
            }
        
#endif
#endif

            cuwa_ha_build_WLL( WLR, WLL ,passParam);

            //now we have new WLL list, use the new one
            cuwa_ha->whichWLL = whichWLL;

            cuwa_trace("whichWLL=%d, totalServer=%d", whichWLL, cuwa_ha->WLLs[whichWLL].totalServers);
        }
        
        //sleep
	{
		int taken = apr_time_sec(apr_time_now()) - (apr_time_sec(loopstart));
		if(taken < CUWA_BUILD_WLL_INTERVAL)
			apr_sleep(apr_time_from_sec(CUWA_BUILD_WLL_INTERVAL - taken));
		else
			cuwa_trace("HA loop ran over by %d seconds",taken-CUWA_BUILD_WLL_INTERVAL);
	}
    }
}

#ifdef WIN32
DWORD WINAPI cuwa_ha_run_window(LPVOID param)
{	
    cuwa_child_param_t *childParam = (cuwa_child_param_t *)param;
  
    cuwa_log_set_keys( NULL, childParam->server, NULL );
    cuwa_malloc_set_pool(childParam->pool );
    cuwa_ha_run( childParam->WLR, childParam->passParam, childParam->pool );
       
    return 0;
}
#endif 

static apr_status_t cuwa_ha_cleanup(void *p)
{
#ifndef WIN32
     cuwa_trace("kill HA process");
     if ( cuwa_ha_task_p )
         apr_proc_kill( cuwa_ha_task_p, SIGKILL);
#else
	 CloseHandle(cuwa_ha_thread);
#endif

    return apr_shm_destroy( cuwa_high_avail_shm );
}

static int cuwa_ha_build_WLR(char *configServerList, char *passParam, apr_pool_t *pool, cuwa_list **WLR)
{
    char *serverList;
    char *host, *state = NULL;
    int good = 0;
    cuwa_ha_t *cuwa_ha;
    cuwa_WLL_t *WLL;
    unsigned int whichWLL = 0;
    int rc = CUWA_OK;
 
    serverList = apr_pstrdup( pool, configServerList );
    host = apr_strtok( serverList, " ", &state);

    while ( host )
    {
        host = cuwa_build_ssl_domain( host, pool );
        if ( cuwa_ha_build_WLR_from_host( host, WLR ,pool, passParam) == CUWA_OK)
        {
            good = 1;
            break;
        }
        else
            host = apr_strtok( NULL, " ", &state);
    }

   if ( good )
   { 
       good = 0;
       serverList = apr_pstrdup( pool, configServerList );
       host = apr_strtok( serverList, " ", &state);
       while ( host )
       {
           host = cuwa_build_ssl_domain( host, pool );

           if ( cuwa_ha_get_permit_servers(pool, host, passParam) == CUWA_OK )
           {
               good = 1;
               break;
           }
           else
                host = apr_strtok( NULL, " ", &state);
       }
    }

    if ( good )
    {
        cuwa_ha = apr_shm_baseaddr_get( cuwa_high_avail_shm );
        if ( !cuwa_ha)
        {
            cuwa_warning("Shared memory error");
            return CUWA_ERR_HIGH_AVAILABILITY;
        }
        memset( cuwa_ha, 0, sizeof(cuwa_ha_t));
        
        //initialize WLL to the login server that we used to build WLR
        whichWLL = 0;
        WLL = &cuwa_ha->WLLs[whichWLL];
        strncpy(WLL->servers[0], host,CUWA_LOGIN_SERVER_STRING_MAX);
        WLL->servers[0][CUWA_LOGIN_SERVER_STRING_MAX-1]=0;
        WLL->totalServers = 1;
        cuwa_ha->whichWLL = whichWLL;
    }
    else
    {   cuwa_crit("Build WLR failed. Check if CUWAWebLoginURL is defined correctly ( %s )",configServerList);
        rc = CUWA_ERR_HIGH_AVAILABILITY;
    }
    return rc;
}

/**
 * cuwa_ha_init Initialize high availability. It takes the web login servers from CUWAWebLoginURL and try to build WLR.
 *              Then fork a child process to build WLL every 5 minutes.
 * @param[in] configServerList Server string defined in CUWAWebLoginURL.
 * @param[in] principal kerberos principal 
 * @param[in] pool The pool to use.
 */
cuwa_err_t cuwa_ha_init(void *server, apr_pool_t *pool)
{
  apr_status_t rv = APR_SUCCESS;
#ifdef WIN32
  cuwa_child_param_t *param;
  void *s = server;
#endif
  cuwa_err_t rc = CUWA_ERR_HIGH_AVAILABILITY;
  char *clientVersion = cuwa_get_client_version();
  char *passString;
  char *configServerList = NULL, *principal=NULL,*kerberosP;
  CUWACfg_t *cfg;
  cuwa_list *WLR = NULL;
  char *sessionFilePath = NULL, *caKeys = NULL;
  cuwa_ha_t *cuwa_ha = NULL;

  while ( server )
  {
      cfg = cuwa_wal_get_config_from_server( server );

      if ( cfg )
      {     
          if ( !configServerList && CFG_CUWAWebLoginURL(cfg) )
              configServerList = CFG_CUWAWebLoginURL(cfg);

          if ( !sessionFilePath && CFG_CUWAsessionFilePath(cfg) )
              sessionFilePath = CFG_CUWAsessionFilePath(cfg);

          kerberosP = CFG_CUWAKerberosPrincipal(cfg);
          if ( kerberosP )
          {
              if (!principal)
                  principal = apr_pstrdup(pool, kerberosP );
              else if ( !strstr( principal, kerberosP ) )
              {
                  if ( strlen( principal ) > 1024 )
                      break;

                  principal = apr_psprintf( pool, "%s,%s", principal, kerberosP);
              }
           }
      }
      server = cuwa_wal_get_next_server(server);
   }

  if (!configServerList)
      cuwa_crit("No web login server defined. Please define CUWAWebLoginURL in conf file.");
  FAIL_IF(!configServerList, rc);

  if ( !SSL_library_init() )
  {
      cuwa_crit("SSL_library_init: Can't initialize SSL");
      FAIL_IF(rc, rc);
  } 

  caKeys = apr_psprintf( pool, "%s/cacerts.pem", sessionFilePath?sessionFilePath:"/tmp");
  rc = cuwa_ssl_init_context(caKeys, pool);
  if ( rc)
      cuwa_crit("Couldn't initialize SSL context");
  FAIL_IF(rc, rc);

  rv = apr_shm_create( &cuwa_high_avail_shm, sizeof(cuwa_ha_t), NULL, pool );
  if ( rv )
  {
      cuwa_crit("Create shm failed");
      CUWA_SHOW_APR_ERROR( rv );
  }
  FAIL_IF(rv, rc);
  
  cuwa_ha = apr_shm_baseaddr_get( cuwa_high_avail_shm );

  apr_pool_cleanup_register( pool, NULL, cuwa_ha_cleanup, apr_pool_cleanup_null);

  if ( principal )
      passString = apr_psprintf(pool, "%s&WAK0Service=%s",clientVersion,principal);
  else
      passString = clientVersion;

  cuwa_util_replace_char( configServerList, '\t' );
  cuwa_util_replace_char( configServerList, ',' );
  cuwa_util_replace_char( configServerList, ';' );

  rc = cuwa_ha_build_WLR(configServerList, passString, pool,&WLR);
  if ( rc )
  {
      cuwa_ha->ha_WLR_status = CUWA_ERR_HIGH_AVAILABILITY;
      cuwa_weblogin_config = apr_pstrdup( pool, configServerList);
      FAIL_IF( !cuwa_weblogin_config, rc );
  }
  else
      cuwa_ha->ha_WLR_status = CUWA_OK;

  rc = CUWA_OK;

#ifndef WIN32
  cuwa_ha_task_p = apr_pcalloc( pool, sizeof( apr_proc_t));

  rv = apr_proc_fork( cuwa_ha_task_p, pool);
  if ( rv == APR_INCHILD )
  {
      apr_initialize();
      cuwa_ha_run( WLR, passString, pool );
  }
#else
  param = (cuwa_child_param_t *)apr_pcalloc(pool, sizeof(cuwa_child_param_t) );
  if ( param )
  {
      param->WLR = WLR;
      param->passParam = passString;
      param->server = s;
      param->pool = pool;
      cuwa_ha_thread = CreateThread(NULL,0,cuwa_ha_run_window,param,0,NULL); 
  }
#endif
  
cleanup:
  cuwa_ha_status = rc;
 
  return rc;
}

/**
 * cuwa_ha_get_login_server Find a web login server
 *
 * @param[in] cookie CUWALastWeblogin cookie.
 * @param[in] newCookie The new CUWALastWeblogin cookie that caller should be set in browser.
 * @param[in] pool The pool to use.
 * @param[out] login server to use
 */
char *cuwa_ha_get_login_server( char *cookie, char **newCookie, apr_pool_t *pool)
{
   char *loginServer = NULL;
   uint64 serverToUse;
   cuwa_ha_t *highAvail = NULL;
   cuwa_WLL_t *WLL;
   unsigned int whichWLL;

   if ( cuwa_ha_get_init_status() )
       return NULL;

   cuwa_assert(cuwa_high_avail_shm);
   highAvail = (cuwa_ha_t *)apr_shm_baseaddr_get(cuwa_high_avail_shm);
   if (!highAvail)
   {
       cuwa_warning("high availablity:shm error");
       return NULL;
   }
   whichWLL = highAvail->whichWLL;
   WLL = &highAvail->WLLs[whichWLL];

   cuwa_trace("whichWLL=%d, totalServers=%d", whichWLL, WLL->totalServers);

   //calculate serverToUse
   if ( WLL->totalServers == 0)
   {
       cuwa_warning("no live web login server available");
       return loginServer;
   }

   if ( cookie )
   {
       serverToUse = atoi(cookie);
       cuwa_trace("have cookie, value=%d", serverToUse);
       serverToUse++;
   }
   else
   {
       serverToUse = cuwa_high_avail_server_to_use++;
   }
   serverToUse = serverToUse%(WLL->totalServers);
   cuwa_trace("serverToUse=%d",serverToUse);
   loginServer = WLL->servers[serverToUse];

   *newCookie = apr_psprintf( pool, "%u", (int)serverToUse );

   cuwa_trace("loginServer %s",loginServer);

   return loginServer;
}

/**
 * cuwa_ha_child_init Randomize serverToUse in the hope that each child will use a different login server at startup.
 */
void cuwa_ha_child_init()
{
   cuwa_high_avail_server_to_use = cuwa_rand64_g();

   cuwa_trace("server_to_use initialized to :%lu", cuwa_high_avail_server_to_use);
}

/**
 * cuwa_ha_init_status Return the status of high availability initialization
 */
int cuwa_ha_get_init_status()
{
    cuwa_ha_t *cuwa_ha = NULL;
    int status;

    if (!cuwa_ha_status)
    {
        cuwa_ha = (cuwa_ha_t *)apr_shm_baseaddr_get(cuwa_high_avail_shm); 
        if (!cuwa_ha) 
        {
            cuwa_warning("Shared memory error");                                                                                                          
            return CUWA_ERR_HIGH_AVAILABILITY;                                                                                                            
        }  
        status = cuwa_ha->ha_WLR_status;
    }
    else
        status = cuwa_ha_status;

    return status;
}

/**
 * cuwa_ha_get_permit_server_string 
 *
 * Get permit server strings that are fetched from login server
 * @param[out] permit servers 
 */
char *cuwa_ha_get_permit_server_string()
{
    return permitServers;
}

const char id_highAvail_highAvail_c[] = "$Id$";
