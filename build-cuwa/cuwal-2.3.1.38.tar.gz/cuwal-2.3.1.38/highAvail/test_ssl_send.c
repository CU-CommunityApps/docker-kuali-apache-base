#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <cuwa_err.h>


int get_header_content(char *buffer, int bufLen, char *rHead, int len1, char *rContent, int len2, int *extraBufSize);
void HexDump( char *label,void *ptr, int len);

int main(int argc, char* argv[])
{
    char *header="HTTP/1.1 200 OK\r\nDate: Mon, 28 Nov 2016 14:33:00 GMT\r\nServer: Apache\r\nContent-Length: 101\r\nConnection: close";
    char *content = "testing content\nweb1.login.cornell.edu\nweb2.login.cornell.edu\nweb3.login.cornell.edu\nweb4.login.cornell.edu"; 
    char *buffer=NULL,*rHead=NULL,*rContent=NULL;
    int extraBufSize, rHeadLen, rContentLen;
    int rc = 0,bufLen=0;
    char *hdEnd="\r\n\r\n";
    char *bufOrigin = NULL;

    rHeadLen = strlen(header);
    rContentLen = strlen(content);

    printf("header length:%d,content length:%d\n",rHeadLen,rContentLen);
    bufLen = rHeadLen + strlen(hdEnd) + rContentLen ;
    buffer = malloc(bufLen+1);
    if (!buffer) goto cleanup;

    bufOrigin = malloc(bufLen+1);
    if (!bufOrigin) goto cleanup;

    strcpy(buffer,header);
    strcat(buffer, hdEnd);
    strcat(buffer, content);
  
    //make a copy of the buffer
    strcpy(bufOrigin, buffer);

    //TEST #1: no content buffer, enough header buffer
    rHead = malloc(rHeadLen+10);
    if (!rHead) goto cleanup;
 
    extraBufSize = 0;
    rc = get_header_content(buffer, bufLen, rHead,rHeadLen+10, rContent, 0, &extraBufSize);        

    if (rc) 
         printf("Testing #1 failed with status %d\n", rc);
    else {
         //compare if we get the header as expected
         if ( strcmp(header, rHead) )
         {
             printf("Testing #1 returned unexpected header\n");
             printf("returned header:%s\n",rHead);
         }    
         else
             printf("Testing #1 succeed\n");
    }
   
    //TEST #2: enough header buffer, enough content buffer
    rContent = malloc(rContentLen +10);
    if (!rContent) goto cleanup;

    //restore buffer
    strcpy(buffer,bufOrigin);
    rc = get_header_content(buffer, bufLen, rHead,rHeadLen+10, rContent, rContentLen+10, &extraBufSize);

    if (rc)
         printf("Testing #2 failed with status %d\n", rc);
    else {
         //compare if we get the content as expected
         if ( strcmp(content, rContent) )
         {
             printf("Testing #2 returned unexpected content\n");
             printf("returned content:%s\n",rContent);
         }
         else 
             printf("Testing #2 succeed\n");
    }

    free(rHead);
    rHead = NULL;
   
   //TEST #3: insufficient header buffer, enough content buffer
   rHead = malloc(rHeadLen-10);
   if (!rHead) goto cleanup;

    extraBufSize = 0;
    strcpy(buffer,bufOrigin);

    rc = get_header_content(buffer, bufLen, rHead,rHeadLen-10, rContent, rContentLen+10, &extraBufSize);
    if (rc == CUWA_ERR_BUFFER_HEADER_SMALL && extraBufSize == 11)
         printf("Testing #3 succeed\n");
    else
         printf("Testing #3 failed with status %d\n",rc); 

    free(rHead);
    rHead = NULL;

   //TEST #4: insufficient content buffer
   free(rContent);
   rContent = NULL;

   rContent = malloc(rContentLen);
   if (!rContent) goto cleanup;

   rHead = malloc(rHeadLen+1);
   if (!rHead) goto cleanup;

    //restore buffer
    strcpy(buffer,bufOrigin);
    extraBufSize = 0;
    rc = get_header_content(buffer, bufLen, rHead,rHeadLen+1, rContent, rContentLen, &extraBufSize);

    if (rc == CUWA_ERR_BUFFER_SMALL && extraBufSize == 1)
         printf("Testing #4 succeed\n");
    else {
         printf("Testing $4 failed with status %d, extraBufSize=%d\n",rc, extraBufSize);
         if (!rc) printf("Content returned %s\n",rContent);
    }

    // TEST #5: received header without content
    extraBufSize = 0;
    free(rHead);
    rHead = malloc(rHeadLen+1);
    if (!rHead) goto cleanup;
    free(rContent);
    rContent = malloc(rContentLen);
    if (!rContent) goto cleanup;

    int t5_bufLen = rHeadLen + strlen(hdEnd) + 1;
    char* t5_buffer = malloc(t5_bufLen+1);
    if (!t5_buffer) goto cleanup;

    strcpy(t5_buffer,header);
    strcat(t5_buffer, hdEnd);
    t5_buffer[t5_bufLen] = '\0';

    rc = get_header_content(t5_buffer, t5_bufLen, rHead,rHeadLen+1, rContent, rContentLen, &extraBufSize);
    printf("debug: Testing #5: rc:%d extraBufSize:%d rHead:%s rContent:%s\n",rc,extraBufSize,rHead,rContent);
    if (rc == CUWA_OK && extraBufSize == 0 && strlen(rHead)==(rHeadLen) && strlen(rContent)==0 )
         printf("Testing #5 succeed\n");
    else
         printf("Testing #5 failed with status %d\n",rc);

cleanup:
    if (buffer) free(buffer);
    if (bufOrigin) free(bufOrigin);
    if (rHead) free(rHead);
    if (rContent) free(rContent);
    
    return 0;
}

int get_header_content(char *buffer, int nbytes, char *rHead, int len1, char *rContent, int len2, int *extraBufSize)
{
    char hdEnd[]="\r\n\r\n";
    int headerLen = 0;
    int contentLen = 0;
    int rc = CUWA_OK;
    char *p = NULL;

    //copy the header to rHead and copy the content to rContent
    p = strstr( buffer, hdEnd );
    if ( p )
    {
         *p ='\0';
         headerLen = strlen(buffer);
         if (rHead != NULL) {
             if ( headerLen >= len1 ) {
                rc = CUWA_ERR_BUFFER_HEADER_SMALL;
                *extraBufSize = headerLen - len1 + 1;
             }
             else {
                 strcpy(rHead, buffer);
             }
         }

         //copy the content to content buffer
         if (!rc && rContent != NULL) {
             contentLen = nbytes - headerLen - strlen(hdEnd);

             //copy content
             p += strlen(hdEnd);
             if ( contentLen >= len2)
             {
                 rc = CUWA_ERR_BUFFER_SMALL;
                 *extraBufSize = contentLen - len2 + 1;
             }else {
                 strcpy(rContent,p);
             }
         }
    }else {
     printf("no header\n");
     rc = CUWA_ERR_SSL;
    }
 
    return rc;
}

