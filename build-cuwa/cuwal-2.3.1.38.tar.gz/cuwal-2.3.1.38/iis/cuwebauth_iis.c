/************************************************************************
 * cuwebauth_iis.c -- CUWebAuth IIS Extension
 *
 * Copyright 2008 Cornell University.
 * All Rights Reserved.
 *
 ************************************************************************
 *  $Log$
 *  Revision 1.80.2.10  2015/09/15 16:16:42  hy93
 *  fix IIS still depends on CUWApermitServer define
 *
 *  Revision 1.80.2.9  2015/08/18 14:13:24  hy93
 *  add debugging log
 *
 *  Revision 1.80.2.8  2015/05/12 19:49:29  hy93
 *  add cache-control etc headers
 *
 *  Revision 1.80.2.7  2015/05/01 13:21:54  hy93
 *  fix typo in previous checkin
 *
 *  Revision 1.80.2.6  2015/04/30 19:57:08  hy93
 *  fix post request failed for two-factor double trip to webLogin
 *
 *  Revision 1.80.2.5  2015/04/29 18:44:08  hy93
 *  write post data only if it is POST request
 *
 *  Revision 1.80.2.4  2015/04/29 18:12:28  hy93
 *  add debugging message
 *
 *  Revision 1.80.2.3  2015/04/29 13:59:26  hy93
 *  fix sometimes error page doesn't show properly. Add getting permitServer from webLogin
 *
 *  Revision 1.80.2.2  2015/01/29 16:46:49  hy93
 *  remove changes for two factor
 *
 *  Revision 1.80.2.1  2014/10/22 19:39:24  hy93
 *  add two factor support
 *
 *  Revision 1.80  2014/10/22 16:24:20  hy93
 *  remove two factor support
 *
 *  Revision 1.79  2014/07/25 17:47:41  hy93
 *  save login server url in the request
 *
 *  Revision 1.78  2013/04/08 18:10:50  hy93
 *  when cacheURL is the same of unparsed_uri, we don't need to change mapped_path
 *
 *  Revision 1.77  2013/04/08 17:37:07  hy93
 *  add debugging log
 *
 *  Revision 1.76  2013/04/08 16:52:16  hy93
 *  remove previous added log message
 *
 *  Revision 1.75  2013/04/08 15:04:14  hy93
 *  add log to see server varable, will remove later
 *
 *  Revision 1.74  2013/04/02 19:58:14  hy93
 *  debugging info
 *
 *  Revision 1.73  2013/04/02 16:04:39  hy93
 *  add log message
 *
 *  Revision 1.72  2013/02/26 15:15:19  hy93
 *  back out check in 1.71
 *
 *  Revision 1.71  2013/02/25 20:56:49  hy93
 *  do not escape &
 *
 *  Revision 1.70  2012/09/14 18:58:15  hy93
 *  makde using cacheURL default
 *
 *  Revision 1.69  2012/09/06 15:02:13  hy93
 *  Fix previous check in broke test harness t08post.t
 *
 *  Revision 1.68  2012/07/23 16:59:34  hy93
 *  add comment to document previous check in
 *
 *  Revision 1.67  2012/07/02 18:39:59  hy93
 *  when a filter is used in IIS that changes the request path, cuwebauth will generate error when it redirect to original url since cuwebauth see changed request path. This change is to use cache_url insteal of actual received request to resolve this issue
 *
 *  Revision 1.66  2011/09/16 19:43:05  hy93
 *  Try to fix HA failed with error Either the application has not called WSAStartup, or WSAStartup failed when call apr_socket_create
 *
 *  Revision 1.65  2011/08/05 18:38:11  hy93
 *  remove previous check in
 *
 *  Revision 1.64  2011/08/05 18:09:40  hy93
 *  escape space in url
 *
 *  Revision 1.63  2011/06/02 17:15:09  pb10
 *  add reset of version string.
 *
 *  Revision 1.62  2011/06/02 15:17:37  pb10
 *  Fix diagnostic for version string issue.  Add more diagnostics
 *
 *  Revision 1.61  2011/06/01 17:19:00  pb10
 *  Fix and diagnostics for garbled version string issue.
 *
 *  Revision 1.60  2011/03/18 16:14:31  hy93
 *  remove impersonate support
 *
 *  Revision 1.59  2011/02/24 19:40:58  hy93
 *  IIS impersonate support
 *
 *  Revision 1.58  2011/02/24 18:35:17  hy93
 *  support IIS impersonation
 *
 *  Revision 1.57  2010/07/20 18:15:09  hy93
 *  add debug log
 *
 *  Revision 1.56  2010/07/14 15:32:06  hy93
 *  support self-recovery when HA can't contact weblogin server during initialization
 *
 *  Revision 1.55  2010/05/06 18:01:50  hy93
 *  remove log rotation feature and checkins that tried to fix log rotation problem
 *
 *  Revision 1.54  2010/03/30 15:36:58  hy93
 *  Fix log.mutext can not be opened/created
 *
 *  Revision 1.53  2010/03/02 22:15:04  pb10
 *  Changed terminateextension behavior.
 *
 *  Revision 1.52  2010/03/02 15:55:58  hy93
 *  create a separate pool for ha
 *
 *  Revision 1.51  2010/02/21 22:49:36  pb10
 *  Another fix.
 *
 *  Revision 1.50  2010/02/21 21:06:55  pb10
 *  Switch from APR to WIN mutex.
 *
 *  Revision 1.49  2010/02/20 19:56:34  pb10
 *  Attempt at fixing IIS crash.
 *
 *  Revision 1.48  2009/11/17 18:49:16  hy93
 *  implement log rotation
 *
 *  Revision 1.47  2009/10/28 19:53:07  pb10
 *  Typo.
 *
 *  Revision 1.46  2009/10/28 17:44:11  pb10
 *  Fix typo.
 *
 *  Revision 1.45  2009/10/27 19:24:32  pb10
 *  Fix POST reading algorithm
 *
 *  Revision 1.44  2009/10/20 19:42:27  gbr4
 *  attempt to resolve IIS POSTed credential read failure
 *
 *  Revision 1.43  2009/10/13 17:10:29  pb10
 *  Fx build issue
 *
 *  Revision 1.42  2009/10/13 14:02:36  pb10
 *  fix typo.
 *
 *  Revision 1.41  2009/10/06 16:39:43  pb10
 *  Added support for webauth accepting a WA credential via POST in addition to URL based cred.
 *  This is to support large credentials that exceed 2K browser limit of IE.
 *
 *  Revision 1.40  2009/06/12 16:54:29  pb10
 *  Commit IIS / AD integration.  This is not yet complete, but the
 *  code shouldn't affect AD-less configuration.
 *
 *  Revision 1.39  2009/04/21 16:46:30  hy93
 *  Fix cuwebauth variables are empty when get from header
 *
 *  Revision 1.38  2009/04/20 17:02:11  hy93
 *  post data encryption support
 *
 *  Revision 1.37  2009/03/11 15:17:01  hy93
 *  Support display initialization error messages to browser
 *
 *  Revision 1.35  2009/02/13 16:29:58  pb10
 *  CUWAReturnURL now accepts a %p that will be replaced with the
 *  original path of the URL (without the file).
 *
 *  Revision 1.34  2009/02/12 19:28:23  pb10
 *  Check from cuwal2sid cookie on return from cuwl.  If present, generates 400
 *  error and includes User-agent in message and log.  This improves error message
 *  in case where old webauth is trying to act as mid-tier using the old
 *  cookie.
 *
 *  Revision 1.33  2009/02/11 06:26:02  pb10
 *  Removal of cuwal2sid cookie.
 *
 *  Revision 1.32  2009/02/10 15:12:37  hy93
 *  print remote IP in IIS log
 *
 *  Revision 1.31  2009/02/05 13:09:48  hy93
 *  fix cuwa variables are empty in HTTP header in classic ASP
 *
 *  Revision 1.30  2009/01/08 18:24:33  pb10
 *  Support for ErrorDocument
 *
 *  Revision 1.29  2008/12/16 19:10:23  hy93
 *  fix authenticaiton is processed eventhough no require directive is defined
 *
 *  Revision 1.28  2008/12/12 18:26:26  hy93
 *  fix invalid pointer was used to access request's notes field that cause IIS crush
 *
 *  Revision 1.27  2008/12/08 21:34:45  hy93
 *  remove a left over code that should be removed with previous checkin
 *
 *  Revision 1.26  2008/11/20 15:42:54  hy93
 *  fix iis crash when request is from https
 *
 *  Revision 1.25  2008/11/05 16:08:44  hy93
 *  Fix parameter in a log message
 *
 *  Revision 1.24  2008/10/29 02:52:19  pb10
 *  added diagnostics for tracing handlers
 *
 *  Revision 1.23  2008/10/28 18:12:06  pb10
 *  Fix IIS POST issue
 *
 *  Revision 1.22  2008/10/17 14:22:35  hy93
 *  Add flag so we only build server version once
 *
 *  Revision 1.21  2008/10/09 16:20:33  hy93
 *  move common code in cuwa_wal_set_cookie to auth.c
 *
 *  Revision 1.20  2008/10/08 13:48:02  hy93
 *  implement cuwa_wal_get_log_error so log can appears in error page
 *
 *  Revision 1.19  2008/10/07 19:36:14  hy93
 *  iis log support
 *
 *  Revision 1.18  2008/09/30 17:29:30  hy93
 *  add portal support
 *
 *  Revision 1.17  2008/09/29 16:23:34  pb10
 *  Fixed crash caused by event/WaitSingleObject. Switched to async.
 *
 *  Revision 1.16  2008/09/27 13:33:55  pb10
 *  t03echo almost working, issue with test harness remains
 *
 *  Revision 1.15  2008/09/26 15:26:56  hy93
 *  fix argument disappeared in url after user logged in
 *
 *  Revision 1.14  2008/09/25 18:42:46  hy93
 *  add port support in virtualHost define
 *
 *  Revision 1.13  2008/09/25 16:33:44  hy93
 *  add include file and modified log domain
 *
 *  Revision 1.12  2008/09/22 18:39:01  hy93
 *  add initialize permit ha
 *
 *  Revision 1.11  2008/09/19 19:57:36  hy93
 *  integrate iis config
 *
 *  Revision 1.10  2008/09/17 04:17:45  pb10
 *  Login and page access is basically working.
 *
 *  Revision 1.9  2008/09/14 10:59:46  pb10
 *  interim commit.
 *
 *  Revision 1.8  2008/09/13 15:49:05  pb10
 *  Fix up version stuff
 *
 *  Revision 1.7  2008/09/13 13:23:53  pb10
 *  Add IIS code and cleanup apache dependency in cuwa_version.c.
 *  Fix naming and positioning of DAV functions in wal.h.
 *
 *  Revision 1.6  2008/09/12 19:17:32  pb10
 *  redirect to weblogin
 *
 *  Revision 1.5  2008/09/12 04:22:31  pb10
 *  HA working, log working
 *
 *  Revision 1.4  2008/09/11 20:31:47  pb10
 *  Compiles
 *
 *  Revision 1.3  2008/09/11 04:43:02  pb10
 *  Most of the functionality is here.
 *
 *  Revision 1.2  2008/09/08 16:05:51  pb10
 *  Minor update
 *
 *  Revision 1.1  2008/09/05 04:57:01  pb10
 *  Skeleton extension w/ librariesbuilds
 *
 *
 ************************************************************************
 */
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <Wininet.h>
#include <httpext.h>
#include <stdio.h>
#include <stdlib.h>
#include <apr_tables.h>
#include <apr_strings.h>
#include <apr_pools.h>
#include <cfg.h>
#include <cuwa_types.h>
#include <cuwa_malloc.h>
#include <highAvail.h>
#include <cuwa_err.h>
#include <log.h>
#include <iis_log.h>
#include <wal.h>
#include <session.h>
#include <iis_cfg.h>
#include <cuwa_version.h>
#include <permit_ha.h>
#include <util.h>
#include <sspiutil.h>

// FIXME: create a new log domain
#define CUWA2_LOG_DOMAIN cuwa.iis

#define OK 0
#define DECLINED -1
#define DONE -2

#define POST_BUFSIZE 1024

#define CUWA_MAGIC_ARG "CUWACRED="
#define CUWA_SID_COOKIE_NAME "cuwal2sid="
#define CUWA_SITE_COOKIE_NAME "cuweblogin2="
#define CUWA_SITE_COOKIE_DISCARDED "cookiediscarded"
#define CUWL_REDIR_SIGNATURE(u)  (strstr((u),CUWA_MAGIC_FILE)?1:0)
#define CUWA_REDIR_SIGNATURE(u)  (strstr((u),CUWA_MAGIC_ARG)?1:0)

#define WRITELINE(s,b)                             \
{                                                  \
    code = write_request( (s), (b), strlen( (b)),0); \
    if (code) goto cleanup;                        \
    code = write_request( (s), "\r\n", 2,0 );        \
    if (code) goto cleanup;                        \
}



#define IIS_TRACE() cuwa_iis_trace_error(__LINE__)
  
typedef struct cuwa_request
{
    EXTENSION_CONTROL_BLOCK *ecb;
    CUWACfg_t *cfg;
    cuwa_iis_dir_config *dirConfig;
    cuwa_iis_server *server;
    apr_pool_t *pool;
    char *method;
    char *path;
    //uri_received is used to save the request that IIS passed to cuwebauth. Then use it to set the subrequest.
    char *uri_received;
    char *unparsed_uri;
    char *mapped_path;
    char *server_name;
    char *port;
    int ssl;
    apr_table_t *notes;
    apr_table_t *headers_in;
    apr_table_t *headers_out;
    apr_table_t *env;
    int nocache;
    char *post_data;
    int post_len;
    HANDLE evt;
    char *remote_IP;
} cuwa_request_t;

static CUWACfg_t *cuwa_root_cfg = NULL;
static void *cuwa_root_vhost = NULL;
static apr_pool_t *cuwa_root_pool = NULL;
static apr_pool_t *cuwa_ver_pool = NULL;
static apr_pool_t *cuwa_ha_pool = NULL;
static char *cuwa_server_version = "IIS";
static char *cuwa_iis_cfg_error_msg = NULL;
static int cuwa_iis_init = 0;
static int cuwa_server_version_created = 0;

static int cuwa_subrequest(cuwa_request_t *request);
static void cuwa_iis_trace_error();
static void cuwa_dump_req(cuwa_request_t *request);
static char *cuwa_get_status_text(apr_pool_t *pool, int status);
static char *cuwa_get_server_variable(void * request, char *name);
static int cuwa_process_inbound(EXTENSION_CONTROL_BLOCK *ecb);
static void cuwa_parse_headers(apr_pool_t *pool, char *buf, apr_table_t *in);
static int cuwa_get_session_from_req(cuwa_request_t *request, char *path, char **credout, char **sidout);
static char * cuwa_divine_html(cuwa_request_t *r, int status);
static char *cuwa_create_header_string(cuwa_request_t *r,apr_table_t *headers);
static int cuwa_request_restore(cuwa_request_t *r, cuwa_session_t *session);
static char * cuwa_get_cookie(cuwa_request_t *r, char *name);
static cuwa_request_t *cuwa_request_init(EXTENSION_CONTROL_BLOCK *ecb);
static void cuwa_request_destroy(cuwa_request_t *r);
static int cuwa_iis_portal_handler(cuwa_request_t *r);


//////////////////////////////////////////////
// WAL Callback functions
//////////////////////////////////////////////
void cuwa_wal_save_error(void *request, int status, int code, char *msg)
{
    char *codeStr, *statusStr;
    cuwa_request_t *r = (cuwa_request_t *)request;

    cuwa_trace("cuwa_request_save_error: status %d code %d %s",status,code,msg);
    codeStr = apr_psprintf( r->pool,"%d",code );
    statusStr = apr_psprintf( r->pool,"%d",status );
    apr_table_set(r->notes,"CUWL-error-status",statusStr);
    apr_table_set(r->notes,"CUWL-error-code",codeStr);
    apr_table_set(r->notes,"CUWL-error-msg",msg);
}

int cuwa_wal_show_error(void *request)
{
    cuwa_request_t *r = (cuwa_request_t *)request;
    char *codeStr, *statusStr, *msg;
    int status = 500, code = 0;

    statusStr = (char*) cuwa_wal_note_get( r,"CUWL-error-status");
    codeStr = (char*) cuwa_wal_note_get( r,"CUWL-error-code");
    msg = (char*) cuwa_wal_note_get( r,"CUWL-error-msg");

    if (statusStr) status = atoi(statusStr);
    if (codeStr) code = atoi(codeStr);
    if (!msg) msg = "";

    return cuwa_core_show_error(r, r->pool, status, code, "%s", msg );
}


char *cuwa_wal_get_remote_IP(void *req)
{
    cuwa_request_t *r = ( cuwa_request_t *)req;
    if ( r )
        return r->remote_IP;
    else
        return "";
}

apr_pool_t *cuwa_wal_get_pool(void *req )
{
    cuwa_request_t *r = ( cuwa_request_t *)req;

    if ( r )
        return r->pool;
    else
        return NULL;
}
  
int cuwa_wal_return_declined()
{
    return DECLINED;
}

const char *cuwa_wal_get_server_version()
{
    return cuwa_server_version;
}

// FIXME: dup'ed code from httpd-2.2.8/server/util.c line 1738.....
char * cuwa_wal_escape_uri( apr_pool_t *p, char *s)
{
    int i, j;
    char *x;

    /* first, count the number of extra characters */
    for (i = 0, j = 0; s[i] != '\0'; i++)
        if (s[i] == '<' || s[i] == '>')
            j += 3;
        else if (s[i] == '&')
            j += 4;
        else if (s[i] == '"')
            j += 5;

    if (j == 0)
        return apr_pstrmemdup(p, s, i);

    x = apr_palloc(p, i + j + 1);
    cuwa_trace("allocated address:%x", x);
    for (i = 0, j = 0; s[i] != '\0'; i++, j++)
        if (s[i] == '<') {
            memcpy(&x[j], "&lt;", 4);
            j += 3;
        }
        else if (s[i] == '>') {
            memcpy(&x[j], "&gt;", 4);
            j += 3;
        }
        else if (s[i] == '&') {
            memcpy(&x[j], "&amp;", 5);
            j += 4;
        }
        else if (s[i] == '"') {
            memcpy(&x[j], "&quot;", 6);
            j += 5;
        }
        else
            x[j] = s[i];

    x[j] = '\0';
    return x;
}

char * cuwa_wal_get_require_line(void *request, void *requires, int i )
{
    return cuwa_iis_get_require_line( requires, i );
}


const apr_array_header_t *cuwa_wal_get_requires(void *request)
{
    cuwa_request_t *r = (cuwa_request_t *) request;

    return cuwa_iis_get_requires( r->dirConfig );
}

char *cuwa_wal_get_authtype(void * request)
{
    cuwa_request_t *r = (cuwa_request_t *) request;

    return cuwa_iis_get_authtype(r->dirConfig);
}

int cuwa_wal_handle_error(void * request, int error)
{
    return 0;  // ErrorDocument feature for Apache
}

int cuwa_wal_send_page(void * request, int status, char *html)
{
    cuwa_request_t *r = (cuwa_request_t *) request;
    EXTENSION_CONTROL_BLOCK *ecb = r->ecb;
    HSE_SEND_HEADER_EX_INFO HeaderExInfo;
    DWORD len = strlen( html );
    char *headers = cuwa_create_header_string(r,r->headers_out);

    cuwa_wal_set_header_in(r, "Content-type", "text/html");
    cuwa_wal_set_header_in(r, "Cache-Control", "no-cache, no-store");
    cuwa_wal_set_header_in(r,"Pragma","no-cache");
    cuwa_wal_set_header_in(r,"Expires","0");

	HeaderExInfo.pszStatus = cuwa_get_status_text(r->pool, status);
	HeaderExInfo.pszHeader = headers;
	HeaderExInfo.cchStatus = strlen(HeaderExInfo.pszStatus);
	HeaderExInfo.cchHeader = strlen(HeaderExInfo.pszHeader);
	HeaderExInfo.fKeepConn = FALSE;

	ecb->ServerSupportFunction(ecb->ConnID, HSE_REQ_SEND_RESPONSE_HEADER_EX, &HeaderExInfo, NULL, NULL);
	ecb->WriteClient( ecb->ConnID, html, &len, 0 );

    cuwa_trace("Send page headers: %s",headers);
    cuwa_trace("Response is: %s",HeaderExInfo.pszStatus);

    return DONE;
}

char *cuwa_get_status_text(apr_pool_t *pool, int status)
{
    char *s = apr_psprintf(pool,"%d",status);
    char *http = "HTTP/1.1";
    char *msg = "Server Error";

    if (strlen(s)==3)
    {
        switch (*s)
        {
            case '1':
                msg = "Continue";
                break;
            case '2':
                msg = "OK";
                break;
            case '3':
                msg = "Redirect";
                break;
            case '4':
                msg = "Access Denied";
                break;
        }
    }

    return apr_psprintf(pool,"%d %s",status,msg);
}

char *cuwa_wal_get_virtual_host(void * request, CUWACfg_t *cfg, char *path)
{
    cuwa_request_t *r = (cuwa_request_t *) request;
    char *host = cuwa_wal_get_hostname(request);
    char *portStr = r->port; 
    int port;

    cuwa_assert(r);
    cuwa_assert(portStr);
    cuwa_assert(host);

    // Since I'm not sure of the API yet, put this check in here...
    cuwa_assert(*portStr>='0');
    cuwa_assert(*portStr<='9');
	port = atoi(portStr);

    cuwa_trace("Port is: %d\n",port);

    return cuwa_core_make_return_url(r->pool, cfg, host, port, r->ssl, path);
}

const char *cuwa_wal_get_method(void * request)
{
    cuwa_request_t *r = (cuwa_request_t *) request;
    return r->method;
}

void cuwa_wal_dont_cache(void * request)
{
    cuwa_request_t *r = (cuwa_request_t *) request;
    r->nocache = 1;
}


char *cuwa_wal_get_uri(void * request, int uri_flags)
{
    cuwa_request_t *r = (cuwa_request_t *) request;
    char *uri;

    cuwa_trace("unparsed_uri=%s, path=%s", r->unparsed_uri, r->path);
    if (uri_flags & CUWA_URI_UNPARSED)
    {
        uri = r->unparsed_uri;
    }
    else
    {
        uri = r->path;
    }

    cuwa_trace("wal_get_uri return %s", uri);
    return uri;
}

char *cuwa_wal_get_hostname(void * request)
{
    char *host = cuwa_get_server_variable(request, "SERVER_NAME");
    cuwa_assert(host);
    return host;
}

char *cuwa_wal_note_get(void *request, char *name)
{
    cuwa_request_t *r = (cuwa_request_t *) request;
    return (char *)apr_table_get(r->notes,name);
}

void cuwa_wal_note_set( void *request, char *name, char *value)
{
    cuwa_request_t *r = (cuwa_request_t *) request;
    apr_table_set(r->notes,name,value);
}


CUWACfg_t *cuwa_wal_get_config(void * request)
{
    cuwa_request_t *r = (cuwa_request_t *) request;
    return r->cfg;
}

const char *cuwa_wal_get_header_in(void * request, char *name)
{
    cuwa_request_t *r = (cuwa_request_t *) request;
    return apr_table_get(r->headers_in, name);
}

void cuwa_wal_set_header_in(void * request, char *name, char *value)
{
    cuwa_request_t *r = (cuwa_request_t *) request;
    char *tmp = apr_pstrdup(r->pool, name);

    apr_table_set(r->headers_in,name,value);
    cuwa_util_replace_char_with(tmp,'_','-');
    apr_table_set(r->headers_in,tmp,value);
}

void cuwa_wal_clear_header_in(void * request, char *name)
{
    cuwa_request_t *r = (cuwa_request_t *) request;
    apr_table_unset( r->headers_in,name);
}

void cuwa_wal_set_header_out(void * request, char *name, char *value)
{
    cuwa_request_t *r = (cuwa_request_t *) request;
    apr_table_set(r->headers_out,name,value);
}

void cuwa_wal_set_env(void * request, char *name, char *value)
{
    cuwa_request_t *r = (cuwa_request_t *) request;
    apr_table_set(r->env,name,value);
	cuwa_trace("Not setting environment variable %s=%s (IIS==CGI broken)",name,value);
}

char * cuwa_wal_get_env(void * request, char *name)
{
    cuwa_request_t *r = (cuwa_request_t *) request;
    return (char *)apr_table_get(r->env, name);
}

void cuwa_wal_set_user(void * request, char *user)
{
	cuwa_trace("Not REMOTE_USER, IIS has no clue: %s",user);
}

int cuwa_wal_is_ssl( void *request )
{
    cuwa_request_t *r = (cuwa_request_t *) request;

    return ( r->ssl );
}

void cuwa_wal_set_cookie(void * request, char *cookieName, char *cookieValue)
{
    cuwa_request_t *r = (cuwa_request_t *) request;
    char *buf;

    buf = cuwa_core_set_cookie( request, cuwa_wal_get_config(request), cookieName, cookieValue );

    cuwa_trace("Set-Cookie %p %s",r->headers_out, buf);
    apr_table_add(r->headers_out,"Set-Cookie",buf);     // Send to browser, normal case

    // Temporary debug code follows...
    {
        char *hdrs = cuwa_create_header_string(r,r->headers_out);
        buf = strstr(buf, hdrs);
        cuwa_trace("Looked in headers it was %s found", buf?"":"NOT");
        cuwa_trace("HEADERS: %s",hdrs);
    }

}

const char *cuwa_wal_get_server_signature( const char *str, void *r)
{
    char *signature = cuwa_get_server_variable(r, "SERVER_NAME");

    if (!signature) return "";

	return signature;
}

const char *cuwa_wal_get_log_error(void * request)
{
    return cuwa_wal_note_get( request,"CUWA-LogError");
}

// FIXME: dup'ed code from apache implementation...
static cuwa_err_t write_request( cuwa_session_t *session, char *buf, int count ,int do_encrypt)
{
    return cuwa_session_write_request( session, buf, count, do_encrypt );
}

// FIXME: dup'ed code from apache implementation...
static int write_header(void *p, const char *key, const char *value)
{
    if (write_request( (cuwa_session_t*)p, (char*) key, strlen(key),0 )) return 0;
    if (write_request( (cuwa_session_t*)p, ": ", 2,0 )) return 0;
    if (write_request( (cuwa_session_t*)p, (char*) value, strlen(value),0 )) return 0;
    if (write_request( (cuwa_session_t*)p, "\r\n", 2,0 )) return 0;

    return 1;
}

// FIXME: dup'ed code from apache implementation...
int cuwa_wal_request_save(uint64 *sessionid, void *request )
{
    apr_status_t code = CUWA_OK;
    cuwa_request_t *r = (cuwa_request_t *) request;
    cuwa_session_t *session = NULL;
    CUWACfg_t *cfg = cuwa_wal_get_config(r);
    char *st,*st2;
    int cnt;
    char *req;

    /*
    file format
    METHOD URI
    Headers_in
    body

    */
    cuwa_trace("cuwa_request_save...");

    // Avoid circular craziness
    if (CUWL_REDIR_SIGNATURE(r->path))
    {
        cuwa_trace("cuwa_request_save can't save request=cuwl_restore");
        return CUWA_OK;
    }

    // Remove the magic arg if it's in the request
    cuwa_trace("cuwa_request_save %s, method=%s",r->unparsed_uri,r->method);
    req = apr_pstrdup(r->pool, r->unparsed_uri);
    st = strstr(req,CUWA_MAGIC_ARG);
    if (st && st!=req)
    {
        st--;
        if (*st=='?' || *st=='&')
        {
            cnt = strlen(CUWA_MAGIC_ARG)+1;
            st2 = st + cnt;
            while(*st2 && *st2!='&') st2++; // search for end of SID
            cuwa_trace("cuwa_request_save rmv magic <%s> <%s> %d",st2,st,cnt);
            while (*st2) *st++ = *st2++;
            *st = 0;
        }
    }

    code = cuwa_session_new( r, r->pool, cfg, &session);
    if (code) goto cleanup;

    code = cuwa_session_get_sessionid( session, sessionid );
    if (code) goto cleanup;

    if ( !strncmp( r->method, "POST", 4 ) )
    {
        code = cuwa_session_encryption_set( session );
        if (code) goto cleanup;
    }
 
    code = cuwa_session_open_request( session, 1 );
    if (code) goto cleanup;

    WRITELINE(session,r->method);
    WRITELINE(session,r->unparsed_uri);
    WRITELINE(session,r->path);
    WRITELINE(session,r->mapped_path);

    // write the headers
    apr_table_do( write_header, session, r->headers_in, NULL);

    WRITELINE(session,"");

    // write POST data
    if ( !strncmp( r->method, "POST", 4 ) )
    {
        char buf[POST_BUFSIZE];
        DWORD totalRead=0, totalWrite=0, readCnt;

        cuwa_trace("POST: %d, %d",r->ecb->cbAvailable,r->ecb->cbTotalBytes);

    	if ( !r->ecb->cbAvailable)
        {
            // Is this an error?  Not sure if this is a chunked encoding case.
            // FIXME, figure out if this is an error condition
            goto cleanup;
    	}

        cuwa_trace("write %d bytes. Data:%s",r->ecb->cbAvailable, r->ecb->lpbData);
        code = write_request( session, r->ecb->lpbData, r->ecb->cbAvailable, 1);
        if (code) goto cleanup;

    	totalRead = r->ecb->cbAvailable;
    	while (totalRead < r->ecb->cbTotalBytes)
        {
            readCnt = r->ecb->cbTotalBytes - totalRead;
            if (readCnt>POST_BUFSIZE) readCnt = POST_BUFSIZE;

    		if (!r->ecb->ReadClient(r->ecb->ConnID, buf, &readCnt) || !readCnt)
            {
                code = CUWA_ERR_REQUEST_SAVE;
    			goto cleanup;
    		}

            code = write_request( session, buf, readCnt, 1);
            if (code) goto cleanup;

    		totalRead += readCnt;
    	}
        code = cuwa_session_encryption_done( session );
        if (code) goto cleanup;
    }

cleanup:

    cuwa_trace("cuwa_request_save done: %d",code);

    if (session)
    {
        cuwa_session_close_request( session );
        cuwa_session_release( session );
    }

    return code;
}

/////////////////////////////////////////////////////////////////////////////////////
// Entry Points
/////////////////////////////////////////////////////////////////////////////////////

BOOL WINAPI GetExtensionVersion(OUT HSE_VERSION_INFO *pVer)
{
    apr_status_t status;
    cuwa_iis_server *s = NULL;
    CUWACfg_t *cfg = NULL;
    int overwritePermitStr = 0 ;
    char *permitStr;
 
    status = apr_initialize();
    if (status)
    {
        OutputDebugString("Program error: Can't initialize apr pools");
        return FALSE;
    }

    status = apr_pool_create(&cuwa_root_pool, NULL);
    if (status)
    {
        OutputDebugString("Program error: Can't create root pool");
        return FALSE;
    }
    cuwa_iis_init = 1;

    cuwa_malloc_init(cuwa_root_pool);

    cuwa_log_init( cuwa_root_pool );
    
    // Create a separate pool for the version string creation - cuwa_build_client_version
    status = apr_pool_create(&cuwa_ver_pool, cuwa_root_pool);
    if (status)
    {
        OutputDebugString("Program error: Can't create ver pool");
        return FALSE;
    }            

    status = cuwa_cfg_init( cuwa_root_pool, &cuwa_root_cfg, &cuwa_root_vhost );
    if (status)
    {
        cuwa_crit("Error reading configuration file");     
        goto FAIL;
    }

    cuwa_log_set_keys(NULL, cuwa_root_vhost, NULL );
 
    cuwa_iis_init = 0;

    if ( CUWA_HA_ENABLED(cuwa_root_cfg) )
    {
        // Create a separate pool for HA
        status = apr_pool_create(&cuwa_ha_pool, cuwa_root_pool);
        if (status)
        {
            OutputDebugString("Program error: Can't create HA pool");
            return FALSE;
        }        

        if ( cuwa_ha_init(cuwa_root_vhost, cuwa_ha_pool) != CUWA_OK )
        {
            cuwa_crit("High availability failed at initialization.");
            goto FAIL;
        }

       permitStr = cuwa_ha_get_permit_server_string();
       if ( !permitStr )
        {
            cuwa_crit("Get permit servers failed at initialization.");
            goto FAIL;
        }
    }

    //check if server wants to use its own permit server define
    s = cuwa_root_vhost;
    while (s)
    {
        cfg = cuwa_iis_server_get_config(s);

        if ( cfg  && CFG_CUWApermitServerOverride(cfg) )
        {
            overwritePermitStr = *CFG_CUWApermitServerOverride((cfg))==O_CFG_CUWApermitServerOverride_on ? 1:0;
            break;
        }
        s = cuwa_iis_get_next_server(s);
    }
    cuwa_trace("overwritePermitStr=%d", overwritePermitStr);

   if ( !permitStr || overwritePermitStr)
   {
       s = cuwa_root_vhost;
       while (s)
       {
           cfg = cuwa_iis_server_get_config(s);

           if ( cfg  && CFG_CUWApermitServer(cfg) )
           {
               permitStr = CFG_CUWApermitServer( cfg );
               break;
           }
           s = cuwa_iis_get_next_server(s);
      }
  }

  if ( permitStr ) cuwa_permit_ha_add_servers( permitStr, cuwa_root_pool );
  else
  {
      cuwa_crit("Get permit servers failed at initialization. Please reboot web server to initialize it.");
      goto FAIL;
  }
  pVer->dwExtensionVersion = MAKELONG(HSE_VERSION_MINOR, HSE_VERSION_MAJOR);
  strncpy_s(pVer->lpszExtensionDesc, sizeof(pVer->lpszExtensionDesc), cuwa_version_get_full(), HSE_MAX_EXT_DLL_NAME_LEN - 1);

  sspiutil_init(cuwa_root_pool);

  OutputDebugString("cuwebauth.dll loaded");	
  cuwa_crit("cuwebauth.dll loaded");

FAIL:
    cuwa_iis_init = 0;
    return TRUE;
}


DWORD WINAPI HttpExtensionProc(IN EXTENSION_CONTROL_BLOCK *ecb)
{
	return cuwa_process_inbound(ecb);
}

BOOL WINAPI TerminateExtension(IN DWORD dwFlags)
{
    cuwa_crit("cuwebauth.dll unloaded");
    // Fixme - Kill the HA thread??

    if (cuwa_root_vhost) cuwa_iis_log_close(cuwa_root_vhost, cuwa_root_pool);

    if (cuwa_root_pool) apr_pool_destroy(cuwa_root_pool);

    apr_pool_terminate();
	return TRUE;
}

static void cuwa_show_config(cuwa_request_t *r)
{
    cuwa_trace("**** Configuration ****");
    if (!r || !r->dirConfig)
    {
        cuwa_trace("No Configuration available");
        return;
    }
    if (r->dirConfig->dir) cuwa_trace("Path: %s",r->dirConfig->dir);
    if (r->dirConfig->auth_type) cuwa_trace("AuthType: %s",r->dirConfig->auth_type);
    if (r->dirConfig->auth_name) cuwa_trace("AuthName: %s",r->dirConfig->auth_name);
    if (r->dirConfig->handler) cuwa_trace("Handler: %s",r->dirConfig->handler);
    if (r->dirConfig->is_directory) cuwa_trace("IsDir: %d",r->dirConfig->is_directory);
    cuwa_trace("**** End Configuration ****");
}

static int cuwa_iis_send_error_response(cuwa_request_t *r)
{
    char * html;

    html = apr_psprintf(r->pool,"<html><body><H2>CUWebAuth Failed at Loading</H2>",r->method,r->ssl);
    html = apr_pstrcat(r->pool, html,cuwa_iis_cfg_error_msg, NULL);

    html = apr_pstrcat(r->pool,html,"</body></html>",NULL);

    cuwa_wal_send_page(r, 200, html);
    cuwa_request_destroy(r);

    return HSE_STATUS_SUCCESS;
}
//////////////////////////////////////////////////////////////////////////////////////////////
// Support functions
//////////////////////////////////////////////////////////////////////////////////////////////

int cuwa_process_inbound(EXTENSION_CONTROL_BLOCK *ecb)
{
	cuwa_request_t *r;
    int rc;
    char *cred=NULL, *sid=NULL;
    char *cookies=NULL;
    
    r = cuwa_request_init(ecb);
	sspiutil_begin_ctx();
    
    if ( cuwa_iis_cfg_error_msg )
    {
        return cuwa_iis_send_error_response(r);
    }
    // Make this easy to find in the log
    cuwa_trace("********************************");
    cuwa_trace("* IIS Inbound request handler");
    cuwa_trace("********************************");
    
    // Get the real version   
    if ( !cuwa_server_version_created )
    {
        cuwa_server_version_created = 1;
        cuwa_trace("Client string: %s",cuwa_get_client_version());
        cuwa_server_version = cuwa_get_server_variable(r, "SERVER_SOFTWARE");
        cuwa_trace("Server software: %s",cuwa_server_version);
        cuwa_build_client_version( cuwa_ver_pool );
        if (strncmp("VerC",cuwa_get_client_version(),4))
        {
            cuwa_crit("Version string is garbled: %s",cuwa_get_client_version());
            cuwa_version_reset();
            cuwa_build_client_version( cuwa_ver_pool );
            if (strncmp("VerC",cuwa_get_client_version(),4)) cuwa_crit("still garbled: %s",cuwa_get_client_version());
        }
    }   
    cuwa_trace("Client string: %s",cuwa_get_client_version());
    cuwa_trace("Path: %s",r->path);
    cuwa_trace("Unparsed URI: %s",r->unparsed_uri);
    cuwa_trace("Mapped path: %s", r->mapped_path);
    
    // Check if this is a special path
    rc = cuwa_get_session_from_req(r, r->unparsed_uri, &cred, &sid);
    if (rc==DONE) return HSE_STATUS_SUCCESS;

    r->cfg = cuwa_cfg_from_path( r->server,r->path,r->mapped_path,&r->dirConfig);

    cuwa_assert(r->cfg);

    cuwa_trace("Inbound... cred: %s sid: %s rc: %d",cred?cred:"NO",sid?sid:"NO",rc);
    cuwa_show_config(r);

    // See if the path is protected
    if (cuwa_wal_get_authtype(r))
    {
        const apr_array_header_t *requiresList = cuwa_wal_get_requires( r);

        if ( requiresList->nelts > 0 )
        {
            cookies = (char *) cuwa_wal_get_header_in(r, "Cookie");
            rc = cuwa_core_authn(r, r->pool, cred, cookies, sid);
            cuwa_trace("cuwa_core_authn: %d",rc);
            if (rc==CUWA_OK) rc = cuwa_core_authz(r, r->pool);
            cuwa_trace("cuwa_core_authz: %d",rc);
        }
        else
            cuwa_trace("No require, access authorized.");
    } else cuwa_trace("No AuthType, access authorized.");

    if (rc>0)
    {
        char *html = cuwa_divine_html(r, rc);
        if (html) rc = cuwa_wal_send_page(r, rc, html);
        else rc = cuwa_core_show_error(r, r->pool, 500, rc, "Unexpected status code: %d", rc );
    } else if (rc!=DONE)   // DECLINED or CUWA_OK (with or without authn)
    {
        rc = cuwa_iis_portal_handler(r);
        if ( rc != DONE )
        {
            // Send subrequest to process file
            rc = cuwa_subrequest(r);
            if (rc==OK) return HSE_STATUS_PENDING;
        }
    }

    // free up resources
	sspiutil_revert_ctx();
    cuwa_request_destroy(r);

    return HSE_STATUS_SUCCESS;
}

// FIXME: dup'ed code from apache implementation...
int cuwa_get_session_from_req(cuwa_request_t *r, char *path, char **credout, char **sidout)
{
	int code;
    char *cred = NULL, *cp;
    char *saved = NULL;
	char *sidstr = NULL;
	uint64 sid;
	int from_cuwl, from_cuwa;
	cuwa_session_t *session = NULL;

    // Only look at GET, POST or HEAD
    if (apr_strnatcasecmp(r->method,"GET") &&
        apr_strnatcasecmp(r->method,"POST") &&
        apr_strnatcasecmp(r->method,"HEAD")) return 0;

    // Look for special signatures
    from_cuwl = CUWL_REDIR_SIGNATURE(path);
    from_cuwa = CUWA_REDIR_SIGNATURE(path);
    if (!from_cuwl && !from_cuwa) return DECLINED;

    // Extract cred if this is from CUWL.
    // Note that if it's redirect from CUWA, the site cookie must be present for authn to work
    if (from_cuwl)
    {
        cred = cuwa_get_cred_from_uri( r->pool, path);        
        if (!cred) 
        {
            // read a cred from POST data...
            DWORD len, totalRead, readCnt;

            if ( apr_strnatcasecmp(r->method,"POST") ) return DECLINED;

            len = r->ecb->cbTotalBytes;
            cuwa_trace("POST data, %d bytes",len);
            cred = apr_pcalloc( r->pool, len+1);
            totalRead = r->ecb->cbAvailable;
            cp = cred;
            memcpy(cp, r->ecb->lpbData, totalRead);
            cp += totalRead;
            while (totalRead < len)
            {
                readCnt = len - totalRead;
                
                if (!r->ecb->ReadClient(r->ecb->ConnID, cp, &readCnt) || !readCnt)
                {
                    IIS_TRACE();
                    cuwa_trace("Problem reading POST data.");
                    return DECLINED;
                }
                cp += readCnt;
                totalRead += readCnt;
            }
            
            cred = cuwa_get_cred_from_args( r->pool, cred);
        }
        
        cuwa_trace("Cred: %s",cred);

        sidstr = cuwa_get_sid_from_uri( r->pool, path);
    }
    else
    {
        cuwa_trace("Filter: inbound redirect from CUWA");
        saved = apr_pstrdup(r->pool, path);

        sidstr = cuwa_get_sid_from_arg(r->pool, path);
    }

    if (!sidstr)
    {
        const char *ua = cuwa_wal_get_header_in(r, "User-Agent");
        sidstr = cuwa_get_cookie(r,CUWA_SID_COOKIE_NAME);
        if (sidstr)
        {
            cuwa_notice("Old cookie cuwal2sid detected, probably from incompatable webauth UA (%s).",ua?ua:"unknown user-agent");
            return cuwa_core_show_error(r, r->pool, 400, 400, "Old cookie cuwal2sid detected, probably from incompatable webauth UA (%s).",ua?ua:"unknown user-agent");
        }
        cuwa_notice("Missing session ID in URI - redirect from %s.",from_cuwl?"weblogin":"webauth");
        return cuwa_core_show_error(r, r->pool, 500, 500, "Missing session ID in URI - redirect from %s.",from_cuwl?"weblogin":"webauth");
    }

    // extract cookies from request and sid cookie
    sscanf( sidstr, "%llX", &sid);
    cuwa_trace("SessionID: %s",sidstr);

    // restore request based on sid cookie
    code = cuwa_session_from_sessionid( r, r->pool, r->cfg, sid, &session);
    if (code)
    {
        cuwa_notice("cuwa_session_from_sessionid failed with status %d",code);
    }
    else
    {
        cuwa_trace("This is from CUWL! %x sessionid=%llX...",session, session->sessionID);
    }

    if (!code) code = cuwa_request_restore(r, session);

    if (code)
    {
        return cuwa_core_show_error(r, r->pool, 500, code, "Can't restore initial request: %d",code);
    }

    *sidout = sidstr;
	*credout = cred;
    return OK;
}

void cuwa_iis_trace_error(int line)
{
    TCHAR *msg;
    DWORD dw = GetLastError();

    FormatMessage(
        FORMAT_MESSAGE_ALLOCATE_BUFFER |
        FORMAT_MESSAGE_FROM_SYSTEM |
        FORMAT_MESSAGE_IGNORE_INSERTS,
        NULL,
        dw,
        MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT),
        (LPSTR)&msg,
        0, NULL );

    cuwa_warning("Line: %d Error: %s",line, msg);

    LocalFree(msg);
}

char *cuwa_get_server_variable(void * request, char *name)
{
    cuwa_request_t *r = (cuwa_request_t *) request;
    BOOL itworked = FALSE;
    char *buf;
    DWORD buflen = 0;

    r->ecb->GetServerVariable(r->ecb->ConnID,name,NULL,&buflen);
    if (GetLastError()!=ERROR_INSUFFICIENT_BUFFER)
    {
        IIS_TRACE();
        cuwa_trace("GetServerVariable %s failed",name);
        return NULL;
    }

    buf = apr_palloc(r->pool,buflen);
    cuwa_assert(buf);

    itworked =  r->ecb->GetServerVariable(r->ecb->ConnID,name,buf,&buflen);
    if (!itworked)
    {
        IIS_TRACE();
        cuwa_trace("GetServerVariable(2) %s failed",name);
        buf = NULL;
    }

    return buf;
}


void cuwa_parse_headers(apr_pool_t *pool, char *buf, apr_table_t *in)
{
	unsigned long i = 0;
	unsigned long len = strlen(buf);
    char *name, *val;

	while (i < len)
    {
        // Skip leading spaces
		for (; i < len && isspace(buf[i]); i++) ;
        if (!len) break;

		name = buf+i;

        // Find colon
		for (; i < len && buf[i] != ':'; i++) ;
        if (!len) break;

		buf[i] = 0;

        // Look for value
		for (i++; i < len && buf[i] == ' ' && buf[i] != '\n'; i++) ;

        // Terminate value
		val = buf+i;
		for (; i < len && (buf[i] != '\n' || isspace(buf[i+1])); i++)
        {
			if (isspace(buf[i]))
				buf[i] = ' ';
		}
		if (buf[i - 1] == ' ') buf[i - 1] = 0;
		buf[i++] = 0;

        // Strip out any CUWA headers
        if (!apr_strnatcasecmp( apr_pstrndup(pool, name, 5), "CUWA_")) continue; 	
        if (!apr_strnatcasecmp( name, "REMOTE_USER")) continue; 	

        apr_table_add(in, name, val);
	}
}

static void cuwa_dump_req(cuwa_request_t *r)
{
    char *html;
    int i;
    const apr_array_header_t *arr=NULL;
    const apr_table_entry_t *elts=NULL;
    apr_table_t *headers = r->headers_in;

    html = apr_psprintf(r->pool,"<html><body>Method: %s<br>SSL: %d<br><br>",r->method,r->ssl);

    if (!headers || apr_is_empty_table(headers))
    {
        html = apr_pstrcat(r->pool,html,"No inbound headers<br>",NULL);
    }
    else
    {
        arr = apr_table_elts( headers );
        elts = (const apr_table_entry_t *)arr->elts;
        for (i=0; i < arr->nelts; i++ )
        {
			cuwa_trace("%s: %s",elts[i].key,elts[i].val);
			html = apr_pstrcat(r->pool,html,elts[i].key,": ",elts[i].val,"<br>",NULL);
        }
    }

    html = apr_pstrcat(r->pool,html,"</body></html>",NULL);

    cuwa_wal_send_page(r, 200, html);
}

char * cuwa_divine_html(cuwa_request_t *r, int status)
{
    char *html;
    const char *location;
    if (status>299 && status < 400)
    {
        location = apr_table_get(r->headers_out,"Location");
        if (!location) return NULL;
        html = apr_pstrcat(r->pool,"<html><body>The location of this page has move to ",location,"</body></html>",NULL);
    }
    else if (status>399 && status < 500)
    {
        html = apr_pstrdup(r->pool,"<html><body>Authorization Required.</body></html>");
    }
    else return NULL;

    return html;
}

char *cuwa_create_header_string(cuwa_request_t *r,apr_table_t *headers)
{
    const apr_array_header_t *arr=NULL;
    const apr_table_entry_t *elts=NULL;
    char *str = "";
    int i;

    if (!headers || apr_is_empty_table(headers))
    {
        str = apr_pstrdup(r->pool,"\r\n");
    }
    else
    {
        arr = apr_table_elts( headers );
        elts = (const apr_table_entry_t *)arr->elts;
        for (i=0; i < arr->nelts; i++ )
        {
			str = apr_pstrcat(r->pool,str,elts[i].key,": ",elts[i].val,"\r\n",NULL);
        }
        str = apr_pstrcat(r->pool,str,"\r\n",NULL);
    }
    return str;
}


static int cuwa_read_buf_line( char **buf, int *len, char **line)
{
    char *s = *buf;
    int i = *len;

    *line = *buf;

    while (s && *s!= '\r') { s++; i--; }
    if (*s) { *s++ = 0; i--; }
    if (*s=='\n') { s++; i--; }
    if (!*s) i = 0;


    *buf = s;
    *len = i;

    if (!strlen(*line)) return 0;
    return 1;
}

int cuwa_request_restore(cuwa_request_t *r, cuwa_session_t *session)
{
    int code = 0;
    apr_size_t len;
    apr_off_t biglen;
    char *buf,*line,*val;
    char *cookies = (char *) cuwa_wal_get_header_in(r,"Cookie");

    cuwa_trace("cuwa_request_restore");

    apr_table_clear(r->headers_in);

    code = cuwa_session_get_req_size(session, &biglen);
    if (code) return code;

    if (biglen>MAXINT) return CUWA_ERR_SESSION_EXCEED_MAX_SESSION;
    len = (int) biglen;

    code = cuwa_session_open_request(session, 0 );
    if (code) return code;

    // Read entire request into memory...
    // This is the best we can do since IIS doesn't support streaming.
    buf = apr_pcalloc(r->pool,len+1);
    code = cuwa_session_read_request( session, buf, &len);
    cuwa_session_close_request( session );
    if (code) return code;

    if (!cuwa_read_buf_line(&buf,&len,&r->method)) return CUWA_ERR_SESSION_INVALID;
    if (!cuwa_read_buf_line(&buf,&len,&r->unparsed_uri)) return CUWA_ERR_SESSION_INVALID;
    if (!cuwa_read_buf_line(&buf,&len,&r->path)) return CUWA_ERR_SESSION_INVALID;
    if (!cuwa_read_buf_line(&buf,&len,&r->mapped_path)) return CUWA_ERR_SESSION_INVALID;

    cuwa_trace("method=%s path=%s",r->method,r->path);

    // Read headers...
    while (cuwa_read_buf_line(&buf,&len,&line))
    {
       val = strchr(line,':');
       if (!val || strlen(val)<2) return CUWA_ERR_SESSION_INVALID;

       *val = 0;
       val +=2;
       cuwa_wal_set_header_in(r,line,val);
    }

    // Replace cookies
    cuwa_wal_set_header_in(r,"Cookie",cookies);

    // Read post
    if (len)
    {
        cuwa_trace("request has POST data: %d bytes", len);
        r->post_data = buf;
        r->post_len  = len;

        r->ecb->cbAvailable = len;
        r->ecb->cbTotalBytes = len;
        r->ecb->lpbData = buf;
    }

    //if user doesn't turn on cachURL feature, we can simply reset uri_received to unparsed_uri. Otherwise we
    //need to check if uri_received contain cuwa added parameter and remove it if there is
    if( !CFG_CUWACacheURL(r->cfg) || (*CFG_CUWACacheURL(r->cfg) == O_CFG_CUWACacheURL_on))
    {
        char *str = strstr( r->uri_received, CUWA_MAGIC_ARG );

	 if ( str )
	 {
	     str--;
	     *str = 0;
	 }
   }
   else
   {
	r->uri_received = r->unparsed_uri;
   }

   return CUWA_OK;
}


char * cuwa_get_cookie(cuwa_request_t *r, char *name)
{
    char *cookies = (char *) cuwa_wal_get_header_in(r,"Cookie");
    char *cookie;
    cuwa_trace("Check cookies for %s",name);
    if (!cookies) return NULL;
    cuwa_trace("Cookies are %s",cookies);
    cookie = cuwa_core_find_cookie(r, r->pool, cookies, name, NULL);
    cuwa_trace("Cookies found?: %s",cookie?cookie:"NO");
    return cookie;
}

VOID WINAPI cuwa_subrequest_complete( LPEXTENSION_CONTROL_BLOCK ecb,PVOID pContext,DWORD cbIO,DWORD dwError)
{
    HSE_EXEC_URL_STATUS status;
    cuwa_request_t *r = (cuwa_request_t *) pContext;

    cuwa_log_set_keys( r, r->server, NULL );
    if ( ecb->ServerSupportFunction( ecb->ConnID,HSE_REQ_GET_EXEC_URL_STATUS,&status,NULL,NULL ) )
    {
        ecb->dwHttpStatusCode = status.uHttpStatusCode;
        SetLastError( status.dwWin32Error );
    }

    ecb->ServerSupportFunction ( ecb->ConnID, HSE_REQ_DONE_WITH_SESSION, &status.uHttpStatusCode, NULL, NULL );
    
    cuwa_request_destroy(r);
}

int cuwa_subrequest(cuwa_request_t *r)
{
    HSE_EXEC_URL_INFO exec_info;
    HSE_EXEC_URL_ENTITY_INFO body_info;

    if (!r->ecb->ServerSupportFunction(r->ecb->ConnID,HSE_REQ_IO_COMPLETION,cuwa_subrequest_complete,NULL,(LPDWORD)r))
    {
        IIS_TRACE();
        return cuwa_core_show_error(r, r->pool, 500, 500, "Subrequest failure 1");
    }

    cuwa_trace("Calling subrequest: %s",r->uri_received);
    memset(&exec_info,0,sizeof(HSE_EXEC_URL_INFO));

    if (r->post_len)
    {
        body_info.cbAvailable = r->post_len;
        body_info.lpbData = r->post_data;
        exec_info.pEntity = &body_info;
    }

    exec_info.pszUrl = r->uri_received;
    exec_info.pszMethod = r->method;
    exec_info.pszChildHeaders = cuwa_create_header_string(r,r->headers_in);
    exec_info.pUserInfo = NULL;
    exec_info.dwExecUrlFlags = HSE_EXEC_URL_IGNORE_CURRENT_INTERCEPTOR;

    // FIXME, parent may need to set headers_out, maybe we can do that before we call the subrequest?

    if (!r->ecb->ServerSupportFunction(r->ecb->ConnID, HSE_REQ_EXEC_URL, &exec_info, NULL, NULL))
    {
        IIS_TRACE();
        return cuwa_core_show_error(r, r->pool, 500, 500, "Subrequest failure 2");
    }

    cuwa_trace("Subrequest pending %d", r->ecb->dwHttpStatusCode);
    return OK;
}

cuwa_request_t *cuwa_request_init(EXTENSION_CONTROL_BLOCK *ecb)
{
	cuwa_request_t *r;
    char *raw_headers;
    apr_status_t status;
    char *https;
    apr_pool_t *pool;

    cuwa_log_set_keys( NULL, cuwa_root_vhost, NULL );

    status = apr_pool_create(&pool, cuwa_root_pool);
    cuwa_assert(status==OK); 
    
    // Initialize request
    r = (cuwa_request_t*) apr_pcalloc(pool,sizeof(cuwa_request_t));
    cuwa_assert(r);

    r->ecb  = ecb;
    r->pool = pool;

    cuwa_malloc_set_pool(pool);

    r->server_name = cuwa_get_server_variable(r, "SERVER_NAME");
    cuwa_assert(r->server_name);

    r->port = cuwa_get_server_variable(r, "SERVER_PORT");
    cuwa_assert(r->port);

    r->server = cuwa_iis_find_server( r->server_name, r->port);
    r->cfg = cuwa_iis_server_get_config( r->server );
    
    https = cuwa_get_server_variable(r, "HTTPS");   
    cuwa_assert(https);
    r->ssl = stricmp("ON",https)?0:1;
 
    r->mapped_path = cuwa_get_server_variable(r, "PATH_TRANSLATED");
    cuwa_assert(r->mapped_path);

    cuwa_trace("mapped_path before cacheURL:%s",r->mapped_path);
    
    r->unparsed_uri = cuwa_get_server_variable(r, "HTTP_URL");
    cuwa_assert(r->unparsed_uri);
    
    cuwa_trace("unparsed_uri HTTP_URL is %s", r->unparsed_uri);

    //save the request that cuwebAuth received from IIS to uri_received. When cuwebauth is done, use uri_received to construct the subrequest
    r->uri_received = r->unparsed_uri;

    r->remote_IP = cuwa_get_server_variable(r, "REMOTE_ADDR");

    r->headers_in = apr_table_make(r->pool,20);
    cuwa_assert(r->headers_in);

    r->headers_out = apr_table_make(r->pool,20);
    cuwa_assert(r->headers_out);

    r->notes = apr_table_make(r->pool,20);
    cuwa_assert(r->notes);

    cuwa_log_set_keys( r, r->server, NULL );

    r->path = cuwa_get_server_variable(r,"PATH_INFO");
    cuwa_assert(r->path);

    cuwa_trace("path_info:%s", r->path);

    r->method = cuwa_get_server_variable(r, "REQUEST_METHOD");
    cuwa_assert(r->method);

    r->env = apr_table_make(r->pool,20);
    cuwa_assert(r->env);

    /********************************************************************
     When there is a filter in IIS that modifies the request,
     the unparsed_uri(set from HTTP_URL) is different than the request that user
     entered in the browser.(for example, user requests index.cfm in browse, filter 
     might change the request to jakoda.dll, servervariable HTTP_URL will give cuwebauth jakoda.dll).
     The following code is designed to resolve this problem. It needs to be enable by set 
     CUWACacheURL on in conf file.
     ********************************************************************/ 
    if( !CFG_CUWACacheURL(r->cfg) || (*CFG_CUWACacheURL(r->cfg) == O_CFG_CUWACacheURL_on))
    {
	char *p = NULL;
        char *cache_url = NULL;
        char *physical_path = NULL;
        int len =0;

	//server has defined CUWACacheURL on   
        //cache_url is like http://domainurl:port/requestedPath
       /*server variable CACHE_URL represents the url that user entered in browser.
        *We should use this to set unparsed_uri( this is the one used for checking 
        * authorization and redirect to original url). We also need to calculate
        * the mapped path since admin might use <directory> to define authorizaiton rule.
        */ 
	cache_url = cuwa_get_server_variable(r,"CACHE_URL");
        physical_path = cuwa_get_server_variable(r,"APPL_PHYSICAL_PATH");

        cuwa_trace("CACHE_URL=%s", cache_url);
        cuwa_trace("APP_PHYSICAL_PATH=%s", physical_path);

	len = strlen(physical_path);
	if (physical_path[len - 1] == '\\' || physical_path[len-1] == '/')
	    physical_path[len-1]= '\0';

        //in case there cuwebauth is installed on old IIS (< 6), cache_url is not available
        if ( cache_url )
        {
            p = strstr(cache_url, r->server_name);
            p = p + strlen(r->server_name);

            p = strchr( p, '/');

            //when cacheURL is the same of unparsed_uri, we don't need to change mapped_path
            if (p && strcmp(p,r->unparsed_uri) )
            {
	        r->unparsed_uri = p;
   	        r->path = p;
	        r->mapped_path = apr_psprintf(pool, "%s%s",physical_path,p);
	        cuwa_trace("cacheURL enabled, now mapped_path=%s, unparsed_uri=%s", r->mapped_path, r->unparsed_uri);
            }
        }
    }

    // Suck in the headers
    raw_headers = cuwa_get_server_variable(r, "ALL_RAW");
    cuwa_trace("RAW HEADERS: %s",raw_headers);
    cuwa_assert(raw_headers);
    cuwa_parse_headers(r->pool, raw_headers, r->headers_in);

    return r;
}

void cuwa_request_destroy(cuwa_request_t *r)
{
    cuwa_trace("IIS inbound complete.");
    apr_pool_destroy(r->pool);    
}



static int cuwa_iis_portal_handler(cuwa_request_t *r)
{
    char *handler = cuwa_iis_get_handler( r->dirConfig );
    cuwa_trace("Handler: %s",handler?handler:"NONE");
    if ( !handler || strncmp(handler, "cuwa_",5) )
        return DECLINED;
    if ( strcmp(r->method,"GET" ) )
        return DECLINED;

    cuwa_trace("Execute handler: %s",handler);
    if ( !strcmp(handler, "cuwa_permit") ) return cuwa_core_portal_permit_handler( r, r->pool);
    if ( !strcmp(handler, "cuwa_proxy") ) return cuwa_core_portal_proxy_handler( r, r->pool);
    if ( !strcmp(handler, "cuwa_davlogin") ) return cuwa_core_portal_davlogin_handler( r, r->pool);
    return DECLINED;
}


void cuwa_iis_cfg_log(const char *fmt, ... )
{
    va_list va;   
    char *msg;

    va_start(va,fmt);
    msg= apr_pvsprintf(cuwa_root_pool,fmt,va);
    va_end(va);
    
    msg = cuwa_wal_escape_uri(cuwa_root_pool,msg);

    if ( cuwa_iis_cfg_error_msg )
        cuwa_iis_cfg_error_msg = apr_pstrcat( cuwa_root_pool,"<p>",msg,"</p>",cuwa_iis_cfg_error_msg, NULL);
    else
        cuwa_iis_cfg_error_msg = apr_pstrcat( cuwa_root_pool,"<p>",msg,"</p>",NULL);   
    
}

int  cuwa_iis_init_in_progress()
{
    return cuwa_iis_init;
}
