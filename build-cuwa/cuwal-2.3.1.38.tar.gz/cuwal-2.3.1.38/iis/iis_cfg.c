/************************************************************************
 * iis_cfg.c -- Config support for IIS
 *
 * Copyright 2008 Cornell University.
 * All Rights Reserved.
 *
 ************************************************************************
 *  $Log$
 *  Revision 1.9  2009/06/22 20:18:41  hy93
 *  check if environment KRB5RCACHETYPE is set
 *
 *  Revision 1.8  2009/03/11 15:16:36  hy93
 *  Support display initialization error messages to browser
 *
 *  Revision 1.7  2008/10/07 19:37:21  hy93
 *  iis log support
 *
 *  Revision 1.6  2008/09/27 13:33:55  pb10
 *  t03echo almost working, issue with test harness remains
 *
 *  Revision 1.5  2008/09/25 18:41:44  hy93
 *  add port support in virtualHost define
 *
 *  Revision 1.4  2008/09/25 16:34:51  hy93
 *  comment out some debug messages.
 *
 *  Revision 1.3  2008/09/19 20:07:00  hy93
 *  add debug message
 *
 *  Revision 1.2  2008/09/16 18:06:17  hy93
 *  add cvs version control block
 *
 ************************************************************************
 */

#include <apr_pools.h>
#include <cuwa_err.h>
#include <iis_server.h>
#include <iis_file.h>
#include <cuwa_parse.h>
#include <log.h>
#include <iis_cmd.h>
#include <iis_cfgtree.h>
#include <apr_strings.h>
#include <cfg.h>
#include <iis_cfg.h>

#define CUWA2_LOG_DOMAIN cuwa.iis.cfg

static cuwa_iis_cmd_parms default_parms = 
{NULL, NULL, NULL, 0, NULL, NULL, NULL, 0};

#define MAX_STRING_LEN 8192

static char *iis_build_config_sub(const char *l, cuwa_iis_cmd_parms *parms, 
                                  apr_pool_t *p, apr_pool_t *temp_pool,
                                  cuwa_iis_directive **current,
                                  cuwa_iis_directive **curr_parent)
{
    const char *args;
    char *cmd_name;
    cuwa_iis_directive *newdir;
    
    if (*l == '#' || *l == '\0')
        return NULL;

    args = l;

    cmd_name = cuwa_getword_conf(parms->pool, &args);
    if (*cmd_name == '\0') 
    {
        /* Note: this branch should not occur. An empty line should have
         * triggered the exit further above.
         */
        return NULL;
    }
    if (cmd_name[1] != '/') 
    {
        char *lastc = cmd_name + strlen(cmd_name) - 1;
        if (*lastc == '>') 
        {
            *lastc = '\0' ;
        }
        if (cmd_name[0] == '<' && *args == '\0') 
        {
            args = ">";
        }
    }
    cuwa_trace("build_config_sub for %s %s", cmd_name,args);

    newdir = apr_pcalloc(p, sizeof(cuwa_iis_directive));
    newdir->directive = cmd_name;
    newdir->args = (const char *)apr_pstrdup(p, args);
    newdir->line_num = parms->line_num;

    if (cmd_name[0] == '<') 
    {
        if (cmd_name[1] != '/') 
        {
            (*current) = cuwa_iis_add_node(curr_parent, *current, newdir, 1);
        }
        else if (*curr_parent == NULL) 
        {
            parms->err_directive = newdir;
            return apr_pstrcat(temp_pool, cmd_name,
                               " without matching <", cmd_name + 2,
                               " section", NULL);
        }
        else 
        {
            char *bracket = cmd_name + strlen(cmd_name) - 1;
            if (*bracket != '>') 
            {
                parms->err_directive = newdir;
                return apr_pstrcat(temp_pool, cmd_name,
                                   "> directive missing closing '>'", NULL);
            }
            *bracket = '\0';
            if (strcasecmp(cmd_name + 2,
                           (*curr_parent)->directive + 1) != 0) 
            {
                parms->err_directive = newdir;
                return apr_pstrcat(temp_pool, "This pair doesn't match <",
                                   (*curr_parent)->directive + 1, "> ",
                                   cmd_name, ">", NULL);
            }
            *bracket = '>';
            /* done with this section; move up a level */
            *current = *curr_parent;
            *curr_parent = (*current)->parent;
        }
    }
    else 
    {
        *current = cuwa_iis_add_node(curr_parent, *current, newdir, 0);
    }
    return NULL;
}

static cuwa_err_t iis_build_config( apr_pool_t *p, apr_pool_t *temp_pool,cuwa_iis_cmd_parms *parm, apr_file_t *file,cuwa_iis_directive **conftree  )
{
    cuwa_err_t rc = CUWA_OK;
    char *l = apr_palloc (parm->temp_pool, MAX_STRING_LEN);
    char *errmsg;
    cuwa_iis_directive *current = *conftree;
    cuwa_iis_directive *curr_parent = NULL;

    cuwa_trace("start to build config tree...");

    while (!(cuwa_iis_file_getline( l,MAX_STRING_LEN, file, parm ))) 
    {
        errmsg = iis_build_config_sub(l, parm, p, temp_pool, 
                                     &current, &curr_parent );
        if (errmsg)
            cuwa_warning("conf error:%s", errmsg);
        FAIL_IF( errmsg, CUWA_ERR_IIS_CONF);

        if (*conftree == NULL && curr_parent != NULL) 
            *conftree = curr_parent;
        
        if (*conftree == NULL && current != NULL) 
            *conftree = current;
        
    }

    if (curr_parent != NULL)  
    {
        errmsg = "";
        while (curr_parent != NULL) 
        {
            errmsg = apr_psprintf(p, "%s%s%s:%u: %s> was not closed.",
                                  errmsg,
                                  *errmsg == '\0' ? "" : APR_EOL_STR,
                                  CUWA_IIS_CONF,
                                  curr_parent->line_num,
                                  curr_parent->directive);
            parm->err_directive = curr_parent;
            curr_parent = curr_parent->parent;
        }
        rc = CUWA_ERR_IIS_CONF;
    }
cleanup:
    if ( rc )
    {        
        cuwa_crit("Syntax error on line %d of %s: %s",
                   parm->err_directive->line_num,
                   CUWA_IIS_CONF, errmsg);
    }
    return rc;
}


static apr_file_t *iis_read_config( apr_pool_t *pool, apr_pool_t *tempPool, cuwa_iis_directive **conftree)
{
    cuwa_err_t rc = CUWA_OK;
    char *confFile;
    cuwa_iis_cmd_parms parms;
    apr_file_t *file = NULL;

    confFile = cuwa_iis_find_conf_file(tempPool);
    FAIL_IF(!confFile, CUWA_ERR_IIS_CONF);
    cuwa_trace("conf file:%s", confFile);

    parms = default_parms;
    parms.server = cuwa_iis_server_get_base(); 
    parms.pool = pool;
    parms.temp_pool = tempPool;
    parms.line_num = 0;
    parms.override = (RSRC_CONF | OR_ALL) & ~(OR_AUTHCFG | OR_LIMIT);
 
    file = cuwa_iis_open_file( confFile, pool );
    FAIL_IF( !file, CUWA_ERR_IIS_CONF );

    rc = iis_build_config( pool,tempPool, &parms, file, conftree );    
    FAIL_IF( rc, rc );

    cuwa_iis_cfgtree_show( *conftree );

cleanup:
    if ( rc )
        file = NULL;
    
    return file;
}

static const char *iis_walk_config_sub(cuwa_iis_directive *current,
                                       cuwa_iis_cmd_parms *parms,
                                       CUWACfg_t *config, cuwa_iis_dir_config *dirConfig)
{
    const cuwa_iis_command_rec *cmd = NULL;
    const char *retval = NULL;
    cuwa_err_t rc;

    //cuwa_trace("find cmd %s", current->directive);
    cmd = cuwa_iis_find_cmd( current->directive );
    if ( !cmd )
    {
        parms->err_directive = current;
        retval = apr_pstrcat(parms->temp_pool, "command ",current->directive,
                               " invalid", NULL);
        FAIL_IF(!cmd, CUWA_ERR_IIS);
    }

    retval = cuwa_iis_invoke_cmd(cmd, parms, config, dirConfig, current->args);
    if (retval != NULL ) 
    {
        /* If the directive in error has already been set, don't
         * replace it.  Otherwise, an error inside a container
         * will be reported as occuring on the first line of the
         * container.
         */
         if (!parms->err_directive) 
             parms->err_directive = current;
    }
cleanup:
    //cuwa_trace(" finished with status %s", retval?retval:"succeed");
    return retval;
}

const char *cuwa_iis_walk_config(cuwa_iis_directive *current,
                                 cuwa_iis_cmd_parms *parms,
                                 CUWACfg_t *config, cuwa_iis_dir_config *dirConfig)
{

    /* scan through all directives, executing each one */
    for (; current != NULL; current = current->next) 
    {
        const char *errmsg;
        parms->directive = current;
        /* actually parse the command and execute the correct function */
        errmsg = iis_walk_config_sub(current, parms, config, dirConfig);

        if (errmsg) 
            return errmsg;
    }
    return NULL;
}

static cuwa_err_t  iis_process_config_tree(cuwa_iis_server *s,
                                           cuwa_iis_directive *conftree,
                                           apr_pool_t *p,
                                           apr_pool_t *ptemp)
{
    const char *errmsg;
    cuwa_iis_cmd_parms parms;

    cuwa_trace("");
    cuwa_trace("Start to process config tree ...");
    parms = default_parms;
    parms.pool = p;
    parms.temp_pool = ptemp;
    parms.server = s;
    parms.override = (RSRC_CONF | OR_ALL) & ~(OR_AUTHCFG | OR_LIMIT);

    errmsg = cuwa_iis_walk_config(conftree, &parms, s->config,NULL);
    if (errmsg) 
    {        
        cuwa_crit("Syntax error on line %d of %s: %s",
                   parms.err_directive->line_num,
                   CUWA_IIS_CONF, errmsg);
        return CUWA_ERR_IIS_CONF;
    }
    return CUWA_OK;    
}

cuwa_err_t cuwa_cfg_init(apr_pool_t *pool, CUWACfg_t **root_cfg, void **root_vhost)
{
    apr_pool_t *tempPool = NULL;
    cuwa_err_t rc = CUWA_OK;
    apr_status_t rv;  
    cuwa_iis_directive *conftree = NULL;
    apr_file_t *file = NULL;
    cuwa_iis_server *s = NULL;
    char *strValue = NULL;
   
    cuwa_trace("start to init iis config");
    //temporary pool. Can be freed by the end of init.
    rv = apr_pool_create( &tempPool, pool );
    if ( rv )
        cuwa_crit("Failed to create temporary pool");
    FAIL_IF( rv, CUWA_ERR_IIS );

    s = cuwa_iis_server_init( pool );
    if ( !s )
        cuwa_crit("Failed to create server");
    FAIL_IF( !s, CUWA_ERR_IIS );
    
    s->loglevel = CUWA2_L_WARNING;
    *root_vhost = s;

    file  = iis_read_config( pool,tempPool, &conftree );
    FAIL_IF( !file, CUWA_ERR_IIS_CONF );

    rc = iis_process_config_tree( *root_vhost, conftree ,pool, tempPool);
    FAIL_IF(rc, rc);

    cuwa_iis_fixup_virtual_hosts();
    
    *root_cfg = cuwa_iis_server_get_config( *root_vhost );

    //check if environment KRB5RCACHETYPE is set
    strValue =  getenv("KRB5RCACHETYPE");
    if (!strValue || strcmp(strValue,"none"))
    {
        cuwa_crit( "CUWA Error: Environment variable KRB5RCACHETYPE is either not set or set to a value other than none. Please add KRB5RCACHETYPE as system environment on your server. Set its value to none. Then reboot Windows server.");
        rc = CUWA_ERR;
    }

cleanup:
    if ( file )
        apr_file_close( file );

    if ( tempPool )
        apr_pool_destroy( tempPool);

    cuwa_trace("iis_cfg_init completed with status=%d", rc);

    return rc;
}

CUWACfg_t *cuwa_cfg_from_path( cuwa_iis_server *server, char *path, char *mapped_path,
                              cuwa_iis_dir_config **dirConfig)
{

    return cuwa_iis_server_find_cfg( server, path, mapped_path,dirConfig );
}

// Config related WAL functions
CUWACfg_t *cuwa_wal_get_config_from_server(void *server)
{
    return cuwa_iis_server_get_config( (cuwa_iis_server *)server );
}

void *cuwa_wal_get_next_server(void *server)
{
    return cuwa_iis_get_next_server((cuwa_iis_server *)server);
}

    

const char id_iis_iis_cfg_c[] = "$Id$";
