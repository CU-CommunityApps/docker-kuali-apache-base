/************************************************************************
 * iis_cfg.h -- Config support for IIS
 *
 * Copyright 2008 Cornell University.
 * All Rights Reserved.
 *
 ************************************************************************
 *  $Log$
 *  Revision 1.15  2011/02/24 18:34:09  hy93
 *  support IIS impersonation
 *
 *  Revision 1.14  2009/11/17 18:49:42  hy93
 *  implement log rotation
 *
 *  Revision 1.13  2009/03/11 15:16:34  hy93
 *  Support display initialization error messages to browser
 *
 *  Revision 1.12  2008/10/07 19:37:24  hy93
 *  iis log support
 *
 *  Revision 1.11  2008/09/25 19:50:01  hy93
 *  SetHandler support
 *
 *  Revision 1.10  2008/09/25 18:41:49  hy93
 *  add port support in virtualHost define
 *
 *  Revision 1.9  2008/09/25 16:35:43  hy93
 *  remove some un-used hack code
 *
 *  Revision 1.8  2008/09/19 19:59:02  hy93
 *  remove hack. modified function prototype
 *
 *  Revision 1.7  2008/09/13 15:49:05  pb10
 *  Fix up version stuff
 *
 *  Revision 1.6  2008/09/12 19:17:32  pb10
 *  redirect to weblogin
 *
 *  Revision 1.5  2008/09/12 04:22:31  pb10
 *  HA working, log working
 *
 *  Revision 1.4  2008/09/11 20:31:47  pb10
 *  Compiles
 *
 *  Revision 1.3  2008/09/11 04:42:31  pb10
 *  More refining of the API.
 *
 *  Revision 1.1  2008/09/09 05:46:56  pb10
 *  Preliminary API established.
 *
 *
 ************************************************************************
 */

#ifndef _IIS_CFG_H
#define _IIS_CFG_H

#include <cfg.h>
#include <apr_pools.h>
#include <iis_server.h>
#include <iis_cfgtree.h>
#include <iis_cmd.h>

// functions called by cuwebauth_iis.c...

// This parses the config file.  I think it will be called for each process created.
// Config file uses same path as the cuwebauth.dll with the name cuwebauth.conf
//
// This function returns the root configuration and vhost
// Returns non-zero if the configuration parse fails
int cuwa_cfg_init( apr_pool_t *pool, CUWACfg_t **root_cfg, void **root_vhost );

// Map the path to the appropriate config
CUWACfg_t *cuwa_cfg_from_path( cuwa_iis_server *s, char *path, char *mapped_path,cuwa_iis_dir_config **dirConfig);

const char *cuwa_iis_walk_config(cuwa_iis_directive *current, cuwa_iis_cmd_parms *parms,CUWACfg_t *section, cuwa_iis_dir_config *dirConfig);
char *cuwa_iis_get_authtype( cuwa_iis_dir_config *dirConfig);
const apr_array_header_t *cuwa_iis_get_requires( cuwa_iis_dir_config *dirConfig);
char *cuwa_iis_get_require_line( void *requires,int index);
char *cuwa_iis_get_handler( cuwa_iis_dir_config *dirConfig );
void cuwa_iis_cfg_log(const char *fmt, ... );
int  cuwa_iis_init_in_progress();
int lock_log_file();
void unlock_log_file();
#endif
