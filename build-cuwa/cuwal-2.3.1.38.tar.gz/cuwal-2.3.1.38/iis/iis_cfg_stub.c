// temporary stub code while hong works on the config piece...
#include <cfg.h>
#include <wal.h>
#include <apr_pools.h>
#include <iis_cfg.h>

static CUWACfg_t cuwa_master_cfg;

static char *CUWAKerberosPrincipal = "web-agent/bosanko@CIT.CORNELL.EDU";
static char *CUWAKeytab  = "c:\\logs\\bosanko.keytab";
static char *CUWAWebLoginURL = "https://web1.login.cornell.edu/";
static char *CUWAsessionFilePath = "c:\\sessions";

int cuwa_cfg_init( apr_pool_t *pool, CUWACfg_t **root_cfg, void **root_vhost )
{
    CUWACfg_t *cfg = &cuwa_master_cfg;

	memset(cfg,0,sizeof(cuwa_master_cfg));
	*root_cfg = cfg;
	*root_vhost = cfg;

    cfg->CUWAKerberosPrincipal.s = CUWAKerberosPrincipal;
    cfg->CUWAWebLoginURL.s = CUWAWebLoginURL;
    cfg->CUWAKeytab.s = CUWAKeytab;
    cfg->CUWAsessionFilePath.s = CUWAsessionFilePath;
	return 0;
}

// Map the path to the appropriate config
CUWACfg_t *cuwa_cfg_from_path(char *server_name, char *path, char *mapped_path)
{
	return &cuwa_master_cfg;
}

CUWACfg_t *cuwa_wal_get_config_from_server(void *server)
{
	return &cuwa_master_cfg;
}

void *cuwa_wal_get_next_server(void *server)
{
	// only one server
	return NULL;
}

