/************************************************************************
 * iis_cmd.h -- directive command support for IIS
 *
 * Copyright 2008 Cornell University.
 * All Rights Reserved.
 *
 ************************************************************************
 *  $Log$
 *  Revision 1.5  2010/02/12 15:00:54  hy93
 *  fix memory problem
 *
 *  Revision 1.4  2008/09/25 16:30:38  hy93
 *  implement location and directory matching and inheritance rules similar to Apache
 *
 *  Revision 1.3  2008/09/22 14:24:58  hy93
 *  modified return type of merge_config function
 *
 *  Revision 1.2  2008/09/19 20:01:12  hy93
 *  remove path from include
 *
 *  Revision 1.1  2008/09/16 17:58:57  hy93
 *  iis config support
 *
 *
 ************************************************************************
 */
#ifndef _IIS_CMD_H
#define _IIS_CMD_H

#include <apr_pools.h>
#include <iis_cfgtree.h>
#include <cfg.h>
#include <iis_server.h>

#define OR_LIMIT 1           /**< *.conf inside <Directory> or <Location>
                                and .htaccess when AllowOverride Limit */
#define OR_OPTIONS 2         /**< *.conf anywhere */
#define OR_AUTHCFG 8         /**< *.conf inside <Directory> or <Location> */
#define RSRC_CONF 128        /**< *.conf outside <Directory> or <Location> */
#define OR_ALL (OR_LIMIT|OR_OPTIONS|OR_AUTHCFG)

#define CUWA_IIS_CMD        1       //cuwebAuth command
#define CUWA_IIS_CORE_CMD   2       // command inherit from Apache,like Location, Directory, VirtualHost

#define IIS_INIT_TAKE1(directive, func,  where, type, help) \
    { directive, func, where, TAKE1, type, help }

#define IIS_INIT_RAW_ARGS(directive, func, where, type, help) \
    { directive, func, where, RAW_ARGS, type, help }

/**
 * How the directives arguments should be parsed.
 * @remark Note that for all of these except RAW_ARGS, the config routine is
 *      passed a freshly allocated string which can be modified or stored
 *      or whatever...
 */
enum cmd_how {
    RAW_ARGS,                   /**< cmd_func parses command line itself */
    TAKE1                      /**< one argument only */
};


typedef const char *(*cmd_func) ();
typedef struct{
    /** Name of this command */
    const char *name;

    /** The function to be called when this directive is parsed */
    cmd_func func;

    int req_override;
    /** What the command expects as arguments
     *  @defvar cmd_how args_how*/
    enum cmd_how args_how;

    //command type, cuwa command or core command
    int type;

    /** 'usage' message, in case of syntax errors */
    const char *errmsg;

}cuwa_iis_command_rec;


typedef struct{

    cuwa_iis_server *server;
    apr_pool_t *pool;
    apr_pool_t *temp_pool;
    int line_num;
    cuwa_iis_directive *directive;
    cuwa_iis_directive *err_directive;

    /** If configuring for a directory, pathname of that directory.
     *  NOPE!  That's what it meant previous to the existance of <Files>,
     * <Location> and regex matching.  Now the only usefulness that can be
     * derived from this field is whether a command is being called in a
     * server context (path == NULL) or being called in a dir context
     * (path != NULL).  */
    char *path;
    int override;
}cuwa_iis_cmd_parms;

const cuwa_iis_command_rec *cuwa_iis_find_cmd(const char *name);
const char *cuwa_iis_invoke_cmd( const cuwa_iis_command_rec *cmd, cuwa_iis_cmd_parms *parms, CUWACfg_t *config, cuwa_iis_dir_config *dirConfig, const char *args );
void cuwa_iis_merge_config(CUWACfg_t *base_config, CUWACfg_t *config);

#endif
