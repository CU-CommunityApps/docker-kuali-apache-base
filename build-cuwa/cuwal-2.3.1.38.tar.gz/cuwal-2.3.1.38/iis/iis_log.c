/************************************************************************
 * iis_log.c -- log support for IIS
 *
 * Copyright 2008 Cornell University.
 * All Rights Reserved.
 *
 ************************************************************************
 *  $Log$
 *  Revision 1.8  2010/05/06 18:02:08  hy93
 *  remove log rotation feature and checkins that tried to fix log rotation problem
 *
 *  Revision 1.7  2010/03/02 15:58:44  hy93
 *  try to fix iis crash
 *
 *  Revision 1.6  2010/02/12 14:48:54  hy93
 *  fix memory leak
 *
 *  Revision 1.5  2009/03/11 15:16:44  hy93
 *  Support display initialization error messages to browser
 *
 *  Revision 1.4  2009/02/11 03:12:43  hy93
 *  add pid tid in log
 *
 *  Revision 1.3  2009/02/10 15:13:01  hy93
 *  print remote IP in IIS log
 *
 *  Revision 1.2  2008/11/11 14:33:38  hy93
 *  fix using a wrong thread key to get server pointer which might cause program corruption
 *
 *  Revision 1.1  2008/10/07 19:36:37  hy93
 *  iis log support
 *
 *
 ************************************************************************
 */

#define CUWA2_LOG_DOMAIN cuwa.iis.log

#include <cfg.h>
#include <log.h>
#include <apr_thread_proc.h>
#include <apr_time.h>
#include <apr_file_io.h>
#include <iis_server.h>
#include <windows.h>
#include <wal.h>
#include <iis_cfg.h>

void cuwa_log_print( int logLevel, char *file, int line, int severity, char *logdomain, char *msg)
{
    apr_threadkey_t *request_key = cuwa_log_get_request_key();
    apr_threadkey_t *server_key = cuwa_log_get_server_key();
    void *req = NULL;
    void *server = NULL;
    char timeStr[100];
    apr_file_t *pFile = NULL;
    int configLogLevel = -1;
    char *strToWrite, *sidStr=NULL;
    char *remote_IP = "";
    
    apr_ctime( timeStr,apr_time_now());
    
    if ( request_key && server_key )
    {
    	apr_threadkey_private_get(&req, request_key);            
        apr_threadkey_private_get(&server, server_key);
                
        pFile = cuwa_iis_server_get_log( server, &configLogLevel );
        if ( req )
        {
            sidStr = cuwa_wal_note_get( req, "CUWA_SID");
            remote_IP = cuwa_wal_get_remote_IP( req );
        }
    } 
    
    if ( (configLogLevel >= 0) && (severity > configLogLevel) )
            return;

   strToWrite = cuwa_sprintf("[%s] %s %lu|%lu %s(%d),%s,|%d|%s|%s\n",timeStr, remote_IP, getpid(),GetCurrentThreadId(),file,line,sidStr?sidStr:"-",severity,logdomain,msg);
 
    if ( pFile )
    {
        apr_size_t len = strlen(strToWrite);
        apr_file_write(pFile, strToWrite, &len );
    }
	
    if ( (severity < CUWA2_L_WARNING) && cuwa_iis_init_in_progress() )
        cuwa_iis_cfg_log("%s", msg);
	
    OutputDebugString(strToWrite);     

	free(strToWrite);
}

CUWACfg_t *cuwa_log_get_config_context()
{
    apr_threadkey_t *request_key = cuwa_log_get_request_key();
    apr_threadkey_t *server_key = cuwa_log_get_server_key();
    apr_status_t apr_err;
    cuwa_err_t status = CUWA_OK;
    CUWACfg_t *cfg = NULL;
    void *server = NULL;

    if ( !request_key || !server_key )
    {
        //log hasn't been initialized yet
        return NULL;
    }

    apr_err = apr_threadkey_private_get(&server, server_key);
    status = cuwa_log_apr_err( apr_err );

    if ( status == CUWA_OK)
    {
        cfg = cuwa_iis_server_get_config( (cuwa_iis_server *)server );
    }

    return cfg;
}

void cuwa_iis_native_log( apr_status_t apr_err, char *buf )
{
    OutputDebugString("thread key error");
    OutputDebugString(buf);
}

void cuwa_iis_log_close( void *server, apr_pool_t *pool)
{
    apr_file_t *file = NULL;
    int level;

    while ( server )
    {
        file = cuwa_iis_server_get_log( server, &level ); 
        if ( file )
            apr_file_close( file );

        server = cuwa_iis_get_next_server( (cuwa_iis_server *)server );
    }

    cuwa_log_delete_key( pool );
} 
          
