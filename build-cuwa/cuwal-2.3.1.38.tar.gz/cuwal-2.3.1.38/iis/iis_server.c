/************************************************************************
 * iis_server.c -- server config support for IIS
 *
 * Copyright 2008 Cornell University.
 * All Rights Reserved.
 *
 ************************************************************************
 *  $Log$
 *  Revision 1.28  2011/06/20 19:39:37  hy93
 *  IIS 7 doesn't put / at the end of mapped path which causes root directory not protected if using <directory> block
 *
 *  Revision 1.27  2011/03/18 16:18:45  hy93
 *  remove impersonatation support
 *
 *  Revision 1.26  2011/02/24 18:33:53  hy93
 *  support IIS impersonation
 *
 *  Revision 1.25  2010/12/16 20:41:09  hy93
 *  fix the error introduced from previous check in
 *
 *  Revision 1.24  2010/12/13 14:44:59  hy93
 *  Fix wrong matching when using location block
 *
 *  Revision 1.23  2010/05/06 18:02:00  hy93
 *  remove log rotation feature and checkins that tried to fix log rotation problem
 *
 *  Revision 1.22  2010/03/02 16:48:15  hy93
 *  should lock before the compare
 *
 *  Revision 1.21  2010/03/02 16:04:01  hy93
 *  try to fix iis crash
 *
 *  Revision 1.20  2010/02/12 15:13:51  hy93
 *  fix memory problem
 *
 *  Revision 1.19  2010/02/12 15:00:25  hy93
 *  fix memory problem
 *
 *  Revision 1.18  2010/01/06 16:26:46  hy93
 *  Fix application corrupt when ErrorLog is defined outside of VirtualHost
 *
 *  Revision 1.17  2010/01/06 15:24:59  hy93
 *  Try to fix program corrunpt on customer win2003 IIS6
 *
 *  Revision 1.16  2009/11/17 18:51:24  hy93
 *  implement log rotation
 *
 *  Revision 1.15  2009/05/26 16:28:33  hy93
 *  Fix locatio block is case sensitive
 *
 *  Revision 1.14  2009/04/21 14:53:37  hy93
 *  Fix access denied error when <directory> block is defined in conf in some situation
 *
 *  Revision 1.13  2009/03/11 15:17:41  hy93
 *  Support display initialization error messages to browser
 *
 *  Revision 1.12  2008/11/03 17:03:31  hy93
 *  Fix no directory mapping found because of case
 *
 *  Revision 1.11  2008/10/29 15:12:30  hy93
 *  add inheritance for authName,authType,require,setHandler
 *
 *  Revision 1.10  2008/10/07 19:36:52  hy93
 *  iis log support
 *
 *  Revision 1.9  2008/09/25 19:49:49  hy93
 *  SetHandler support
 *
 *  Revision 1.8  2008/09/25 18:42:17  hy93
 *  add port support in virtualHost define
 *
 *  Revision 1.7  2008/09/25 16:36:06  hy93
 *  implement location and directory matching and inheritance rules similar to Apache
 *
 *  Revision 1.6  2008/09/22 14:25:43  hy93
 *  modified return type of merge_config function
 *
 *  Revision 1.5  2008/09/19 20:04:58  hy93
 *  convert backward slash to forward slash in mapped path before trying to find cfg
 *
 *  Revision 1.4  2008/09/17 03:20:50  hy93
 *  add support for logLevel and errorLog
 *
 *  Revision 1.3  2008/09/16 18:04:18  hy93
 *  add version control
 *
 ************************************************************************
 */
#include <log.h>
#include <list.h>
#include <cuwa_err.h>
#include <iis_server.h>
#include <apr_pools.h>
#include <apr_strings.h>
#include <iis_cmd.h>
#include <util.h>
#include <cuwa_malloc.h>

#define CUWA2_LOG_DOMAIN cuwa.iis.server

#define CUWA_SERVER_NAME(s) s->name?s->name:"base"

//list of all servers 
static cuwa_list *cuwa_iis_server_list = NULL;

static void iis_server_add( cuwa_iis_server *s)
{
    cuwa_list_append( &cuwa_iis_server_list, s );
}

cuwa_iis_server * cuwa_iis_server_init( apr_pool_t *pool )
{
    cuwa_err_t rc = CUWA_OK;
    cuwa_iis_server *s = NULL;
    cuwa_node *lastNode = NULL;
    cuwa_iis_server *lastServer = NULL;

    if ( cuwa_iis_server_list )
        lastNode = cuwa_iis_server_list->tail;

    if ( lastNode )
        lastServer = (cuwa_iis_server *)lastNode->data;
 
    //create server
    s = (cuwa_iis_server *)apr_pcalloc(pool, sizeof(cuwa_iis_server));
    FAIL_IF( !s, CUWA_ERR_IIS );

    s->name = NULL; 
    s->dirConfigs = NULL;
    s->config = (CUWACfg_t *) apr_pcalloc(pool, sizeof(CUWACfg_t));
    s->is_virtual = 0;
    s->next = NULL;
    s->port = NULL;

    iis_server_add( s );

    if ( lastServer )
        lastServer->next = s;

cleanup:
    cuwa_trace("new server created with status =%d", rc); 
    return s;
}

cuwa_iis_server *cuwa_iis_server_get_base()
{
    cuwa_node *node = cuwa_iis_server_list->head;
    cuwa_iis_server *server = NULL;
 
    if ( node )
        server = (cuwa_iis_server *)node->data;

    return server;
}    


const char *cuwa_iis_init_virtual_host(apr_pool_t *p,
                                       const char *hostname,
                                       cuwa_iis_server **ps)
{
    cuwa_iis_server *s = cuwa_iis_server_init( p );
    char *str = NULL;

    if ( !s )
        return apr_pstrcat(p, "Failed to create host", hostname, NULL );

    s->is_virtual = 1;

    //let's check if port number is defined in virtual host
    str = strchr(hostname,':');
    if (str)
    {
        s->port = apr_pstrdup( p, str+1 );
        *str = '\0';
    }
    s->name = apr_pstrdup(p, hostname);
    s->loglevel = -1;

    *ps = s;
    cuwa_trace("new virtual host created:%s:%s", s->name,s->port);
    return NULL;
}

cuwa_iis_dir_config *cuwa_iis_server_new_dirConfig( apr_pool_t *pool, cuwa_iis_server *s)
{
   cuwa_iis_dir_config *dir;

   if ( !s->dirConfigs )
       s->dirConfigs = apr_array_make( pool, 1, sizeof(cuwa_iis_dir_config) );

   dir = apr_array_push( s->dirConfigs );

   dir->requires = apr_array_make( pool, 1, sizeof(struct require_line));

   return dir;

}


/*
 * return the parent directory name including trailing / of the file s
 */
static char *iis_make_dirstr_parent(apr_pool_t *p, const char *str)
{
    char *last_slash;
    char *d;
    int l;
    char *s = apr_pstrdup( p, str);

    if ( s[strlen(s)-1] == '/' )
        s[strlen(s)-1] = 0;

    last_slash = strrchr(s, '/');

    if (last_slash == NULL) {
        return NULL;
    }
    l = (last_slash - s) + 1;
    d = apr_palloc(p, l + 1);
    memcpy(d, s, l);
    d[l] = 0;

    return (d);
}

static void iis_merge_dir( cuwa_iis_dir_config *dir1,cuwa_iis_dir_config *dir2 )
{
    if ( !dir2->auth_type )
        dir2->auth_type = dir1->auth_type;

    if ( !dir2->auth_name )
        dir2->auth_name = dir1->auth_name;

    if ( !dir2->handler )
        dir2->handler = dir1->handler;

    if ( !dir2->requires || (dir2->requires->nelts == 0) )
        dir2->requires = dir1->requires;
}

static void iis_inherit_parent_dir( apr_array_header_t *dirConfigs, CUWACfg_t *cfg, cuwa_iis_dir_config *dir, char *name)
{
    int i;
    cuwa_iis_dir_config *dirs;

    if ( !dirConfigs )
        return;

    dirs = (cuwa_iis_dir_config *)dirConfigs->elts;

    for (i=dirConfigs->nelts-1; i>=0; i--)
    {    
        //only check for directory
        if ( !dirs[i].is_directory )
            continue;
         
        if ( !stricmp( dirs[i].dir, name ) )
        {
            cuwa_trace("inherited from %s",dirs[i].dir);
            cuwa_iis_merge_config( dirs[i].config, cfg);                    
            iis_merge_dir( &dirs[i], dir);
        }
    }
}

static void iis_inherit_dir( apr_array_header_t *dirConfigs, apr_array_header_t *base_dirConfigs,CUWACfg_t *cfg, cuwa_iis_dir_config *dir, char *mpath)
{
    char *name = NULL; 
    apr_pool_t *p = cuwa_malloc_get_pool();
       
    name = apr_pstrdup( p, mpath );
    cuwa_trace("check inheritance from parent: %s", mpath);
   
    while ( name )
    {
        //find if parent dir is defined
        iis_inherit_parent_dir( dirConfigs, cfg, dir, name);
        
        iis_inherit_parent_dir( base_dirConfigs, cfg, dir, name);            
        
        name = iis_make_dirstr_parent( p, name);
   }
}



void cuwa_iis_fixup_virtual_hosts()
{
    cuwa_node *node = cuwa_iis_server_list->head;   //we have at lease one server in server list
    cuwa_iis_server *base_server = (cuwa_iis_server *)node->data;
    cuwa_iis_server *server = NULL;

    cuwa_trace("going to fixup virtual hosts...");
    
    while ( (node=node->next) )
    {
        server = (cuwa_iis_server *)node->data;
        cuwa_trace("merge server config %s with base server", server->name); 

        cuwa_iis_merge_config( base_server->config, server->config );        
        
        //inherit log file setting from base server
        if ( server->loglevel < 0 )
            server->loglevel = base_server->loglevel;

        if ( !server->log_file )
        {
            server->log_file = base_server->log_file;
            server->error_log = base_server->error_log;
        }
    } 
    
}

static CUWACfg_t *iis_cfg_from_dir( apr_array_header_t *dirConfigs, char *path, cuwa_iis_dir_config **returnDir)
{
    CUWACfg_t *cfg = NULL;
    cuwa_iis_dir_config *dirs = NULL;
    int i, currLevel = 0;

    if ( !dirConfigs )
        return NULL;
    
    dirs = (cuwa_iis_dir_config *)dirConfigs->elts;

    for (i=0; i<dirConfigs->nelts; i++)
    {   
        if ( !dirs[i].is_directory )
            continue;
        
        if ( !strnicmp( dirs[i].dir, path, strlen(dirs[i].dir) ))
        {
            //we found a match
            //cuwa_trace("component=%d, currentLevel=%d",dirs[i].d_components,currLevel );
            if ( dirs[i].d_components >= currLevel )
            {
                cuwa_trace("found qualified dir:%s", dirs[i].dir);
                currLevel = dirs[i].d_components;
                cfg = dirs[i].config;
                *returnDir = &dirs[i];                
            }
        }
    }
    return cfg;
}

static CUWACfg_t *iis_search_cfg_by_dir( cuwa_iis_server *server, char *path, cuwa_iis_dir_config **returnDir)
{
    apr_array_header_t *dirConfigs = server->dirConfigs, *base_dirConfigs=NULL;
    cuwa_iis_dir_config *dirs1=NULL,*dirs2=NULL;
    CUWACfg_t *cfg = NULL, *cfg2=NULL, *returnCfg=NULL;
    cuwa_iis_server *base_server = cuwa_iis_server_get_base();
    cuwa_iis_dir_config *dir = NULL;
 
    cuwa_trace("search cfg from directory:path=%s",path);

    if ( server->is_virtual )
        base_dirConfigs = base_server->dirConfigs;

    cfg = iis_cfg_from_dir(dirConfigs, path,&dirs1);

    cfg2 = iis_cfg_from_dir(base_dirConfigs, path,&dirs2);

    //let's see which match is the closer
    if ( cfg && cfg2 )
    {
        if ( dirs1->d_components >= dirs2->d_components )
            *returnDir = dirs1;
        else
        {
            *returnDir = dirs2;
            cfg = cfg2;
        }
    }
    else if (!cfg && cfg2)
    {
        cfg = cfg2;
        *returnDir = dirs2;
    }
    else if ( cfg && !cfg2 )
        *returnDir = dirs1;
    else
        *returnDir = NULL;
     
    //need to allocate new memory for dirConfig since we need to do inheritance later
    if ( *returnDir )
    {
        dir = cuwa_calloc(1, sizeof(cuwa_iis_dir_config));
        cuwa_assert(dir);

        memcpy( dir, *returnDir, sizeof(cuwa_iis_dir_config));
        *returnDir = dir;
    }

    //found the match in both virtual host and base, let's see which one is closer
    if (!cfg )
        cuwa_trace("we didn't find a match directory");
    else
    {
        returnCfg = cuwa_calloc( 1, sizeof(CUWACfg_t) );
        memcpy(returnCfg, cfg, sizeof(CUWACfg_t));

        //handle directory inheritance
        iis_inherit_dir( dirConfigs, base_dirConfigs, returnCfg, *returnDir, path);
        
        //merge with server config
        cuwa_iis_merge_config( server->config, returnCfg);
    }
    return returnCfg;
}

static CUWACfg_t *iis_cfg_from_location( apr_array_header_t *dirConfigs, char *path, cuwa_iis_dir_config **returnDir,int *index)
{
    int i;
    cuwa_iis_dir_config *dirs = NULL;
    CUWACfg_t *cfg = NULL;
    cuwa_iis_dir_config *dir = NULL;
    int len = 0;

    if ( !dirConfigs )
        return NULL;

    dirs = (cuwa_iis_dir_config *)dirConfigs->elts;

    for (i=dirConfigs->nelts-1;i>=0; i--)
    {      
        if ( dirs[i].is_directory )
            continue;

        len = strlen(dirs[i].dir);
        if ( !strnicmp( dirs[i].dir, path, len ))
        {
            if ( !strcmp( dirs[i].dir, "/") || path[len] == '\0' || path[len] == '/')
            {
                //we found a match
                cuwa_trace("found qualified dir:%s", dirs[i].dir);
                
                cfg = dirs[i].config;

                dir = cuwa_calloc(1, sizeof(cuwa_iis_dir_config));
                cuwa_assert(dir);
                memcpy(dir, &dirs[i], sizeof(cuwa_iis_dir_config));

                *returnDir = dir;  
                *index = i;
                break;
           }
        }
    }

    return cfg;
}

static CUWACfg_t *iis_search_cfg_by_location( cuwa_iis_server *server, char *path, char *mpath, cuwa_iis_dir_config **returnDir)
{    
    apr_array_header_t *dirConfigs = server->dirConfigs, *base_dirConfigs=NULL;
    cuwa_iis_dir_config *dirs = NULL;
    int i,index = 0;
    CUWACfg_t *cfg = NULL, *returnCfg=NULL;
    cuwa_iis_server *base_server = cuwa_iis_server_get_base();
    int foundInBase = 0;
    int len = 0;

    cuwa_trace("search server %s:path=%s",CUWA_SERVER_NAME(server),path);

    if ( server->is_virtual )
        base_dirConfigs = base_server->dirConfigs;
    
    cfg = iis_cfg_from_location( dirConfigs, path, returnDir, &index);
    if ( cfg )
    {
        dirs = (cuwa_iis_dir_config *)dirConfigs->elts; 
    }
    else if ( base_dirConfigs )
    {
        //search from the base server directories
        cfg = iis_cfg_from_location( base_dirConfigs, path, returnDir, &index);
        if ( cfg )
        {
            dirs = (cuwa_iis_dir_config *)base_dirConfigs->elts; 
            foundInBase = 1;
        }
    }

    if ( !cfg )
    {      
        cuwa_trace("we didn't find a match directory");
        return cfg;
    }

    returnCfg = cuwa_calloc(1, sizeof(CUWACfg_t) );
    cuwa_assert( returnCfg);

    memcpy( returnCfg, cfg, sizeof(CUWACfg_t) );

    //we found a match, now we need to handle inheritance. Check location inheritance first
    for ( i = index -1; i>=0; i-- )
    {
        if ( dirs[i].is_directory )
            continue;

        len = strlen(dirs[i].dir);
        if ( !strnicmp( dirs[i].dir, path, len ))
        {
            if ( !strcmp(dirs[i].dir, "/") || path[len] == '\0' || path[len] == '/')
            {
                //we found a match
                cuwa_trace("inheritance from:%s", dirs[i].dir);
                
                cuwa_iis_merge_config( dirs[i].config, returnCfg );                 
                iis_merge_dir( &dirs[i], *returnDir );
            }
         }
    }

    //handle inheritance with base server location define            
    if ( base_dirConfigs && !foundInBase)
    {
        dirs = (void *)base_dirConfigs->elts; 
        for (i = base_dirConfigs->nelts-1;i>=0; i--)
        {         
            if ( dirs[i].is_directory )
                continue;

            if ( !strnicmp( dirs[i].dir, path, strlen(dirs[i].dir) ))
            {
                //we found a match
                cuwa_trace("inheritance from:%s", dirs[i].dir);
                cuwa_iis_merge_config( dirs[i].config, returnCfg ); 
                iis_merge_dir( &dirs[i], *returnDir ); 
            }
        }
    }
    //handle directory inheritance
    iis_inherit_dir( dirConfigs, base_dirConfigs, returnCfg, *returnDir, mpath);
        
    //merge with server config
    cuwa_iis_merge_config( server->config, returnCfg);
    
    return returnCfg;
}

cuwa_iis_server * cuwa_iis_find_server( char *name, char *port )
{
    cuwa_iis_server *server = NULL, *tmpServer;
    cuwa_node *node = cuwa_iis_server_list->head;
    cuwa_iis_server *base_server = (cuwa_iis_server *)node->data;

    server = base_server;

    cuwa_trace("find server that matches %s",name);
    while ( (node=node->next) )
    {
       tmpServer = (cuwa_iis_server *)node->data;
      
       if ( !stricmp(tmpServer->name, name) )
       {
           if ( !(tmpServer->port) || ( tmpServer->port && !strcmp( tmpServer->port, port )) )
           {
                server = tmpServer;
                break;
           }
       }
    }
    return server;

}


CUWACfg_t *cuwa_iis_server_find_cfg( cuwa_iis_server *server, char *path, char *mPath, cuwa_iis_dir_config **dirConfig)
{
    CUWACfg_t *cfg = NULL;
    
    if ( mPath )
    {
        cuwa_util_replace_char_with( mPath,'/','\\');
        if (mPath[strlen(mPath)-1] != '\\' )
            mPath = apr_pstrcat( cuwa_malloc_get_pool(), mPath,"\\",NULL);
    }

    if ( path )
    {
        cfg = iis_search_cfg_by_location(server, path, mPath, dirConfig);       
    }

    //we didn't find a match by location, let's try directory
    if ( !cfg && mPath)
    {       
        cfg = iis_search_cfg_by_dir( server, mPath,dirConfig );
    }

    if (!cfg)
    {
        cfg = server->config;
        *dirConfig = NULL;
    }
    
    return cfg;
}



CUWACfg_t *cuwa_iis_server_get_config( cuwa_iis_server *s)
{
    if (s)
        return s->config;
    else
        return NULL;
}

cuwa_iis_server *cuwa_iis_get_next_server(cuwa_iis_server *server)
{
    return server->next;
}

char *cuwa_iis_get_authtype( cuwa_iis_dir_config *dirConfig)
{
    if ( dirConfig )
        return dirConfig->auth_type;

    return NULL;
}

const apr_array_header_t *cuwa_iis_get_requires( cuwa_iis_dir_config *dirConfig)
{
    if ( dirConfig )
        return dirConfig->requires;

    return NULL;
}

char *cuwa_iis_get_require_line( void *r,int index)
{
    struct require_line *requires = (struct require_line *)r;

    if (requires)
        return requires[index].requirement;

    return NULL; 
}

char *cuwa_iis_get_handler( cuwa_iis_dir_config *dirConfig )
{
    if ( dirConfig )
        return dirConfig->handler;

    return NULL;
}

apr_file_t *cuwa_iis_server_get_log( void *server, int *configLevel )
{
    cuwa_iis_server *s = (cuwa_iis_server *)server;
    
    if ( !s )
        return NULL;

    *configLevel = s->loglevel;

    return s->log_file;
}
 
const char id_iis_iis_server_c[] = "$Id$";


