/************************************************************************
 * iis_server.h -- Server Config support for IIS
 *
 * Copyright 2008 Cornell University.
 * All Rights Reserved.
 *
 ************************************************************************
 *  $Log$
 *  Revision 1.13  2011/02/24 18:33:41  hy93
 *  support IIS impersonation
 *
 *  Revision 1.12  2010/05/06 18:02:28  hy93
 *  remove log rotation feature and checkins that tried to fix log rotation problem
 *
 *  Revision 1.11  2010/02/12 14:57:57  hy93
 *  fix memory leak
 *
 *  Revision 1.10  2009/12/01 16:03:29  hy93
 *  log rotation support
 *
 *  Revision 1.9  2008/10/31 19:59:07  hy93
 *  remove user in server_rec
 *
 *  Revision 1.8  2008/10/29 16:45:12  hy93
 *  add directive User
 *
 *  Revision 1.7  2008/10/07 19:37:01  hy93
 *  iis log support
 *
 *  Revision 1.6  2008/09/25 19:49:54  hy93
 *  SetHandler support
 *
 *  Revision 1.5  2008/09/25 18:42:27  hy93
 *  add port support in virtualHost define
 *
 *  Revision 1.4  2008/09/25 16:36:29  hy93
 *  implement location and directory matching and inheritance rules similar to Apache
 *
 *  Revision 1.3  2008/09/19 20:05:22  hy93
 *  remove path from include
 *
 *  Revision 1.2  2008/09/17 03:20:53  hy93
 *  add support for logLevel and errorLog
 *
 *  Revision 1.1  2008/09/16 17:59:20  hy93
 *  iis config support
 *
 *
 ************************************************************************
 */

#ifndef _IIS_SERVER_H
#define _IIS_SERVER_H

#include <cfg.h>
#include <apr_pools.h>
#include <apr_tables.h>
#include <apr_file_io.h>

typedef struct cuwa_iis_server_t cuwa_iis_server;
struct cuwa_iis_server_t{
    char *name;                         //serverName
    char *port;
    apr_array_header_t *dirConfigs;     //all directory configs under this server
    CUWACfg_t *config;                  //pointer to server wide configuration
    int is_virtual;
    char *error_log;                    //error log
    int loglevel;                       //log Level
    apr_file_t *log_file;               //file pointer to opened log file
    struct cuwa_iis_server_t *next;    //pointer to next server
};


typedef struct{
    char *dir;                //path to the directory
    char *auth_type;
    char *auth_name;
    apr_array_header_t *requires;   //all require lines
    CUWACfg_t *config;              //pointer to configuration
    int d_components;
    int is_directory;              //1=directory,0=location
    char *handler;            //for SetHandler
}cuwa_iis_dir_config;

struct require_line {
    /** The complete string from the command line */
    char *requirement;
};


cuwa_iis_server *cuwa_iis_find_server( char *name, char *port );
void cuwa_iis_fixup_virtual_hosts();
cuwa_iis_dir_config *cuwa_iis_server_new_dirConfig( apr_pool_t *p, cuwa_iis_server *s);

const char *cuwa_iis_init_virtual_host(apr_pool_t *p,const char *hostname,cuwa_iis_server **ps);
cuwa_iis_server *cuwa_iis_server_get_base();
cuwa_iis_server *cuwa_iis_server_init( apr_pool_t *pool );

CUWACfg_t *cuwa_iis_server_find_cfg(cuwa_iis_server *server, char *path, char *mPath, cuwa_iis_dir_config **dirConfig);

cuwa_iis_server *cuwa_iis_get_next_server(cuwa_iis_server *server);
CUWACfg_t *cuwa_iis_server_get_config( cuwa_iis_server *s);
const apr_array_header_t *cuwa_iis_get_requires( cuwa_iis_dir_config *dirConfig);
apr_file_t *cuwa_iis_server_get_log( void *s, int *configlevel);
#endif
