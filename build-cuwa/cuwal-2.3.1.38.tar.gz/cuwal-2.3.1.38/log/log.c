/************************************************************************
 * log.c -- logging for CUWebAuth
 *
 * Copyright 2008 Cornell University.
 * All Rights Reserved.
 *
 * Note: Reads environment variables CUWA_LOG and CUWA_LEVEL
 * CUWA_LOG will force logging to the specified file
 * CUWA_LEVEL will override all configuration based log levels
 *
 *
 ************************************************************************
 *  $Log$
 *  Revision 1.44  2008/10/03 19:52:30  hy93
 *  don't need to manipulate file name since Apache's log function will do it
 *
 *  Revision 1.43  2008/10/03 17:01:04  hy93
 *  remove the call to cuwa_malloc_get_pool to avoid using null pool
 *
 *  Revision 1.42  2008/10/03 14:47:34  hy93
 *  add time stamp to windows log
 *
 *  Revision 1.41  2008/09/16 19:22:39  hy93
 *  add static to functions that are internal in the file
 *
 *  Revision 1.40  2008/09/05 02:56:12  gbr4
 *  remove paths to source files from the log messages. When we switched to absolute pathing this got way too big
 *
 *  Revision 1.39  2008/05/09 15:35:58  gbr4
 *  get rid of assertion passed messages. Also add more tracing to weblogin.
 *
 *  Revision 1.38  2008/05/05 19:13:15  gbr4
 *  fix error introduced in log 1.37 that broke solaris build. also commit conditional code used in klocwork build and add an assert in rand to check that /dev/urandom read succeeded.
 *
 *  Revision 1.37  2008/05/03 03:51:26  gbr4
 *  fix resource leak in log.c if stderr is closed and the environment variable for the log file is set.
 *
 *  fix uninitialized variable in cuwl_aputil
 *
 *  Revision 1.36  2008/04/10 16:57:11  gbr4
 *  Line endings only. This set of files had mixed line endings which breaks visual studio (and looks ugly in vim). Each file was converted to the format that resulted in the fewest line changes (i.e. whichever format it was mostly in).
 *
 *  Revision 1.35  2008/03/24 21:32:22  pb10
 *  Better error page support.
 *
 *  Revision 1.34  2008/02/05 07:33:45  gbr4
 *  the id tag can't be static
 *
 *  Revision 1.33  2008/01/28 16:34:30  gbr4
 *  Log now reads environment variables CUWA_LOG and CUWA_LEVEL.
 *
 *  Revision 1.32  2008/01/28 16:33:40  gbr4
 *  Log now reads environment variables CUWA_LOG and CUWA_LEVEL.
 *
 *  Revision 1.31  2008/01/25 01:43:47  gbr4
 *  Added an ID string to every file
 *
 *  Revision 1.30  2008/01/18 15:53:55  hy93
 *  remove absolute path to log file
 *
 *  Revision 1.29  2008/01/18 05:54:09  gbr4
 *  slightly cleaner fprintf hack
 *
 *  Revision 1.28  2008/01/17 16:59:20  hy93
 *  fix compiler warning.chage loglevel to alarm for assertion failure
 *
 *  Revision 1.27  2008/01/17 16:21:25  gbr4
 *  hack to redirect logging to /tmp/apache.out
 *
 *  Revision 1.26  2008/01/16 18:06:12  hy93
 *  Add comment block back for cvs log
 *
 *  Revision 1.24  2008/01/15 14:38:08  hy93
 *  Add version block for cvs
 *
 ************************************************************************
 */

const char id_log_log_c[] = "$Id$";

#ifndef _GNU_SOURCE
#define _GNU_SOURCE
#endif

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdarg.h>
#include <log.h>
#include <pal.h>
#include <util.h>

#ifndef assert
#include <assert.h>
#endif

#define CUWA2_LOG_DOMAIN cuwa.logger

#define CUWA2_LOG_BUF_SIZE 8*1024

static  char *envCUWA_LOG=NULL;
static int initCUWA_LOG=0;
static int envCUWA_LEVEL=-1;


/**
 * vsprintf that allocates and returns a new string. Primarily a helper for logs, most users should see cuwa_sprintf.
 * @param[in] fmt format string (same as *printf)
 * @param[in] args variable argument list
 * @return a pointer to a newly allocated string. Caller must free when done.
 * @see cuwa_sprintf
 */
static char * cuwa_vsprintf(const char *fmt, va_list args)
{
    char* buf=NULL;
#if defined (_MSC_VER)
#pragma warning(push)
#pragma warning( disable:4996 )
    int len=_vscprintf(fmt,args)+1;
    buf=malloc(len);
    if(buf)
    {
        vsnprintf(buf,len,fmt,args);
        buf[len-1]='\0';
    }
#pragma warning(pop)
#elif defined (SUNOS)
    buf = malloc(CUWA2_LOG_BUF_SIZE);
    if ( buf )
    {
        int outSize;

        outSize = vsnprintf(buf,CUWA2_LOG_BUF_SIZE, fmt,args);

        if (  (outSize > 0 ) && (outSize < CUWA2_LOG_BUF_SIZE -1 ))
        {
             //shrink the buffer
             buf = realloc( buf, outSize );
             buf[outSize]='\0';
        }
    }

#else
    vasprintf(&buf,fmt,args);
#endif
    if(!buf)
    {
        cuwa_crit("Unable to format %s", fmt);
        assert(buf); //DIE!
    }
    return(buf);
}

/**
 * sprintf that allocates and returns a new string.
 * @param[in] fmt format string (same as *printf)
 * @return a pointer to a newly allocated string. Caller must free when done.
 * @see cuwa_sprintf
 */
char * cuwa_sprintf(const char * fmt, ...){
    char *ret;
    va_list va;
    va_start(va,fmt);
    ret=cuwa_vsprintf(fmt,va);
    va_end(va);
    return(ret);
}

/**
 * internal logging implimentation
 * @param[in] logdomain the current logging domain. Usually read from CUWA2_LOG_DOMAIN
 * @param[in] file the current source file. Usually __FILE__
 * @param[in] func the current function. Usually __func__
 * @param[in] line the current line. Usually __LINE__
 * @param[in] severity the severity of the message. ranges from atrace to alarm. @see cuwa_atrace|cuwa_trace|cuwa_info|cuwa_notice|cuwa_warning|cuwa_crit|cuwa_alarm
 * @param[in] fmt a printf style format string. All the usual warnings apply
 * @see cuwa_atrace|cuwa_trace|cuwa_info|cuwa_notice|cuwa_warning|cuwa_crit|cuwa_alarm
 */
void cuwa_writelog( int configLogLevel, char * logdomain, const char * file, const char * func, const int line, const int severity, const char * fmt, ...){
    char *cleanfile;
    char *msg;
    va_list va;

    // fixme, might be a concurrancy bug where pointer assignments are not atomic
    if(!initCUWA_LOG){
    	const char * env;
    	env=getenv("CUWA_LOG");
    	if(env){
    		envCUWA_LOG=strdup(env);
    		if(!strcmp(envCUWA_LOG,"stderr")) envCUWA_LOG[0]='\0';
    	}
    	env=getenv("CUWA_LEVEL");
    	if(env){
    	  	envCUWA_LEVEL = atoi(env);    	    		
    	}
    	initCUWA_LOG=1;
    }

    if ((envCUWA_LEVEL==-1 && ((configLogLevel < 0) || (severity <= configLogLevel))) || (envCUWA_LEVEL >=0 && severity <= envCUWA_LEVEL))
    {
        va_start(va,fmt);
        msg = cuwa_vsprintf(fmt,va);
        va_end(va);

#ifdef WIN32
        cleanfile=strrchr(file,'\\');
        cleanfile=cleanfile?cleanfile+1:(char *)file; //trim \ if present
#else
        cleanfile=strrchr(file,'/');
        cleanfile=cleanfile?cleanfile+1:(char *)file; //trim / if present
#endif

#if (defined APACHE_BUILD || defined WIN32)
        if(!envCUWA_LOG){
            if (cuwa_log_should_stash(severity))
                cuwa_log_stash_msg(severity,msg);
        	cuwa_log_print(configLogLevel, cleanfile, line, severity,logdomain, msg);
        }
        else
#else
        {
		int needClose=0;
        	FILE *pFile=stderr; 

		if(envCUWA_LOG && envCUWA_LOG[0]){
			pFile=fopen(envCUWA_LOG,"a");
			if(pFile) needClose=1;
			else pFile=stderr;
		}

        	fprintf(pFile, "%s(%d)|%d|%s|%s\n",cleanfile,line,severity,logdomain,msg);
                fflush( pFile );
        	if(needClose) fclose(pFile);
        }

#endif
        free(msg);
    }
#if (defined APACHE_BUILD || defined WIN32)
    else
    {
        if (cuwa_log_should_stash(severity))
        {
            va_start(va,fmt);
            msg = cuwa_vsprintf(fmt,va);
            va_end(va);
            cuwa_log_stash_msg(severity,msg);
            free(msg);
        }
    }
#endif
}

/**
 * internal assertion implimentation
 * @param[in] logdomain the current logging domain. Usually read from CUWA2_LOG_DOMAIN
 * @param[in] file the current source file. Usually __FILE__
 * @param[in] func the current function. Usually __func__
 * @param[in] line the current line. Usually __LINE__
 * @param[in] expr the stringization of the expression to be evaluated. Used in the log message on failure.
 * @param[in] value if this is false then the assertion fails
 * @param[in] die if this is true and the assertion fails the program is aborted. false for cuwa_test
 */
int cuwa_assertlog( int configLevel, char * logdomain, const char * file, const char * func, const int line, const char* expr, const int value, const int die){
    if(value){
    //    cuwa_writelog(configLevel, logdomain,file,func,line,CUWA2_L_ATRACE,"Assertion %s passed",expr);
    }
    else
        cuwa_writelog(configLevel,logdomain,file,func,line,CUWA2_L_ALARM,"Assertion %s *FAILED*",expr);

    if (die && !value)
    {
        assert(value && expr);
    }
    return(value);
}


