/************************************************************************
 * log_util.c -- log utility 
 *
 * Copyright 2008 Cornell University.
 * All Rights Reserved.
 *
 ************************************************************************
 *  $Log$
 *
 ************************************************************************
 */
#include <apr_pools.h>
#include <apr_strings.h>
#include <apr_thread_proc.h>
#include <cuwa_err.h>
#include <log.h>
#include <wal.h>
#include <stdlib.h>

#ifdef APACHE_BUILD
#include <log_apache.h>
#else
#include <iis_log.h>
#endif

#define CUWA2_LOG_DOMAIN cuwa.logger

static apr_threadkey_t *request_key = NULL;
static apr_threadkey_t *server_key = NULL;
static apr_threadkey_t *connection_key = NULL;

static char * cuwa_log_sanitize(apr_pool_t *pool, char *msg, int init);

cuwa_err_t cuwa_log_apr_err( apr_status_t apr_err)
{
   cuwa_err_t status = CUWA_OK;

   if ( apr_err)
   {
        char buf[512];

        apr_strerror( apr_err, buf, 512 );

#ifdef APACHE_BUILD
        cuwa_apache_native_log(apr_err, buf);
#else
        cuwa_iis_native_log( apr_err, buf );
#endif

        status = CUWA_ERR_THREAD_KEY;
    }

    return status;
}

void cuwa_log_delete_key(void *p)
{
    if ( request_key )
        apr_threadkey_private_delete(request_key);

     if ( server_key )
        apr_threadkey_private_delete(server_key);

     if ( connection_key )
        apr_threadkey_private_delete(connection_key);

}

static cuwa_err_t cuwa_log_create_key( apr_pool_t *pool, apr_threadkey_t **key)
{
    apr_status_t apr_err;
    cuwa_err_t status = CUWA_OK;

    apr_err = apr_threadkey_private_create(key, cuwa_log_delete_key, pool);
    status = cuwa_log_apr_err( apr_err );

    return status;
}

void cuwa_log_set_keys( void *request, void *server, void *conn)
{

    apr_threadkey_private_set(request, request_key);
    apr_threadkey_private_set(server, server_key);
    apr_threadkey_private_set(conn, connection_key);

}
cuwa_err_t cuwa_log_init(apr_pool_t *pool)
{
    cuwa_err_t rc = CUWA_OK;

    cuwa_log_sanitize(NULL, NULL, 1);

    rc = cuwa_log_create_key( pool, &request_key);
    FAIL_IF(rc, rc);

    rc = cuwa_log_create_key( pool, &server_key);
    FAIL_IF(rc, rc);

    rc = cuwa_log_create_key( pool, &connection_key);
    FAIL_IF(rc, rc);

    cuwa_log_set_keys( NULL, NULL, NULL );

cleanup:
    if ( rc )
        cuwa_log_delete_key(NULL);

    return rc;
}

int cuwa_log_should_stash(int logLevel)
{
    char *levelStr = NULL;
    int level = -1;
    void *r = NULL;

    if (logLevel==CUWA2_L_TRACE) return 0;

    apr_threadkey_private_get(&r, request_key);

    if ( r )
    {
        levelStr = cuwa_wal_note_get( r,"CUWA-LogErrorLevel");
        if (!levelStr) return 1;

        level = atoi(levelStr);

        if (logLevel<level) return 1;
    }

    return 0;
}

void cuwa_log_stash_msg(int logLevel, char *msg)
{
    void *r = NULL;
    char *levelStr;
    apr_pool_t *pool;

    apr_threadkey_private_get(&r, request_key);

    if ( r )
    {
        pool = cuwa_wal_get_pool( r );
        if ( !pool )
            return;

        levelStr = apr_itoa(pool, logLevel);
        msg      = cuwa_log_sanitize(pool, msg, 0);
        cuwa_wal_note_set( r, "CUWA-LogErrorLevel",levelStr);
        cuwa_wal_note_set( r,"CUWA-LogError",msg);
    }
}

static char * cuwa_log_sanitize(apr_pool_t *pool, char *msg, int init)
{
    char *out;
    unsigned char *s;
    static int clean_chars[256];

    if (init)
    {
        // Initialize white list once per child...
        memset(clean_chars,0,sizeof(clean_chars));
        clean_chars['-'] = 1;
        clean_chars['_'] = 1;
        clean_chars['.'] = 1;
        clean_chars['/'] = 1;
        clean_chars[':'] = 1;
        clean_chars['@'] = 1;

#define SET_RANGE(f,t,c) do {int i;for (i=(f);i<=(t);i++) (c)[i]=1;} while(0)

        SET_RANGE('a','z',clean_chars);
        SET_RANGE('A','Z',clean_chars);
        SET_RANGE('0','9',clean_chars);
        return NULL;
    }

    // Replace potentially dangerous characters with space
    out = apr_pstrdup( pool, msg );
    s = (unsigned char *) out;
    for (;*s;s++) if (!clean_chars[*s]) *s = ' ';

    return out;
}

apr_threadkey_t *cuwa_log_get_request_key()
{
    return request_key;
}

apr_threadkey_t *cuwa_log_get_server_key()
{
    return server_key;
}

apr_threadkey_t *cuwa_log_get_connection_key()
{
    return connection_key;
}

const char id_log_log_util_c[] = "$Id$";

