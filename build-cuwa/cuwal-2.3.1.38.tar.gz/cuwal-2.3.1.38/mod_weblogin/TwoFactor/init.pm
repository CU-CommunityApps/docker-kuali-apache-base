package TwoFactor::init;

use strict;

use vars qw(%duoConfig);

my $IKEY = "";
my $SKEY = "";
my $AKEY = "";
my $CKEY = "";
my $PASS_THROUGH = "";
my $DUO_HOST = "api-68fd2842.duosecurity.com";

my $key_file_name = "/app/weblogin/conf/cuwl-2FA.key";

open(my $FH, $key_file_name);
while (my $line = readline($FH) ){
    my ($KEY,$value) = split(/=/,$line);

    #remove " and carriage return in the value
    $value =~ tr/"\n\r//d;

    if ($KEY eq "AKEY")
    {
        $AKEY=$value;
    }
    if ($KEY eq "IKEY")
    {
       $IKEY=$value;
    }
    if ($KEY eq "SKEY")
    {
       $SKEY=$value;
    }
    if ($KEY eq "CKEY")
    {
       $CKEY=$value;
    }
    if ($KEY eq "PASSTHROUGH")
    {
       $PASS_THROUGH = $value;
    }
}
close($FH);

my $duoWeb = `cat /app/weblogin/cuwl-html/duoWeb.html`;
my $duoMobile = `cat /app/weblogin/cuwl-html/duoWebMobile.html`;

%duoConfig = (
    keys => {
        IKEY => $IKEY,
        SKEY => $SKEY,
        AKEY => $AKEY,
        CKEY => $CKEY,
    },
    HOST  => $DUO_HOST,
    PASS_THROUGH => $PASS_THROUGH,
    html => {
        web => $duoWeb,
        mWeb => $duoMobile, 
    },
);
