package TwoFactor::test;

use strict;
use warnings;
use CGI ':standard';
use CGI::Cookie;
use LWP::UserAgent;
use TwoFactor::DualHtml;
use Apache2::Const qw(REDIRECT OK);
use TwoFactor::init ();

my $CKEY=$TwoFactor::init::duoConfig{keys}{CKEY};
my $HOST = $TwoFactor::init::duoConfig{HOST};;

my $keeper = "keeper";

my $testID = "cuwa-test-dual\@DEV.CORNELL.EDU";
my $testIDOptin = "cuwa-test-dual-optin\@DEV.CORNELL.EDU";
my $testIDDelegate = "cuwa-test-dlgt\@DEV.CORNELL.EDU";

sub handler {
my $query = CGI->new();
my $r = shift;

my $content = `cat /app/weblogin/cuwl-html/testharness.html`;

if($r->method eq 'GET') {

     my $queryString = &TwoFactor::DualHtml::encode_string($ENV{'QUERY_STRING'});
     $content =~ s/DUO_QUERY_STRING/$queryString/i;

     $r->no_cache(1);
     $r->content_type('text/html; charset=ISO-8859-1');
     $r->print($content);
} 
elsif($r->method eq 'POST') {
    my %cookies = CGI::Cookie->fetch;
    my $dualCookie = "";
    my $netid = "";
    my $keeperStr = $ENV{'QUERY_STRING'};

    $keeperStr = substr $keeperStr, length($keeper)+1;
    my $paramString = &TwoFactor::DualHtml::decode_string( $keeperStr );

    if ($cookies{'cuwlduals'} ) {
        $dualCookie = $cookies{'cuwlduals'}->value;

        $netid = &TwoFactor::DualHtml::verify_cookie($dualCookie,$CKEY);
    }
    if ( ($netid eq $testID) || ($netid eq $testIDOptin) || ($netid eq $testIDDelegate) )
    {
        my $cookie = &TwoFactor::DualHtml::add_cookie( $netid, "TEST", $CKEY);
        $cookie = "\"".$cookie."\"";
        my $newlocation = "/TESTdone?$paramString";

        my $outCookie = CGI::Cookie->new(-name => 'cuwldualv',
                                         -value => $cookie);

        $cookie="cuwldualv=".$cookie.";path=/; secure; HttpOnly";
        $r->err_headers_out->add('Set-Cookie' => $cookie);
        $r->headers_out->set(Location => $newlocation);
        $r->status(REDIRECT);
        $r->content_type('text/html; charset=ISO-8859-1');
    }
    else
    {
        $r->print("Invalid access");
    }

}
return OK;
}
1;


