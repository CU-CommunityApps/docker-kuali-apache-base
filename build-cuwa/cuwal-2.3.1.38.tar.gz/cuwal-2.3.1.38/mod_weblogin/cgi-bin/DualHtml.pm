package DualHtml;

use MIME::Base64;
use Digest::HMAC_SHA1 qw(hmac_sha1);

sub printStyle
{
print <<HTML;

<style type="text/css">

body {
   margin: 0;
   padding: 0;
   font-family: verdana, arial, helvetica, sans-serif;
   font-size: 63.125%;
   color: #222;
}

#cu-identity {
    height: 75px;
    background: #b31b1b;
}

#cu-logo {
    margin: 0 auto;
    width: 740px;
    background: url(banner_1.jpg) no-repeat top left;
}

hr.banner-separator {
   display: none;
}

#identity {
   padding: 25px 0;
   background: #fff;
}

#identity h1 {
   margin: 0 auto;
   width: 740px;
   font-family: verdana, arial, helvetica, sans-serif;
   font-size: 2.4em;
   font-weight: normal;
   color: #73736c;
}

#wrap {
   float: left;
   width: 100%;
}

#content {
   margin: 0 auto;
   width: 740px;
/* unhack ie5/win */
   text-align: left;
}
#footer {
   float: left;
   width: 100%;
   font-size: 1.0em;
}

#fc {
   width: 740px;
   margin: 0 auto;
}

#footer-content {
   margin: 0 auto;
   padding: 5px 0 1em 0;
   width: 68em;
   font-size: .9em;
   color: #73736c;
   float: left;
   margin-top: .5em;
}

#footer a {
   font-size: 1.0em;
 }

p {
   margin: 0 0 1em 0;
   font-size: 1.3em;
   line-height: 1.4em;
}

</style>
HTML
}

sub printHeader
{
print <<HTML;

<body>
<hr class="banner-separator" />

<div id="cu-identity">
   <div id="cu-logo">
       <img src="/banner_1.jpg" alt="Cornell University Logo"/>
   </div>
</div>

<div id="identity">
   <h1>CUWebLogin Two Factor Authentication $_[0]</h1>
</div>

<div id="wrap">
<div id="content">

HTML
}

sub printFooter
{
print <<HTML;

<div id="footer">
 <div id="fc">
   <div id="footer-content">
    <p>
     <a target="_blank" href="http://www.it.cornell.edu/services/cuweblogin/safe.cfm#exit">To log out, you must Exit or Quit your browser.</a>
    </p>
    <p>
     <strong>Caution:</strong> Always check your browser's address bar before you enter your NetID password to make sure the address starts with https://web*.login.cornell.edu/ (where web* is either web1, web2, web3 or web4).
    </p>
    <p>
     CUWebLogin is a component of Cornell University's central authentication service.  If you are unsure of the authenticity of any online University service, please contact <a href="http://it.cornell.edu/support/">the IT Service Desk.</a>
    </p>
    <p>
     This service and the services to which it provides access are for authorized use only.  Any attempt to gain unauthorized access, or exceed authorized access, to online University resources will be pursued, as applicable, under campus codes and state or federal law.
    </p>

    &copy; 2013 Cornell University. All Rights Reserved.
   </div>
  </div>
</div>   

</div>
</div>

HTML
}

sub add_cookie {
    my ($user,$method,$key) = @_;

    my $authTime = time;
    my $cookie = $user.":".$authTime.":".$method;

    my $sig = hmac_sha1($cookie, $key);
    $sig = encode_base64($sig,'');

    return "$cookie:$sig";
}

sub verify_cookie {
   my ($cookie,$key) = @_;

   $cookie = substr $cookie,1, length($cookie)-2;
   my ($netid, $startTime, $sid, $sig) = split(/:/,$cookie);

   my $info = $netid.":".$startTime.":".$sid;
   my $sig1 = hmac_sha1($info, $key);
   $sig1 = encode_base64($sig1,'');

  if ($sig != $sig1 ) {
     $netid="";
  }

  return "$netid";

}

1;
