#!/usr/bin/perl
use strict;
use warnings;
use lib "/var/www/duo";
use CGI ':standard';
use CGI::Cookie;
use DuoWeb;
use LWP::UserAgent;
use Data::Dumper();
use DualHtml;

my $IKEY = "";
my $SKEY = "";
my $AKEY="";

my $HOST = "api-68fd2842.duosecurity.com";

my $key_file_name = "/app/weblogin/conf/cuwl-dual.key";
open(my $FH, $key_file_name);
while (my $line = readline($FH) ){
    my ($KEY,$value) = split(/=/,$line);
    
    #remove " and carriage return in the value
    $value =~ tr/"\n\r//d;

    if ($KEY eq "AKEY")
    {
        $AKEY=$value;
    }
    if ($KEY eq "IKEY")
    {
       $IKEY=$value;
    }
    if ($KEY eq "SKEY") 
    {
       $SKEY=$value;
    }
} 
close($FH);

my $query = CGI->new();

if($query->request_method() eq 'GET') {

    my $method = $query->param('DualMethod');
    my %cookies = CGI::Cookie->fetch;
    my $dualCookie = "";
    my $netid = "";

    if ($cookies{'cuwlduals'} ) {
        $dualCookie = $cookies{'cuwlduals'}->value;
  
        $netid = &DualHtml::verify_cookie($dualCookie,$AKEY);

        #remove realm
        my $result = index($netid,'@');

        if ($result > 0 )
        {
            $netid = substr $netid, 0,$result;
        }
    }

    my $sig_request = DuoWeb::sign_request($IKEY, $SKEY, $AKEY, $netid);

    print $query->header();
print <<HTML;
    <!DOCTYPE html
        PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
         "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
    <html xmlns="http://www.w3.org/1999/xhtml" lang="en-US" xml:lang="en-US">

    <head>
    <title>Cornell Two Factor Authentication</title>
HTML
    &DualHtml::printStyle;
print <<HTML;
    <script src='/DUOWeb/Duo-Web-v1.bundled.min.js'></script>
    <script>
      Duo.init({'host':'$HOST', 'sig_request':'$sig_request','post_action':'/DUO?$ENV{'QUERY_STRING'}'});
    </script>
    </head>
HTML
    &DualHtml::printHeader("");

    print "<p><img src=\"/DuoLogo.jpg\" width=100px></p>\n";
    print "<iframe align=middle marginheight=2px frameborder=1 height=330px width=620px id='duo_iframe' /></iframe>\n";
 #   if (!$method) 
 #   {
 #       print "<br /><p>Switch to <a href=/RSA?$ENV{'QUERY_STRING'}>RSA Login</a></p>\n";
 #   }
    &DualHtml::printFooter;

} elsif($query->request_method() eq 'POST') {
    # keep for debugging

    my $sig_response = $query->param('sig_response');
    my $auth_username = DuoWeb::verify_response($IKEY, $SKEY, $AKEY, $sig_response);

    my $cookie = "";

     if ($auth_username) 
     {
         $cookie = &DualHtml::add_cookie( $auth_username, "DUO", $AKEY); 
         $cookie = "\"".$cookie."\"";
     }
     my $newlocation = "/DUOdone?$ENV{'QUERY_STRING'}";

     print "Set-Cookie: cuwldualv=$cookie;path=/; secure\n";
     print redirect($newlocation);    
}
print $query->end_html();


