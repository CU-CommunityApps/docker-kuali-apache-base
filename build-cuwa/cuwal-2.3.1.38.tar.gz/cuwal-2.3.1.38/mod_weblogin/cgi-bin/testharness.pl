#!/usr/bin/perl
use strict;
use warnings;
use CGI ':standard';
use CGI::Cookie;
use LWP::UserAgent;
use Data::Dumper();
use DualHtml;

my $IKEY = "";
my $SKEY = "";
my $AKEY="";

my $HOST = "api-68fd2842.duosecurity.com";

my $key_file_name = "/app/weblogin/conf/cuwl-dual.key";
open(my $FH, $key_file_name);
while (my $line = readline($FH) ){
    my ($KEY,$value) = split(/=/,$line);
    
    #remove " and carriage return in the value
    $value =~ tr/"\n\r//d;

    if ($KEY eq "AKEY")
    {
        $AKEY=$value;
    }
    if ($KEY eq "IKEY")
    {
       $IKEY=$value;
    }
    if ($KEY eq "SKEY") 
    {
       $SKEY=$value;
    }
} 
close($FH);

my $testID = "cuwa-test-dual\@DEV.CORNELL.EDU";

my $query = CGI->new();

if($query->request_method() eq 'GET') {

    my $method = $query->param('DualMethod');
    my %cookies = CGI::Cookie->fetch;
    my $dualCookie = "";
    my $netid = "";

    if ($cookies{'cuwlduals'} ) {
        $dualCookie = $cookies{'cuwlduals'}->value;
  
        $netid = &DualHtml::verify_cookie($dualCookie,$AKEY);
    }
    if ( $netid eq $testID )
    {
        my $cookie = &DualHtml::add_cookie( $netid, "TEST", $AKEY);
        $cookie = "\"".$cookie."\"";
        my $newlocation = "/TESTdone?$ENV{'QUERY_STRING'}";

        print "Set-Cookie: cuwldualv=$cookie;path=/; secure\n";
        print redirect($newlocation);
    }
    else 
    {
        print $query->header();
        print "Invalid access";
    }
} 
print $query->end_html();


