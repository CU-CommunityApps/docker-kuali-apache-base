#ifndef CUWL_APUTIL_INCLUDED
#define CUWL_APUTIL_INCLUDED

#include <httpd.h>

char* cuwa1_post_decode(apr_pool_t *p, char *data);
int cuwa1_buildPostData (request_rec *r, apr_table_t *pData);

char *cuwl_get_cookie(request_rec *r, char *cookieName);
#endif
