#ifndef CUWL_CFG_H_INCLUDED
#define CUWL_CFG_H_INCLUDED

#define CFG_CUWLhtml(x) "cuwl-html/login.html"
#define CFG_CUWLformhtml(x) "cuwl-html/form.html"
#define CFG_CUWLk3key(x) "conf/cuwl-k3.key"
#define CFG_CUWLreloginName(x) "cuwlrelogin"
#define CFG_CUWLhtml_mobile(x) "cuwl-html/login_mobile.html"
#define CFG_CUWLmobile(x) "cuwl-html/mobile_agent.txt"
#define CFG_CUWL2FAKey(x) "conf/cuwl-2FA.key"
#define CFG_CUWLpermit(x) "conf/permit"
#define CFG_CUWLreloginCookies(x) "cuwlcookietotal"
#ifdef SUPPORT_IMPERSONATION
#define CFG_CUWLformImpersonate(x) "cuwl-html/impersonate.html"
#endif
#endif
