
#include <weblogin.h>
#include <log.h>
#include "http_protocol.h"
#include "http_config.h"
#include <wal.h>
#include <cuwa_malloc.h>
#include <cuwl_mobile.h>
#include <cuwl_dual.h>
#include <cuwl_permit.h>

#ifdef SUPPORT_IMPERSONATION
#include <cuwl_impersonate.h>
#endif

#define CUWA2_LOG_DOMAIN weblogin
#define ISSET(x) (((x)) && ((x))[0])

int webauth_vercheck(char *have, int maj_req, int min_req, int rev_req){
	int maj=-1,min=-1,rev=-1;
        if(3==sscanf(have,"%d.%d.%d",&maj,&min,&rev)){
		if(maj < maj_req) return 0;
		if(maj > maj_req) return -1;
		if(min < min_req) return 0;
		if(min > min_req) return -1;
		if(rev < rev_req) return 0;
		if(rev >= rev_req) return -1;
	}
	return 0;
}

/** Controls number of characters sent to ap_rprintf which has 8K buffer limit (AP_IOBUFSIZE)*/
#define CUWL_APACHE_PRINTF_LIMIT 4096
#define CUWL_APACHE_PRINTF_LIMIT_FMT "%4096s"
#define CUWL_IE_URL_LIMIT 2048

/** Format string for the base HTML login page */
static char *html_login_base_g=NULL; 

/** Format string for the base HTML login form */
static char *html_login_form_g=NULL; 

/** Format string for realm selection */
static char *html_login_form_realm_g=NULL; 

/** Format string for the main login page */
static char *html_login_g=NULL; 

/** Format string for mobile device  main login page */
static char *html_login_mobile_g=NULL;

/** Format string for fatal errors */
static char *html_fatal_g=NULL;

/** Format string for the configuration page */
static char *html_configure_g=NULL;

/** Format string for the big post page */
static char *html_bigpost2_g=NULL;
static char *html_bigpost1_g=NULL;

/** Format string for the warning page */
static char *html_warning_g=NULL;

/** Format string for the security warning */
static char *html_block_security_g=NULL;

#ifdef SUPPORT_IMPERSONATION
/** Format string for impersonation selection page */
static char *html_impersonate_g=NULL;
static char *html_impersonate_mobile_g=NULL;
static char *html_impersonate_form_g=NULL;
#endif

/** Horrible hack -- encryption key for protecting K3's**/
static char *html_nothtml_weblogin_k3_key_g=NULL;

const char id_cuwl_html_c[] = "$Id$";


void cuwl_load_html(apr_pool_t *tmp, apr_pool_t *spool, const char *file, char **data){
    char *html;
    char * fullpath;
    apr_status_t st;
    apr_file_t *f=NULL;
    apr_finfo_t finfo;
    fullpath=ap_server_root_relative(tmp,file);
    cuwa_trace("loading HTML from %s",fullpath);
    st=apr_file_open(&f,fullpath,APR_READ,APR_REG,tmp);
    if(APR_SUCCESS != st){
       char err[512];
       apr_strerror(st,err,512);
       cuwa_alarm("Error loading file %s (%d):%s",file,st,err);
       return;
    }
    //fixme check st

    st=apr_file_info_get(&finfo, APR_FINFO_SIZE,f);
    if(APR_SUCCESS != st){
        char err[512];
        apr_strerror(st,err,512);
        cuwa_alarm("Error loading file %s (%d):%s",file,st,err);
        return;
    }
    //fixme check st

    html=apr_palloc(tmp,finfo.size+1);
    st=apr_file_read_full(f,html,finfo.size,NULL);
    html[finfo.size]='\0';
    *data=apr_pstrdup(spool,html);
  
}

void cuwl_load_file(apr_pool_t *tmp, apr_pool_t *spool, const char *file, char **data)
{
    cuwl_load_html(tmp, spool, file, data);
}

/**
 * Read in the format strings. Not thread safe, call only from child_init
 * This will initialize the module local format strings.
 * */
void cuwl_init_html(apr_pool_t *pool){
    char *head, *tail;
    char *html_login_base_mobile;

    cuwl_load_html(pool,pool,CFG_CUWLhtml(NULL),&html_login_base_g);
    cuwl_load_html(pool,pool,CFG_CUWLformhtml(NULL),&html_login_form_g);
    cuwl_load_html(pool,pool,CFG_CUWLhtml_mobile(NULL),&html_login_base_mobile);

    cuwl_load_html(pool,pool,CFG_CUWLk3key(NULL),&html_nothtml_weblogin_k3_key_g);

#ifdef SUPPORT_IMPERSONATION
    cuwl_load_html(pool, pool, CFG_CUWLformImpersonate(NULL), &html_impersonate_form_g);
    html_impersonate_g=apr_psprintf(pool,html_login_base_g,""," - Impersonation", html_impersonate_form_g);
    html_impersonate_mobile_g=apr_psprintf(pool,html_login_base_mobile,""," - Impersonation", html_impersonate_form_g);
#endif
  
    html_login_g=apr_psprintf(pool,html_login_base_g,"\"sf()\"","",html_login_form_g);
    html_login_mobile_g=apr_psprintf(pool,html_login_base_mobile,"\"sf()\"", "",html_login_form_g);

    //html_fatal_g="<html><body><h1>Your request contained errors</h1><p>fixme</p><hr><ul>%s</ul></body></html>";
    html_fatal_g=apr_psprintf(pool,html_login_base_g,"\"sf()\"","","<h2>Your request contained errors</h2><hr><ul>%s</ul>");
    html_configure_g="<html><body><h1>Configuration page</h1><p>fixme</p><hr><ul>%s</ul></body></html>";
    html_warning_g=apr_psprintf(pool,html_login_base_g,"\"sf()\"","", "<h2>CUWebLogin Warning</h2><p>%s</p><p>If you would still like to login, click here <form name=\"continueanyway\" method=\"post\" action=\"%s\"><input type=\"hidden\" name=\"wa\" value=\"%s\"/>Continue to %s (%s)<input type=\"submit\" value=\"continue\" name=\"continue\"/></form>");
    html_block_security_g="<hr><div style=\"font-size: 200\%;line-height: 100\%; color:red\">Security Warning:</div><div style=\"color:red;\"><ul>%s</ul></div><p>Your password is safe, but data on that site might not be secure. Using this configuration for a production service might violate university policy. Please ask the administrator of %s to correct this condition. This issue has also been logged by weblogin.</p><hr>";
    html_login_form_realm_g="";
    
    // This section initializes support for really large credentials that need to be transmitted via POST.
    // Apache has a limit on how much data can be written to the response in a single write (8K) so credential writes happen in 3 sections...
    //   * Head
    //   * Credential - one or more writes
    //   * Tail    
    head=apr_psprintf(pool,html_login_base_g,"\"document.bigpost.submit()\"","","%s");
    tail=strstr(head,"%s");
    if (!tail) 
    {
        tail = "";
    }
    else
    {
        *tail = 0;
        tail += 2;
    }
    html_bigpost1_g=apr_psprintf(pool,"%s%s",head,"<h2>Login OK</h2><p>Your login credentials are being transmitted to the website via POST. <noscript>If you are not automatically redirected please click the continue button below<br></noscript><form name=\"bigpost\" enctype=\"application/x-www-form-urlencoded\"  method=\"post\" action=\"%s\"><input type=\"hidden\" name=\"wa\" value=\"");
    html_bigpost2_g=apr_psprintf(pool,"%s%s","\"/><noscript><input type=\"submit\" value=\"continue\" name=\"continue\"/></noscript></form>",tail);    
}


/**
 * Formats and sends a response to the client. You must have called cuwl_init_html from the current process first.
 * @param[in] wr a fully processed weblogin request.
 */
int cuwl_send_response(weblogin_req_t *wr){
    char * reason_block="";
    char * realm_block="<!-- realm -->";

    cuwa_assert(html_login_g);
    cuwa_assert(html_login_mobile_g);
    cuwa_assert(html_fatal_g);
    cuwa_assert(html_configure_g);

#ifdef SUPPORT_IMPERSONATION
    cuwa_assert(html_impersonate_g);
    cuwa_assert(html_impersonate_mobile_g);
#endif

    reason_block=apr_pstrcat(wr->p, 
                 wr->r.securitywarning[0]?apr_psprintf(wr->p,html_block_security_g,wr->r.securitywarning,wr->q.ReturnHost):"",
                 "<ul>",wr->q.errors,"</ul>",
                 "<ul>",wr->r.reason,"</ul>",
                 NULL);
	
    if(wr->r.securitywarning[0]) cuwl_audit_add(wr,1,"sec_warning");
	
    //if multiple domains are set, spit out realm select
    cuwa_trace("WAK0Realms: %s",DENULL(wr->q.WAK0Realms));
    if(ISSET(wr->q.WAK0Realms) && strchr(wr->q.WAK0Realms,',')){
         realm_block=apr_pstrcat(wr->p,"<div class=\"form-pair-realm\">\n"
                                      "<div class=\"form-item-realm\">\n"
                                      "<label for=\"realm\">",
                                      wr->r.realmlabel,
                                      " </label>\n"
                                      "</div>\n"
                                      "<div class=\"form-value-realm\">\n"
                                      "<SELECT ID=\"realm\" NAME=\"realm\">\n",NULL);
        
        char *arealm=apr_pstrdup(wr->p,wr->q.WAK0Realms);
        while(ISSET(arealm)){
            char *next=strchr(arealm,',');
            if(next){
                *next='\0';
            }
            realm_block=apr_pstrcat(wr->p, realm_block, "<OPTION VALUE='",arealm,"'>",arealm,"</OPTION>\n",NULL);
            arealm=next?next+1:NULL;
        }
        realm_block=apr_pstrcat(wr->p,realm_block,"</SELECT>\n</div></div>",NULL);
    }
	
	
    if(wr->r.sso && wr->r.ssodomain){
        char *tmp;
        CUWACfg_t *cfg = cuwa_wal_get_config((void *)wr->apreq);
        int cookieMaxLen = *CFG_CUWLCookieLenMax(cfg);
        int totalCuwlCookies = 0;
        char *cookie = NULL;
        char *cookieName = CFG_CUWLreloginName(wr);
        char *p = wr->r.sso;
        int totalCopied = 0; 
        int bytesToCopy = 0;
        int ssoCookieSize = strlen(wr->r.sso);
        int i = 0;

        if ( ssoCookieSize > 0 )
            totalCuwlCookies = ssoCookieSize/cookieMaxLen+1;

        //when use AD for authentication, kerberos token contains group information so the size
        //is big and might exceed the maximum cookie size allowed by the browser.
        //As for Nov 2016, the maximum single cookie size - Firefox, Safari about 4086,Chrome 4076
        //The total max cookie size of each domain - Safari has the least which is about 8000
        //We haven't found any AD user has token size exceed 8000. So right now we'll split the SSO
        //cookie to multip to avoid it exceed maximum single cookie size.
        cuwa_trace("credential size=%d,total webLoginCookie:%d", ssoCookieSize,totalCuwlCookies);
        for ( i=0; i<totalCuwlCookies;i++)
        {
            //the first SSO cookie keeps the name as we have now.Additional will have name cuwlrelogin1,cuwlrelogin2,...
            if ( i > 0 ) 
                cookieName = apr_psprintf(wr->p, "%s%d",CFG_CUWLreloginName(wr),i);

            if ( totalCuwlCookies == 1 )
                cookie = wr->r.sso;
            else 
            {
               //we have to split. Allocate a buffer called cookie once. Copy part of SSO cookie to this buffer.
                bytesToCopy = ssoCookieSize - totalCopied > cookieMaxLen ? cookieMaxLen:ssoCookieSize-totalCopied;

                if ( cookie == NULL ) 
                    cookie = cuwa_malloc(cookieMaxLen+1);

                memset(cookie,0,cookieMaxLen+1);
                memcpy(cookie, p, bytesToCopy);
            
                totalCopied += bytesToCopy;
                p += bytesToCopy;
            }
            tmp=apr_psprintf(wr->p,"%s=\"%s\"; path=/; domain=%s; secure; HttpOnly",cookieName, cookie, wr->r.ssodomain);
            cuwl_output_header(wr,"Set-Cookie",tmp);
            cuwa_info("Sending relogin cookie %s",cookieName);
        } 

        cuwl_audit_add(wr,1,apr_psprintf(wr->p,"sso_out/%s",cuwl_md5(wr->p,wr->r.sso,0)));

        if(wr->r.ssoendtime){
            tmp=apr_psprintf(wr->p,"cuwltgttime=\"%s\"; path=/; domain=%s",wr->r.ssoendtime,wr->r.ssopresent); //fixme need to insert time
            cuwl_output_header(wr,"Set-Cookie",tmp);
            cuwa_info("Sending cuwltgttime cookie");
        }					

        //we might set more than one cuwl cookies, let's save the total #of SSO cookie in a cookie name
        tmp = apr_psprintf(wr->p,"%s=\"%d\"; path=/; domain=%s; secure; HttpOnly",CFG_CUWLreloginCookies(wr),totalCuwlCookies,wr->r.ssodomain);
        cuwl_output_header(wr,"Set-Cookie",tmp);
        cuwa_info("Sending cuwlcookietotal=%d",totalCuwlCookies);
        cuwl_audit_add(wr,1,apr_psprintf(wr->p,"sso_out_cookie_num/%d",totalCuwlCookies));
        
    }
	
    if (wr->r.dualAuthCookie && wr->r.ssodomain) {
        char *tmp;
        tmp=apr_psprintf(wr->p,"%s=\"%s\"; path=/; domain=%s; secure; HttpOnly",CUWL_DUAL_COOKIE,wr->r.dualAuthCookie,wr->r.ssodomain);
        cuwl_output_header(wr,"Set-Cookie",tmp);
        cuwa_info("Sending dualAuth cookie");
        cuwl_audit_add(wr,1,apr_psprintf(wr->p,"dual_cookie_set/%s",cuwl_md5(wr->p, wr->r.dualAuthCookie,0)));
    }
	
    if ( wr->status == 401 ) {
        //redirect to password scramble page
        cuwa_trace("redirect to password scramble page");
        cuwl_output_header(wr,"Location","/HA/passinstr.html");
        wr->apreq->status = 307;
        wr->apreq->content_type = "text/html;charset=ISO-8859-1";
        cuwl_audit_add(wr,1,"response_redirect_password_scramble");

        return wr->status;
    }

    if(400 <= wr->status){
        //some status has already been set
        //and it is an error
        cuwa_info("Error: Request appears to be malformed, returning %d",wr->status);
        cuwl_audit_add(wr,0,"response_fatal");
        wr->apreq->content_type = "text/html;charset=ISO-8859-1";
        wr->apreq->no_cache = 1;
        ap_rprintf(wr->apreq, html_fatal_g, wr->q.errors);
        wr->apreq->status=wr->status;

        return wr->status;		
    }	
	
    if(wr->status < 300){	
        //cuwa_assert(wr->status); //apparantly this is 0 and that is fine
        //we got here, either there was no cookie present or the cookie was unsatisfactory. Prompt time.	
        cuwa_info("Sending a login form (status: %d)",wr->status);
        //weblogin_show_form(wr->apreq->uri,wr->apreq->args,r->pool,r,wr->q.errors,"NetID");
		
        ap_rprintf(wr->apreq, 
                   cuwl_from_mobile(wr)?html_login_mobile_g:html_login_g,
                   wr->query,
                   reason_block,
                   wr->q.IDName,
                   realm_block);
        wr->apreq->content_type = "text/html;charset=ISO-8859-1";
        wr->apreq->no_cache = 1;
        wr->apreq->status=200;

        //expire duo cookie
        char *tmp;
        tmp=apr_psprintf(wr->p,"%s=\"%s\"; expires=Thu, 01 Jan 1970 00:00:00 UTC;path=/; domain=%s; secure; HttpOnly",CUWL_DUAL_COOKIE,wr->r.dualAuthCookie,wr->r.ssodomain);
        cuwl_output_header(wr,"Set-Cookie",tmp);
        cuwa_info("Expiring dualAuth cookie");

        return wr->status;
    }
    else{ //status 300-399 
        char *location=NULL;
        cuwa_assert(wr->r.cred);

        if(wr->r.cred){

            cuwl_audit_add(wr,1,apr_psprintf(wr->p,"cred_out/%s",cuwl_md5(wr->p,wr->r.cred,0)));

            //check if user needs to do two factor authentication
            if ( cuwl_dual_auth_needed( wr ) == CUWL_PERMIT_ERROR ) {
                char *msg = apr_psprintf(wr->p,"Checking two factor authenticaiton permit %s failed. Make sure permit name is correct.",wr->q.dualAuth);
                CUWL_REQ_ERROR_FATAL(wr,msg);
                cuwl_audit_add(wr,0,"dual_permit_fail"); 
                wr->apreq->content_type = "text/html;charset=ISO-8859-1";
                ap_rprintf(wr->apreq, html_fatal_g, wr->q.errors);
                wr->apreq->status=wr->status;
                return wr->status;
            }
            if ( wr->needDualAuth == CUWL_DUAL_AUTH_YES )
            {
                char *method = cuwl_dual_get_method(wr);

                if (!method) 
                {
                    char *msg = apr_psprintf(wr->p,"%s is misconfigured with invalid two factor method.",wr->q.ReturnHost);
                    CUWL_REQ_ERROR_FATAL(wr,msg);
                    cuwl_audit_add(wr,0,"dual_permit_fail");
                    wr->apreq->content_type = "text/html;charset=ISO-8859-1";
                    ap_rprintf(wr->apreq, html_fatal_g, wr->q.errors);
                    wr->apreq->status=wr->status;
                    return wr->status;
                }
                //check if user is in allowed 2FA realms
                if ( cuwl_dual_realm_check( wr ) !=CUWA_OK )
                {
                    char *msg = apr_psprintf(wr->p,"The web site you are accessing requires two-step login. But two-step login doesn't support your ID type %s",wr->r.cuwlUser);
                    CUWL_REQ_ERROR_FATAL(wr,msg);
                    cuwl_audit_add(wr,0,"dual_realm_fail");
                    wr->apreq->content_type = "text/html;charset=ISO-8859-1";
                    ap_rprintf(wr->apreq, html_fatal_g, wr->q.errors);
                    wr->apreq->status=wr->status;
                    return wr->status;
                }
                else 
                {
                    cuwl_dual_set_start_cookie( wr );

#ifdef SUPPORT_IMPERSONATION
                    if ( wr->tryImpersonate ) cuwl_impersonate_set_cookie( wr );
#endif
                    location = apr_psprintf(wr->p, "/%s?%s&CUWLUser=%s",method, wr->query,wr->r.cuwlUser ); 

                    cuwl_output_header(wr,"Location",location);
                    cuwa_info("Success: Issuing a redirect to: %s",location);
                    wr->apreq->status = wr->status;
                    wr->apreq->content_type = "text/html;charset=ISO-8859-1";
                    cuwl_audit_add(wr,1,"response_redirect_dual_form");
                    return(wr->status);
                }
            
            }
#ifdef SUPPORT_IMPERSONATION
            //if webauth support impersonation, let's check if user can impersonate anyone
            if ( wr->q.supportImpersonation && wr->r.impersonateNetID == NULL && wr->allowImpersonate == CUWL_IMPERSONATE_UNKNOWN )
            {
                char *impersonateNetIDList;

                if ( cuwl_impersonate_check( wr, &impersonateNetIDList ) == CUWL_IMPERSONATE_YES )
                {
                    char *impersonate_block=NULL;
                    char *ptr, *state;

                    //show user impersonation selection form
                    cuwa_trace("Sending a impersonation form for user %s with netid list:%s", wr->r.cuwlUser, impersonateNetIDList);

                    //build the drop down list of the netID that user can impersonated as
                    ptr = apr_strtok( impersonateNetIDList, " ", &state );
                    while( ptr )
                    {
                       if ( !impersonate_block ) 
                           impersonate_block = apr_psprintf( wr->p, "<OPTION VALUE='%s'>%s</OPTION>\n", ptr, ptr);
                       else
                           impersonate_block = apr_pstrcat( wr->p, impersonate_block, "<OPTION VALUE='", ptr ,"'>", ptr,"</OPTION>\n",NULL);
                       ptr = apr_strtok( NULL, " ", &state );
                   }

                  if ( impersonate_block ) 
                  {
                      ap_rprintf(wr->apreq,
                               cuwl_from_mobile(wr)?html_impersonate_mobile_g:html_impersonate_g,
                               wr->query,
                               wr->q.ReturnHost,
                               impersonate_block);

                      wr->apreq->content_type = "text/html;charset=ISO-8859-1";
                      wr->apreq->no_cache = 1;
                      wr->apreq->status=200;

                      return wr->status;
                  }
                }
           }
#endif
            location = wr->q.ReturnURL;
           
            cuwl_output_header(wr,"Location",location);

            wr->status=200;
            wr->apreq->status=200;
            wr->apreq->content_type = "text/html;charset=ISO-8859-1";

            if(!wr->r.mustWarn)
            {
                // Build HTML page
                ap_rprintf(wr->apreq,html_bigpost1_g,wr->q.ReturnURL);
                ap_rprintf(wr->apreq,"%s",wr->r.cred);
                ap_rprintf(wr->apreq,html_bigpost2_g);

                cuwa_info("Success: Issuing a redirect to: (via POST) %s",location);
                cuwl_audit_add(wr,1,apr_psprintf(wr->p,"response_redirect_post/%d",(int)strlen(location)));
            }
            else {
               ap_rprintf(wr->apreq,
                           html_warning_g,
                           reason_block,
                           wr->q.ReturnURL,
                           wr->r.cred,
                           wr->q.ReturnHost,
                           wr->q.WAK0Service);
               cuwa_info("Success: Issuing a redirect to: (with warning) %s",location);
               cuwl_audit_add(wr,1,"response_redirect_warning");
            } 
            return 0;
        }
        cuwa_alarm("Error: unreachable code, status is redirect but I lack a credential");
        return(500);
        //unreachable
    }
	
}


/**
 * access function for long term key
 * doesn't belong here.
 */
char * cuwl_get_k3_key(){
    return html_nothtml_weblogin_k3_key_g;
}

