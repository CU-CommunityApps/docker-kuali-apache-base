#ifndef cuwl_html_included_h
#define cuwl_html_included_h

void cuwl_init_html(apr_pool_t *pool);
int cuwl_send_response(weblogin_req_t *wr);
unsigned char * cuwl_get_k3_key();
void cuwl_load_html(apr_pool_t *tmp, apr_pool_t *spool, const char *file, char **data);
void cuwl_load_file(apr_pool_t *tmp, apr_pool_t *spool, const char *file, char **data);
#endif
