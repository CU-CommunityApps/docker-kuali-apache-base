#include <apr_pools.h>

#include <weblogin.h>
#include <cuwl_html.h>
#include <cuwl_permit.h>
#include <log.h>
#include <cuwl_aputil.h>
#include <cuwl_impersonate.h>
#include <util.h>
#include <cuwa_malloc.h>
#include <wal.h>
#include <cfg.h>
#include <impersonate.h>
#include <cuwl_dual.h>

#include <time.h>
#include <list.h>

#undef CUWA2_LOG_DOMAIN
#define CUWA2_LOG_DOMAIN weblogin

#ifdef SUPPORT_IMPERSONATION

//check if authenticated user has been granted any impersonation permission to the site user is accessing
//If user has such permission, impersonateNetIDList will contain a list of netID that user can represent and
//wr->allowImpersonate is iset to CUWL_IMPERSONATE_YES
int cuwl_impersonate_check( weblogin_req_t *wr, char **impersonateNetIDList )
{
    int result = CUWL_IMPERSONATE_NO;
    CUWACfg_t *cfg = cuwa_wal_get_config((void *)wr->apreq);
    int sts;
   
    //if user is not in dual allowed realm, they can not perform DUO, can not impersonate
    if ( wr->q.supportImpersonation && cuwl_dual_realm_check(wr) == CUWA_OK)
    {
        char *impersonateGroupName;
        char *members=NULL,*nonemembers=NULL;

        impersonateGroupName = cuwa_get_impersonate_group_name(wr->p, wr->q.WAK0Service, wr->r.cuwlUser);

        sts = cuwl_check_permits(wr->p,CFG_CUWLPermitPrincipal(cfg), CFG_CUWLPermitKeytab(cfg), impersonateGroupName, "all", &members, &nonemembers);        
        if ( sts )
            cuwa_crit("permit check failed with status:%d for group %s", sts, impersonateGroupName);
        else
        {
            cuwa_trace("check group %s return members=%s", impersonateGroupName, DENULL(members));

            if ( members && strlen(members)>2 ) 
            {
                char *netid = apr_pstrdup( wr->p, wr->r.cuwlUser );
                char *ptr2 = strchr(netid,'@');

                if ( ptr2 ) *ptr2 = '\0';

                result = CUWL_IMPERSONATE_YES;

                members = apr_psprintf(wr->p, "%s %s",netid,members);
                *impersonateNetIDList = members;
           }
        }
    }
    wr->allowImpersonate = result;
    return result;
}

/*****************************************************
 * set CUWL_IMPERSONATE_COOKIE before redirect 
 * user to do two factor authentication. This cookie
 * record user's impersonation choice. 
 ********************************************************/
void cuwl_impersonate_set_cookie( weblogin_req_t *wr )
{
    char *sig,*cookie,*tmp,*timeStr;
    apr_time_exp_t xt;

    apr_time_exp_gmt(&xt, apr_time_now());
    timeStr = apr_psprintf( wr->p, "%s,%02d %s %4d %02d:%02d:%02d GMT",
                                    apr_day_snames[xt.tm_wday],
                                    xt.tm_mday,
                                    apr_month_snames[xt.tm_mon],
                                    xt.tm_year+1900,
                                    xt.tm_hour,
                                    xt.tm_min+10,
                                    xt.tm_sec );


    cookie = apr_psprintf(wr->p, "%s:%s",wr->r.impersonateNetID, wr->sid);
    cuwl_dual_hash( wr->p, cookie, &sig );

    cookie = apr_pstrcat( wr->p, cookie, ":",sig, NULL);

    tmp=apr_psprintf(wr->p,"%s=\"%s\"; path=/; expires=%s; secure;HttpOnly", CUWL_IMPERSONATE_COOKIE, cookie, timeStr);
    cuwl_output_header(wr,"Set-Cookie",tmp);
    cuwa_info("Sending impersonate cookie");

}

//check if there is impersonation cookie set that indicate user's impersonation wish
void cuwl_impersonate_get_cookie(  weblogin_req_t *wr )
{
    char *cookie = NULL;
    char *ptr,*state;
    int i = 0;
    char *cookieData[3];
    char *infoToValidate = NULL;
    char *encoded = NULL;
    char *cookie_sig=0L;

    cookie = cuwl_get_cookie( wr->apreq, CUWL_IMPERSONATE_COOKIE);
    if (cookie)
    {
       cuwa_trace("found cookie %s",cookie);
        
       ptr = apr_strtok( cookie, ":", &state );
       while ( ptr && i < 3 )
       {
            cookieData[i] = apr_pstrdup( wr->p, ptr);
            i++;
            ptr = apr_strtok( NULL, ":", &state);
       }
 
       //if cookies has the correct format and is for current SID, verify cookie
       if ( i == 3 && !strcmp(wr->sid,cookieData[1] ) )
       {
           infoToValidate = apr_psprintf( wr->p, "%s:%s", cookieData[0], cookieData[1]); 
           cookie_sig = cookieData[2];

           cuwl_dual_hash( wr->p, infoToValidate, &encoded );

           if ( encoded  && !strcmp((char *)encoded, cookie_sig))
           {
               //we have a good impersonate cookie
               wr->r.impersonateNetID = apr_pstrdup( wr->p, cookieData[0] );
               wr->tryImpersonate = 1;
           }
        }
    }
}
           
#endif
