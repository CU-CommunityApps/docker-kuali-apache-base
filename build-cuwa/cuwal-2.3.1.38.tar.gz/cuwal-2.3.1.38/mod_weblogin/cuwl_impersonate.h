#ifdef SUPPORT_IMPERSONATION

#ifndef CUWL_IMPERSONATE_INCLUDED

#define CUWL_IMPERSONATE_INCLUDED

#include <weblogin.h>

#define CUWL_IMPERSONATE_UNKNOWN   0
#define CUWL_IMPERSONATE_YES       1
#define CUWL_IMPERSONATE_NO        2

#define CUWL_IMPERSONATE_COOKIE   "cuwlimpersonateid"

int cuwl_impersonate_check( weblogin_req_t *wr, char **impersonateNetIDList );
void cuwl_impersonate_set_cookie( weblogin_req_t *wr );
void cuwl_impersonate_get_cookie(  weblogin_req_t *wr );
#endif

#endif
