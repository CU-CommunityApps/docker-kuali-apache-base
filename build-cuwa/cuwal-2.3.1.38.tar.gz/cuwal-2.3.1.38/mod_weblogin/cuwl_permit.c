#include <log.h>
#include <cuwl_permit.h>
#include <cuwl_html.h>
#include <permit_ha.h>
#include <cuwl_cfg.h>

#undef CUWA2_LOG_DOMAIN
#define CUWA2_LOG_DOMAIN weblogin

static char permit_default[] = "permitd/permit1@CIT.CORNELL.EDU@permit1.cit.cornell.edu:80 permitd/permit1@CIT.CORNELL.EDU@permit0.cit.cornell.edu:80";

int cuwl_in_permit(apr_pool_t *p, char *cuwlPermitPrincipal, char *cuwlPermitKeytab, char *permit, char *member){

    char *answers=NULL;
    char *garbage=NULL;
    int sts = 0;

    cuwa_assert(permit);
    cuwa_assert(member);

    sts = cuwa_permit_ha_check( p, cuwlPermitPrincipal, cuwlPermitKeytab, member, permit,&answers,&garbage);    
    if ( !sts )
    {
        if(answers){
            cuwa_info("principal %s is in permit %s",member,permit);
            return(CUWL_PERMIT_HAS);
        }
        else{
            cuwa_info("principal %s is NOT in permit %s (memberships: %s)",member,permit,answers);
            return(CUWL_PERMIT_MISSING);
        }
    }
    return sts;
}

int cuwl_check_permits(apr_pool_t *p, char *cuwlPermitPrincipal, char *cuwlPermitKeytab, char *permits, char *netid, char **members, char **nonemembers)
{
    return cuwa_permit_ha_check( p, cuwlPermitPrincipal, cuwlPermitKeytab, netid, permits, members, nonemembers);
}

//load permit server list from file to memory
void cuwl_init_permit( apr_pool_t *pool ) 
{
    char *permit_list = NULL;

    cuwl_load_file(pool, pool, CFG_CUWLpermit(NULL), &permit_list);

    if ( !permit_list )
        permit_list = permit_default;
    cuwa_permit_ha_add_servers( permit_list, pool ); 
    
}        

//remove a netID from a group
int cuwl_permit_remove(apr_pool_t *p, char *cuwlPermitPrincipal, char *cuwlPermitKeytab,char *netid, char *permit)
{
    char *members=NULL, *nonemembers=NULL;
    int sts = 0;

    sts = cuwa_permit_ha_delete( p, cuwlPermitPrincipal, cuwlPermitKeytab,netid, permit,&members,&nonemembers);
    if ( !sts )
    {
        if(nonemembers){
            cuwa_info("principal %s is not in permit %s",netid,permit);
        }
    }
    cuwa_trace("permit_remove return status %d",sts);
    return sts;
}
