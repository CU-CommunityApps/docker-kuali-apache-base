#ifndef CUWL_PERMIT_INCLUDED
#define CUWL_PERMIT_INCLUDED

#include "weblogin.h"

#define CUWL_PERMIT_ERROR -1
#define CUWL_PERMIT_HAS 0
#define CUWL_PERMIT_MISSING 1

void cuwl_init_permit(apr_pool_t *pool);
int cuwl_in_permit(apr_pool_t *p, char *cuwlPermitPrincial, char *cuwlPermitKeytab, char *permit, char *member);
int cuwl_check_permits(apr_pool_t *p, char *cuwlPermitPrincipal, char *cuwlPermitKeytab, char *permits, char *netid, char **members, char **nonemembers);
int cuwl_permit_remove(apr_pool_t *p, char *cuwlPermitPrincipal, char *cuwlPermitKeytab,char *netid, char *permit);
#endif
