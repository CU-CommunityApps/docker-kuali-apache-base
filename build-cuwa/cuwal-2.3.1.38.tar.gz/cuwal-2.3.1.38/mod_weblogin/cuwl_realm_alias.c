#include <cuwl_realm_alias.h>
#include "apr_strings.h"
#include <cuwa_parse.h>

// FIXME: These should be pulled from a file, but for now...
static const char *alias[] = 
{
"cornell.edu",
"GuestID",
"NetID",
"WCMC-CWID",
"DevID",
"ApplicantID",
NULL
};

static const char *realms[] = 
{
"CORNELL.EDU",
"CORNELL.EDU",
"CIT.CORNELL.EDU",
"A.WCMC-AD.NET",
"DEV.CORNELL.EDU",
"CORNELL.EDU",
NULL
};

const char * cuwl_realm_from_alias(char *realm)
{
    int i;
    
    for (i=0;alias[i];i++)
    {
        if (!apr_strnatcasecmp(alias[i],realm)) return realms[i];
    }
    return NULL;
}

int cuwl_find_realm( apr_pool_t *pool, char *realmlist, char *realm)
{
    // realmlist, comma separated list of realms or realm aliases
    // realm, realm to match
    int i;
 
    // check basic realm match
    if (cuwa_strlist_member(pool, realmlist, realm, ',')) return 1;
    
    // check if realm matches an alias in realmlist
    for (i=0;realms[i];i++)
    {
        if (!apr_strnatcasecmp(realms[i],realm)) 
        {
            if (cuwa_strlist_member(pool,realmlist, (char *) alias[i], ',')) return 1;
        }

    }
        
    return 0;
}

