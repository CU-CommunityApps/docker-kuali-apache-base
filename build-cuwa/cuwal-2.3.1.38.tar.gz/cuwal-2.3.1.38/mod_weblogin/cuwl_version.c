/************************************************************************
 * cuwl_version.c -- Get the module's version number
 *
 * Copyright 2008 Cornell University.
 * All Rights Reserved.
 *
 ************************************************************************
 */
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <autoconfig.h>
#include <log.h>
#include <util.h>

#ifdef HAVE_UNISTD_H
#include <unistd.h>
#endif

static char *version = NULL;

char cuwa_version_string[] = CUWA_PROD;
char cuwa_build_string[] = CUWA_BUILDFULL;
char cuwa_server[] = "weblogin";

#define CUWA2_LOG_DOMAIN cuwa.version

static void cuwl_version_init();

void cuwl_version_init()
{
    version = malloc(strlen(cuwa_server)+strlen(cuwa_version_string)+strlen(cuwa_build_string)+3);
    sprintf(version,"%s/%s.%s",cuwa_server,cuwa_version_string,cuwa_build_string);
}

// Hack, same name as function name as in cuwa_version.c to simplify header linkage
char *cuwa_version_get_full()
{
    if (!version) cuwl_version_init();
    return version;
}

const char id_mod_weblogin_cuwl_version_c[] = "$Id$";
