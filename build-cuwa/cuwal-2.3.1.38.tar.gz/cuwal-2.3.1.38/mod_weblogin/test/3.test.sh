#./bin/sh
# template case for weblogin

#include general config
. ./util/config.sh

#configure $OUT
. ./util/std-setup.sh
export OUT1=$OUT.1
export OUT2=$OUT.2
export OUT3=$OUT.3

export TEST_INFO="test a full single-sign on transaction"

export OUT=$OUT1
rm $OUT.*
touch $OUT.cookies

echo Requesting login form
#setup for a curl
. ./util/std-setup.sh
#do the curl
curl $CURL_FLAGS "$WEBLOGIN_TARGET/?$STANDARD_LOGIN_QUERY"
cp $OUT1.cookies $OUT2.cookies

echo Parsing form
./util/formfind.pl < $OUT.data > $OUT.form
URL=`cat $OUT.form | grep 'POST to URL' | cut -d \" -f 2`

echo Submitting form
export OUT=$OUT2
#setup for a curl
. ./util/std-setup.sh
#do the curl

curl -d "netid=$TEST_ID&password=$TEST_PW" $CURL_FLAGS "$WEBLOGIN_TARGET/$URL"
cp $OUT2.cookies $OUT3.cookies
. ./util/std-creddecode.sh

echo Trying a single-sign-on login
export OUT=$OUT3
#setup for a curl
. ./util/std-setup.sh
#do the curl
curl $CURL_FLAGS "$WEBLOGIN_TARGET/?$STANDARD_LOGIN_QUERY"
. ./util/std-creddecode.sh

. ./util/std-checks.sh
