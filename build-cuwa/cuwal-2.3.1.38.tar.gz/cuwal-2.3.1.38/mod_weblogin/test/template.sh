#./bin/sh
# template case for weblogin

#include general config
. ./util/config.sh

export TEST_INFO="Describe the test here"

#setup for a curl
. ./util/std-setup.sh

#do the curl
curl --data "netid=$TEST_ID&password=$TEST_PW" $CURL_FLAGS "$WEBLOGIN_TARGET/loginAction?$STANDARD_LOGIN_QUERY"

. ./util/std-creddecode.sh

. ./util/std-checks.sh
