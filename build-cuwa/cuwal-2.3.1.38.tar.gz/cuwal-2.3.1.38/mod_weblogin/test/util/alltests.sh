#./bin/sh
# test wrapper for weblogin
# 

test -f $0.out && rm $0.out

for t in *.test.sh; do
	echo "** Test case $t **" | tee -a $0.out
	sh $t 2>/dev/null | grep '** FAIL **' | tee -a $0.out
done
	
