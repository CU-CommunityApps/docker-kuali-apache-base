# include don't run
#
# converts $OUT.cred to $OUT.checkcred-timeless
# if $OUT.cred is missing, construct it from $OUT.headers

test -f $OUT.cred || cat $OUT.headers | egrep '^Location' | cut -d \? -f 2 | cut -b 4-4096 > $OUT.cred

if [ -s $OUT.cred ]; then
../../apache/checkcred/checkcred $WEBAUTH_TARGET $WEBAUTH_SERVICE $WEBAUTH_KEYTAB 2> $OUT.checkcred-errors > $OUT.checkcred < $OUT.cred
cat $OUT.checkcred | grep -v '_time:' > $OUT.checkcred-timeless

fi
