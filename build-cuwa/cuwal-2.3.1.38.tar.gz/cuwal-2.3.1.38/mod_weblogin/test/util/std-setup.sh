# Don't run this
# include it in test cases with .

if [ -z "$OUT" ]; then
	export OUT="./out/$0"
fi

export CURL_COOKIES=""

if [ -f $OUT.cookies ]; then
	export CURL_COOKIES="-b $OUT.cookies -c $OUT.cookies"
fi

export CURL_FLAGS="--dump-header $OUT.headers --output $OUT.data --trace-ascii $OUT.trace $CURL_COOKIES"

if [ ! -z "$NEWQUERY" ]; then
	export STANDARD_LOGIN_QUERY="SID=$WEBAUTH_SID&WAK0Service=$WEBAUTH_SERVICE&WAK2Name=NetID&ReturnURL=$WEBAUTH_TARGET/cuweblogin&VerP=1&VerC=curl&Accept=K2&WAK2Flags=0"
fi
