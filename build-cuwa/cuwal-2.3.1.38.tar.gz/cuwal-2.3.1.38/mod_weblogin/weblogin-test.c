#include <stdio.h>
#include "apr_general.h"
#include "apr_strings.h"
#include "apr_tables.h"
#include "apr_errno.h"

#include "weblogin.h"
#include <log.h>

#define ALLOC_BYTES 1024
#define ap_rputs(x,y) printf(x)

static apr_pool_t *pmain = NULL;




int main(int argc, char **argv){
	apr_initialize();
	apr_pool_create(&pmain,NULL);
	//weblogin_get(argv[1], argv[2], pmain, NULL);
	weblogin_show_form(argv[1], argv[2], pmain, NULL,"because","NetID");
}
const char id_mod_weblogin_weblogin-test_c[] = "$Id$";
