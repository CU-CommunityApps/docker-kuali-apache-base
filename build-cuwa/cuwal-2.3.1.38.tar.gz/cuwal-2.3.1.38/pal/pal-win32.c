#ifdef _MSC_VER
#define no
#endif
#include "../config/config.h"

#ifdef _MSC_VER
static __declspec(thread) cuwa_config *cuwa_pal_tls_conf = 0;
#else
//FIXME threadsafe
static cuwa_config *cuwa_pal_tls_conf = 0;
#endif

cuwa_config *cuwa_pal_get_thread_conf ()
{
	return cuwa_pal_tls_conf;
}

void
cuwa_pal_set_thread_conf (cuwa_config * c)
{
	cuwa_pal_tls_conf = c;
}



const char id_pal_pal_win32_c[] = "$Id$";
