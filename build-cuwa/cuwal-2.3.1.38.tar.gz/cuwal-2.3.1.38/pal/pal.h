#include "../config/config.h"

/**
 * platform specific get for a specific thread local variable
 * Should only be called from config.c, all other users should use
 * cuwa_config_get_active.
 * @see cuwa_config_get_active
 */
cuwa_config *cuwa_pal_get_thread_conf ();

/**
 * platform specific set for a specific thread local variable
 * Should only be called from config.c, all other users should use
 * cuwa_config_set_active.
 * @see cuwa_config_set_active
 */
void cuwa_pal_set_thread_conf (cuwa_config * c);

#ifdef _MSC_VER
#define CUWA_TLS static __declspec(thread)


#else

//GCC
#define CUWA_TLS static __thread
#define _strdup strdup
#define _stricmp strcmp
#define _strnicmp strncasecmp
#define __analysis_assume(x)  0
#endif
