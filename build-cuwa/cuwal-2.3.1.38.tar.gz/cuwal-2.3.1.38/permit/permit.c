/************************************************************************
 * permit.c -- Look up one or more permits using CUSSP v3 protocol
 *
 * Copyright 2007 Cornell University.
 * All Rights Reserved.
 *
 ************************************************************************
 *  $Log$
 *  Revision 1.26  2008/09/16 19:21:01  hy93
 *  remove un-used function
 *
 *  Revision 1.25  2008/09/08 17:10:50  hy93
 *  add static to global variables define to remove them from global symbol table
 *
 *  Revision 1.24  2008/08/21 22:00:05  pb10
 *  Cleanup permit code to use apr functions instead of hand rolled.
 *
 *  Revision 1.23  2008/08/19 20:55:14  pb10
 *  Fix intermittent segfault.
 *
 *  Revision 1.22  2008/08/19 19:31:09  hy93
 *  fix compiler warning
 *
 *  Revision 1.21  2008/08/12 15:55:04  pb10
 *  Add check for number of permits requested (getPermits).
 *
 *  Revision 1.19  2008/08/12 02:26:00  pb10
 *  Fix getPermit results parsing bug.
 *
 *  Revision 1.18  2008/08/11 23:04:15  gbr4
 *  fix CUWAPortalPermit intermittant failure (primarily OpenBSD). Also add more helpful text for permit -4008 errors.
 *
 *  Revision 1.17  2008/08/09 06:29:31  gbr4
 *  try to fix solaris problem
 *
 *  Revision 1.16  2008/08/09 01:16:49  pb10
 *  Support listPermit call (CUWAInquire permit all).
 *
 *  Revision 1.15  2008/05/22 18:15:34  hy93
 *  disable non-block before read to fix read failure on window
 *
 *  Revision 1.14  2008/05/05 19:50:55  gbr4
 *  fix a couple places where pointers were dereferenced and then checked for NULL
 *
 *  Revision 1.13  2008/04/29 13:34:55  hy93
 *  fix warning regarding assignment differ in signedness
 *
 *  Revision 1.12  2008/04/28 18:33:52  hy93
 *  Convert malloc's to APR allocations.
 *
 *  Revision 1.11  2008/04/24 14:12:59  hy93
 *  replace socket implementation with APR_SOCKET
 *
 *  Revision 1.10  2008/04/11 03:51:09  gbr4
 *  More ugly hacks to support Win32. Actually I think CVS's acronym is more descriptive (woe).
 *  It actually fully compiles now. I am sure that it doesn't run yet without even testing it :-)
 *
 *  In the very least permit.c needs its ioctl call changed to something more portable.
 *
 *  Revision 1.9  2008/04/10 23:26:36  gbr4
 *  ok. actually it wasn't that either. try NETINET_IN_H
 *
 *  Revision 1.8  2008/04/10 23:20:14  gbr4
 *  HAVE_NETINET_TCP_H not NETINET_TCP_H
 *
 *  Revision 1.7  2008/04/10 23:08:06  gbr4
 *  fixed all *compile* errors under msvc9.0 (studio 2008). Still has link errors
 *  and tons of warnings. This might cause regressions.
 *
 *  Revision 1.6  2008/02/22 18:39:40  hy93
 *  Update permit lookup code to expect return codes
 *
 *  Revision 1.5  2008/02/12 18:29:26  hy93
 *  remove line feed
 *
 *  Revision 1.4  2008/01/25 01:43:47  gbr4
 *  Added an ID string to every file
 *
 *  Revision 1.3  2008/01/13 21:27:10  pb10
 *  Lowercase CUWA2_LOG_DOMAIN setting.
 *
 *  Revision 1.2  2008/01/11 04:26:04  pb10
 *  Integration with logging.
 *
 *  Revision 1.1  2007/10/18 20:08:38  pb10
 *  initial
 *
 ************************************************************************
 * Some CUSSP protocol notes...
 * Here's the quick and dirty version of a cussp v3 message:
 ************************************************************************
 * Get permit...
 *
 * front = ffbdff03 [getPermit] FFEF [2] FFEF FFBB
 *
 *   [kerberos ticket] - remember to convert 0xff to 0xffff
 *
 * middle = FFEB FFBC0101
 *
 *   [contentLen-32-bit] {permitName FFEF netid FFEF permitName FFEF netid FFEF ...}
 *
 * tail = FFED
 *
 * Response...
 *
 * FFBC0101 [contentLen-32-bit] {retCode FFEF message FFEF params FFED}
 *
 * params... permitName 0x09 netid 0x09 value 0x09 permitName 0x09 netid 0x09 value 0x09...
 * value...0 or errorCode
 ************************************************************************
 * List permits...
 *
 * front = ffbdff03 [listPermits] FFEF [2] FFEF FFBB
 *
 *   [kerberos ticket] - remember to convert 0xff to 0xffff
 *
 * middle = FFEB FFBC0101
 *
 *   [contentLen-32-bit] {FFEF netid FFEF FFEF }
 *
 * tail = FFED
 *
 * Response...
 *
 * FFBC0101 [contentLen-32-bit] {retCode FFEF message FFEF params FFED}
 *
 * params... permitName 0x0d permitName 0x0d permitName 0x0d permitName ...
 ************************************************************************
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <krb5.h>
#include <sys/types.h>
#include "../autoconfig.h"
#include <apr_network_io.h>
#include <apr_pools.h>
#include <apr_version.h>
#include <apr_strings.h>

#include <log.h>
#include <kutil.h>
#include <cuwa_err.h>
#include <cuwa_types.h>
#include <cuwa_malloc.h>

#define APR_WANT_STRFUNC
#define APR_WANT_MEMFUNC
#define APR_WANT_STDIO
#define APR_WANT_IOVEC
#define APR_WANT_BYTEFYNC


#ifndef EINPROGRESS
#define EINPROGRESS WSAEINPROGRESS
#endif

#define CUWA2_LOG_DOMAIN cuwa.permit

#define BLOCKSIZE 8192
#define CONNECT_TIMEOUT 10
#define WRITE_TIMEOUT 5
#define READ_TIMEOUT 10

static unsigned char getcmd[]    = {0xff,0xbd,0xff,0x03,'g','e','t','P','e','r','m','i','t',0xff,0xef,'2',0xff,0xef,0xff,0xbb,0};
static unsigned char listcmd[]   = {0xff,0xbd,0xff,0x03,'l','i','s','t','P','e','r','m','i','t','s',0xff,0xef,'1',0xff,0xef,0xff,0xbb,0};
static unsigned char part2[]     = {0xff,0xeb,0xff,0xef,0xff,0xbc,0x01,0x01,0};
static unsigned char part3[]     = {0xff,0xed,0};
static unsigned char eoc[]       = {0xff,0xef,0};
static unsigned char rsp[]       = {0xff,0xbd,0xff,0x03,0xff,0xbc,0x01,0x01,0};
static unsigned char eom[]       = {0xff,0xed,0};

#define eofield 0x09
#define eorec   0x0d
#define iac     0xff
#define eocChar 0xef
#define eomChar 0xed

#if APR_MAJOR_VERSION > 0
#define apr_socket_create_ex   apr_socket_create
#endif

typedef struct command_buf
{
    char *data;
    int length;
    int alloc;
    char *rp;
} command_buf_t;

static int cuwa_permit_connect(char *permitHostName, int permitPort, int timeout, apr_socket_t **sock,apr_pool_t *pool );
static int cuwa_permit_bin_escape(char *in, int inLen, char **out, int *outLen);
static int cuwa_permit_put_32( command_buf_t *buf, int num);
static int cuwa_permit_decode_get(apr_pool_t *pool, char *in, int inLen, char *netid, int permitCnt, char **memberships, char **nonmember);
static int cuwa_permit_decode_list(apr_pool_t *pool, char *in, int inLen, char **memberships);
static int cuwa_permit_build_msg_get(apr_pool_t *pool, char *netid, char *permits, char **out, int *permitCnt);
static int cuwa_permit_put_bytes( command_buf_t *buf, char *in, int len);
static int cuwa_permit_read_32(apr_socket_t *sock, command_buf_t *inBuf, int *num, int timeout);
static int cuwa_permit_read_bytes(apr_socket_t *sock, command_buf_t *inBuf, char *out, int length, int timeout);
static int cuwa_permit_read( apr_socket_t *s, char *buffer, apr_size_t *length, int timeout );
static int cuwa_permit_write( apr_socket_t *s, char *buffer, apr_size_t *length, int timeout);
static int cuwa_permit_exec(kutil_session_t ksess, char *localid,
                            char *permitHostName, int permitPort, char *permitid,
                            unsigned char *cmd, char *msg, char **resp, apr_pool_t *pool);
static int cuwa_permit_read_rc(apr_pool_t *pool, char **inout, int *inoutLen, int *cmdrc, char **msg);


#define BYTESPERLINE    (12)

/**
 * cuwa_permit_check looks up one or more permit values by sending CUSSP message to permit server.
 * @param[in] ksess Kerberos session, login must be established before calling cuwa_permit_check
 * @param[in] localid The kerberos principal that is logged in locally.
 * @param[in] permitHostName Host name / IP address of permit server.
 * @param[in] permitPort Port to connect to permit server.
 * @param[in] permitid Kerberos principal of permit server.
 * @param[in] netids An ordered list of netids to be looked up.
 * @param[in] permit_names An ordered list of permits to be looked up.
 * @param[out] permits An ordered list of int, 0=accept, error code.
 */
int cuwa_permit_check(kutil_session_t ksess, char *localid,
                      char *permitHostName, int permitPort, char *permitid,
                      char *netid, char *permit_names, char **memberships, char **nonmember, apr_pool_t *pool)
{
    int rc, len, cmdrc, permitCnt;
    char *resp,*msg;
    cuwa_assert(netid);
    cuwa_assert(permit_names);

    *nonmember   = NULL;
    *memberships = NULL;

    if (!strcmp("all",permit_names))
    {
        cuwa_trace("cuwa_permit_check - listPermits...\n");
        msg = apr_psprintf(pool,"%s%s%sinvisible%s",eoc,netid,eoc,eoc);
        rc = cuwa_permit_exec(ksess,localid,permitHostName,permitPort,permitid,listcmd,msg,&resp,pool);
        if (!rc) len = strlen(resp);
        if (!rc) rc = cuwa_permit_read_rc(pool, &resp, &len, &cmdrc, &msg);
        if (!rc) rc = cuwa_permit_decode_list(pool, resp, len, memberships);
    }
    else
    {
        cuwa_trace("cuwa_permit_check - getPermit %s...\n",permit_names);
        rc = cuwa_permit_build_msg_get(pool, netid, permit_names, &msg, &permitCnt);
        if (!rc) rc = cuwa_permit_exec(ksess,localid,permitHostName,permitPort,permitid,getcmd,msg,&resp,pool);
        if (!rc) len = strlen(resp);
        if (!rc) rc = cuwa_permit_read_rc(pool, &resp, &len, &cmdrc, &msg);
        if (!rc) rc = cuwa_permit_decode_get(pool, resp, strlen(resp), netid, permitCnt, memberships, nonmember);
    }
    return rc;
}


/**
 * cuwa_permit_exec handles building, send/recv, and unpacking message to permit server.
 * @param[in] ksess Kerberos session, login must be established before calling cuwa_permit_check
 * @param[in] localid The kerberos principal that is logged in locally.
 * @param[in] permitHostName Host name / IP address of permit server.
 * @param[in] permitPort Port to connect to permit server.
 * @param[in] permitid Kerberos principal of permit server.
 * @param[in] netids An ordered list of netids to be looked up.
 * @param[in] permit_names An ordered list of permits to be looked up.
 * @param[out] permits An ordered list of int, 0=accept, error code.
 */
int cuwa_permit_exec(kutil_session_t ksess, char *localid,
                      char *permitHostName, int permitPort, char *permitid,
                      unsigned char *cmd, char *msg, char **resp,
                      apr_pool_t *pool)
{
    int code;
    apr_socket_t *sock = NULL;
    cuwa_err_t rc = CUWA_OK;
    kutil_krb_ctx_t ctx = NULL;
    char *req=NULL, *req2=NULL, *clear=NULL, *ciph=NULL, *ptr=NULL;
    int reqLen, reqLen2, clearLen, ciphLen, ptrLen=0;
    command_buf_t buf,inBuf;
    apr_size_t sent;
    char hdr[8];

    cuwa_assert(ksess);
    cuwa_assert(localid);
    cuwa_assert(permitHostName);
    cuwa_assert(permitPort);
    cuwa_assert(permitid);

    memset(&buf,0,sizeof(buf));
    memset(&inBuf,0,sizeof(inBuf));

    code = cuwa_permit_connect(permitHostName, permitPort, CONNECT_TIMEOUT, &sock ,pool);
    FAIL_IF(code,code);

    /* Establish authentication context */

    code = kutil_make_req( &ctx, ksess, permitid, &req, &reqLen );
    FAIL_IF(code,code);

    code = cuwa_permit_bin_escape(req, reqLen, &req2, &reqLen2);
    FAIL_IF(code,code);

    code = cuwa_permit_put_bytes( &buf, (char *)cmd, strlen((char *)cmd));
    FAIL_IF(code,code);
    code = cuwa_permit_put_bytes( &buf, req2, reqLen2);
    FAIL_IF(code,code);
    code = cuwa_permit_put_bytes( &buf, (char *)part2, strlen((char *)part2));
    FAIL_IF(code,code);

    code = kutil_mk_priv( ctx, msg, strlen(msg), &ciph, &ciphLen );
    FAIL_IF(code,code);

    code = cuwa_permit_put_32( &buf, ciphLen);
    FAIL_IF(code,code);
    code = cuwa_permit_put_bytes( &buf, ciph, ciphLen);
    FAIL_IF(code,code);

    code = cuwa_permit_put_bytes( &buf, (char *)part3, strlen((char *)part3));
    FAIL_IF(code,code);

    cuwa_free(ciph);
    ciph = NULL;

    /* Sent the entire message */
    sent = buf.length;

//HexDump("send",buf.data,buf.length);

    code = cuwa_permit_write(sock, buf.data, &sent, WRITE_TIMEOUT);
    FAIL_IF(code,code);

    cuwa_trace("Send complete.\n");

    /* Collect the response */
    code = cuwa_permit_read_bytes(sock, &inBuf, hdr, 8, READ_TIMEOUT);
    FAIL_IF(code,code);

    /* Make sure this is valid return message */
    FAIL_IF((memcmp(hdr,rsp,8)!=0), CUWA_ERR_PERMIT_PROTO);

    code = cuwa_permit_read_32(sock, &inBuf, &ptrLen, READ_TIMEOUT);
    FAIL_IF(code,code);

    ptr = cuwa_malloc(ptrLen);
    FAIL_IF(!ptr,CUWA_ERR_MEM);

    code = cuwa_permit_read_bytes(sock, &inBuf, ptr, ptrLen, READ_TIMEOUT);
    FAIL_IF(code,code);

    code = kutil_rd_priv( ctx, ptr, ptrLen, &clear, &clearLen );
    FAIL_IF(code,code);

    cuwa_trace("kutil_rd_priv inLen: %d, outLen: %d\n",ptrLen,clearLen);

    code = cuwa_permit_read_bytes(sock, &inBuf, hdr, 2, READ_TIMEOUT);
    FAIL_IF((memcmp(hdr,eom,2)!=0), CUWA_ERR_PERMIT_PROTO);
    cuwa_trace("Found EOM...\n");

    *resp = apr_pcalloc(pool, clearLen+1);
    memcpy(*resp,clear,clearLen);

cleanup:

    if (req)     cuwa_free(req);
    if (req2)    cuwa_free(req2);
    if (ciph)    cuwa_free(ciph);
    if (clear)   cuwa_free(clear);
    if (sock )
       apr_socket_close( sock );

    return rc;
}



/**
 * cuwa_permit_connect connect to the permit server.
 * @param[in] permitHostName Host name / IP address of permit server.
 * @param[in] permitPort Port to connect to permit server.
 * @param[in] timeout number of seconds before connection attemp is aborted.
 * @param[out] sock the socket returned.
 */
int cuwa_permit_connect(char *permitHostName, int permitPort, int timeout, apr_socket_t **new_sock, apr_pool_t *pool )
{
    cuwa_err_t rc = CUWA_OK;
    apr_status_t rv;
    apr_socket_t *sock;
    apr_sockaddr_t *permitServer;

    cuwa_assert(permitHostName);
    cuwa_assert(timeout);

    rv = apr_socket_create_ex( &sock,  APR_INET, SOCK_STREAM, APR_PROTO_TCP,  pool );
    FAIL_IF_APR_SOCK_ERR(rv);

    rv = apr_socket_opt_set(sock, APR_SO_NONBLOCK, 1);
    FAIL_IF_APR_SOCK_ERR(rv);

    rv = apr_socket_timeout_set( sock, apr_time_from_sec(timeout));
    FAIL_IF_APR_SOCK_ERR(rv);

    rv = apr_sockaddr_info_get(&permitServer,permitHostName, APR_INET, permitPort, 0, pool);
    FAIL_IF_APR_SOCK_ERR(rv);

    rv = apr_socket_connect(sock, permitServer);
    FAIL_IF_APR_SOCK_ERR(rv);

    *new_sock = sock;

cleanup:

    if (!rc)
    {
        *new_sock = sock;
    }

    return rc;
}

/**
 * cuwa_permit_write write bytes on a connection.
 * @param[in] sock the socket.
 * @param[in] buffer pointer to bytes to write.
 * @param[in/out] length number of bytes to write / number of bytes written.
 * @param[in] timeout number of seconds before abort.
 */
int cuwa_permit_write( apr_socket_t *sock, char *buffer, apr_size_t *length, int timeout)
{
    cuwa_err_t rc = CUWA_OK;
    apr_status_t rv;

    cuwa_assert(sock);
    cuwa_assert(buffer);
    cuwa_assert(length);
    cuwa_assert(timeout);
    cuwa_assert(*length);

    /* Write the bytes */
    apr_socket_timeout_set( sock, apr_time_from_sec(timeout) );

    rv = apr_socket_send( sock, buffer, length );
    FAIL_IF_APR_SOCK_ERR(rv);

cleanup:

    return rc;
}

/**
 * cuwa_permit_read read bytes on a connection. Bytes actually read may not match bytes requested.
 * @param[in] sock the socket.
 * @param[in] buffer pointer to copy read bytes to.
 * @param[in/out] length number of bytes to read / number of bytes read.
 * @param[in] timeout number of seconds before abort.
 */
int cuwa_permit_read( apr_socket_t *sock, char *buffer, apr_size_t *length, int timeout )
{
    cuwa_err_t rc = CUWA_OK;
    apr_status_t rv;

    cuwa_assert(sock);
    cuwa_assert(buffer);
    cuwa_assert(length);
    cuwa_assert(timeout);
    cuwa_assert(*length);

    apr_socket_opt_set(sock, APR_SO_NONBLOCK, 0);

    /* read the bytes */
    apr_socket_timeout_set( sock, apr_time_from_sec( timeout ) );
    rv = apr_socket_recv( sock, buffer, length);
    FAIL_IF_APR_SOCK_ERR( rv );

cleanup:

    return rc;
}


/**
 * cuwa_permit_read_bytes read bytes from connection. Bytes always match bytes requested if not error.
 * @param[in] sock the socket.
 * @param[in] inBuf pointer to chache buffer.
 * @param[in] out pointer to copy read bytes to.
 * @param[in] length number of bytes to read.
 * @param[in] timeout number of seconds before abort.
 */
int cuwa_permit_read_bytes(apr_socket_t *sock, command_buf_t *inBuf, char *out, int length, int timeout)
{
    cuwa_err_t rc = CUWA_OK;
    int code;
    apr_size_t rdlen;
    int left;

    cuwa_assert(inBuf);
    cuwa_assert(out);
    cuwa_assert(timeout);
    cuwa_assert(length);

    left = inBuf->length - (inBuf->rp - inBuf->data);

    while (length > left)
    {
        if (left)
        {
            memcpy(out,inBuf->rp,left);
            length -= left;
            out += left;
        }

        if (!inBuf->alloc)
        {
            inBuf->data = cuwa_malloc(BLOCKSIZE);
            inBuf->alloc = BLOCKSIZE;
            FAIL_IF(!inBuf->alloc,CUWA_ERR_MEM);
        }

        rdlen = inBuf->alloc;
        code = cuwa_permit_read( sock, inBuf->data, &rdlen, timeout );
        FAIL_IF(code,code);

        inBuf->length = rdlen;
        inBuf->rp = inBuf->data;
        left = rdlen;
    }

    memcpy(out,inBuf->rp,length);
    inBuf->rp += length;

cleanup:

    return rc;
}

/**
 * cuwa_permit_read_32 read a 32 bit integer.
 * @param[in] sock the socket.
 * @param[in] inBuf pointer to chache buffer.
 * @param[out] num the integer returned.
 * @param[in] timeout number of seconds before abort.
 */
int cuwa_permit_read_32(apr_socket_t *sock, command_buf_t *inBuf, int *num, int timeout)
{
    cuwa_err_t rc = CUWA_OK;
    int code;
    uint32 num32;

    code = cuwa_permit_read_bytes(sock, inBuf, (char*) &num32, sizeof(num32), timeout);
    FAIL_IF(code,code);

    *num = ntohl(num32);

cleanup:

    return rc;

}

/**
 * cuwa_permit_put_bytes copies bytes into buffer. Makes sure buffer is big enough to handle new bytes.
 * @param[in] buf pointer to buffer.
 * @param[in] in pointer to bytes to copy.
 * @param[in] len number of bytes to copy.
 */
int cuwa_permit_put_bytes( command_buf_t *buf, char *in, int len)
{
    cuwa_err_t rc = CUWA_OK;

    cuwa_assert(buf);
    cuwa_assert(in);
    cuwa_assert(len);

    if ((buf->length + len) > buf->alloc)
    {
        int newsize = (((buf->length + len) / BLOCKSIZE) + 1) * BLOCKSIZE;
        char *p = cuwa_malloc( newsize );
        FAIL_IF(!p,CUWA_ERR_MEM);

        //copy the original data to the new buffer
        memcpy( p, buf->data, buf->length );
        buf->data = p;
        buf->alloc = newsize;
    }

    memcpy(&buf->data[buf->length],in,len);
    buf->length += len;

cleanup:

    return rc;
}

/**
 * cuwa_permit_put_bytes 32 bit integer in buffer.
 * @param[in] buf pointer to buffer.
 * @param[in] num the number.
 */
int cuwa_permit_put_32( command_buf_t *buf, int num)
{
    uint32 num32 = (uint32) num;

    cuwa_assert(buf);

    num32 = htonl(num32);
    return cuwa_permit_put_bytes(buf, (char*)&num32, sizeof(num32));
}

/**
 * cuwa_permit_bin_escape convert 0xff to 0xffff.
 * @param[in] in pointer to buffer.
 * @param[in] inLen the number of bytes in.
 * @param[out] out pointer to out buffer. Caller must free.
 * @param[out] outLen the number of bytes out.
 */
int cuwa_permit_bin_escape(char *in, int inLen, char **out, int *outLen)
{
    int i;
    unsigned char *ptr;
    unsigned char *inp = (unsigned char*) in;

    cuwa_assert(in);
    cuwa_assert(inLen);
    cuwa_assert(out);
    cuwa_assert(outLen);

    ptr = cuwa_malloc(inLen*2);
    if (!ptr)
    {
        return CUWA_ERR_MEM;
    }

    *out = (char *) ptr;

    for (i=0;i<inLen;i++)
    {
        *ptr++ = *inp++;
        if (*inp==0xff)
        {
            *ptr++ = 0xff;
        }
    }

    *outLen = ((char *)ptr) - *out;

    return CUWA_OK;
}

/**
 * cuwa_permit_build_msgs build the message content (permit lookup requests).
 * @param[in] netids ordered list of netids.
 * @param[in] permits ordered list of permit names.
 * @param[out] out pointer to out buffer. Caller must free.
 * @param[out] outLen the number of bytes out.
 * @param[out] msgCnt the number of requests found.
 */
int cuwa_permit_build_msg_get(apr_pool_t *pool, char *netid, char *permits, char **out, int *permitCnt)
{
    char *p = "";
    char *permit,*last;
    int cnt=0;

    /* Calculate size */
    permit = apr_strtok( permits," ", &last );
    while ( permit )
    {
        cnt++;
        p = apr_psprintf(pool,"%s%s%s%s%s",p,permit,eoc,netid,eoc);
        permit = apr_strtok( NULL, " ", &last );
    }

    *out = p;
    *permitCnt = cnt;

    return 0;
}

/**
 * cuwa_permit_decode_resps build the message content (permit lookup requests).
 * @param[in] in pointer to buffer.
 * @param[in] inLen the number of bytes in.
 * @param[out] list of booleans representing the permit value.
 * @param[in] pmax expected number of permits in the message.
 */
int cuwa_permit_decode_get(apr_pool_t *pool, char *in, int inLen, char *innetid, int permitCnt, char **memberships, char **nonmember)
{
    cuwa_err_t rc = CUWA_OK;
    char *str=in, *permit, *netid;
    int permitAllow;
    char *last,*eos;
    const char sep[]={eofield,0};

    cuwa_assert(in);
    cuwa_assert(inLen);
    cuwa_assert(innetid);
    cuwa_assert(memberships);

    *memberships = NULL;
    *nonmember = NULL;

    eos = strchr(in,iac);
    if (eos) *eos = 0;

    cuwa_trace("cuwa_permit_decode_resps remaining: %d",inLen);

    permit = apr_strtok(in,sep,&last);	
    while (permitCnt-- && permit)
    {
        cuwa_trace("cuwa_permit_decode_resps permit: %s",permit);

        netid = apr_strtok(NULL,sep,&last);
        FAIL_IF( (!netid), CUWA_ERR_PERMIT_PROTO);

        cuwa_trace("cuwa_permit_decode_resps neitd: %s",netid);

        str = apr_strtok(NULL,sep,&last);
        FAIL_IF( (!str), CUWA_ERR_PERMIT_PROTO);
        permitAllow = atoi(str);

        if (!strcmp(netid,innetid))
        {
            switch (permitAllow)
            {
            case 0:
                cuwa_trace("permit member, netid=%s permit=%s allow=%s",netid, permit, str);
                if (!*memberships) *memberships = apr_pstrdup(pool,permit);
                else *memberships = apr_pstrcat(pool,*memberships," ",permit,NULL);
                break;
            case -4003:
                cuwa_trace("permit non-member, netid=%s permit=%s allow=%s",netid, permit, str);
                if (!*nonmember) *nonmember = apr_pstrdup(pool,permit);
                else *nonmember = apr_pstrcat(pool,*nonmember," ",permit,NULL);
                break;
            case -4008:
                cuwa_crit("permit lookup error -- read access to permit denied. Check that this ServiceID has read access to this permit, netid=%s permit=%s allow=%s",netid, permit, str);
                break;
            default:
                // Elevate this error, probably a misconfiguration
                cuwa_crit("permit lookup error, netid=%s permit=%s allow=%s",netid, permit, str);
                break;
            }
        }
        else
        {
            // This may indicate an attempt at replaying a previous message (for a different netid)
            cuwa_warning("permit lookup netid mismatch, netid=%s expected=%s permit=%s allow=%s",netid, innetid, permit, str);
        }
        cuwa_trace("Member thus far: %s",DENULL(*memberships));

        permit = apr_strtok(NULL,sep,&last);	
    }


cleanup:

    cuwa_trace("cuwa_permit_decode_resps done: rc: %d",rc);

    return rc;
}


/**
 * cuwa_permit_decode_resps build the message content (permit lookup requests).
 * @param[in] in pointer to buffer.
 * @param[in] inLen the number of bytes in.
 * @param[out] list of booleans representing the permit value.
 * @param[in] pmax expected number of permits in the message.
 */
int cuwa_permit_decode_list(apr_pool_t *pool, char *in, int inLen, char **memberships)
{
    char *permit;
    char *last,*eos;
    const char sep[]={eorec,0};

    cuwa_assert(in);
    cuwa_assert(inLen);
    cuwa_assert(memberships);

    *memberships = NULL;

    eos = strchr(in,iac);
    if (eos) *eos = 0;

    permit = apr_strtok(in,sep,&last);	
    while (permit)
    {
        if (strlen(permit))
        {
            if (!*memberships) *memberships = permit;
            else *memberships = apr_pstrcat(pool,*memberships," ",permit,NULL);
        }
        permit = apr_strtok(NULL,sep,&last);	
    }

    return 0;
}

int cuwa_permit_read_rc(apr_pool_t *pool, char **inout, int *inoutLen, int *cmdrc, char **msg)
{
    int rc = 0;
    int inLen = *inoutLen;
    unsigned char *inp  = (unsigned char *)*inout;
    char *str = (char *)inp;

    /* Get the response code */
    for (; inLen && *inp!=0xff; inLen--,inp++);
    FAIL_IF( (inLen<=0), CUWA_ERR_PERMIT_PROTO);
    *inp = 0; inLen-=2; inp+=2;
    *cmdrc = atoi(str);

    cuwa_trace("Permit server RC: %d",*cmdrc);

    FAIL_IF( (inLen<=0), CUWA_ERR_PERMIT_PROTO);

    /* Get the message response */
    str = (char *)inp;
    for (; inLen && *inp!=0xff; inLen--,inp++);
    FAIL_IF( (inLen<=0), CUWA_ERR_PERMIT_PROTO);
    *inp = 0; inLen-=2; inp+=2;
    *msg = str;
    FAIL_IF( (inLen<=0), CUWA_ERR_PERMIT_PROTO);

    if (*cmdrc) cuwa_trace("Permit server message: %s (%d)",*msg,*cmdrc);

    *inout = (char *)inp;
    *inoutLen = inLen;

cleanup:

    return rc;
}


const char id_permit_permit_c[] = "$Id$";
