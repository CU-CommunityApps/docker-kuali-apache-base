/************************************************************************
 * permit_cache.c -- permit lookup cache
 *
 * Copyright 2008 Cornell University.
 * All Rights Reserved.
 *
 ************************************************************************
 *  $Log$
 *  Revision 1.10.2.2  2015/10/01 16:05:07  hy93
 *  add session to cuwa_permit_cache_set,cuwa_permit_cache_check,uwa_session_update_permit_cache
 *
 *  Revision 1.10.2.1  2015/04/29 13:05:09  hy93
 *  Fix sometimes error page didn't show properly
 *
 *  Revision 1.10  2014/10/22 16:39:43  hy93
 *  remove Apache 2.4 support
 *
 *  Revision 1.8  2013/07/05 15:16:09  hy93
 *  include util.h to fix compiler warning
 *
 *  Revision 1.7  2012/08/23 16:08:09  hy93
 *  fix case mis-match permit added to cache repeatedly
 *
 *  Revision 1.6  2009/08/03 16:14:17  hy93
 *  add text in error message
 *
 *  Revision 1.5  2009/02/09 21:32:26  pb10
 *  Fix bug in previous commit.
 *
 *  Revision 1.4  2009/02/09 20:22:45  pb10
 *  Fixed | delimiter being returned in CUWA_GROUPS when requesting
 *  permit "all" from cache.
 *
 *  Revision 1.3  2008/08/22 14:53:20  hy93
 *  remove line feed
 *
 *  Revision 1.2  2008/08/15 17:27:18  pb10
 *  Need to make copy of cache before use in get_cache
 *
 *  Revision 1.1  2008/08/09 01:19:07  pb10
 *  Initial coding.
 *
 ************************************************************************
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include "../autoconfig.h"
#include <apr_pools.h>
#include <apr_strings.h>
#include <log.h>
#include <kutil.h>
#include <cuwa_err.h>
#include <cuwa_types.h>
#include <session.h>
#include <wal.h>
#include <cuwa_parse.h>
#include <permit_ha.h>
#include <util.h>

#define CUWA2_LOG_DOMAIN cuwa.permit

static char *empty_str = "";
static char * cuwa_permit_strip_cache(apr_pool_t *pool, char *c);

//#define REPLACE(str,c1,c2)  do {char *_s_=str; while (*_s_) {if (*_s_==*(c1)) *_s_ = *(c2);_s_++;}} while (0)

#define INSERT_NAME(pool,name,list)                              \
  do {                                                           \
    if (!(list)) (list) = apr_pstrdup((pool),(name));            \
    else (list) = apr_pstrcat((pool), (list)," ", (name), NULL); \
  } while (0)

#define PERMIT_TYPE_DELIMITER       "=="
#define PERMIT_DELIMITER       "|"

// CUWA_SESSION_PERMITS notes field appears to be there for performance reasons, but I'm not sure.
// On face value it seems that a session could be obtained using same mechanism used by cuwa_session_update_permit_cache,
// and the permit cache could be obtained from the session.
#define CUWA_SESSION_PERMITS "CUWA_PERMITS"


static void REPLACE(char *s,char *c1,char *c2)
{
    for (;*s;s++) if (*s==*c1) *s=*c2;
}


static int cuwa_permit_cache_hit(apr_pool_t *pool, char *permit, char *cache);
static void cuwa_permit_cache_set(void *r, apr_pool_t *pool, void *session, CUWACfg_t *cfg, int allFlag, char *members, char *nonmembers, char *inYes, char *inNo);
static void cuwa_permit_cache_get(void *r, apr_pool_t *pool, int *allFlag, char **members, char **nonmembers);

cuwa_err_t cuwa_permit_cache_check( void *request, apr_pool_t *pool, void *session, CUWACfg_t *cfg, char *localid, char *keytab,
                                    char *netid, char *permitlist, char **memberships, char **nonmember )
{
    char *requestedPermits=NULL;
    int code = 0;
    char *state;
    int total, allFlag = 0;
    char *cacheMembers, *cacheNonmembers, *permitName, *cachefault=NULL;
    char *lookupYes=NULL, *lookupNo=NULL;

    *memberships = NULL;
    *nonmember   = NULL;

    cuwa_permit_cache_get(request, pool, &allFlag, &cacheMembers, &cacheNonmembers);
    cuwa_info("Cached Permits for user %s: %s (non:%s)", netid, cacheMembers, cacheNonmembers);

    // parse the permit list, removing quotes if there are any
    total = 0;
    while (*permitlist)
    {
         total++;
         INSERT_NAME(pool,cuwa_getword_conf(pool, (const char**) &permitlist),requestedPermits);
    }

    if ( total == 0)
    {
        char *msg = "Server is not properly configured. Check the require directive.";

        cuwa_wal_save_error(request, HTTP_SERVER_ERROR, CUWA_ERR,msg);
        return CUWA_ERR;
    }

    cuwa_trace("requestedPermits:%s", requestedPermits);

    if (!strcmp("all",requestedPermits))
    {
        if (allFlag)
        {
            *memberships = cuwa_permit_strip_cache(pool, cacheMembers);
            return CUWA_OK;
        }

        allFlag = 1;
        cachefault = requestedPermits;
    }
    else
    {
        // Check the cache...
        permitName = apr_strtok( requestedPermits," ", &state );
        while ( permitName )
        {
            if (cuwa_permit_cache_hit(pool,permitName,cacheMembers))
            {
                INSERT_NAME(pool,permitName,*memberships);
            }
            else if (cuwa_permit_cache_hit(pool,permitName,cacheNonmembers))
            {
                INSERT_NAME(pool,permitName,*nonmember);
            }
            else
            {
                INSERT_NAME(pool,permitName,cachefault);
            }

            permitName = apr_strtok( NULL, " ", &state );
        }

        if (!cachefault) return CUWA_OK;
    }

    code = cuwa_permit_ha_check( pool, localid, keytab, netid, cachefault, &lookupYes, &lookupNo);
    cuwa_trace("cuwa_permit_ha_check: %d",code);

    if (code)
    {
        char *msg = apr_psprintf(pool,"Permit verification failed with error %d. The permit service may be down or permit is misconfigured in cuwebauth conf file.",code );

         cuwa_wal_save_error(request, HTTP_SERVER_ERROR, code, msg);
         return CUWA_ERR;
    }

    if (lookupYes) INSERT_NAME(pool,lookupYes,*memberships);
    if (lookupNo) INSERT_NAME(pool,lookupNo,*nonmember);

    cuwa_trace("Permit Cache members: %s",*memberships?*memberships:"NULL");
    cuwa_trace("Permit Cache nonmembers: %s",*nonmember?*nonmember:"NULL");

    cuwa_permit_cache_set(request, pool, session, cfg, allFlag, cacheMembers, cacheNonmembers, lookupYes, lookupNo);

    cuwa_trace("Permit Cache update complete <<%s>>",*memberships?*memberships:"");

    // Make sure we don't return an empty string
    cuwa_assert(!*memberships || strlen(*memberships));
    cuwa_assert(!*nonmember || strlen(*nonmember));

    return CUWA_OK;
}

void cuwa_permit_cache_load(void *r, cuwa_session_t *session, apr_pool_t *pool)
{
    char *cache = cuwa_session_get_permit_cache( session );

    if (cache)
    {
        cuwa_trace("about to load permit cache:%s",cache);
        cuwa_wal_note_set(r,CUWA_SESSION_PERMITS,cache);
    }
}

void cuwa_permit_cache_get(void *r, apr_pool_t *pool, int *allFlag, char **members, char **nonmembers)
{
    char *cache = cuwa_wal_note_get(r, CUWA_SESSION_PERMITS );
    char *s2,*s1;

    if (!cache)
    {
        *allFlag    = 0;
        *members    = empty_str;
        *nonmembers = empty_str;
        return;
    }

    cache = apr_pstrdup(pool, cache);

    cuwa_trace("Permit cache is: %s",cache);

    *allFlag = (*cache=='1')?1:0;

    s1 = strstr( cache, PERMIT_TYPE_DELIMITER );
    cuwa_assert(s1);
    s1 += strlen(PERMIT_TYPE_DELIMITER);

    s2 = strstr( s1, PERMIT_TYPE_DELIMITER );
    cuwa_assert(s2);
    *s2 = 0;
    s2 += strlen(PERMIT_TYPE_DELIMITER);

    *members = s1;
    *nonmembers = s2;
}

#define NONULL(w) (w)?(w):""
void cuwa_permit_cache_set(void *r, apr_pool_t *pool, void *session, CUWACfg_t *cfg, int allFlag, char *members, char *nonmembers, char *inYes, char *inNo)
{
    char *cache;

    if (inYes) REPLACE(inYes," ",PERMIT_DELIMITER);
    if (inNo) REPLACE(inNo," ",PERMIT_DELIMITER);

    cache = apr_psprintf(pool,"%d%s%s%s%s%s%s%s%s%s%s",allFlag,PERMIT_TYPE_DELIMITER,
                           NONULL(members),PERMIT_DELIMITER,NONULL(inYes),PERMIT_DELIMITER,PERMIT_TYPE_DELIMITER,
                           NONULL(nonmembers),PERMIT_DELIMITER,NONULL(inNo),PERMIT_DELIMITER);

    cuwa_trace("Permit Cache Raw: %s",cache);

    // Save it to notes field and to disk
    cuwa_wal_note_set(r,CUWA_SESSION_PERMITS,cache);
    cuwa_session_update_permit_cache( r, pool, session, cfg, cache );
}

int cuwa_permit_cache_hit(apr_pool_t *pool, char *permit, char *cache)
{
    char *search = apr_pstrcat(pool,PERMIT_DELIMITER,permit,PERMIT_DELIMITER,NULL);

    return strstr_case_insensitive(cache,search)?1:0;
}

char * cuwa_permit_strip_cache(apr_pool_t *pool, char *c)
{
    char *s = apr_palloc(pool,strlen(c)+1);
    char *str = s;

    while(*c && *c==*PERMIT_DELIMITER) c++;

    while (*c) 
    {
        while(*c && *c!=*PERMIT_DELIMITER) *s++ = *c++;
        while(*c && *c==*PERMIT_DELIMITER) c++;
        if (*c) *s++ = ' ';
    }
    *s = 0;
    return str;
}


const char id_permit_permit_cache_c[] = "$Id$";
