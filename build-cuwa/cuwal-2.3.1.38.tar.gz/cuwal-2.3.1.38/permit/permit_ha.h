/************************************************************************
 * permit_ha.h -- permit high availability support
 *
 * Copyright 2007 Cornell University.
 * All Rights Reserved.
 *
 ************************************************************************
 *  $Log$
 *  Revision 1.1  2008/04/24 14:09:15  hy93
 *  permit support
 *
 *
 ************************************************************************
 */

#ifndef _PERMIT_HA_H
#define _PERMIT_HA_H

#include <apr_pools.h>
#include <cfg.h>

void cuwa_permit_ha_add_servers( char *permitList , apr_pool_t *pool);

int cuwa_permit_ha_check( apr_pool_t *pool, char *localid, char *keytab,
                          char *netid, char *permitlist, char **memberships, char **nonmember);

int cuwa_permit_ha_delete( apr_pool_t *pool, char *localid, char *keytab,
                          char *netid, char *permits,char **memberships, char **nonmember);
void cuwa_permit_random_server_to_use();

int cuwa_permit_ha_check_IPSN( apr_pool_t *pool, char *localid, char *keytab,
                          char *netid, char *delegate,char **memberships, char **nonmember);
#endif
