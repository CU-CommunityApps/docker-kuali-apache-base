/************************************************************************
 * permit_http.c -- Look up one or more permits using HTTP
 *
 * Copyright 2007 Cornell University.
 * All Rights Reserved.
 *
 ************************************************************************
 *  $Log$
 *  Revision 1.23  2010/11/01 16:15:42  pb10
 *  Make cuwa_permit_add_to_buf copy safe.
 *  Reduced potential for improper use of recycled buffer in cuwa_perit_add_to_buf.
 *  Added comments to explain buffer reuse.
 *  Added comments to explain cuwa_version string changes.
 *
 *  Revision 1.22  2010/06/23 17:05:46  hy93
 *  fix the bug instroduced in the checkin of v1.20
 *
 *  Revision 1.21  2010/06/18 15:00:41  hy93
 *  replace listallnetids command with old listnetids
 *
 *  Revision 1.20  2010/06/16 18:54:17  hy93
 *  Fix consuming large memory when there is lots of permit data sent back from permit server
 *
 *  Revision 1.19  2010/05/28 19:59:58  hy93
 *  return better error message for permit checking
 *
 *  Revision 1.18  2010/03/19 14:45:42  hy93
 *  remove set Permit-Audit in header. Audit is done in permit server now
 *
 *  Revision 1.17  2009/12/22 15:27:42  hy93
 *  support add/delete multiple permits in one command.Remove duplicate code
 *
 *  Revision 1.16  2009/11/05 20:16:09  hy93
 *  add Permit-Audit in note field for permit audit purpose
 *
 *  Revision 1.15  2009/10/09 03:30:38  pb10
 *  Add and delete functions are now supported in mod_permit.
 *  Also added support into getpermit command for testing purposes, but not into permit portal.
 *  May remove feature from getpermit command after testing completes TBD.
 *
 *  Revision 1.14  2009/08/04 15:44:02  hy93
 *  add error message for listing member of a permit which serviceID is not authorized to
 *
 *  Revision 1.13  2009/08/03 16:16:45  hy93
 *  set rc to error code when there is permit error returned by permit serve so portal will show error message
 *
 *  Revision 1.12  2009/06/23 15:48:09  hy93
 *  Implement listnetds in permit
 *
 *  Revision 1.11  2009/01/08 18:25:54  pb10
 *  Fixed compiler warnings.
 *
 *  Revision 1.10  2008/12/15 19:02:13  hy93
 *  fix using wrong error code to examine permit server return code
 *
 *  Revision 1.9  2008/11/21 14:34:57  pb10
 *  Convert port 756 to port 80 for backward compatability.
 *
 *  Revision 1.8  2008/10/08 21:09:10  pb10
 *  Solaris fix
 *
 *  Revision 1.7  2008/10/08 19:00:16  pb10
 *  Save.
 *
 *  Revision 1.6  2008/10/08 18:55:29  pb10
 *  Adjust protocol.
 *
 *  Revision 1.5  2008/10/08 18:48:55  pb10
 *  Add response label.
 *
 *  Revision 1.4  2008/10/08 17:50:37  pb10
 *  Fix fault.
 *
 *  Revision 1.3  2008/10/08 17:37:40  pb10
 *  protocol fix.
 *
 *  Revision 1.2  2008/10/08 15:29:39  pb10
 *  CI the correct file :-)
 *
 *  Revision 1.1  2008/10/02 19:39:49  pb10
 *  Initial coding for permit client that uses HTTP instead of CUSSP.
 *
 ************************************************************************
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <krb5.h>
#include <sys/types.h>
#include "../autoconfig.h"
#include <apr_network_io.h>
#include <apr_pools.h>
#include <apr_version.h>
#include <apr_strings.h>

#include <log.h>
#include <kutil.h>
#include <cuwa_err.h>
#include <cuwa_types.h>
#include <cred_krb.h>
#include <cred_base64.h>
#include <cred.h>
#include <cuwa_version.h>
#include <util.h>

#define APR_WANT_STRFUNC
#define APR_WANT_MEMFUNC
#define APR_WANT_STDIO
#define APR_WANT_IOVEC
#define APR_WANT_BYTEFYNC


#ifndef EINPROGRESS
#define EINPROGRESS WSAEINPROGRESS
#endif

#define CUWA2_LOG_DOMAIN cuwa.permit

#define WRAP_LABEL "base64-wrap:"
#define BLOCKSIZE 8192
#define MAXLINE 1024
#define CONNECT_TIMEOUT 10
#define WRITE_TIMEOUT 5
#define READ_TIMEOUT 10

#if APR_MAJOR_VERSION > 0
#define apr_socket_create_ex   apr_socket_create
#endif

typedef struct command_buf
{
    char *data;
    int length;
    int alloc;
    char *rp;
} command_buf_t;

static int cuwa_permit_connect(char *permitHostName, int permitPort, int timeout, apr_socket_t **sock,apr_pool_t *pool );
static int cuwa_permit_read_bytes(apr_socket_t *sock, command_buf_t *inBuf, char *out, int length, int timeout);
static int cuwa_permit_read( apr_socket_t *s, char *buffer, apr_size_t *length, int timeout );
static int cuwa_permit_write( apr_socket_t *s, char *buffer, apr_size_t *length, int timeout);
static void cuwa_permit_init_buf(apr_pool_t *pool, command_buf_t *inBuf);
static int cuwa_permit_send(apr_socket_t *sock, apr_pool_t *pool, char *wa, char **resp);
static int cuwa_permit_decode(apr_pool_t *pool, char *innetid, char *resp, int len, char **memberships, char **nonmember);
static int cuwa_permit_read_char(apr_socket_t *sock, command_buf_t *inBuf, char *ch);
static int cuwa_permit_read_more(apr_socket_t *sock, command_buf_t *inBuf);
static int cuwa_permit_send_cmd(kutil_session_t ksess, char *netid,
                         char *permitHostName, int permitPort, char *permitid, char *msg,
                         apr_pool_t *pool,char **memberships, char **nonmember);

// FIXME: comments on pretty much every function block are wrong

/**
 * cuwa_permit_check looks up one or more permit values by sending CUSSP message to permit server.
 * @param[in] ksess Kerberos session, login must be established before calling cuwa_permit_check
 * @param[in] localid The kerberos principal that is logged in locally.
 * @param[in] permitHostName Host name / IP address of permit server.
 * @param[in] permitPort Port to connect to permit server.
 * @param[in] permitid Kerberos principal of permit server.
 * @param[in] netid A netid to be looked up.
 * @param[in] permit_names An ordered list of permits to be looked up.
 * @param[out] permits An ordered list of int, 0=accept, error code.
 */
int cuwa_permit_check(kutil_session_t ksess, char *localid,
                      char *permitHostName, int permitPort, char *permitid,
                      char *netid, char *permit_names, char **memberships, char **nonmember, apr_pool_t *pool)
{
    int rc=0;
    char *msg = NULL;

    cuwa_assert(netid);
    cuwa_assert(permit_names);

    *nonmember   = NULL;
    *memberships = NULL;

    if (!strcmp("all",permit_names))
    {
        msg = apr_psprintf(pool,"cmd=listpermits&netid=%s",netid);
    }
    else if (!strcmp("all",netid))
    {
        msg = apr_psprintf(pool,"cmd=listnetids&permits=%s",permit_names);
    }
    else
    {
        msg = apr_psprintf(pool,"cmd=getpermit&netid=%s&permits=%s",netid,permit_names);
    }
    cuwa_assert(msg);

    rc = cuwa_permit_send_cmd( ksess, netid, permitHostName, permitPort, permitid, msg, pool, memberships, nonmember);


    return rc;
}

int cuwa_permit_add(kutil_session_t ksess, char *localid,
                    char *permitHostName, int permitPort, char *permitid,
                    char *netid, char *permit_name, apr_pool_t *pool, char **memberships, char **nonmember)
{
    int rc;
    char *msg;

    // build message
    msg = apr_psprintf(pool,"cmd=addpermit&netid=%s&permit=%s",netid,permit_name);
    
    rc = cuwa_permit_send_cmd(ksess, netid, permitHostName, permitPort, permitid, msg, pool, memberships, nonmember);
    
    return rc;
}

int cuwa_permit_delete(kutil_session_t ksess, char *localid,
                    char *permitHostName, int permitPort, char *permitid,
                    char *netid, char *permit_name, apr_pool_t *pool, char **membership, char **nonmember)
{
    int rc;
    char *msg;

    // build message
    msg = apr_psprintf(pool,"cmd=deletepermit&netid=%s&permit=%s",netid,permit_name);
    
    rc = cuwa_permit_send_cmd(ksess, netid, permitHostName, permitPort, permitid, msg, pool, membership, nonmember);
    
    return rc;
}

int cuwa_permit_check_IPSN(kutil_session_t ksess, char *localid,
                    char *permitHostName, int permitPort, char *permitid,
                    char *netid, char *delegate, apr_pool_t *pool, char **membership, char **nonmember)
{
    int rc;
    char *msg;

    // build message
    msg = apr_psprintf(pool,"cmd=checkIPSN&netid=%s&delegate=%s",netid,delegate);
    cuwa_trace("IPSN msg=%s",msg); 
    rc = cuwa_permit_send_cmd(ksess, netid, permitHostName, permitPort, permitid, msg, pool, membership, nonmember);
    
     return rc;
 }
    
/**  
 * cuwa_permit_send_cmd build the message content (permit lookup requests).
 * @param[in] ksess - kutil session with permit bridge
 * @param[in] netid - netid that is being looked up
 * @param[in] permitHostName - hostname of permit server to connect to
 * @param[in] permitPort - permit server port
 * @param[in] permitid - serviceid of the permit service.
 * @param[in] msg - message to send to permit bridge.
 * @param[in] pool - memory pool to use for allocations.
 * @param[out] memberships - space separated list of memberships returned (allocated from kutil unwrap).
 * @param[out] nonmember - space separated list of non-memberships returned (allocated from pool).
 */
int cuwa_permit_send_cmd(kutil_session_t ksess, char *netid,
                         char *permitHostName, int permitPort, char *permitid, char *msg, 
                         apr_pool_t *pool,char **memberships, char **nonmember)
{
    int rc=0, code=0;
    char *resp = NULL, *clear = NULL, *str;
    apr_socket_t *sock = NULL;
    char *k2 = NULL, *wa = NULL, *respbin;
    int k2Len, waLen, clearLen, len;
    kutil_sec_ctx_t ctx = NULL;
    uint64 sessionID = 0LL;   // FIXME: ** set and check this
 
    cuwa_assert(msg);
    
    // To support old configurations that specify 756 instead of 80
    if (permitPort==756) permitPort = 80;
    
    code = cuwa_permit_connect(permitHostName, permitPort, CONNECT_TIMEOUT, &sock ,pool);
    FAIL_IF(code,code);
    
    code = cuwa_krb_make_k2( &ctx, permitHostName, permitid, &sessionID, 0, &k2, &k2Len,
                            "t1", msg, strlen(msg), NULL );
    FAIL_IF(code,code);
    
    code = cuwa_base64_make_wa(&wa, &waLen, k2Len, 1, k2, k2Len);
    FAIL_IF(code,code);
    
    wa = apr_pstrcat(pool,"WA=",wa,NULL);
   cuwa_trace("about to send"); 
    code = cuwa_permit_send(sock,pool,wa, &resp);
    FAIL_IF(code,code);
    
    cuwa_trace("Response: %s",resp);
    
    if (strncmp(resp,WRAP_LABEL,strlen(WRAP_LABEL)))
    {
        cuwa_warning("Response label '%s' not present",WRAP_LABEL);
        FAIL_IF(1,CUWA_ERR_PERMIT_PROTO);
    }
    
    resp += strlen(WRAP_LABEL);
    
    len = cuwa_base64_decode_bytes( resp );
    
    respbin = apr_palloc(pool,len);
    cuwa_assert(respbin);
    
    len = cuwa_base64_decode(resp, respbin);
    
    code = kutil_unwrap(ctx, respbin, len, &clear, &clearLen);
    FAIL_IF(code,code);
    
    if (clear[clearLen-1]!=0)
    {
        // Make sure string is NULL terminated
        str = apr_pcalloc(pool,clearLen+1);
        cuwa_assert(str);
        
        memcpy(str,clear,clearLen);
        clear = str;
    }
    
    // IMPORTANT: cuwa_permit_decode will write to the clear buffer.  Don't use clear buffer after this call!
    code = cuwa_permit_decode(pool, netid, clear, clearLen, memberships,nonmember);
    FAIL_IF(code,code);

cleanup:
    
    if (ctx) kutil_end_sec_context(ctx);
    if (sock) apr_socket_close( sock );
    
    return rc;
}




/**
 * cuwa_permit_connect connect to the permit server.
 * @param[in] permitHostName Host name / IP address of permit server.
 * @param[in] permitPort Port to connect to permit server.
 * @param[in] timeout number of seconds before connection attemp is aborted.
 * @param[out] new_sock the socket returned.
 * @param[in] pool.
 */
int cuwa_permit_connect(char *permitHostName, int permitPort, int timeout, apr_socket_t **new_sock, apr_pool_t *pool )
{
    cuwa_err_t rc = CUWA_OK;
    apr_status_t rv;
    apr_socket_t *sock;
    apr_sockaddr_t *permitServer;

    cuwa_assert(permitHostName);
    cuwa_assert(timeout);

    rv = apr_socket_create_ex( &sock,  APR_INET, SOCK_STREAM, APR_PROTO_TCP,  pool );
    FAIL_IF_APR_SOCK_ERR(rv);

    rv = apr_socket_opt_set(sock, APR_SO_NONBLOCK, 1);
    FAIL_IF_APR_SOCK_ERR(rv);

    rv = apr_socket_timeout_set( sock, apr_time_from_sec(timeout));
    FAIL_IF_APR_SOCK_ERR(rv);

    rv = apr_sockaddr_info_get(&permitServer,permitHostName, APR_INET, permitPort, 0, pool);
    FAIL_IF_APR_SOCK_ERR(rv);

    rv = apr_socket_connect(sock, permitServer);
    FAIL_IF_APR_SOCK_ERR(rv);

    *new_sock = sock;

cleanup:

    if (!rc)
    {
        *new_sock = sock;
    }

    return rc;
}

/**
 * cuwa_permit_write write bytes on a connection.
 * @param[in] sock the socket.
 * @param[in] buffer pointer to bytes to write.
 * @param[in/out] length number of bytes to write / number of bytes written.
 * @param[in] timeout number of seconds before abort.
 */
int cuwa_permit_write( apr_socket_t *sock, char *buffer, apr_size_t *length, int timeout)
{
    cuwa_err_t rc = CUWA_OK;
    apr_status_t rv;

    cuwa_assert(sock);
    cuwa_assert(buffer);
    cuwa_assert(length);
    cuwa_assert(timeout);
    cuwa_assert(*length);

    /* Write the bytes */
    apr_socket_timeout_set( sock, apr_time_from_sec(timeout) );

    rv = apr_socket_send( sock, buffer, length );
cuwa_trace("apr_socket_send: %d",rv);
    FAIL_IF_APR_SOCK_ERR(rv);

cleanup:

    return rc;
}

/**
 * cuwa_permit_read read bytes on a connection. Bytes actually read may not match bytes requested.
 * @param[in] sock the socket.
 * @param[in] buffer pointer to copy read bytes to.
 * @param[in/out] length number of bytes to read / number of bytes read.
 * @param[in] timeout number of seconds before abort.
 */
int cuwa_permit_read( apr_socket_t *sock, char *buffer, apr_size_t *length, int timeout )
{
    cuwa_err_t rc = CUWA_OK;
    apr_status_t rv;

    cuwa_assert(sock);
    cuwa_assert(buffer);
    cuwa_assert(length);
    cuwa_assert(timeout);
    cuwa_assert(*length);

    apr_socket_opt_set(sock, APR_SO_NONBLOCK, 0);

    /* read the bytes */
    apr_socket_timeout_set( sock, apr_time_from_sec( timeout ) );
    rv = apr_socket_recv( sock, buffer, length);
    FAIL_IF_APR_SOCK_ERR( rv );

cleanup:

    if (rc || rv) cuwa_trace("cuwa_permit_read error: %d - %d",rc,rv);

    return rc;
}


/**
 * cuwa_permit_read_bytes read bytes from connection. Bytes always match bytes requested if not error.
 * @param[in] sock the socket.
 * @param[in] inBuf pointer to chache buffer.
 * @param[in] out pointer to copy read bytes to.
 * @param[in] length number of bytes to read.
 * @param[in] timeout number of seconds before abort.
 */
int cuwa_permit_read_bytes(apr_socket_t *sock, command_buf_t *inBuf, char *out, int length, int timeout)
{
    cuwa_err_t rc = CUWA_OK;
    int code;
    apr_size_t rdlen;
    int left;

    cuwa_assert(inBuf);
    cuwa_assert(out);
    cuwa_assert(timeout);
    cuwa_assert(length);

cuwa_trace("cuwa_permit_read_bytes: %d",length);

    left = inBuf->length;

    while (length > left)
    {
        if (left)
        {
            memcpy(out,inBuf->rp,left);
            length -= left;
            out += left;
        }

        rdlen = inBuf->alloc;
        code = cuwa_permit_read( sock, inBuf->data, &rdlen, timeout );
cuwa_trace("cuwa_permit_read: %d, code=%d",rdlen,code);
        FAIL_IF(code,code);

        inBuf->length = rdlen;
        inBuf->rp = inBuf->data;
        left = rdlen;
    }

    memcpy(out,inBuf->rp,length);
    inBuf->rp += length;

cleanup:

    return rc;
}


/**
 * cuwa_permit_read_bytes read bytes from connection. Bytes always match bytes requested if not error.
 * @param[in] sock the socket.
 * @param[in] inBuf pointer to chache buffer.
 * @param[in] out pointer to copy read bytes to.
 * @param[in] length number of bytes to read.
 * @param[in] timeout number of seconds before abort.
 */
int cuwa_permit_read_line(apr_socket_t *sock, command_buf_t *inBuf, char *line, int maxsize)
{
    int rc;
    int len = 0;

    maxsize--; // leave room for string termination

    while ((rc = cuwa_permit_read_char(sock, inBuf, line))==CUWA_OK && *line != '\n' && maxsize)
    {
        line++;
        maxsize--;
        len++;
    }

    if (rc) return rc;

    if (len<1 || !maxsize)
    {
        cuwa_warning("pcuwa_permit_read_line: Malformed line len=%d max=%d",len,maxsize);
        return CUWA_ERR_PERMIT_PROTO;
    }

    if (*line=='\n') *line-- = 0;
    if (*line=='\r') *line = 0;
    return CUWA_OK;
}

/**
 * cuwa_permit_read_bytes read bytes from connection. Bytes always match bytes requested if not error.
 * @param[in] sock the socket.
 * @param[in] inBuf pointer to chache buffer.
 * @param[in] out pointer to copy read bytes to.
 * @param[in] length number of bytes to read.
 * @param[in] timeout number of seconds before abort.
 */
int cuwa_permit_read_char(apr_socket_t *sock, command_buf_t *inBuf, char *ch)
{
    int rc;

    if (!inBuf->length)
    {
        rc = cuwa_permit_read_more(sock, inBuf);
        if (rc) return rc;
    }

    *ch = *inBuf->rp++;
    inBuf->length--;

    return CUWA_OK;
}

/**
 * cuwa_permit_read_bytes read bytes from connection. Bytes always match bytes requested if not error.
 * @param[in] sock the socket.
 * @param[in] inBuf pointer to chache buffer.
 * @param[in] out pointer to copy read bytes to.
 * @param[in] length number of bytes to read.
 * @param[in] timeout number of seconds before abort.
 */
int cuwa_permit_read_more(apr_socket_t *sock, command_buf_t *inBuf)
{
    int rc;
    apr_size_t rdlen;

    rdlen = BLOCKSIZE;
    rc = cuwa_permit_read( sock, inBuf->data, &rdlen, READ_TIMEOUT );
    if (rc) return rc;

    inBuf->length = rdlen;
    inBuf->rp = inBuf->data;

    return rc;
}


void cuwa_permit_init_buf(apr_pool_t *pool, command_buf_t *inBuf)
{
    cuwa_assert(inBuf);
    cuwa_assert(pool);

    inBuf->data = apr_pcalloc(pool,BLOCKSIZE);
    cuwa_assert(inBuf->data);
    inBuf->alloc = BLOCKSIZE;
    inBuf->length = 0;
    inBuf->rp = inBuf->data;
}

/**
 * cuwa_permit_add_to_buf copies permit string into buffer which contains a list of space separated permits. This
 * function copies with the assumption that destination and source may overlap because the permit name is being
 * pulled from some point further into the buffer.
 * @param[in/out] bufPtr - pointer to the current write position in the buffer.
 * @param[in/out] bufLen - number of bytes currently written to the buffer.
 * @param[in] bufMax - physical size of the buffer (can't write past this point).
 * @param[in] permit - NULL terminated string containing the permit name to write.
 */
int cuwa_permit_add_to_buf( char **bufPtr, int *bufLen, int bufMax, char *permit )
{
    cuwa_err_t rc = CUWA_OK;
    char *out = *bufPtr;
    int i, outLen = *bufLen;
    int permitLen = 0;

    if (!permit) return rc;

    permitLen = strlen(permit); 
    if ( outLen + permitLen < bufMax )                                                       
    {                                                                                                       
        if ( outLen > 0 )                                                                                
        {                                                                                                   
            *out++ = ' ';
            outLen++;                                                                                    
        } 
        
        for (i=0;i<permitLen;i++) *out++ = *permit++;
        *out = 0; // NULL terminate
        
        outLen += permitLen;
        
        *bufPtr = out;
        *bufLen = outLen;
   }                                                                                                       
   else                                                                                                    
   {                                                                                                       
       cuwa_warning("Do not have enough buffer");                                                          
       rc = CUWA_ERR_MEM;                                                                      
   }                   

   return rc;
}


/** 
 * cuwa_permit_decode build the message content (permit lookup requests).
 * @param[in] pool - small allocations are made from this pool.
 * @param[in] innetid - the netid that was requested in the permit looked request sent to the bridge - Check that response corresponds the this request.
 * @param[in/out] resp - HACK ALERT - at call, resp contains cleartext response from permit bridge.  On return,
 *                this buffer is reused to store memberships for returned memberships array.  This avoids
 *                having to do multiple large allocations for big lists of permits.
 * @param[in] len - length of the cleartext respose from bridge.  This function will not write into resp buffer
 *                beyond this length.
 * @param[out] memberships - space separated list of memberships.  Memory is not allocated (resp buffer is used)!
 * @param[out] nonmember - list of permits that user is not a member of when specific list of permit lookups was requested.  This is allocated off the pool.
 */
int cuwa_permit_decode(apr_pool_t *pool, char *innetid, char *resp, int len, char **memberships, char **nonmember)
{
    cuwa_err_t rc = CUWA_OK, rc1=CUWA_OK;
    char *str, *permit, *netid;
    int permitAllow;
    char *word,*wdstate,*key;
    char *permitBuf = NULL, *permitPtr = NULL;
    int permitLen = 0;
 
    *memberships = NULL;
    *nonmember = NULL;
	
   cuwa_trace("permit decode");

   permitBuf = resp;
   permitPtr = permitBuf;

    while ((word = cuwa_nextword(&resp, ' '))!=NULL)
    {
        key = apr_strtok(word,":",&wdstate);
        if (!key) continue;
        if (apr_strnatcasecmp(key,"permit")) continue;

        netid = apr_strtok(NULL,",",&wdstate);
        if (!netid) continue;
        permit = apr_strtok(NULL,",",&wdstate);
        if (!permit) continue;
        str = apr_strtok(NULL,",",&wdstate);
        if (!str) continue;

        permitAllow = atoi(str);

        if (!strcmp(netid,innetid))
        {
            switch (permitAllow)
            {
            case 0:
                cuwa_trace("permit member, netid=%s permit=%s allow=%s",netid, permit, str);
                rc1 = cuwa_permit_add_to_buf( &permitPtr, &permitLen, len, permit );
                if (rc1 ) rc = rc1;
                FAIL_IF( rc1, rc1 );
                break;

            case 1:
                 cuwa_crit("permit lookup error -- read access to permit denied. Check that this ServiceID has read access to this permit, netid=%s permit=%s allow=%s",netid, permit, str);
                rc = CUWA_ERR_PERMIT_DECODE;
                break;

            case 2:
                cuwa_crit("permit lookup error -- permit %s not exist, netid=%s allow=%s",permit,netid, str);
                rc= CUWA_ERR_LDAP_NOT_EXIST;
                break;

            case 3:
                cuwa_trace("permit non-member, netid=%s permit=%s allow=%s",netid, permit, str);
                if (!*nonmember) *nonmember = apr_pstrdup(pool,permit);
                else *nonmember = apr_pstrcat(pool,*nonmember," ",permit,NULL);
                break;

            default:
                // Elevate this error, probably a misconfiguration
                cuwa_crit("permit lookup error, netid=%s permit=%s allow=%s",netid, permit, str);
                rc= CUWA_ERR_PERMIT_DECODE;
                break;
            }
        }
        else if (!strcmp(innetid,"all") )
        {
            //cuwa_trace("permit member, netid=%s permit=%s allow=%s",netid, permit,str);                                    
            switch (permitAllow)
            {
                 case 0:
                    rc = cuwa_permit_add_to_buf( &permitPtr, &permitLen, len, netid );
                    FAIL_IF( rc, rc );

                    break;

                case 1:
                 cuwa_crit("permit lookup error -- read access to permit denied. Check that this ServiceID has read access to this permit %s allow=%s",permit, str);
                rc = CUWA_ERR_PERMIT_DECODE;
                break;

                case 2:
                  cuwa_crit("permit lookup error -- permit %s not exist", permit);
                  rc= CUWA_ERR_LDAP_NOT_EXIST;
                  break;

                case -1:
                   cuwa_crit("permit lookup error --list netids for large list permit %s is not supported. ",permit);
                   rc= CUWA_ERR_PERMIT_DECODE;
                   break;

                default:
                    // Elevate this error, probably a misconfiguration                                       
                    cuwa_crit("list permit error, permit=%s allow=%s",permit, str);        
                    rc= CUWA_ERR_PERMIT_DECODE;
                    break;  
            }
        }
        else
        {
            // This may indicate an attempt at replaying a previous message (for a different netid)
            cuwa_warning("permit lookup netid mismatch, netid=%s expected=%s permit=%s allow=%s",netid, innetid, permit, str);
        }
    }

cleanup:
    cuwa_trace("cuwa_permit_decode_resps done: rc: %d",rc);

    if ( permitLen>0 )
    {
        permitBuf[permitLen] = 0;

        *memberships = permitBuf;
             
       cuwa_trace("memberships:%s", DENULL(*memberships));
       cuwa_trace("none-memberships:%s",DENULL(*nonmember)); 
    }

    return rc;
}

int cuwa_permit_send(apr_socket_t *sock, apr_pool_t *pool, char *wa, char **resp)
{
    char *msg;
    command_buf_t inBuf;
    char *line = apr_palloc(pool,MAXLINE);
    char *ln, *word;
    int length = 0;
    int status = 500, rc = CUWA_OK, errorCode = 0;
    apr_size_t outlen;

    msg = apr_psprintf(pool, "POST /permit HTTP/1.0\r\n"
                             "User-Agent: %s\r\n"
                             "Content-Type: text/plain\r\n"
                             "Content-Length: %d\r\n\r\n%s", cuwa_version_get_full(), (int) strlen(wa), wa);
    outlen = strlen(msg);

    rc = cuwa_permit_write( sock, msg, &outlen, WRITE_TIMEOUT);
    if (rc)
    {
        cuwa_warning("cuwa_permit_write error: %d",rc);
        return rc;
    }

    cuwa_permit_init_buf(pool, &inBuf);

    while(!rc)
    {
        rc = cuwa_permit_read_line(sock, &inBuf, line, MAXLINE);
        if (rc)
        {
            cuwa_warning("cuwa_permit_write read_line: %d",rc);
            return rc;
        }
        cuwa_trace("LINE: %s",line);

        if (!strlen(line)) break; // last line of header

        ln = line;
        word = cuwa_nextword (&ln, ' ');
        
        if (!word || strlen(word)==0) continue;

        if (!strncasecmp(word,"http/",5))
        {
            word = cuwa_nextword (&ln, ' ');
            if (strlen(word)!=3)
            {
                cuwa_warning("cuwa_permit_write bad status word: %s",word);
                return CUWA_ERR_PERMIT_PROTO;
            }
            if (*word!='1') status = atoi(word);
        }
        else if (!apr_strnatcasecmp(word,"Content-Length:"))
        {
            word = cuwa_nextword (&ln, ' ');
            if (!word || !strlen(word))
            {
                cuwa_warning("cuwa_permit_write bad Content-Length: %s",word);
                return CUWA_ERR_PERMIT_PROTO;
            }
            length = atoi(word);
        }
        else if (!strcasecmp(word,"ErrorMsg:") )
        {
            line += strlen("ErrorMsg: "); 
            cuwa_warning("%s", line);
        }
        else if (!strcasecmp(word,"ErrorCode:") )
        {
            word = cuwa_nextword (&ln, ' ');                                                            
            if (!word || !strlen(word))                                                                 
            {                                                                                           
                cuwa_warning("cuwa_permit_write bad error code returned by bridge");                          
                return CUWA_ERR_PERMIT_PROTO;                                                           
            }                                                                                           
            errorCode = atoi(word);                                                                        
        }                         
    }

    if (status != 200)
    {
        cuwa_warning("cuwa_permit_write status code: %d",status);
        return errorCode? errorCode: CUWA_ERR_PERMIT_PROTO;
    }

    if (rc)
    {
        cuwa_warning("cuwa_permit_write rc: %d",rc);
        return CUWA_ERR_PERMIT_PROTO;
    }

    if (!length)
    {
        cuwa_warning("cuwa_permit_write response has no content");
        return CUWA_ERR_PERMIT_PROTO;
    }

    *resp = apr_pcalloc(pool,length+1);
    cuwa_assert(*resp);
    return cuwa_permit_read_bytes(sock, &inBuf, *resp, length, READ_TIMEOUT);
}


const char id_permit_permit_c[] = "$Id$";
