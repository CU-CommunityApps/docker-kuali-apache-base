#!/bin/sh

KRB5_CONFIG=../tests/t/conf/krb5.conf
export KRB5_CONFIG

./getpermit  -i cuwa-test/serviceid@DEV.CORNELL.EDU -k ../tests/t/conf/keytab -s permitd/dev1@DEV.CORNELL.EDU -h permitdev.cit.cornell.edu -p 8175 -n cuwa-test goodone "cuwa-test.public-yes" "cuwa-test.public-no"

./getpermit   -i cuwa-test/serviceid@DEV.CORNELL.EDU -k ../tests/t/conf/keytab -s permitd/dev1@DEV.CORNELL.EDU -h permitdev.cit.cornell.edu -p 8175 -n cuwa-test all
