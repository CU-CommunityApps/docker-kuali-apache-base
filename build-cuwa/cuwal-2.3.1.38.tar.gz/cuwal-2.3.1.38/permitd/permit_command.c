#include <stdlib.h>
#include <cuwa_malloc.h>
#include <permit_command.h>
#include <permitdb.h>
#include <log.h>
#include <apr_strings.h>

#define CUWA2_LOG_DOMAIN cuwa.apache

#define BUFLEN		1024	/* must be >= permitdb.h INFOLEN */

int permit_is_slave = 1;  // assume we are the slave for now

#define PERMIT_RETURN_BUF_LEN   4194304  //4 meg
char permit_return_buf[PERMIT_RETURN_BUF_LEN+1];
 
static int AllowSender (apr_pool_t *pool, char *netid, PdInfo *pdInfo, int requested);
static char *normalize_id (apr_pool_t *pool, char *netid);
static int getpermit (request_rec *r, char *netid, char *fullid, apr_table_t *args_in, char **args_out);
static int addpermit(request_rec *r, char *netid, char *fullid, apr_table_t *args_in, char **args_out);
static int deletepermit(request_rec *r, char *netid, char *fullid, apr_table_t *args_in, char **args_out);
static int listpermits (request_rec *r, char *netid, char *fullid, apr_table_t *args_in, char **args_out);
static int listnetids (request_rec *r, char *netid, char *fullid, apr_table_t *args_in, char **args_out);
static char *nextword (char **str, char sep);
static int allowModify( char *netid, request_rec *r );
static int addToReturnBuf( char **returnStr, int *len, char *id, char *permit,int rc );

int permit_command(request_rec *r, char *netid, char *fullid, apr_table_t *args_in, char **args_out)
{
    const char *cmd = apr_table_get( args_in,"cmd");

    if (!cmd) return permit_error_response(r,500,0,"Request must contain 'cmd=xxxx' argument.");

    if (!strcmp(cmd,"getpermit")) return getpermit(r,netid,fullid,args_in,args_out);
    if (!strcmp(cmd,"listpermits")) return listpermits(r,netid,fullid,args_in,args_out);
    if (!strcmp(cmd,"listnetids")) return listnetids(r,netid,fullid,args_in,args_out);
    if (!strcmp(cmd,"addpermit")) return addpermit(r,netid,fullid,args_in,args_out);
    if (!strcmp(cmd,"deletepermit")) return deletepermit(r,netid,fullid,args_in,args_out);

    return permit_error_response(r,500,0,"Unsupported command... %s",cmd);
}

int getpermit(request_rec *r, char *netid, char *fullid, apr_table_t *args_in, char **args_out)
{
    char buf1[BUFLEN] = "";
    char buf2[BUFLEN] = "";
    char *permit;
    char *permits = (char*) apr_table_get( args_in,"permits");
    char *lookupid = (char*) apr_table_get( args_in,"netid");
    char *dbid;
    PdInfo *pdInfo;
    int rc, dataLen = 0;
    char *returnStr = permit_return_buf;

    if (!netid) netid = "anonymous";

    if (!lookupid) return permit_error_response(r,500,0,"Missing netid argument");

    memset(permit_return_buf,0,PERMIT_RETURN_BUF_LEN);

    dbid = normalize_id(r->pool,lookupid);
 
    while (NULL != (permit = nextword(&permits,' ')))
    {
        pdInfo = NULL;

        cuwa_portal_log(r,r->pool,"getpermit: %s",permit);
        rc = DbGetPdInfo(permit, &pdInfo);
        cuwa_portal_log(r,r->pool,"DbGetPdInfo: %d",rc);
        if (!rc && strcmp(netid,lookupid) && strcmp(fullid,lookupid)) rc = AllowSender(r->pool,netid, pdInfo, allowLookup);
        cuwa_portal_log(r,r->pool,"AllowSender: %d",rc);
        if (!rc) rc = DbGetPermit(dbid, pdInfo, buf1, buf2, NULL, NULL, NULL, NULL );
        cuwa_portal_log(r,r->pool,"DbGetPermit: %d",rc);

        rc = addToReturnBuf( &returnStr, &dataLen, lookupid, permit, rc ); 
        if (rc)   return permit_error_response( r, 500, 0, "Not enough memory for returning result");

        cuwa_portal_log(r,r->pool,"getpermit %s %s %s: %d\n", netid, lookupid, permit, rc);

        cuwa_info("LOG getpermit %s %s %s: %d",netid,lookupid,permit,rc);
    }
    rc = addToReturnBuf( &returnStr, &dataLen, NULL, NULL, 0);
    if (rc)   return permit_error_response( r, 500, 0, "Not enough memory for returning result");

    *args_out = permit_return_buf;

    return OK;
}

int addpermit(request_rec *r, char *netid, char *fullid, apr_table_t *args_in, char **args_out)
{
    char *permits = (char*) apr_table_get( args_in,"permit");
    char *permit = NULL;
    char *lookupid = (char*) apr_table_get( args_in,"netid");
    PdInfo *pdInfo;
    int rc;
    char *returnStr = permit_return_buf;
    int dataLen = 0;
 
    if (!netid) return permit_error_response(r,500,0,"Missing netid, must be authenticated to add permit");    
    if (!lookupid) return permit_error_response(r,500,0,"Missing netid argument");
    
    cuwa_portal_log(r,r->pool,"addpermit: %s for %s by %s",permits,lookupid,netid);
    
    rc = allowModify( netid,r );
    cuwa_portal_log(r, r->pool, "allowModify return %d", rc);

    if ( rc ) return permit_error_response(r, 500,0, "%s is not allowed to update permit",netid);

    memset(permit_return_buf,0,PERMIT_RETURN_BUF_LEN);

    while (NULL != (permit=nextword(&permits,' ')))
    {
        rc = DbGetPdInfo(permit, &pdInfo);
        cuwa_portal_log(r,r->pool,"DbGetPdInfo: %d",rc);    
    
        if (!rc) rc = AllowSender(r->pool,netid, pdInfo, allowUpdate);
        cuwa_portal_log(r,r->pool,"AllowSender: %d",rc);
        if (!rc) rc = DbAddPermit( lookupid, pdInfo, 1 );
        cuwa_portal_log(r,r->pool,"DbAddPermit: %d",rc);

        rc = addToReturnBuf( &returnStr, &dataLen, lookupid, permit, rc );
        if (rc)   return permit_error_response( r, 500, 0, "Not enough memory for returning result");

        cuwa_portal_log(r,r->pool,"addpermit %s %s %s: %d\n", netid, lookupid, permit, rc);
   }
   rc = addToReturnBuf( &returnStr, &dataLen, NULL, NULL, 0 );
   if (rc)   return permit_error_response( r, 500, 0, "Not enough memory for returning result");
   *args_out = permit_return_buf;

   return OK;
}

int deletepermit(request_rec *r, char *netid, char *fullid, apr_table_t *args_in, char **args_out)
{
    char *permits = (char*) apr_table_get( args_in,"permit");
    char *permit;
    char *lookupid = (char*) apr_table_get( args_in,"netid");
    PdInfo *pdInfo;
    int rc;
    int dataLen = 0;
    char *returnStr = permit_return_buf;

    if (!netid) return permit_error_response(r,500,0,"Missing netid, must be authenticated to add permit");
    if (!lookupid) return permit_error_response(r,500,0,"Missing netid argument");

    cuwa_portal_log(r,r->pool,"deletepermit: %s for %s by %s",permits,lookupid,netid);

    rc = allowModify( netid,r );
    cuwa_portal_log(r, r->pool, "allowModify return %d", rc);

    if ( rc ) return permit_error_response(r, 500,0, "%s is not allowed to update permit",netid);

    memset(permit_return_buf,0,PERMIT_RETURN_BUF_LEN);

    while (NULL != (permit=nextword(&permits,' ')))
    {
        pdInfo = NULL;
        rc = DbGetPdInfo(permit, &pdInfo);
        cuwa_portal_log(r,r->pool,"DbGetPdInfo for permit %s: %d",permit,rc);

        if (!rc) rc = AllowSender(r->pool,netid, pdInfo, allowUpdate);
        cuwa_portal_log(r,r->pool,"AllowSender: %d",rc);
        if (!rc) rc = DbDeletePermit( lookupid, pdInfo );
        cuwa_portal_log(r,r->pool,"DbDeletePermit %s return: %d",permit,rc);

        //if delete successfully, return status 3 means that netid doesn't have such permit anymore
        rc = addToReturnBuf( &returnStr, &dataLen, lookupid, permit, rc?rc:3 );
        if (rc)   return permit_error_response( r, 500, 0, "Not enough memory for returning result");

        cuwa_portal_log(r,r->pool,"deletepermit %s %s %s: %d\n", netid, lookupid, permit, rc);
    }
    rc = addToReturnBuf( &returnStr, &dataLen, NULL, NULL, 0 );
    if (rc)   return permit_error_response( r, 500, 0, "Not enough memory for returning result");
    *args_out = permit_return_buf;
    return OK;
}

int listpermits(request_rec *r, char *netid, char *fullid, apr_table_t *args_in, char **args_out)
{
    char *permit,*permits;
    char *lookupid = (char*) apr_table_get( args_in,"netid");
    int rc;
    char *dbid;
    char *returnStr = permit_return_buf;
    int dataLen =0;

    if (!netid) netid = "anonymous";

    if (!lookupid) return permit_error_response(r,500,0,"Missing netid argument");

    dbid = normalize_id(r->pool,lookupid);

    permits = apr_pcalloc(r->pool,32768); // FIXME: current permitdb expects this large buffer value with no protection against overflow

    rc = DbListPermits(netid, dbid, NULL, 'I', permits);
    if (rc)
    {
        cuwa_portal_log(r,r->pool,"DbListPermits failure: %d\n",rc);
        return permit_error_response(r,500,0,"Permit lookup failed",rc);
    }

    memset(permit_return_buf,0,PERMIT_RETURN_BUF_LEN);

    while (NULL != (permit = nextword(&permits,0x0d)))
    {
         rc = addToReturnBuf(&returnStr, &dataLen, lookupid,permit,rc);
         if (rc)   return permit_error_response( r, 500, 0, "Not enough memory for returning result");
    }
    rc = addToReturnBuf( &returnStr, &dataLen, NULL, NULL, 0);
    if (rc)   return permit_error_response( r, 500, 0, "Not enough memory for returning result");
    *args_out = permit_return_buf;

    return OK;
}

int listnetids(request_rec *r, char *netid, char *fullid, apr_table_t *args_in, char **args_out)
{
    char *permits = (char *)apr_table_get(args_in,"permits");
    PdInfo *pdInfo = NULL;
    char *permit, *id;
    int rc;
    char *netids;
    char *returnStr = permit_return_buf;
    int dataLen = 0;
    if (!permits) return permit_error_response(r,500,0,"Missing permits argument");

    memset(permit_return_buf,0,PERMIT_RETURN_BUF_LEN);

    if (NULL != (permit = nextword(&permits,' ')))
    {
        cuwa_portal_log(r, r->pool, "listnetids in permit %s",permit);

        pdInfo = NULL;
        rc = DbGetPdInfo(permit, &pdInfo);
        if ( rc )
        {
            cuwa_portal_log(r,r->pool,"DbGetPdInfo: %d",rc);
            rc = addToReturnBuf(&returnStr, &dataLen, "unknown",permit,rc);
            rc = addToReturnBuf( &returnStr, &dataLen, NULL,NULL,0);  //add /r/n to the end 
            *args_out = permit_return_buf;
            return OK;
        }

        cuwa_portal_log(r,r->pool,"check if %s is in acl",netid);
        rc = AllowSender(r->pool, netid, pdInfo, allowLookup);
        cuwa_portal_log(r,r->pool,"AllowSender: %d",rc);
        if ( rc )
        {
            rc = addToReturnBuf(&returnStr, &dataLen, "unknown",permit,rc);
            rc = addToReturnBuf( &returnStr, &dataLen, NULL,NULL,0);
            *args_out = permit_return_buf;
            return OK;
        }

        if ( pdInfo->largeList )
        {
            cuwa_portal_log(r,r->pool,"List large permit is not supported");
            rc = addToReturnBuf(&returnStr, &dataLen, "unknown",permit,-1);
            rc = addToReturnBuf( &returnStr, &dataLen, NULL,NULL,0);
            *args_out = permit_return_buf;

            return OK;
        }
 
        rc = DbGetPermitList( permit, 'P', pdInfo, &netids, NULL );
        if (rc)
        {
            cuwa_portal_log(r,r->pool,"DbGetPermitList failure: %d\n",rc);
            rc = addToReturnBuf(&returnStr, &dataLen, "unknown",permit,rc);
            rc = addToReturnBuf( &returnStr, &dataLen, NULL,NULL,0);  
            *args_out = permit_return_buf;

            return OK;
        }

        cuwa_trace("listnetids:len=%d",strlen(netids));

        while (NULL != (id = nextword(&netids,0x0d)))
        {
           rc = addToReturnBuf( &returnStr, &dataLen,id,permit,0);
           if (rc)   return permit_error_response( r, 500, 0, "Not enough memory for returning result");
        }
        rc = addToReturnBuf( &returnStr, &dataLen, NULL,NULL,0);
        if (rc)   return permit_error_response( r, 500, 0, "Not enough memory for returning result");
    }
    *args_out = permit_return_buf;
    return OK;
}


int AllowSender (apr_pool_t *pool, char *netid, PdInfo *pdInfo, int requested)
{
    int allowed;
    int tryk4 = 0;
    char *found = NULL, *slash;

    cuwa_assert(netid);

    // Dump ACL info...
    cuwa_trace("ACL lookup, netid=%s permit=%s...",netid,pdInfo->pName);
    cuwa_trace("owner: %s",pdInfo->owner);
    cuwa_trace("admin: %s",pdInfo->pdAdminACL);
    cuwa_trace("update: %s",pdInfo->idUpdateACL);
    cuwa_trace("lookup: %s",pdInfo->idLookupACL);
    cuwa_trace("public: %s",pdInfo->public?"Y":"N");

    allowed = SenderAccess(netid, pdInfo);
    cuwa_trace("Allowed access: %d",allowed);

    // Compensate for K4 and K5 principal naming conventions (/ or .)
    if (strchr(netid, '/'))
    {
        if (allowed == allowNothing) tryk4 = 1;
        if (allowed == allowLookup)
        {
            // if not in Lookup ACL is and permit is public. the only reason they got allowLookup
            // on the first pass was because the permit was public.  If so, try lookup with K4 name.
            found = strstr(pdInfo->idLookupACL, netid);
            if (!found && pdInfo->public) tryk4 = 1;
        }
    }

    if (tryk4)
    {
        netid = apr_pstrdup(pool,netid);
        slash = strchr(netid, '/');
        *slash = '.';
        allowed = SenderAccess(netid, pdInfo);
        cuwa_trace("Access level (%s): %d",netid,allowed);
    }

    /* only allowLookup level functions on a slave server */
    /* exception: permitMaster can make temporary changes */
    if (requested > allowLookup && allowed < allowMaster && permit_is_slave) 
    {
        cuwa_trace("Access Denied: Only master can write to slave");
        return 1;
    }
    if (requested < allowMaster && allowed < allowMaster && !pdInfo) 
    {
        cuwa_trace("Access Denied: allowed=%d, requested=%d pdInfo==NULL",allowed,requested);
        return 1;
    }
    if (allowed < requested) 
    {
        cuwa_trace("Access Denied: allowed=%d, requested=%d",allowed,requested);
        return 1;
    }
    
    cuwa_trace("Access granted");

    return(0);
}

char * nextword (char **str, char sep)
{
    char *cur=*str,*next;
    if (!*str) return NULL;
    next = strchr(*str,sep);
    if (!next) *str = NULL;
    else
    {
        *next++ = 0;
        *str = next;
    }
    return cur;
}

int addToReturnBuf( char **returnStr, int *dataInBuf, char *netid, char *permit,int rc )
{
    char temp[BUFLEN];
    char *p;
    int dataNow = 0;
 
    if ( !netid )
        strcpy(temp, "\r\n");
    else
        sprintf(temp, "permit:%s,%s,%d ", netid, permit, rc);

    p = *returnStr;

    dataNow = *dataInBuf + strlen(temp); 
    if ( dataNow > PERMIT_RETURN_BUF_LEN )
    {
        return -1;
    }
    strcpy( p, temp );
    p += strlen(temp);

    *returnStr = p;
    *dataInBuf = dataNow;
 
    return OK;
}

int permit_command_init(char *path)
{
    char *slavestr = getenv("PERMITSLAVE");
    int rc = DbSetPath(path);
    if (rc) return rc;
    
    permit_is_slave = (slavestr && strcmp(slavestr,"1")==0)?1:0;
    cuwa_trace("permit_is_slave=%d (PERMITSLAVE=%s)",permit_is_slave,slavestr?slavestr:"NULL");
    
    return GetPermitMaster();
}

char *normalize_id (apr_pool_t *pool, char *netid)
{
    char *id, *at;

    id = apr_pstrdup(pool,netid);
    at = strchr(id,'@');
    if (!at) return netid;

    *at++ = 0;
    if (!strcmp(at,"CIT.CORNELL.EDU"))
    {
        return id;
    }
    else if (!strcmp(at,"GUEST.CORNELL.EDU"))
    {
        return apr_pstrcat(pool,"$g_",id,NULL);
    }
    else
    {
        return netid;
    }
}

/* check if requester principal is in permit-update permit */
int allowModify( char *principal, request_rec *r )
{
    char buf1[BUFLEN] = "";
    char buf2[BUFLEN] = "";
    PdInfo *pdInfo;
    int rc;
    char *dbid;

    cuwa_portal_log( r, r->pool, "check if %s is in permit-update", principal );

    dbid = normalize_id(r->pool, principal);

    pdInfo = NULL;

    rc = DbGetPdInfo("permit-update", &pdInfo);
    cuwa_portal_log(r,r->pool,"DbGetPdInfo: %d",rc);
    if (!rc) rc = DbGetPermit(dbid, pdInfo, buf1, buf2, NULL, NULL, NULL, NULL );
    cuwa_portal_log(r,r->pool,"DbGetPermit: %d",rc);

   return rc; 
}
