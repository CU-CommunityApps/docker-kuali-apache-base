/* permitdb.c -- Authorization server daemon database routines

Copyright 1996 Mandarin Consortium, Inc. All rights reserved.
*/

/********************************************************************
 * $Log$
 * Revision 1.9  2010/01/26 19:34:40  hy93
 * fix possible buffer overflow when listing netids in a pemit
 *
 * Revision 1.8  2009/06/23 15:44:24  hy93
 * fix compiler warning
 *
 * Revision 1.7  2008/09/23 17:23:16  pb10
 * Basically working.
 *
 * Revision 1.6  2008/09/23 09:05:53  pb10
 * Fixed config.  Added initialization and DB path.
 *
 * Revision 1.5  2008/09/23 03:16:45  pb10
 * Fix brain-dead CVS log tags.
 *
 * Revision 1.4  2008/09/23 03:12:32  pb10
 * Fix indenting and lineend.
 *
 * Revision 1.3  2008/09/23 03:07:53  pb10
 * Compiles.
 *
 * Revision 1.2  2008/09/23 02:37:56  pb10
 * Interrim
 *
 * Revision 1.2  2006/06/26 18:01:39  se10
 * Now does Solaris clusters!
 *
 * Revision 2.0  96/02/06  17:34:25  laurie
 * Feb 6, 1996 release
 *
*********************************************************************/

#include <permitdb.h>

//#include <netinet/in.h> // sse: needed for cussplib.h
#include <cuwa_malloc.h>
#include <sys/signal.h>
#include <unistd.h>
#include <fcntl.h>
#include <setjmp.h>
#include <string.h>
#include <stdio.h>
#include <log.h>
#include <time.h>

#define CUWA2_LOG_DOMAIN cuwa.apache

#define ENTERING(a,b) cuwa_trace("ENTERING: " a);
#define CUSSP_APP NULL


/* ----------------------------------------------------------------- */
/* define database errors */
#define dbMemErr 101
#define dbNoRecord 102

/* from cussplib.c */
#define EOREC  (unsigned char) '\x0d'  /* End-Of-Record */

enum
{
    IdDb, PdDb, CxDb
};


/* ----------------------------------------------------------------- */
PdInfoPtr m_pPdiList;
int m_iPdiList;
char m_szPermitMaster[MAXIDLEN] = "";
char m_szPermitMasterAdmin[PD_ACLLEN] = "";
char *permitdb_path = "";
jmp_buf jmp_env; /* for alarm timeout, defined in setjmp.h */


/* ----------------------------------------------------------------- */
void lockAlarmHandler (int) ;
static int OpenDatabase (int, GDBM_FILE*, int *) ;
static int CloseDatabase (GDBM_FILE, int) ;
static int allowList (char *, int, short, PdInfo *) ;
void SetIdKey2 (char *, char *, short) ;
int FetchDbRecord (GDBM_FILE, char *, char *, int *) ;
int FetchDbRecord_dynamicMem (GDBM_FILE, char *, char **, int *) ;
int CrossIndexDelete (GDBM_FILE, char *, char *, int) ;
int StoreDbRecord (GDBM_FILE, char *, char *, int) ;
int RemoveDbRecord (GDBM_FILE, char *) ;
void DbConvertList (char *, char *) ;
int GetNewPermitKey (int *) ;

/* ----------------------------------------------------------------- */
int DbSetPath(char *path)
{
    if (!path) path = "";
    permitdb_path = cuwa_malloc(strlen(path)+1);
    if (!permitdb_path) return 1;

    strcpy(permitdb_path,path);
    return 0;
}


// On success, returns pSuccess, malloc's ppPdInfo and returns PdInfo
// struct in ppPdInfo.  Caller must free ppPdInfo.
/* ----------------------------------------------------------------- */
int DbGetPdInfo (char * pszPermitName, PdInfo ** ppPdInfo)
{
    datum key, value;
    GDBM_FILE pDb;
    int iReturn;

    ENTERING("DbGetPdInfo",CUSSP_APP);

    *ppPdInfo = cuwa_malloc(sizeof(PdInfo));
    if (!*ppPdInfo)
        return(pGeneralError);


    cuwa_trace("DbGetPdInfo: %s\n",
               pszPermitName?pszPermitName:"no permitName");

    if (!pszPermitName)
        return(pNoSuchPermitName);

    /* Open the database: */
    iReturn = OpenDatabase(PdDb, &pDb, NULL);
    if (iReturn)
    {
        cuwa_free (*ppPdInfo);
        *ppPdInfo = NULL;
        return(iReturn);
    }

    key.dptr  = pszPermitName;
    key.dsize = strlen(pszPermitName);

    /* look up permit descriptor record */
    value = gdbm_fetch(pDb, key);
    CloseDatabase(pDb, 0);

    if (value.dptr)
    {
        memcpy((char *)*ppPdInfo, value.dptr, value.dsize );
        free(value.dptr);
        return(pSuccess);
    }
    else
    {
        cuwa_free (*ppPdInfo);
        *ppPdInfo = NULL;
        return(pNoSuchPermitName);
    }
}


/* ----------------------------------------------------------------- */
int LoadPdInfoList (void)
{
    GDBM_FILE db;
    datum   keyDatum, codeDatum;
    int    retCode = pSuccess;

    ENTERING("LoadPdInfoList",CUSSP_APP);
    /* Open the database: */
    db = gdbm_open(PDDBNAME, GDBM_BLOCK_SIZE, GDBM_READER, 0, NULL) ;
    if (db == NULL)
        return pDbOpenErr;

    m_pPdiList = NULL;         /* just to make sure */

    for (keyDatum = gdbm_firstkey(db); keyDatum.dptr != NULL;
        keyDatum = gdbm_nextkey(db, keyDatum))
    {
        PdInfoPtr newPdInfo, infoPtr;

        /* Allocate memory for another permit descriptor record: */
        if ( !m_pPdiList )
        {
            newPdInfo = (PdInfoPtr) cuwa_malloc( sizeof( PdInfo ) );
            m_iPdiList = 1;
        }
        else
        {
            newPdInfo = (PdInfoPtr) cuwa_malloc( sizeof( PdInfo ) * ++m_iPdiList );
            memcpy(newPdInfo,m_pPdiList,sizeof( PdInfo ));
        }
        if ( !newPdInfo )
        {       /* memory allocation problem */
            if ( m_pPdiList ) cuwa_free( m_pPdiList );
            retCode = dbMemErr;
            break;
        }
        m_pPdiList = newPdInfo;
        infoPtr = m_pPdiList + m_iPdiList - 1;

        /* Read the permit descriptor record into memory: */
        codeDatum = gdbm_fetch(db, keyDatum);   /* get next record */
        memcpy(infoPtr, codeDatum.dptr, codeDatum.dsize);
        free(codeDatum.dptr);
    }

    gdbm_close(db);         /* close the database */
    return retCode;
}


/* ----------------------------------------------------------------- */
PdInfoPtr GetPdInfoFromName (char * permitName)
{
    int     pdInfoCnt = m_iPdiList;
    PdInfoPtr chkPdInfo = m_pPdiList;

    ENTERING("GetPdInfoFromName",CUSSP_APP);
    while ( pdInfoCnt-- )
    {
        if ( strcmp( permitName, chkPdInfo->pName ) == 0 ) /* a match? */
            return chkPdInfo;       /* return a pointer to the entry */
        chkPdInfo++;         /* check the next entry */
    }
    return NULL;           /* not found */
}


/* ----------------------------------------------------------------- */
PdInfoPtr GetPdInfoFromKey (short permitKey)
{
    int     pdInfoCnt = m_iPdiList;
    PdInfoPtr chkPdInfo = m_pPdiList;

    ENTERING("GetPdInfoFromKey",CUSSP_APP);
    while ( pdInfoCnt-- )
    {
        if ( permitKey == chkPdInfo->pKey ) /* a match? */
            return chkPdInfo;       /* return a pointer to the entry */
        chkPdInfo++;         /* check the next entry */
    }
    return NULL;           /* not found */
}


// sse: Returns 0 on success, -1 on error
/* ----------------------------------------------------------------- */
int ResetLargeLists (void)
{
    int pdInfoCnt = m_iPdiList;
    PdInfoPtr chkPdInfo = m_pPdiList;
    char listName[256];
    FILE *largeList;

    ENTERING("ResetLargeLists", CUSSP_APP);
    while (pdInfoCnt--)
    {
        if (chkPdInfo->largeList)
        {
            strcpy(listName, LARGELISTS);
            strcat(listName, chkPdInfo->pName);
            cuwa_trace( "filename: %s\n", listName );

            if ((largeList = fopen(listName, "w+")) == NULL )
                return(-1);

            fclose(largeList);
        }
        chkPdInfo++;         /* check the next entry */
    }
    return(0);
}


// sse: Returns 0 on success, -1 otherwise
/* ----------------------------------------------------------------- */
int StoreLargeList (char * szNetID, char * pszPermitName)
{
    char szPathSpec[256];
    FILE * pFileLargeList;

    ENTERING("StoreLargeList", CUSSP_APP);

    if (!szNetID || !pszPermitName)
        return(-1);

    strcpy(szPathSpec, LARGELISTS);
    strcat(szPathSpec, pszPermitName);
    if ((pFileLargeList = fopen(szPathSpec, "a+")) == NULL )
        return(-1);

    fprintf(pFileLargeList, "%s\n", szNetID);
    fclose(pFileLargeList);
    return(0) ;
}


/* ----------------------------------------------------------------- */
void SetIdKey2 (char * idKey, char * netID, short permitKey)
{
    char *idPtr;  /* points to end of idKey */

    ENTERING("SetIdKey2",CUSSP_APP);

    strcpy(idKey,netID);
    idPtr = idKey + strlen(idKey);
    *idPtr = '_';
    idPtr++;
    if (permitKey <256)
    {
        *idPtr = (unsigned char)permitKey;
        idPtr++;
    }
    else
    {
        memcpy(idPtr,&permitKey,sizeof(permitKey));
        idPtr += sizeof(permitKey);
    }

    *idPtr = '\0';
    cuwa_trace("SetIdKey: (%d) ",permitKey);
}


/* ----------------------------------------------------------------- */
void SetIdKey (char * pszIdKey, char * pszKey1, short iPermitKey)
{
    char szNum[5];

    ENTERING("SetIdKey", CUSSP_APP);

    /* put number into key */
    memset(szNum, 0, sizeof(szNum));
    sprintf(szNum, "%04d", iPermitKey);
    sprintf(pszIdKey, "%s_%s", pszKey1, szNum);

    cuwa_trace( "SetIdKey: %s (%d) ", pszIdKey, iPermitKey);
}


/* ----------------------------------------------------------------- */
int DbGetPermit (char * netID, PdInfo * pdInfo, char * numPermits,
                 char * userInfo, char * cdate, char * mdate,
                 char * edate, char * pdate)
{
    GDBM_FILE db;
    int  retCode;
    PermitInfo permitInfo;
    //	int numP = 0;
    int  piLen;
    char idKey[MAXIDLEN+3];
    // int revoked;

    ENTERING("DbGetPermit",CUSSP_APP);
    cuwa_trace("DbGetPermit: %s : %d\n",netID, pdInfo ? pdInfo->pKey: 0);

    strcpy(numPermits,"none");
    userInfo[0] = '\0';
    memset(&permitInfo,'\0',sizeof(permitInfo));

    if (!pdInfo)
        return pNoSuchPermitName;

    retCode = OpenDatabase(IdDb, &db, NULL); /* read only */
    if (retCode)
        return retCode;

    /* Fetch ID record */
    SetIdKey(idKey, netID, pdInfo->pKey);
    retCode = FetchDbRecord(db, idKey, (char *)&permitInfo, &piLen);
    if ( retCode == dbNoRecord )
    {    /* no record */
        retCode = pNoPermit;
    }
    else if (piLen != sizeof(permitInfo))
    {  /* sanity check */
        retCode =pDbReadErr;
    }
    else
    {
        sprintf(numPermits,"%d",permitInfo.numPermits);
        strcpy (userInfo, permitInfo.userInfo);
        cuwa_trace("Permit: Num=%s,revoked=%d,info=%s\n",
                   numPermits,permitInfo.revoked,userInfo);
        if (permitInfo.revoked)
            retCode = pIdRevoked;
        else if (permitInfo.numPermits < 1)
            retCode = pNoPermit;
        else if (permitInfo.expire && (permitInfo.expire < time(0)))
            retCode = pPermitExpired;
        else if (pdInfo->cut_off)
        {
            if (permitInfo.created < pdInfo->cut_off &&
                permitInfo.modified < pdInfo->cut_off)
                retCode = pPermitExpired;
        }
        else
            retCode = pSuccess;
    }
    CloseDatabase(db, 0);

    /* translate dates */
    if (cdate)
    {
        if (permitInfo.created)
        {
            strcpy(cdate,ctime(&permitInfo.created));
            cdate[strlen(cdate)-1] = '\0';
        }
        else
            strcpy(cdate,"none");
    }
    if (mdate)
    {
        if (permitInfo.modified)
        {
            strcpy(mdate,ctime(&permitInfo.modified));
            mdate[strlen(mdate)-1] = '\0';
        }
        else
            strcpy(mdate,"none");
    }
    if (edate)
    {
        if (permitInfo.expire)
        {
            strcpy(edate,ctime(&permitInfo.expire));
            edate[strlen(edate)-1] = '\0';
        }
        else
            strcpy(edate,"none");
    }
    if (pdate)
    {
        if (pdInfo->cut_off)
        {
            strcpy(pdate,ctime(&(pdInfo->cut_off)));
            pdate[strlen(pdate)-1] = '\0';
        }
        else
            strcpy(pdate,"none");
    }
    return retCode;
}


/* ----------------------------------------------------------------- */
int DbAddPermit(char * netID, PdInfo * pdInfo, int incrFlag)
{
    GDBM_FILE db;
    int    lockdb;  /* db lockfile */
    int    retCode;
    PermitInfo permitInfo;
    int    piLen;
    char   idKey[MAXIDLEN+3];
    int pExists = false;

    ENTERING("DbAddPermit",CUSSP_APP);
    if (!pdInfo)
        return pNoSuchPermitName;

    /* open the ID database */
    retCode = OpenDatabase(IdDb, &db, &lockdb);
    if (retCode)
        return retCode;

    /* Fetch the ID record: */
    SetIdKey(idKey, netID, pdInfo->pKey);
    retCode = FetchDbRecord(db, idKey, (char *)&permitInfo, &piLen);
    if ( retCode == dbNoRecord )
    {    /* new record */
        permitInfo.numPermits = 1;
        permitInfo.revoked = 0;
        permitInfo.created = time(NULL);
        permitInfo.modified = 0;
        permitInfo.expire = 0;
        permitInfo.userInfo[0] = 0;
    }
    else
    { /* existing record */
        if (piLen != sizeof(permitInfo))
        { /* sanity check */
            CloseDatabase(db,lockdb);
            return pDbReadErr;
        }
        if (permitInfo.revoked)
        {
            CloseDatabase(db,lockdb);
            return pIdRevoked;
        }

        permitInfo.modified = time(NULL);
        if (incrFlag || permitInfo.numPermits <1 )
            permitInfo.numPermits += 1;
        else
            pExists = true;
    }

    cuwa_trace("Add, numPermits=%d\n",permitInfo.numPermits);
    /* Replace the database record: */
    retCode = StoreDbRecord(db, idKey, (char *)&permitInfo, sizeof(permitInfo));
    CloseDatabase(db,lockdb);
    if (retCode < 0)
        return pDbWriteErr;
    if (pExists)
        return pPermitExists;

    if (permitInfo.numPermits == 1)
    {
        /* first permit, add to cross index*/
        retCode =  OpenDatabase(CxDb, &db, &lockdb);
        if (!retCode)
        {
            SetIdKey(idKey, netID, 'P');
            CrossIndexAdd(db, idKey, (char *)&(pdInfo->pKey), sizeof(pdInfo->pKey));
            if (pdInfo->largeList)
            {
                StoreLargeList(netID, pdInfo->pName);
            }
            else
            {
                SetIdKey(idKey, pdInfo->pName, 'P');
                CrossIndexAdd(db,idKey,netID,strlen(netID));
            }
            CloseDatabase(db,lockdb);
        }
    }
    return pSuccess;
}


/* ----------------------------------------------------------------- */
int DbChangePermit (char * netID, PdInfo * pdInfo, char * newUserInfo)
{
    GDBM_FILE db;
    int    lockdb;   /* db lockfile */
    int    retCode;
    PermitInfo permitInfo;
    int    piLen;
    char   idKey[MAXIDLEN+3];

    ENTERING("DbChangePermit",CUSSP_APP);
    if (!pdInfo)
        return pNoSuchPermitName;

    cuwa_trace("New Permit Info: %s\n",newUserInfo ? newUserInfo : "");
    /* Check length of userInfo */
    if (strlen(newUserInfo) > INFOLEN)
    {
        return pInfoTooLong;
    }


    /* open the ID database */
    retCode = OpenDatabase(IdDb, &db, &lockdb);
    if (retCode)
        return retCode;

    /* Fetch the ID record: */
    SetIdKey(idKey, netID, pdInfo->pKey);
    retCode = FetchDbRecord(db, idKey, (char *)&permitInfo, &piLen);
    if (retCode == dbNoRecord)
        retCode = pNoPermit;
    else if (piLen != sizeof(permitInfo))  /* sanity check */
        retCode = pDbReadErr;
    else
    { /* replace old userInfo */
        if (strlen(newUserInfo) > INFOLEN)
            strncpy(permitInfo.userInfo,newUserInfo,INFOLEN);
        else
            strcpy(permitInfo.userInfo,newUserInfo);
        permitInfo.modified = time(NULL);
        cuwa_trace("changed permit info: %s (%d)\n", permitInfo.userInfo,
                   strlen(permitInfo.userInfo));
        /* Replace the database record: */
        retCode = StoreDbRecord(db, idKey, (char *)&permitInfo, sizeof(permitInfo));
    }

    CloseDatabase(db,lockdb);
    return retCode;
}


/* ----------------------------------------------------------------- */
int DbDeletePermit (char * pszNetID, PdInfo * pPdInfo)
{
    GDBM_FILE pNdbm;
    int iLockDb;   /* db lockfile */
    int iReturn;
    PermitInfo pi;
    int piLen;
    char szIdKey[MAXIDLEN+3];
    int iDeleted = false;

    ENTERING("DbDeletePermit", CUSSP_APP);
    if (!pPdInfo)
        return(pNoSuchPermitName) ;

    /* open the ID database */
    iReturn = OpenDatabase(IdDb, &pNdbm, &iLockDb);
    if (iReturn)
        return(iReturn);

    /* Fetch the ID record: */
    SetIdKey(szIdKey, pszNetID, pPdInfo->pKey);
    iReturn = FetchDbRecord(pNdbm, szIdKey, (char *)&pi, &piLen);
    if (iReturn == dbNoRecord)
    {
        CloseDatabase(pNdbm, iLockDb);
        return(pNoPermit);
    }

    if (piLen != sizeof(pi))
    {  /* sanity check */
        CloseDatabase(pNdbm, iLockDb);
        return(pDbReadErr);
    }

    /* decrease numPermits by 1 */
    if (pi.numPermits > 0)
    {
        iDeleted = true;
        // sse: pi.numPermits -= 1;
        pi.numPermits = 0 ;
        pi.modified = time(NULL);
    }

    cuwa_trace( "old permit, num now %d\n", pi.numPermits);

    /* Replace the database record: */
    iReturn = StoreDbRecord(pNdbm, szIdKey, (char *)&pi, sizeof(pi));
    CloseDatabase(pNdbm, iLockDb);
    if (iReturn < 0)
        return(pDbWriteErr);
    else if (pi.numPermits<1 && iDeleted)
    {
        /* deleted last permit, remove from cross index */
        iReturn = OpenDatabase(CxDb, &pNdbm, &iLockDb);
        if (!iReturn)
        {
            SetIdKey(szIdKey, pszNetID, 'P');
            CrossIndexDelete(pNdbm, szIdKey, (char *)&(pPdInfo->pKey),
                             sizeof(pPdInfo->pKey));
            if (!pPdInfo->largeList)
            {
                SetIdKey(szIdKey, pPdInfo->pName, 'P');
                CrossIndexDelete(pNdbm, szIdKey, pszNetID, strlen(pszNetID));
            }
            CloseDatabase(pNdbm, iLockDb);
        }
    }
    return(pSuccess);
}


/* ----------------------------------------------------------------- */
int DbRevokePermit (char * netID, PdInfo * pdInfo, unsigned char revoked)
{
    GDBM_FILE db;
    int    lockdb;   /* db lockfile */
    int    retCode;
    PermitInfo permitInfo;
    int    piLen;
    char   idKey[MAXIDLEN+3];

    ENTERING("DbRevokePermit",CUSSP_APP);
    if (!pdInfo)
        return pNoSuchPermitName;

    /* open the ID database */
    retCode = OpenDatabase(IdDb, &db, &lockdb);
    if (retCode)
        return retCode;

    /* Fetch the ID record: */
    SetIdKey(idKey, netID, pdInfo->pKey);
    retCode = FetchDbRecord(db, idKey, (char *)&permitInfo, &piLen);
    if ( retCode == dbNoRecord )
    {    /* no record */
        CloseDatabase(db,lockdb);
        return pNoPermit;
    }
    else if (piLen != sizeof(permitInfo))
    {  /* sanity check */
        CloseDatabase(db,lockdb);
        return pDbReadErr;
    }
    else
    {
        permitInfo.revoked = revoked;
        permitInfo.modified = time(NULL);
    }

    /* Replace the database record: */
    retCode = StoreDbRecord(db, idKey, (char *)&permitInfo, sizeof(permitInfo));
    CloseDatabase(db,lockdb);
    if (retCode < 0)
        return pDbWriteErr;
    else
    {
        retCode =  OpenDatabase(CxDb, &db, &lockdb);
        if (!retCode)
        {
            /* update cross index */
            if (revoked)
            {
                SetIdKey(idKey, netID, 'P');
                CrossIndexDelete(db, idKey, (char *)&(pdInfo->pKey), sizeof(pdInfo->pKey));
                if (!pdInfo->largeList)
                {
                    SetIdKey(idKey, pdInfo->pName, 'P');
                    CrossIndexDelete(db,idKey,netID,strlen(netID));
                }
                SetIdKey(idKey, pdInfo->pName, 'R');
                CrossIndexAdd(db,idKey,netID,strlen(netID));
            }
            else
            { /* reinstated */
                SetIdKey(idKey, netID, 'P');
                CrossIndexAdd(db, idKey, (char *)&(pdInfo->pKey), sizeof(pdInfo->pKey));
                if (!pdInfo->largeList)
                {
                    SetIdKey(idKey, pdInfo->pName, 'P');
                    CrossIndexAdd(db,idKey,netID,strlen(netID));
                }
                SetIdKey(idKey, pdInfo->pName, 'R');
                CrossIndexDelete(db,idKey,netID,strlen(netID));
            }
            CloseDatabase(db,lockdb);
        }
    }
    return pSuccess;
}


/* cross index database routines */
/* ----------------------------------------------------------------- */
int CrossIndexAdd (GDBM_FILE pDb, char * pszKey, char * pszAppend, int iAppendLen)
{
    char szValue[DBM_MAXLEN];   /* list of permitNames by permitKey */
    char * psz1 = szValue;
    int iValueLen = 0;
    int iReturn = 0;

    ENTERING("CrossIndexAdd", CUSSP_APP);
    {
        memcpy(szValue, pszAppend, iAppendLen);
        szValue[iAppendLen] = '\0';
        cuwa_trace("CrossIndexAdd: key=%s, data=%s (%d)\n",
                   pszKey, szValue, iAppendLen);
    }

    memset(szValue,'\0', sizeof(szValue));

    /* fetch record if exists */
    iReturn = FetchDbRecord(pDb, pszKey, szValue, &iValueLen);
    // HexDump("before",szValue,iValueLen);

    if (iReturn == dbNoRecord )
    {    /* doesn't exist, make stub */
        *psz1++ = ':';
        iValueLen++;
        cuwa_trace( "new record, key=%s\n", pszKey);

    }
    else
    {  /* add to the end of the list */
        psz1 = szValue + iValueLen;
        cuwa_trace( "existing record, len=%d, key=%s\n", iValueLen, pszKey);
    }

    iValueLen += iAppendLen + 1;  /* add size for "cxData:" */
    if (iValueLen > DBM_MAXLEN)
    {
        memcpy(szValue, pszAppend, iAppendLen);
        cuwa_trace("Cross index full for %s, %s not added\n", pszKey, szValue);

        return(pInfoTooLong);
    }

    /* add permitKey to end of DbRecord */
    memcpy(psz1, pszAppend, iAppendLen);
    psz1 += iAppendLen;
    *psz1 = ':';
    cuwa_trace( "store record, len=%d\n", iValueLen);

    // HexDump("after",szValue,iValueLen);
    iReturn = StoreDbRecord(pDb, pszKey, szValue, iValueLen);
    if (iReturn)
    {
        // HexDump("after",szValue,iValueLen);
        memcpy(szValue, pszAppend, iAppendLen);
        cuwa_trace( "Database error writing record for %s, %d not added\n",
                    pszKey, *pszAppend);

        /* ljc */
        return(pDbWriteErr);
    }

    return(pSuccess);
}


/* ----------------------------------------------------------------- */
int CrossIndexDelete (GDBM_FILE cxDb, char * cxKey, char * cxData, int cxDataLen)
{
    char dbRecord[DBM_MAXLEN];   /* list of permitNames by permitKey */
    char *dbRecordPtr;
    char *dbRecordEnd;
    char *newPtr;
    int  dbRecordLen = 0;
    int  oldDbRecordLen;
    int  retCode = 0;

    ENTERING("CrossIndexDelete",CUSSP_APP);
    cuwa_trace("CrossIndexDelete: key=%s ",cxKey);

    memset(dbRecord,'\0',sizeof(dbRecord));
    /* fetch record if exists */
    retCode = FetchDbRecord( cxDb, cxKey, dbRecord, &dbRecordLen );
    // HexDump("before",dbRecord,dbRecordLen);

    if ( retCode == dbNoRecord )
        return pSuccess;

    else
    {  /* delete from list */
        oldDbRecordLen = dbRecordLen;
        dbRecordEnd = dbRecord + dbRecordLen;
        dbRecordPtr = dbRecord +1;
        while (dbRecordPtr <= dbRecordEnd)
        {
            if (memcmp(dbRecordPtr,cxData,cxDataLen) == 0)
            {
                newPtr = dbRecordPtr + cxDataLen+1;
                while (newPtr <= dbRecordEnd)
                    *dbRecordPtr++ = *newPtr++;
                dbRecordLen -= cxDataLen+1;  /* delete size for "cxData:" */
                break;
            }
            else
            {
                while (dbRecordPtr <= dbRecordEnd)
                    if (*dbRecordPtr++ == ':')
                        break;
            }
        }

        if (dbRecordLen != oldDbRecordLen )
        {
            /* need to save new record */
            // HexDump("new",dbRecord,dbRecordLen);
            retCode = StoreDbRecord(cxDb,cxKey,dbRecord,dbRecordLen);
            if (retCode)
            {
                memcpy(dbRecord,cxData,cxDataLen);
                cuwa_trace("error writing record for %s, %s not deleted\n",
                           cxKey, cxData);
                return pSuccess; /* don't care if fails */
            }
        }
    }
    return pSuccess;
}


/* ----------------------------------------------------------------- */
void CrossIndexPermitDescriptor (GDBM_FILE pCxDb, PdInfo * pdInfo)
{
    char szDbKey[MAXIDLEN+2];    /* netid index for cross index database */
    char * pszKey;                /* points inside dbKey */
    char * pszAcl;                /* points inside ACL lists */
    char * pszAclLen;               /* length of ACL lists */

    ENTERING("CrossIndexPermitDescriptor", CUSSP_APP);

    /* key is _permitKey */
    SetIdKey(szDbKey, "PKEY", pdInfo->pKey);
    cuwa_trace( "permitKey cross index, key= %s (%d), name= %s\n",
                szDbKey, pdInfo->pKey, pdInfo->pName);

    StoreDbRecord(pCxDb, szDbKey, (char *)pdInfo, sizeof(PdInfo));

    /* owner key = netid_O */
    SetIdKey(szDbKey, pdInfo->owner, 'O');
    cuwa_trace( "owner cross index, key= %s, pName= %d\n", szDbKey ,pdInfo->pKey);

    CrossIndexAdd(pCxDb, szDbKey, (char *)&(pdInfo->pKey), sizeof(pdInfo->pKey));

    /* idLookupACL key = netid_L */
    pszAcl = &(pdInfo->idLookupACL[0]) + 1; /* skip first ':' */
    pszAclLen = pszAcl + strlen(pdInfo->idLookupACL) - 1;
    while (pszAcl < pszAclLen)
    {
        memset(szDbKey, '\0', sizeof(szDbKey));
        pszKey = szDbKey;
        while (((*pszKey = *pszAcl++) != ':') && pszAcl < pszAclLen)
            pszKey++;

        *pszKey = '\0';
        SetIdKey(szDbKey, szDbKey, 'L');
        cuwa_trace( "idLookupACL cross index, key= %s, pName= %d\n",
                    szDbKey,pdInfo->pKey);

        CrossIndexAdd(pCxDb, szDbKey, (char *)&(pdInfo->pKey), sizeof(pdInfo->pKey));
    }

    /* idUpdateACL key = netid_U */
    pszAcl = &(pdInfo->idUpdateACL[0]) + 1; /* skip first ':' */
    pszAclLen = pszAcl + strlen(pdInfo->idUpdateACL) -1;
    while (pszAcl < pszAclLen)
    {
        memset(szDbKey, '\0', sizeof(szDbKey));
        pszKey = szDbKey;

        while (((*pszKey = *pszAcl++) != ':') && pszAcl < pszAclLen)
            pszKey++;

        *pszKey = '\0';
        printf("\ndbkey=%s\n", szDbKey);

        SetIdKey(szDbKey, szDbKey, 'U');

        cuwa_trace( "idUpdateACL cross index, key= %s, pName= %d\n",
                    szDbKey,pdInfo->pKey);

        CrossIndexAdd(pCxDb, szDbKey, (char *)&(pdInfo->pKey), sizeof(pdInfo->pKey));
    }

    /* pdAdminACL  key = netid_A */
    pszAcl = &(pdInfo->pdAdminACL[0]) + 1; /* skip first ':' */
    pszAclLen = pszAcl + strlen(pdInfo->pdAdminACL) -1;
    while (pszAcl < pszAclLen)
    {
        memset(szDbKey, '\0', sizeof(szDbKey));
        pszKey = szDbKey;
        while (((*pszKey = *pszAcl++) != ':') && pszAcl < pszAclLen)
            pszKey++;

        *pszKey = '\0';
        SetIdKey(szDbKey, szDbKey, 'A');

        cuwa_trace( "pdAdminACL cross index, key= %s, pName= %d\n",
                    szDbKey,pdInfo->pKey);

        CrossIndexAdd(pCxDb, szDbKey, (char *)&(pdInfo->pKey), sizeof(pdInfo->pKey));
    }
}


/* ----------------------------------------------------------------- */
void TouchDbFile (char * appendFormat, char * dbName, int openFlags)
{
    char   dbFileName[ FILENAME_MAX ];
    int dbFile;

    ENTERING("TouchDbFile",CUSSP_APP);
    sprintf( dbFileName, appendFormat, dbName );
    if ((dbFile = open( dbFileName, openFlags, 0600 )) < 0)
    {
        cuwa_trace( "can't create/truncate database file %s\n",
                    dbFileName );
        exit(3);
    }
    close (dbFile);
}


/* internal permitdb.c routines */
/* ----------------------------------------------------------------- */
void lockAlarmHandler (int what)
{
    /* return to setjmp in OpenDatabase */
    longjmp(jmp_env, 1); /* return to alarm base */
}


/* ------------------------------------------------------------------------ */
static int OpenDatabase (int iDbType, GDBM_FILE * pDb, int * piLockFile)
{
    // int i;
    char szDbFileName[FILENAME_MAX];
    char szLockFileName[FILENAME_MAX];
    void (*prevHandler) (); /* store previous ALRM handler for restore */


    cuwa_trace( "Entering OpenDatabase()\n");

    switch (iDbType)
    {
    case IdDb:
        sprintf(szDbFileName, "%s/%s", permitdb_path,   IDDBNAME);
        sprintf(szLockFileName, "%s/%s", permitdb_path, IDLOCKFILE);
        break;

    case PdDb:
        sprintf(szDbFileName, "%s/%s", permitdb_path,  PDDBNAME);
        sprintf(szLockFileName, "%s/%s", permitdb_path,PDLOCKFILE);
        break;

    case CxDb:
        sprintf(szDbFileName, "%s/%s", permitdb_path,  CROSSDBNAME);
        sprintf(szLockFileName, "%s/%s", permitdb_path,CROSSLOCKFILE);
        break;

    default:
        return(pDbOpenErr);
    }


    cuwa_trace( "OpenDatabase: %s %s\n", szDbFileName, piLockFile? "locked":"unlocked");

    if (!piLockFile)
    {
        /* open the database (not locked) */
        *pDb = gdbm_open(szDbFileName, GDBM_BLOCK_SIZE, GDBM_READER, 0, NULL) ;
        if (*pDb == NULL)
            return(pDbOpenErr);
        else
            return(pSuccess);
    }

    /* open locked database */
    *piLockFile = open(szLockFileName, O_RDWR|O_CREAT, 0640);
    if (*piLockFile<0)
    {
        return(pDbOpenErr);
    }

    /* First time through, setjmp = 0 */
    /* if alarm sounds, alarmHandler returns here with setjmp = 1 */
    prevHandler = signal(SIGALRM, lockAlarmHandler);
    if (setjmp(jmp_env) == 0 )
    {
        alarm(5);

        cuwa_trace( "Attempting lock...\n");

        if (lockf(*piLockFile, F_LOCK, 1) == 0)
        {  /* lock ok */
            alarm(0);
            signal(SIGALRM, prevHandler);
            if ((*pDb = gdbm_open(szDbFileName, GDBM_BLOCK_SIZE, GDBM_WRITER | GDBM_NOLOCK, 0, NULL)) == NULL)
            {
                close (*piLockFile);
                *piLockFile = 0 ;


                cuwa_trace( "gdbm_open failed...\n");

                return(pDbOpenErr);
            }


            cuwa_trace( "Lock & dbm_open succeeded...\n");

            return pSuccess;
        }
        else
        {

            perror("Lock failed...\n");
        }
    }
    else
    {

        cuwa_trace("Lock timed out...\n");
    }

    signal(SIGALRM, prevHandler);
    return(pDbOpenErr);
}


/* ----------------------------------------------------------------- */
static int CloseDatabase (GDBM_FILE pDb, int lockFile)
{
    ENTERING("CloseDatabase", CUSSP_APP);


    cuwa_trace( "close %s database\n", lockFile ? "locked" : "unlocked");

    if (lockFile)
        close(lockFile);

    gdbm_close(pDb);

    return(pSuccess);
}


/* ----------------------------------------------------------------- */
int FetchDbRecord (GDBM_FILE fromDb, char * dbKey, char * dbRecord, int * dbRecordLen)
{
    datum  keyDatum, codeDatum;
    int   retCode;

    ENTERING("FetchDbRecord",CUSSP_APP);


    cuwa_trace( "FetchDbRecord: %s (%d)\n", dbKey, strlen(dbKey));

    keyDatum.dptr  = dbKey;
    keyDatum.dsize = strlen(dbKey);
    codeDatum = gdbm_fetch(fromDb, keyDatum);    /* look up ID record */

    if (!codeDatum.dptr)
    {
        retCode = dbNoRecord;
    }
    else
    {
        /* copy the record */
        memcpy(dbRecord, codeDatum.dptr, *dbRecordLen = codeDatum.dsize);
        free(codeDatum.dptr);
        retCode = pSuccess;
    }


    cuwa_trace( "rc=%d\n",retCode);

    return(retCode);
}


/* ----------------------------------------------------------------- */
int FetchDbRecord_dynamicMem (GDBM_FILE fromDb, char * dbKey, char ** dbRecord, int * dbRecordLen)
{
    datum  keyDatum, codeDatum;
    int   retCode;
    char *buf = NULL;

    ENTERING("FetchDbRecord",CUSSP_APP);


    cuwa_trace( "FetchDbRecord: %s (%d)\n", dbKey, strlen(dbKey));

    keyDatum.dptr  = dbKey;
    keyDatum.dsize = strlen(dbKey);
    codeDatum = gdbm_fetch(fromDb, keyDatum);    /* look up ID record */

    if (!codeDatum.dptr)
    {
        retCode = dbNoRecord;
    }
    else
    {
        /* copy the record */
        buf = cuwa_calloc(1, codeDatum.dsize+1);
        cuwa_trace("FetchDbRecord: allocate %d", codeDatum.dsize);
        if (!buf)
        {
            retCode = pNoMem;
            cuwa_warning("FetchDbRecord_dynamicMem:not enough memory to allocate %d", codeDatum.dsize);
        }
        else
        {
            memcpy(buf, codeDatum.dptr, *dbRecordLen = codeDatum.dsize);
            retCode = pSuccess;
        }
        free(codeDatum.dptr);
    }

    cuwa_trace( "rc=%d\n",retCode);
    *dbRecord = buf;

    return(retCode);
}

/* ----------------------------------------------------------------- */
int StoreDbRecord (GDBM_FILE pDb, char * pszKey, char * pszValue, int iValueLen)
{
    datum key, value;
    int iReturn=0;

    ENTERING("StoreDbRecord", CUSSP_APP);


    cuwa_trace( "StoreDbRecord: key: %s, len: %d\n", pszKey, iValueLen);

    key.dptr = pszKey;
    key.dsize = strlen(pszKey);
    value.dptr = pszValue;
    value.dsize = iValueLen;

    /* store the new ID record, if any */
    if (iValueLen)
        iReturn = gdbm_store(pDb, key, value, GDBM_REPLACE);


    cuwa_trace( "gdbm_store returns: %d\n", iReturn);

    return iReturn ? pDbWriteErr : pSuccess;
}


/* ----------------------------------------------------------------- */
int RemoveDbRecord (GDBM_FILE toDb, char * dbKey)
{
    datum  keyDatum;
    int   retCode;
    cuwa_trace( "RemoveDbRecord: %s\n,",dbKey);

    ENTERING("RemoveDbRecord", CUSSP_APP);
    keyDatum.dptr = dbKey;
    keyDatum.dsize = strlen(dbKey);

    retCode = gdbm_delete(toDb, keyDatum);

    cuwa_trace( "rc=%d\n",retCode);

    return retCode ? pDbWriteErr : pSuccess;
}


/* ----------------------------------------------------------------- */
int SenderAccess (char * pszSenderID, PdInfo * pPdInfo)
{
    char * psz1 ;

    ENTERING("SenderAccess", CUSSP_APP);


    cuwa_trace("SenderAccess: SenderID %s\n", pszSenderID);

    if (!pszSenderID || !pszSenderID[0])
        return(allowNothing);

    {
        cuwa_trace( "permitMaster: %s (%d)\n", m_szPermitMaster,
                    !strcmp(m_szPermitMaster, pszSenderID));

        psz1 = strstr(m_szPermitMasterAdmin, pszSenderID) ;

        if (psz1)
            cuwa_trace( "permitMasterAdmin: %s (%s)\n", m_szPermitMasterAdmin, psz1) ;

    }

    // allow master
    if ((strstr(m_szPermitMasterAdmin, pszSenderID) != NULL) ||
        (strcmp(m_szPermitMaster, pszSenderID) == 0))
        return(allowMaster);


    cuwa_trace("pdInfo is %s (0x%x).\n", pPdInfo?"valid":"null",
               (unsigned int)pPdInfo);

    if (!pPdInfo)
        return(allowNothing);


    cuwa_trace("owner: %s (%d)\n", pPdInfo->owner,
               !strcmp(pPdInfo->owner, pszSenderID));

    // allow owner
    if (strcmp(pPdInfo->owner,pszSenderID) == 0)
        return allowOwner;


    cuwa_trace( "admin: %s (%s)\n", pPdInfo->pdAdminACL,
                strstr(pPdInfo->pdAdminACL, pszSenderID)?"Y":"N");

    // allow admin
    if (strstr(pPdInfo->pdAdminACL, pszSenderID) != NULL)
        return(allowAdmin);


    cuwa_trace( "update: %s (%s)\n", pPdInfo->idUpdateACL,
                strstr(pPdInfo->idUpdateACL, pszSenderID)?"Y":"N");

    // allow update
    if (strstr(pPdInfo->idUpdateACL,pszSenderID) != NULL)
        return(allowUpdate);


    cuwa_trace( "lookup: %s (%s)\n", pPdInfo->idLookupACL,
                strstr(pPdInfo->idLookupACL, pszSenderID)?"Y":"N");

    // allow lookup
    if ((strstr(pPdInfo->idLookupACL, pszSenderID) != NULL) || pPdInfo->public)
        return(allowLookup);

    return(allowNothing);
}


/* ----------------------------------------------------------------- */
static int allowList (char * senderID, int senderSelf, short indexType,
                      PdInfo * pdInfo)
{
    ENTERING("allowList",CUSSP_APP);

    if (senderSelf || SenderAccess(senderID,pdInfo) >= allowAdmin)
    {
        /* sender can list own, owner and admin can list everything */
        if (indexType != 'P')
            return(true);
        else if (pdInfo->visible)  /* invisible permits not shown */
            return(true);

        /* anyone can list public permits */
        /* sender must be in ACL to list non-public permits */
    }
    else if (SenderAccess(senderID,pdInfo) >= allowLookup)
    {
        if (indexType == 'P' && pdInfo->visible)
            return(true);
        else if (indexType == 'I')
            return(true);
    }

    return(false);
}


/* ----------------------------------------------------------------- */
int DbListPermits(char * senderID, char * netID, char * pNamePrefix,
                  short indexType, char * userInfo)
{
    /* cross index database lookups */
    GDBM_FILE cxDb;
    int  retCode = 0;
    char idKey[MAXIDLEN+2];           /* index for cross index database */
    char permitList[DBM_MAXLEN];   /* key=netid, record=list permitKeys*/
    int  permitLLen = 0;
    char *permitLPtr = permitList+1; /* jump over first : */
    char *permitLEnd; /* permitList + permitLLen */
    short permitKey;
    PdInfo pdInfo;
    int  pdInfoLen;
    char *userInfoPtr;
    int  senderSelf = true;
    int  numLen;

    ENTERING("DbListPermits",CUSSP_APP);

    cuwa_trace("DbListPermits: %s asks for %s's list.\n",
               senderID,netID);

    /* Open cross index database */
    retCode = OpenDatabase(CxDb, &cxDb, NULL);
    if (retCode)
    {
        cuwa_trace( "can't open database %s for reading\n",
                    CROSSDBNAME);
        return pDbOpenErr;
    }

    /* fetch list of permits */
    if (indexType == 'I')
        SetIdKey(idKey,netID,'P');
    else
        SetIdKey(idKey,netID,indexType);

    memset(permitList,'\0',sizeof(permitList));
    retCode = FetchDbRecord( cxDb, idKey, permitList, &permitLLen );
    if (retCode == dbNoRecord)
    {  /* no permit list */
        *userInfo = '\0';
        CloseDatabase(cxDb, 0);
        return pSuccess;
    }

    //
    // HexDump("before permitList",permitList,permitLLen);

    /* initial setup for scan */
    if (strcmp(senderID,netID) != 0)
        senderSelf = false;
    numLen  = sizeof(permitKey);
    userInfoPtr = userInfo;
    permitLEnd = permitList + permitLLen;

    /* cycle through list of permitKeys*/
    while (permitLPtr < permitLEnd)
    {
        memcpy(&permitKey,permitLPtr,numLen);
        cuwa_trace("permitKey=%d\n",permitKey);

        /* pull permitName based on permitKey */
        SetIdKey(idKey,"PKEY",permitKey);
        retCode = FetchDbRecord(cxDb, idKey, (char *)&pdInfo, &pdInfoLen);

        /* can senderId look at permit? */

        cuwa_trace("rc=%d, senderSelf=%d, visible=%d, allow=%d\n",
                   retCode,senderSelf,pdInfo.visible,allowList(senderID,senderSelf,
                                                               indexType,&pdInfo));

        if (!retCode && allowList(senderID,senderSelf,indexType,&pdInfo))
        {
            if (!pNamePrefix || !pNamePrefix[0] || strstr(pdInfo.pName,pNamePrefix))
            {
                cuwa_trace("pName = %s\n",pdInfo.pName);
                memcpy(userInfoPtr,pdInfo.pName,
                       strlen(pdInfo.pName));
                userInfoPtr += strlen(pdInfo.pName);
                /* put end of record mark */
                *userInfoPtr++ = EOREC;
            }
        }
        permitLPtr += numLen + 1; /* jump over num: */
    }
    *userInfoPtr = '\0';
    // HexDump("permitlist",userInfo,userInfoPtr-userInfo);
    CloseDatabase(cxDb, 0);
    return pSuccess;
}


/* ----------------------------------------------------------------- */
int DbRemoveNetID (char * netID, char * newNetID)
{
    GDBM_FILE pdDb;
    GDBM_FILE idDb;
    GDBM_FILE cxDb;
    int    idLockdb, cxLockdb;  /* db lockfile */
    datum  keyIndex;
    int    retCode = pSuccess;
    PdInfo pdInfo;  /* permit descriptor */
    int pdInfoLen;
    PermitInfo permitInfo;  /* permit info */
    int  piLen, i;
    char dbRecord[DBM_MAXLEN];   /* list of permits */
    int  dbRecordLen;
    char indexSet[6] = "POLUA";
    // datum keyDatum;  /* for deletes */
    char idKey[MAXIDLEN+3];


    ENTERING("DbRemoveNetID",CUSSP_APP);
    /* open databases */
    retCode = OpenDatabase (PdDb, &pdDb, NULL);
    if (retCode) return retCode;
    retCode =  OpenDatabase (IdDb, &idDb, &idLockdb);
    if (retCode) return retCode;
    retCode =  OpenDatabase (CxDb, &cxDb, &cxLockdb);
    if (retCode) return retCode;

    /* if replacement, does newNetID already have permits */
    if (newNetID[0])
    {
        SetIdKey(idKey, newNetID, 'P');
        retCode = FetchDbRecord( cxDb, idKey, dbRecord, &dbRecordLen );
        if (!retCode) /* permit list exists already */
            return pReplaceFailed;
    }

    /* cycle through permit descriptors and find all occurances */
    for (keyIndex = gdbm_firstkey(pdDb); keyIndex.dptr != NULL;
        keyIndex = gdbm_nextkey(pdDb, keyIndex))
    {

        /* get pdInfo */
        memset(idKey,'\0',sizeof(idKey));
        if ( keyIndex.dptr )
            (void) memcpy(idKey, keyIndex.dptr, keyIndex.dsize );

        // HexDump("permitName",idKey,strlen(idKey));
        retCode = FetchDbRecord(pdDb, idKey, (char *)&pdInfo, &pdInfoLen);
        if ( retCode)
            continue;

        /* get permit for permitName */
        SetIdKey(idKey, netID, pdInfo.pKey);
        retCode = FetchDbRecord(idDb, idKey, (char *)&permitInfo, &piLen);
        if (!retCode)
        {  /* found permit */
            /* delete permit, add for newNetID */
            retCode = RemoveDbRecord( idDb, idKey);
            cuwa_trace("deleted, largeList=%d\n",pdInfo.largeList);
            if (!pdInfo.largeList)
            {
                SetIdKey(idKey, pdInfo.pName, 'P');
                CrossIndexDelete(cxDb,idKey,netID,strlen(netID));
            }
            if (permitInfo.revoked)
            {
                SetIdKey(idKey, pdInfo.pName, 'R');
                CrossIndexDelete(cxDb,idKey,netID,strlen(netID));
            }

            /* if replacing with new netid */
            if (newNetID[0])
            {

                cuwa_trace( "newNetID=%s (%s)\n", newNetID, newNetID);

                SetIdKey(idKey, newNetID, pdInfo.pKey);
                retCode = StoreDbRecord(idDb, idKey, (char *)&permitInfo,
                                        sizeof(permitInfo));
                if (retCode)
                    return retCode;
                if (!pdInfo.largeList)
                {
                    SetIdKey(idKey, pdInfo.pName, 'P');
                    CrossIndexAdd(cxDb,idKey,newNetID, strlen(newNetID));
                }
                if (permitInfo.revoked)
                {
                    SetIdKey(idKey, pdInfo.pName, 'R');
                    CrossIndexAdd(cxDb,idKey,newNetID,strlen(newNetID));
                }
            }
        } /* end found permit */

        /* check ACL lists */
        if (strcmp(pdInfo.owner,netID) == 0)
        {
            if (newNetID[0])
                DbChangeOwner (&pdInfo, newNetID);
            else
                DbChangeOwner (&pdInfo, m_szPermitMaster);
        }
        if (strstr(pdInfo.idLookupACL,netID) != NULL)
        {
            DbChangeAcl(&pdInfo, netID, "lookup", false);
            if (newNetID[0])
                DbChangeAcl(&pdInfo, newNetID, "lookup", true);
        }
        if (strstr(pdInfo.idUpdateACL, netID) != NULL)
        {
            DbChangeAcl(&pdInfo, netID, "update", false);
            if (newNetID[0])
                DbChangeAcl(&pdInfo, newNetID, "update", true);
        }
        if (strstr(pdInfo.pdAdminACL,netID) != NULL)
        {
            DbChangeAcl(&pdInfo, netID, "admin", false);
            if (newNetID[0])
                DbChangeAcl(&pdInfo, newNetID, "admin", true);
        }
    }  /* end for each permitName */
    CloseDatabase(idDb, idLockdb);
    CloseDatabase(pdDb, 0);

    /* remove from crossindex */
    for (i=0; i < strlen(indexSet); i++)
    {
        SetIdKey(idKey, netID, indexSet[i]);
        retCode = FetchDbRecord( cxDb, idKey, dbRecord, &dbRecordLen );
        if (!retCode)
        {
            retCode = RemoveDbRecord( cxDb, idKey);
            if (newNetID[0] && indexSet[i] == 'P')
            {
                SetIdKey(idKey, newNetID, 'P');
                StoreDbRecord( cxDb, idKey, dbRecord, dbRecordLen );
            }
        }
    }

    CloseDatabase(cxDb,cxLockdb);
    return pSuccess;
}


/* ----------------------------------------------------------------- */
void DbConvertList (char * destList, char * srcList)
{
    char *srcListPtr = srcList+1; /* jump over first : */
    char *destListPtr = destList;
    char *srcListLen;

    ENTERING("DbConvertList",CUSSP_APP);
    if (!destList || !srcList)
        return;

    /* convert list to EOREC list */
    srcListLen = srcList + strlen(srcList);
    while (srcListPtr < srcListLen)
    {
        while ((*destListPtr = *srcListPtr++) != ':')
            destListPtr++;
        *destListPtr++ = EOREC;
    }
    *destListPtr = '\0';
}


/* Given a permitName list the netid's that have permits */
/* ----------------------------------------------------------------- */
int DbGetPermitList (char * permitName, short indexType, PdInfo * pdInfo,
                     char **userInfo, FILE ** largeList)
{

    /* cross index database lookups */
    GDBM_FILE cxDb;
    int  retCode = 0;
    char idKey[PNAMELEN+2];          /* index for cross index database */
    char *permitList;   /* key=netid, record=list netids */
    int  permitLLen = 0;
    char listName[256];
    char *returnList = NULL;

    ENTERING("DbGetPermitList",CUSSP_APP);


    cuwa_trace( "DbGetPermitList: for %s.\n", permitName);

    if ((indexType != 'R') && pdInfo && pdInfo->largeList)
    {
        *userInfo = cuwa_malloc(strlen( "LargeList")+1);
        strcpy(*userInfo,"LargeList");

        if (largeList)
        {
            strcpy(listName, LARGELISTS);
            strcat(listName, permitName);

            cuwa_trace( "DbGetPermitList: filename %s.\n", listName);

            *largeList = fopen(listName, "r" );
        }
        return pSuccess;
    }

    if (largeList)
        *largeList = NULL;

    /* Open cross index database */
    retCode = OpenDatabase (CxDb, &cxDb, NULL);
    if (retCode)
    {
        cuwa_trace( "can't open database %s for reading\n",
                    CROSSDBNAME);
        return pDbOpenErr;
    }

    /* fetch permit list */
    SetIdKey(idKey, permitName, indexType);
    retCode = FetchDbRecord_dynamicMem(cxDb, idKey, &permitList, &permitLLen );
    CloseDatabase(cxDb, 0);
    if (retCode == dbNoRecord)
    {  /* no list */
        *userInfo = cuwa_calloc(1,1);
        return pSuccess;
    }
    if (retCode)
        return pDbReadErr;

    cuwa_trace("going to allocate %d buffer", permitLLen+1);
    returnList = cuwa_calloc( 1,permitLLen+1);
    if (!returnList)
    {
       cuwa_warning("not enough memory to allocate:%d", permitLLen+1);
       return pNoMem;
    }

    DbConvertList(returnList,permitList);
    *userInfo = returnList;

    // HexDump("permitList",userInfo,strlen(userInfo));
    return pSuccess;
}


/* ----------------------------------------------------------------- */
char * DbShowFriendly (PdInfo * pdInfo)
{
    ENTERING("DbShowFriendly",CUSSP_APP);
    if (pdInfo && pdInfo->friendlyName)
        return pdInfo->friendlyName;
    else
        return "";
}


/* ----------------------------------------------------------------- */
char * DbShowOwner (PdInfo * pdInfo)
{
    ENTERING("DbShowOwner",CUSSP_APP);
    if (pdInfo && pdInfo->owner)
        return pdInfo->owner;
    else
        return "";
}


/* ----------------------------------------------------------------- */
char * DbShowMode (PdInfo * pdInfo, char * indexType)
{
    ENTERING("DbShowMode",CUSSP_APP);
    if (pdInfo)
    {
        switch (*indexType)
        {
        case 'p':  /* public */
            if (pdInfo->public)
                return "yes";
            break;
        case 'v':  /* visible */
            if (pdInfo->visible)
                return "yes";
            break;
        case 'l':  /* largeList */
            if (pdInfo->largeList)
                return "yes";
            break;
        default:
            return "";
        }
        return "no";
    }
    else
        return "";
}


/* ----------------------------------------------------------------- */
char * DbShowAcl (PdInfo * pdInfo, char * indexType)
{
    static char userInfo[DBM_MAXLEN];

    ENTERING("DbShowAcl",CUSSP_APP);
    memset(userInfo,'\0',sizeof(userInfo));
    if (pdInfo)
        switch (*indexType)
        {
        case 'l':  /* lookup */
            DbConvertList(userInfo,pdInfo->idLookupACL);
            break;
        case 'u':  /* update */
            DbConvertList(userInfo,pdInfo->idUpdateACL);
            break;
        case 'a':  /* admin */
            DbConvertList(userInfo,pdInfo->pdAdminACL);
            break;
        default:
            *userInfo = '\0';
        }
    return userInfo;
}


/* ----------------------------------------------------------------- */
int GetPermitMaster (void)
{
    GDBM_FILE pDb;
    int iOption;  /* db lockfile */
    datum key, code;
    int iReturn;
    PdInfo * pPdInfo;
    PdInfo pdi ;

    ENTERING("GetPermitMaster", CUSSP_APP);

    /* lock pdInfo database */
    iReturn =  OpenDatabase(PdDb, &pDb, &iOption);
    if (iReturn)
        return(pDbOpenErr);

    /* look up master info record */
    key.dptr = MASTERPERMIT;
    key.dsize = strlen(MASTERPERMIT);
    code = gdbm_fetch(pDb, key);

    if (code.dptr)
    {
        memset(m_szPermitMaster, 0, sizeof(m_szPermitMaster)) ;
        memset(m_szPermitMasterAdmin, 0, sizeof(m_szPermitMasterAdmin)) ;
        memset(&pdi, 0, sizeof(pdi)) ;
        memcpy(&pdi, code.dptr, code.dsize) ;

        pPdInfo = (PdInfo *)&pdi ;
        if (pPdInfo->owner)
            strcpy(m_szPermitMaster, pPdInfo->owner);

        if (pPdInfo->pdAdminACL)
            strcpy(m_szPermitMasterAdmin, pPdInfo->pdAdminACL);

        free(code.dptr);
    }
    else
    {
        CloseDatabase(pDb, iOption);
        return(pDbReadErr);
    }

    CloseDatabase(pDb, iOption);
    return(pSuccess);
}


/* ----------------------------------------------------------------- */
int GetNewPermitKey (int * newNum)
{
    GDBM_FILE db;
    int    lockdb;  /* db lockfile */
    datum  keyDatum, codeDatum;
    int    retCode;
    PdInfo   pdInfo;

    ENTERING("GetNewPermitKey",CUSSP_APP);
    /* lock descriptor database */
    retCode =  OpenDatabase(PdDb, &db, &lockdb);
    if (retCode)
        return pDbOpenErr;

    /* look up master info record */
    keyDatum.dptr  = MASTERPERMIT;
    keyDatum.dsize = strlen(MASTERPERMIT);
    codeDatum = gdbm_fetch(db, keyDatum);

    if ( codeDatum.dptr )
        (void) memcpy( (char *) &pdInfo, codeDatum.dptr, codeDatum.dsize );
    else
    {
        CloseDatabase(db,lockdb);
        return pDbReadErr;
    }

    /* calculate new permit descriptor key(stored in visible value) */
    pdInfo.visible++;
    if (pdInfo.visible == 58) /* 58 = 3A = ':' */
        pdInfo.visible++;
    codeDatum.dptr = (char *) &pdInfo;
    codeDatum.dsize = sizeof(PdInfo);
    retCode = gdbm_store(db, keyDatum, codeDatum, GDBM_REPLACE);

    free(codeDatum.dptr);

    CloseDatabase(db,lockdb);
    if (retCode)
        return pDbWriteErr;
    else
    {
        *newNum = pdInfo.visible;
        return pSuccess;
    }
}


/* ----------------------------------------------------------------- */
int DbCreatePdInfo (PdInfo * pdInfo, char * newPermitName)
{
    int  newPermitKey;
    PdInfo * newPdInfoPtr = NULL;
    char oldName[PNAMELEN];
    char *oldNamePtr = oldName;
    char *namePtr;
    GDBM_FILE db;
    int    lockdb;  /* db lockfile */
    datum  keyDatum, codeDatum;
    int    retCode = pSuccess;

    ENTERING("DbCreatePdInfo", CUSSP_APP);

    /* does permitName already exist? */

    cuwa_trace("retCOde=%d, ptr= 0x%x\n", retCode, (unsigned int)newPdInfoPtr);

    retCode = DbGetPdInfo(newPermitName, &newPdInfoPtr);


    cuwa_trace("retCOde=%d, ptr= 0x%x\n", retCode, (unsigned int)newPdInfoPtr);

    if (retCode && retCode != pNoSuchPermitName)
        return retCode;

    if (newPdInfoPtr)
    {
        cuwa_free (newPdInfoPtr);
        return pInvalidPermitName;
    }

    /* get new number from master pdInfo (atomic lock and release) */
    retCode = GetNewPermitKey (&newPermitKey);
    if (retCode)
        return retCode;

    /* replace pName, pKey and friendlyName in pdInfo */
    strcpy(pdInfo->pName, newPermitName);
    pdInfo->pKey = newPermitKey;
    pdInfo->created = time(0);
    pdInfo->modified = 0;
    pdInfo->cut_off = 0;
    if (pdInfo->visible)
        pdInfo->visible = 1;

    /* put *replace* in friendlyName */
    strcpy (oldName, pdInfo->friendlyName);
    strcpy(pdInfo->friendlyName,"*replace* ");
    namePtr = pdInfo->friendlyName + 10;
    while (((*namePtr = *oldNamePtr++) != '\0') &&
           (namePtr - pdInfo->friendlyName <= PNAMELEN))
        namePtr++;

    /* store new pdInfo*/
    retCode =  OpenDatabase(PdDb, &db, &lockdb);
    if (retCode)
        return pDbOpenErr;

    keyDatum.dptr = newPermitName;
    keyDatum.dsize = strlen(newPermitName);
    codeDatum.dptr = (char *) pdInfo;
    codeDatum.dsize = sizeof(PdInfo);
    retCode = gdbm_store(db, keyDatum, codeDatum, GDBM_INSERT);

    CloseDatabase(db,lockdb);
    if (retCode < 0)
        return pDbWriteErr;
    else
    {
        retCode =  OpenDatabase(CxDb, &db, &lockdb);
        if (!retCode)
        {
            CrossIndexPermitDescriptor(db,pdInfo);
            CloseDatabase(db,lockdb);
        }
    }
    return pSuccess;
}


/* ----------------------------------------------------------------- */
int DbRemovePermits (PdInfo * pdInfo, int savePD)
{
    int  newPermitKey;
    int  oldPermitKey;
    GDBM_FILE db;
    int    lockdb;  /* db lockfile */
    char dbKey[MAXIDLEN+2];  /* index for cross index database */
    int    retCode = pSuccess;

    ENTERING("DbRemovePermits",CUSSP_APP);

    if (!pdInfo)
        return pNoSuchPermitName;

    oldPermitKey = pdInfo->pKey;
    if (savePD)
    {
        /* get new number from master pdInfo (atomic lock and release) */
        retCode = GetNewPermitKey (&newPermitKey);
        if (retCode)
            return retCode;
        pdInfo->pKey = newPermitKey;

        /* store pdInfo*/
        retCode =  OpenDatabase(PdDb, &db, &lockdb);
        if (retCode)
            return pDbOpenErr;

        retCode = StoreDbRecord(db, pdInfo->pName, (char *)pdInfo, sizeof(PdInfo));
        CloseDatabase(db,lockdb);
        if (retCode < 0)
            return pDbWriteErr;

    }
    else
    {  /* don't save permitDescriptor */
        retCode =  OpenDatabase(PdDb, &db, &lockdb);
        if (retCode)
            return pDbOpenErr;
        retCode = RemoveDbRecord( db, pdInfo->pName);
        CloseDatabase(db,lockdb);
        if (retCode < 0)
            return pDbWriteErr;
    }

    /* fix permit descriptor crossindex references */
    retCode =  OpenDatabase(CxDb, &db, &lockdb);
    if (!retCode)
    {
        /* crossindex new permit entry */
        if (savePD)
            CrossIndexPermitDescriptor(db,pdInfo);

        /* key = _oldpermitKey */
        SetIdKey(dbKey,"PKEY",oldPermitKey);
        RemoveDbRecord(db,dbKey);

        /* remove service_P entry */
        SetIdKey(dbKey, pdInfo->pName, 'P');
        RemoveDbRecord(db,dbKey);

        /* remove service_R entry */
        SetIdKey(dbKey, pdInfo->pName, 'R');
        RemoveDbRecord(db,dbKey);

        CloseDatabase(db,lockdb);
    }

    return pSuccess;
}


/* ----------------------------------------------------------------- */
int DbChangeOwner (PdInfo * pdInfo, char * newOwner)
{
    GDBM_FILE db;
    int    lockdb;  /* db lockfile */
    int    retCode;
    char   oldNetID[MAXIDLEN];
    char dbKey[MAXIDLEN+2];      /* netid index for cross index database */

    ENTERING("DbChangeOwner",CUSSP_APP);
    strcpy(oldNetID,pdInfo->owner);
    strcpy(pdInfo->owner, newOwner);

    /* store pdInfo*/
    retCode =  OpenDatabase(PdDb, &db, &lockdb);
    if (retCode)
        return pDbOpenErr;

    retCode = StoreDbRecord(db, pdInfo->pName, (char *)pdInfo, sizeof(PdInfo));
    CloseDatabase(db,lockdb);
    if (retCode < 0)
        return pDbWriteErr;
    else
    {

        /* update cross index */
        retCode =  OpenDatabase(CxDb, &db, &lockdb);
        if (!retCode)
        {
            /* add to cross index of new netid_O */
            SetIdKey(dbKey,pdInfo->owner,'O');

            cuwa_trace( "owner cross index add, key= %s, pName= %d\n",
                        dbKey,pdInfo->pKey);
            CrossIndexAdd(db, dbKey, (char *)&(pdInfo->pKey), sizeof(pdInfo->pKey));

            /* delete from cross index of old netid_O */
            SetIdKey(dbKey,oldNetID,'O');

            cuwa_trace( "owner cross index delete, key= %s, pName= %d\n",
                        dbKey,pdInfo->pKey);
            CrossIndexDelete(db, dbKey, (char *)&(pdInfo->pKey), sizeof(pdInfo->pKey));
            CloseDatabase(db,lockdb);
        }
    }
    return pSuccess;
}


/* ----------------------------------------------------------------- */
int DbChFriendly (PdInfo * pdInfo, char * newFriendly)
{
    GDBM_FILE db;
    int    lockdb;  /* db lockfile */
    int    retCode;

    ENTERING("DbChFriendly",CUSSP_APP);
    /* Check length of new name */
    if (strlen(newFriendly) > PNAMELEN)
    {
        return pInfoTooLong;
    }

    strcpy(pdInfo->friendlyName, newFriendly);

    /* store pdInfo*/
    retCode =  OpenDatabase(PdDb, &db, &lockdb);
    if (retCode)
        return pDbOpenErr;

    retCode = StoreDbRecord(db, pdInfo->pName, (char *)pdInfo, sizeof(PdInfo));

    CloseDatabase(db,lockdb);
    if (retCode < 0)
        return pDbWriteErr;
    else
        return pSuccess;
}


/* ----------------------------------------------------------------- */
int DbChCutOff (PdInfo * pdInfo, time_t * newdate)
{
    GDBM_FILE db;
    int    lockdb;  /* db lockfile */
    int    retCode;

    ENTERING("DbChCutOff",CUSSP_APP);
    /* Check length of new name */

    memcpy(&pdInfo->cut_off, newdate, sizeof(newdate));

    /* store pdInfo*/
    retCode =  OpenDatabase(PdDb, &db, &lockdb);
    if (retCode)
        return pDbOpenErr;

    retCode = StoreDbRecord( db, pdInfo->pName, (char *)pdInfo, sizeof(PdInfo));

    CloseDatabase(db,lockdb);
    if (retCode < 0)
        return pDbWriteErr;
    else
        return pSuccess;
}


/* ----------------------------------------------------------------- */
int DbChangeAcl (PdInfo * pPdInfo, char * pszNetID, char * pszIndexTypeS, int iAction)
{
    GDBM_FILE pDb;
    int iLockDb;  /* db lockfile */
    int iRetCode;
    char szDbKey[MAXIDLEN+2];      /* netid index for cross index database */
    char * pszDbKey = szDbKey;
    char * pszPos;
    char * pszAcl;
    int iAclLen;
    short iIndexType;  /* converted indexTypeS */

    ENTERING("DbChangeAcl", CUSSP_APP);


    cuwa_trace( "ChangeACL, index=%c\n", *pszIndexTypeS);

    /* update Acl */
    switch (*pszIndexTypeS)
    {
    case 'L':  /* lookup */
    case 'l':
        pszAcl = pPdInfo->idLookupACL;
        iIndexType = 'L';
        break;

    case 'U':  /* update */
    case 'u':
        pszAcl = pPdInfo->idUpdateACL;
        iIndexType = 'U';
        break;

    case 'A':  /* admin */
    case 'a':
        pszAcl = pPdInfo->pdAdminACL;
        iIndexType = 'A';
        break;

    default:
        return pBadAclCode;
    }

    if (iAction)
    {  /* add to Acl */
        iAclLen = strlen(pszAcl);
        if (iAclLen + strlen(pszNetID) > ID_ACLLEN)
            return pInfoTooLong;


        cuwa_trace("ChangeACL add, len=%d\n", iAclLen);

        pszAcl += iAclLen;
        if (!iAclLen)
        {
            *pszAcl = ':';
            pszAcl++;
        }

        strcpy(pszAcl, pszNetID);
        pszAcl += strlen(pszNetID);
        *pszAcl = ':';
    }
    else
    {  /* delete */

        cuwa_trace("ChangeACL delete, acl=%s\n", pszAcl);

        memset(szDbKey, '\0', sizeof(szDbKey));
        *pszDbKey = ':';
        pszDbKey++;
        strcpy(pszDbKey, pszNetID);
        pszDbKey += strlen(pszNetID);
        *pszDbKey = ':';
        pszPos = (char *)strstr(pszAcl, szDbKey);


        cuwa_trace( "ChangeACL delete, key=%s (0x%x)\n", szDbKey,
                    (unsigned int)pszPos);

        if (pszPos)
        { /* shift rest of Acl over old netid */
            pszAcl = pszPos + strlen(pszNetID)+1;
            while ((*pszPos++ = *pszAcl++) != '\0');
        }
    }

    /* store pdInfo*/
    iRetCode =  OpenDatabase(PdDb, &pDb, &iLockDb);
    if (iRetCode)
        return pDbOpenErr;

    iRetCode = StoreDbRecord(pDb, pPdInfo->pName, (char *)pPdInfo, sizeof(PdInfo));
    CloseDatabase(pDb, iLockDb);
    if (iRetCode < 0)
        return pDbWriteErr;
    else
    {

        /* update cross index */
        iRetCode =  OpenDatabase(CxDb, &pDb, &iLockDb);
        if (!iRetCode)
        {
            /* update cross index of netid */
            SetIdKey(szDbKey, pszNetID, iIndexType);

            cuwa_trace( "owner cross index, key= %s, pName= %d\n",
                        szDbKey, pPdInfo->pKey);

            if (iAction)  /* add to cross index */
                CrossIndexAdd(pDb, szDbKey, (char *)&(pPdInfo->pKey), sizeof(pPdInfo->pKey));
            else  /* delete */
                CrossIndexDelete(pDb, szDbKey, (char *)&(pPdInfo->pKey), sizeof(pPdInfo->pKey));

            /* replace _# cross index for permitName */
            SetIdKey(szDbKey,"PKEY",pPdInfo->pKey);
            iRetCode = StoreDbRecord(pDb, szDbKey, (char *)pPdInfo, sizeof(PdInfo));
            CloseDatabase(pDb,iLockDb);
        }
    }
    return pSuccess;
}


/* ----------------------------------------------------------------- */
int DbChangeMode (PdInfo * pdInfo, short indexType, int actVal)
{
    GDBM_FILE db;
    int  lockdb;  /* db lockfile */
    int  retCode;
    char dbKey[MAXIDLEN+2];      /* netid index for cross index database */
    // time_t nnow;

    ENTERING("DbChangeMode",CUSSP_APP);
    cuwa_trace("ChangeMode, index=%c, act=%d\n",indexType,actVal);
    cuwa_trace("pName=%s, master=%s\n", pdInfo->pName,MASTERPERMIT);

    switch (indexType)
    {
    case 'V':  /* visible */
    case 'v':
        /* visible field of master pdInfo used to store next unique # */
        if (strcmp(pdInfo->pName,MASTERPERMIT)==0)
            return pBadModeCode;
        pdInfo->visible = actVal;
        break;
    case 'P':  /* public */
    case 'p':
        pdInfo->public = actVal;
        break;
    case 'L':  /* largeList */
    case 'l':
        pdInfo->largeList = actVal;
        break;
    default:
        return pBadModeCode;
    }

    /* store pdInfo*/
    retCode =  OpenDatabase(PdDb, &db, &lockdb);
    if (retCode)
        return pDbOpenErr;

    retCode = StoreDbRecord(db, pdInfo->pName, (char *)pdInfo, sizeof(PdInfo));
    CloseDatabase(db,lockdb);
    if (retCode < 0)
        return pDbWriteErr;
    else
    {

        /* update cross index */
        retCode =  OpenDatabase(CxDb, &db, &lockdb);
        cuwa_trace("ret=%d\n",retCode);
        if (!retCode)
        {
            /* replace _# cross index for permitName */
            SetIdKey(dbKey,"PKEY",pdInfo->pKey);
            retCode = StoreDbRecord(db, dbKey, (char *)pdInfo, sizeof(PdInfo));
            CloseDatabase(db,lockdb);
        }
    }
    return pSuccess;
}
