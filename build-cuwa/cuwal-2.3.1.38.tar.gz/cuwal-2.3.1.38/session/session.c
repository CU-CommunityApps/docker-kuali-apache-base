/************************************************************************

 * session.c -- session manager for CUWebAuth
 *
 * Copyright 2007 Cornell University.
 * All Rights Reserved.
 *
 ************************************************************************
 */
#include <session.h>
#include <stdlib.h>
#include <stdio.h>
#include <cred.h>
#include <cred_getput.h>
#include <cred_session.h>
#include <cred_base64.h>
#include <log.h>
#include <cuwarand.h>
#include <apr_strings.h>
#include <cuwa_malloc.h>
#include <kutil.h>
#include <wal.h>
#include <cuwa_parse.h>
#include <session_file.h>
#include <sha1.h>
#include <sys/types.h>
#include <sspiutil.h>
#include <permit_cache.h>
#include <util.h>
#include <cred_krb.h>
#include <highAvail.h>
#include <permit_ha.h>
#include <impersonate.h>

#include "../autoconfig.h"
#ifdef HAVE_UNISTD_H
#include <unistd.h>
#endif
#define CUWA2_LOG_DOMAIN cuwa.session

#define CUWA_SESSION_HEADER "#!/bin/cat\n"

#define CUWA_SESSION_VERSION "3"

#define CUWA_SESSION_SID   "CUWA_SID"
#define CUWA_TWO_FACTOR_OPT_IN "CIT-optin-twofactor"

#define CUWA_SESSION_CHECK_IMPERSONATE_RATE  600  //every 10 minutes
#define CUWA_SESSION_MINIMUM_EXIST_TIME 300

#define CUWA_SESSION_READ_HEADER(pFile) do {                           \
 apr_size_t len = strlen(CUWA_SESSION_HEADER);                         \
 char *header = cuwa_malloc(len);                                      \
 apr_status_t rv;                                                      \
 cuwa_assert(header);                                                  \
 rv = apr_file_read(pFile, header, &len);                              \
 cuwa_free(header);                                                    \
 FAIL_IF_FILE_ERROR( rv );                                             \
 }while(0)

static cuwa_err_t cuwa_session_flush( cuwa_session_t *session );
static cuwa_err_t cuwa_session_impersonate( void *request, cuwa_session_t *session, char *serviceName, char *keytab );
static cuwa_err_t cuwa_session_impersonate_verify( void *request, cuwa_session_t *session, char *serviceName, char *keytab );

/**
 * cuwa_session_get_inactivity_timeout return inactivity timeout value.
 * Internal function
 */
static int cuwa_session_get_inactivity_timeout(CUWACfg_t *cfg)
{
    int *timeout = NULL;
    int inactivityTimeout = -1;

    cuwa_trace("In cuwa_session_get_inactivity_timeout");

    timeout =  CFG_CUWAinactivityTimeout(cfg);
    if ( timeout )
    {
        inactivityTimeout = *timeout;
    }
    cuwa_trace("cuwa_session_get_inactivity_timeout return %d", inactivityTimeout);

    return inactivityTimeout;
}

/**
 * cuwa_session_get_max_session_size return maximum session size value.
 * Internal function
 */
static int cuwa_session_get_max_session_size(CUWACfg_t *cfg)
{
    int *maxSessionSize = NULL;
    int size = 0;

    cuwa_assert(cfg);

    maxSessionSize =  CFG_CUWAmaxSessionSize(cfg);
    if ( maxSessionSize )
    {
        size = (*maxSessionSize);        //max session size is in bytes
    }

    return size;
}

/**
 * cuwa_session_get_use_primary_file_name allocate memory and return .pri filename for session
 * INTERNAL to session manager
 * @param[in] pool used for memory allocation.
 * @param[in] path session file name
 * @param[out] fileName.
 */
void cuwa_session_get_primary_file_name( apr_pool_t *pool, char *path, char **fileName )
{
    *fileName = apr_psprintf(pool,"%s.%s", path,"pri");
}

static cuwa_err_t cuwa_session_hash_sid( cuwa_session_t *session, uint64 *newSid )
{
    cuwa_err_t sts = CUWA_OK;
    char *sidStr = apr_psprintf(session->pool, "%16qX", session->sessionID);
    SHA1Context ctx;

    SHA1Reset(&ctx);

    SHA1Input(&ctx,(unsigned char*)"3.14159265358",12);
    SHA1Input(&ctx,(unsigned char*)sidStr,16);
    SHA1Input(&ctx,(unsigned char*)"1.4142135623",12);

    if(!SHA1Result(&ctx)) 
    {
        cuwa_warning("hash sid failed");
        sts = CUWA_ERR_SESSION_SHA1;
    }
    else
        *newSid = ((((apr_uint64_t)(ctx.Message_Digest[0])) << 32) | ((apr_uint64_t)(ctx.Message_Digest[1])));
    
    cuwa_trace("hashed sid=%llX",*newSid); 
    return sts;
}


/**
 * cuwa_session_get_session_file_path return the file name for primary session including path.
 * if CUWASessionPath is not defined, session file will be stored in default directory
 * Internal function.
 */
cuwa_err_t cuwa_session_get_session_file_path(char **pathOut, cuwa_session_t *session, int idToUse)
{
    char *filename = NULL;
    char *path;
    cuwa_err_t sts = CUWA_OK;
 
    //determin where the session files should store
    filename =  CFG_CUWAsessionFilePath(session->cfg);
    if ( filename )
    {
         path = apr_psprintf( session->pool, "%s", filename);
    }
    //if CUWASessionPath is not defined, write session file to /tmp
    else
    {
        cuwa_trace("CUWASessionPath is not defined, use tmp directory");
        cuwa_assert(session->pool);
        path = apr_psprintf( session->pool, "%s",CUWA_SESSION_DEFAULT_PATH);
    }
    if ( (idToUse == CUWA_SESSION_FILE_UNKNOWN ) ||
         (idToUse == CUWA_SESSION_FILE_SESSION_ID ) )
    {
        *pathOut = apr_psprintf(session->pool, "%s/%qX", path,session->sessionID );

        session->encrypt = CUWA_SESSION_ENCRYPTION_NO;
        if ( idToUse == CUWA_SESSION_FILE_UNKNOWN )
        {
            apr_status_t code;
            char *priFile;
            apr_finfo_t  finfo; 
 
            cuwa_session_get_primary_file_name( session->pool, *pathOut, &priFile );

            //check if session file using sessionID exist on disk. If not, hash file name to check
            code = apr_stat(&finfo, priFile,APR_FINFO_SIZE|APR_FINFO_LINK, session->pool);
            if ( code )
                idToUse = CUWA_SESSION_FILE_ENCRYPTED_ID;
        } 
    }           

    if ( idToUse == CUWA_SESSION_FILE_ENCRYPTED_ID )
    {
        uint64 newId = 0;

        sts = cuwa_session_hash_sid( session, &newId );

        if ( sts == CUWA_OK )
        {
            *pathOut = apr_psprintf( session->pool, "%s/%qX", path, newId);
  
            session->encrypt = CUWA_SESSION_ENCRYPTION_YES;
        }
    }
   return sts;
}

/**
 * cuwa_session_dump print out the primary session data. This function is for debuging purpose
 *
 * @param[in] session: the session.
 */
static void cuwa_session_dump( cuwa_session_t *session )
{
    if ( session )
    {
        cuwa_trace("***** dumping session data *****");
        cuwa_trace("sessionID: 0x%llX", session->sessionID );
        cuwa_trace("sessionKey:0x%llX", session->sessionKey );
        cuwa_trace("State: %d", session->state );
        cuwa_trace("End time:%u", (int)session->endTime );
        cuwa_trace("impersonated:%d", session->impersonated);
        {
            // Had to put this code in to satisfy the test harness :-)
            char *k3 = cuwa_session_get_attribute(session,"CUWA_K3",0)
            if ( k3) cuwa_trace("k3:%s", k3);
        }

        if ( session->permitList )
            cuwa_trace("CachedPermits:%s", session->permitList);

        if ( session->proxyTable )
        {
            //write proxy table
            const apr_array_header_t *arr = apr_table_elts( session->proxyTable);
            const apr_table_entry_t *elts = (const apr_table_entry_t *)arr->elts;
            int i;

            for (i=0; i < arr->nelts; i++ )
            {
                cuwa_trace("write proxy:key=%s,value=%s",elts[i].key,elts[i].val);
            }
        }

        cuwa_trace("***** dump done *****");
   }
}

/**
 * cuwa_session_clear remove all the data in session.
 *
 * @param[in] session: the session.
 * @return NONE
 */
static void cuwa_session_clear( cuwa_session_t *session )
{
    if ( session )
    {

        if (session->cred) cuwa_cred_release( session->cred );

        cuwa_trace("Clear session data");

        session->sessionID = 0;
        session->save = 0;
        session->endTime = 0;
        session->state = 0;
        session->sessionKey = 0;

        if ( session->proxyTable)
        {
            apr_table_clear( session->proxyTable );
            session->proxyTable = NULL;
        }

        if ( session->proxyCookiesTable)                                                                                                            
        {                                                                                                                                    
            apr_table_clear( session->proxyCookiesTable );                                                                                          
            session->proxyCookiesTable = NULL;                                                                                                      
        }  
    }
}

/**
 * cuwa_session_from_file populate data in session field by reading session data from from session file
 *
 * @param[in] session: the session.
 * @return CUWA_OK or CUWA_ERR_MEM CUWA_ERR_SESSION_NOT_FOUND CUWA_ERR_SESSION_DB_ERR
 */
static cuwa_err_t cuwa_session_restore_from_file( cuwa_session_t *session )
{
    apr_status_t rv;
    cuwa_err_t rc = CUWA_OK;
    apr_file_t *pFile = NULL;
    char *version = NULL;

    cuwa_trace("In cuwa_session_restore_from_file");
    rv = apr_file_open( &pFile, session->sessionFile, APR_READ, APR_UREAD|APR_UWRITE, session->pool );
    if ( rv == APR_SUCCESS )
    {
        //read header
        CUWA_SESSION_READ_HEADER( pFile );

        //read session verion
        CUWA_SESSION_READ_STRING( pFile, &version );
        cuwa_trace("read session cache version = %s", version );
    
        //session files that have different version number might have different format, so don't use it  
        FAIL_IF( strcmp(version,CUWA_SESSION_VERSION), CUWA_ERR_SESSION_NOT_FOUND );

        //read session state
        CUWA_SESSION_READ_NUM( pFile, session->state );
        cuwa_trace("read session state return status=%d, state=0x%x", rv, session->state);

        //read key
        CUWA_SESSION_READ_NUM( pFile,session->sessionKey );
        cuwa_trace("read sessionKey, status=%d, key=0x%llX", rv, session->sessionKey);

        //read endTime
        CUWA_SESSION_READ_NUM( pFile, session->endTime );
        cuwa_trace("read session endtime return status=%d, endtime=%u", rv, session->endTime);

        if ( session->state & CUWA_SESSION_ACTIVE )
        {

            if ( session->state & CUWA_SESSION_HAS_PERMIT )
            {
                //read permit list
                CUWA_SESSION_READ_STRING( pFile, &session->permitList );
                cuwa_trace("read session permitList=%s", session->permitList);
            }

            rc = cuwa_session_read_table( session->pool, pFile, &session->proxyTable );
            FAIL_IF(rc,rc);

            rc = cuwa_session_read_table( session->pool, pFile, &session->proxyCookiesTable );
            FAIL_IF(rc,rc);

            rc = cuwa_cred_deserialize( session->pool, &session->cred, pFile );
            FAIL_IF(rc,rc);

            //read impersonated
            if ( atoi(version) > 2 )
            {
                CUWA_SESSION_READ_NUM( pFile, session->impersonated );
                CUWA_SESSION_READ_NUM( pFile, session->impersonate_verfiy_time);
            }
        }
        cuwa_session_dump( session );
    }
    else
        rc = CUWA_ERR_SESSION_NOT_FOUND;

cleanup:
    if (pFile)
        apr_file_close(pFile);

    cuwa_trace("cuwa_session_restore_from_file return status %d", rc);
    return rc;
}

/**
 * cuwa_session_get_use_file_name allocate memory and return .use filename for session
 * INTERNAL to session manager
 * @param[in] pool used for memory allocation.
 * @param[in] path session file name
 * @param[out] fileName.
 */
void cuwa_session_get_use_file_name( apr_pool_t *pool, char *path, char **fileName )
{
    *fileName = apr_psprintf(pool,"%s.%s", path,"use");
}

/**
 * cuwa_session_get_req_file_name allocate memory and return .req filename for session
 * INTERNAL to session manager
 * @param[in] pool used for memory allocation.
 * @param[in] path session file name
 * @param[out] fileName.
 */
void cuwa_session_get_req_file_name( apr_pool_t *pool, char *path, char **fileName )
{
    *fileName = apr_psprintf(pool,"%s.%s", path,"req");
}


/**
 * cuwa_session_delete delete sessions on disk due to session expired
 * @param[in] session: the session that needs to verify
 */
static void cuwa_session_delete( cuwa_session_t *session )
{
    cuwa_trace("In cuwa_session_delete");

    //remove all files associated with this session
    apr_file_remove( session->sessionFile, session->pool );

    apr_file_remove( session->useFile, session->pool );

    apr_file_remove( session->reqFile, session->pool );

    cuwa_trace("done delete session");
}

/*
 * cuwa_session_get_access_time returns last modified time of the file
 *
 * @param[in] file - the file to check.
 * @param[in] pool - pool to use
 * @param[out] access_time.
 * @return CUWA_OK, CUWA_ERR
 */
cuwa_err_t cuwa_session_get_access_time( char *file, apr_pool_t *pool, apr_time_t *mtime )
{
    apr_status_t code;
    apr_finfo_t  finfo;
    cuwa_err_t rc = CUWA_OK;

    code = apr_stat(&finfo,file,APR_FINFO_MTIME|APR_FINFO_LINK, pool);
    FAIL_IF_FILE_ERROR( code );

    if (finfo.mtime<=0)
    {
        cuwa_warning("invalid modified time stamp for %s", file);
        rc = CUWA_ERR_SESSION_DB_ERR;
    }
    else
        *mtime = apr_time_sec(finfo.mtime);

cleanup:

    return rc;
}

cuwa_err_t cuwa_session_get_access_time_uid( char *file, apr_pool_t *pool, apr_time_t *mtime, apr_uid_t *uid )
{
    apr_status_t code;
    apr_finfo_t  finfo;
    cuwa_err_t rc = CUWA_OK;

    code = apr_stat(&finfo,file,APR_FINFO_MTIME|APR_FINFO_LINK, pool);
    FAIL_IF_FILE_ERROR( code );

    if (finfo.mtime<=0)
    {
        cuwa_warning("invalid modified time stamp for %s", file);
        rc = CUWA_ERR_SESSION_DB_ERR;
    }
    else
    {
        *mtime = apr_time_sec(finfo.mtime);
        *uid = finfo.user;
    }

cleanup:

    return rc;
}

/**
 * cuwa_session_validate valify if the session is valid
 *
 * @param[in] session: the session that needs to verify
 * @param[in] sessionKey: sessionKey
 * @return CUWA_OK or CUWA_ERR_SESSION_EXPIRED or CUWA_ERR_SESSION_INVALID
 */
static cuwa_err_t cuwa_session_validate( cuwa_session_t *session, uint64 sessionKey )
{
    cuwa_err_t status = CUWA_OK;
    apr_time_t now = apr_time_sec( apr_time_now() );
    int inactivityTimeout;

    cuwa_assert( session );
    inactivityTimeout = session->inactivityTimeout;
    cuwa_trace("In cuwa_session_validate, currTime=%u, endTime=%u, inactivityTimeout=%d",(int)now, (int)session->endTime, inactivityTimeout);

    if ( !(session->state & CUWA_SESSION_ACTIVE) )
    {
        cuwa_trace("cuwa_session_validate state err: %d", session->state);
        status = CUWA_ERR_SESSION_INVALID;
    }
    else if ( session->sessionKey != sessionKey )
    {
        cuwa_trace("cuwa_session_validate sessionkey err: 0x%llX 0x%llX", session->sessionKey,sessionKey);
        status = CUWA_ERR_SESSION_INVALID;
    }
    else if ( now > session->endTime )
    {
        status = CUWA_ERR_SESSION_EXPIRED;
    }
    else if ( inactivityTimeout >= 0 )
    {
        apr_time_t lastAccess;

        //get last access time
        status = cuwa_session_get_access_time( session->sessionFile, session->pool, &lastAccess );

        if ( status == CUWA_OK )
        {
           cuwa_trace("now=%u,lastAccess=%u,timeout=%d",(int)now, (int)lastAccess, inactivityTimeout);
           if ( now > lastAccess +inactivityTimeout )
           {
               status = CUWA_ERR_SESSION_EXPIRED;
           }
        }	
    }
    cuwa_trace("cuwa_session_validate return status:%d", status);
    return status;
}

static uint64 cuwa_session_random()
{
    uint64 random=cuwa_rand64_g();

    cuwa_trace("random number generated 0x%llX", random);
    return random;
}


/**
 * cuwa_session_setup setup inactivityTimeout,maxSessionSize,sessionFile,useFile and reqFile fields in session
 *
 * @param[in] session the session.
 * idToUse: 0  unknow
 *          1  sessionID
 *          2  encryptedID 
 */
static cuwa_err_t cuwa_session_setup( cuwa_session_t *session, int idToUse)
{
    char *path;
    cuwa_err_t status = CUWA_OK;

    status = cuwa_session_get_session_file_path( &path, session , idToUse);

    session->maxSessionSize = cuwa_session_get_max_session_size( session->cfg );
    session->inactivityTimeout = cuwa_session_get_inactivity_timeout( session->cfg );
    session->encryptionCtx = NULL;
    session->noneEncryptDataLen = 0;
    session->encryptedLen = 0;
    cuwa_session_get_primary_file_name( session->pool, path, &session->sessionFile );
    cuwa_session_get_use_file_name( session->pool, path, &session->useFile );
    cuwa_session_get_req_file_name( session->pool, path, &session->reqFile );

    return status;
}

/**
 * cuwa_session_new creates a new session. The new session is initialized as
 *  - Generates a sessionID
 *  - Generates a sessionKey
 *  - Sets the AccessTime=now,
 *  - Sets the state attribute to CUWA_SESSION_NEW
 *
 * @param[in] pool: pool used for apr memory allocaiton.
 * @param[in] cfg config contex
 * @param[out] session: the newly created session. Caller must call cuwa_session_release to release session if function succeed
 * @return CUWA_OK or CUWA_ERR_MEM
 */
cuwa_err_t cuwa_session_new( void *request, apr_pool_t *pool, CUWACfg_t *cfg, cuwa_session_t **session)
{
    cuwa_err_t status = CUWA_OK;
    cuwa_session_t *newSession = NULL;

    cuwa_trace("In cuwa_session_new");
    newSession = (cuwa_session_t *)apr_pcalloc( pool, sizeof(cuwa_session_t) );

    if ( !newSession )
    {
        status = CUWA_ERR_MEM;
    }
    else
    {
        newSession->save = CUWA_SESSION_SAVE_PRIMARY | CUWA_SESSION_SAVE_ACCESS;
        newSession->sessionID = cuwa_session_random();
        newSession->sessionKey = cuwa_session_random();
        newSession->endTime = apr_time_sec(apr_time_now()) + CUWA_SESSION_DEFAULT_TIMEOUT;
        newSession->state = CUWA_SESSION_NEW;
        newSession->pool = pool;
        newSession->cfg = cfg;
        newSession->sessionSize = 0;

        cuwa_wal_note_set( request, CUWA_SESSION_SID, apr_psprintf(pool,"%qX",newSession->sessionID) );

        cuwa_session_setup( newSession, CUWA_SESSION_FILE_SESSION_ID );

        cuwa_session_dump( *session );
    }

    *session = newSession;

    cuwa_trace("cuwa_session_new return status %d", status);
    return status;
}


/**
 * cuwa_session_open_request open the request file for reading or writing
 *
 * @param[in] session: the session.
 * @param[in] write: ==1 if the file should be open for writing, otherwise it is opened for read access
 * @return CUWA_OK, CUWA_ERR_SESSION_NOT_FOUND (write==0 only), CUWA_ERR_SESSION_DB_ERR
 */
cuwa_err_t cuwa_session_open_request( cuwa_session_t *session, int write)
{
    apr_file_t *pFile;
    apr_status_t rv;
    cuwa_err_t rc = CUWA_OK;

    cuwa_trace("In cuwa_session_open_request");
    cuwa_assert( session );

    cuwa_trace("ready to open request file %s for %s", session->reqFile, write? "write":"read");

    if ( write )
    {
        cuwa_session_garbage_collect( session, 0 );

        //open request file for write
        rv = apr_file_open( &pFile, session->reqFile, APR_WRITE|APR_CREATE, APR_UREAD|APR_UWRITE, session->pool );
       //write header
       if ( !rv )
       {
           apr_size_t len = strlen(CUWA_SESSION_HEADER);
           rv = apr_file_write( pFile, CUWA_SESSION_HEADER, &len);

           while ( APR_STATUS_IS_ENOSPC(rv))
           {
               //file system probably is full, do garbage collection
               apr_file_close( pFile );
               if (cuwa_session_garbage_collect( session, 1 ))
                   break;

               //try again
               cuwa_trace("Try write header for request file again");
               rv = apr_file_open( &pFile, session->reqFile, APR_WRITE|APR_CREATE, APR_UREAD|APR_UWRITE, session->pool );
               if (!rv)
               {
                   len =  strlen(CUWA_SESSION_HEADER);
                   rv = apr_file_write( pFile, CUWA_SESSION_HEADER, &len);
               }
           }
       }
    }
    else
    {
        rv = apr_file_open( &pFile, session->reqFile, APR_READ, APR_UREAD|APR_UWRITE, session->pool );
        //read header and discard
        if (!rv )
        {
            CUWA_SESSION_READ_HEADER( pFile );
        }
    }

    FAIL_IF_FILE_ERROR( rv );

cleanup:

    if ( rc == CUWA_ERR_SESSION_NOT_FOUND )
    {
        cuwa_warning("session not found:%s", session->reqFile);
        CUWA_SHOW_APR_ERROR(rv);
    }

    if (!rv)
    {
        //succeed
        session->reqFH = pFile;
        cuwa_trace("open request file %s succeed", session->reqFile);
    }
    else
        session->save = CUWA_SESSION_REMOVE;

    cuwa_trace("cuwa_session_open_request return status %d", rc);
    return rc;
}

    
/**
 * cuwa_session_read_request read bytes from the request file
 *
 * @param[in] session: the session.
 * @param[in] buf pointer to where bytes are written
 * @param[in/out] count on entry number of bytes requested, exit number of bytes actually read.
 * @return CUWA_OK, CUWA_ERR_SESSION_DB_ERR, CUWA_ERR_SESSION_EOF
 */
cuwa_err_t cuwa_session_read_request( cuwa_session_t *session, char *buf, apr_size_t *count)
{
    apr_file_t *pFile = NULL;
    apr_status_t rv = 0;
    cuwa_err_t rc = CUWA_OK;
    char *p = buf;

    cuwa_trace("In cuwa_session_read_request,read %d bytes", *count);
    cuwa_assert(session);

    pFile = session->reqFH;
    cuwa_assert( pFile );

    if ( session->encrypt == CUWA_SESSION_ENCRYPTION_NO )
    {
        rv = apr_file_read_full( pFile, buf, *count, count );
        FAIL_IF_FILE_ERROR( rv );
    }
    else
    {
        apr_size_t dataRead = 0;
        int dataRequested = *count;
 
        if ( session->noneEncryptDataLen > 0 ) 
        {
            dataRead = ( session->noneEncryptDataLen > dataRequested )? dataRequested: session->noneEncryptDataLen;

            cuwa_trace("Read none encrypted data:%d", dataRead);
            //we have none encrypted data, let's read that first
            rv = apr_file_read_full( pFile, buf, dataRead, &dataRead );
            FAIL_IF_FILE_ERROR( rv );

            session->noneEncryptDataLen = session->noneEncryptDataLen - dataRead; 
            p += dataRead;
        }

        if ( dataRead < dataRequested )
        {
            apr_size_t dataToRead = dataRequested - dataRead;

            //we now need to read encrypted data
            rc = cuwa_session_encryption_read( session, p, &dataToRead );
            if ( rc ) goto cleanup;

            dataRead += dataToRead; 
            buf[dataRead] = '\0';

            cuwa_trace("%d bytes of Data returned", dataRead);
        }
        *count = dataRead;
  }

cleanup:
    if ( rv == APR_EOF )
        rc = CUWA_ERR_SESSION_EOF;

    if (!rv)
        buf[*count] = '\0';
    else
        session->save = CUWA_SESSION_REMOVE;

    //cuwa_trace("cuwa_session_read_request return %d", rc);
    return rc;
}

cuwa_err_t cuwa_session_do_write( cuwa_session_t *session, char *buf, int count)
{
     cuwa_err_t rc = CUWA_OK;
     apr_file_t *pFile = NULL;
     apr_status_t rv;
     apr_size_t bytesWritten = count;
     apr_off_t size;

     pFile = session->reqFH;
     cuwa_assert( pFile );

     rv = apr_file_write( pFile, buf, &bytesWritten);

     while(  APR_STATUS_IS_ENOSPC(rv) )
     {
        apr_file_close( pFile );
        cuwa_trace("force garbage collection");
        if (cuwa_session_garbage_collect( session, 1 ))
            break;

        cuwa_trace("rewrite request again");
        rv = apr_file_open( &pFile, session->reqFile, APR_WRITE|APR_CREATE, APR_UREAD|APR_UWRITE, session->pool );
        FAIL_IF_FILE_ERROR( rv );

        session->reqFH = pFile;

        //calculate the total bytes we have written to the file previously
        size = session->sessionSize + strlen(CUWA_SESSION_HEADER);

        rv = apr_file_seek( pFile, APR_CUR, &size );
        FAIL_IF_FILE_ERROR( rv );

        bytesWritten = count;
        rv = apr_file_write( pFile, buf, &bytesWritten);
    }

    FAIL_IF_FILE_ERROR( rv );

    if ( bytesWritten != count )
        rc = CUWA_ERR_SESSION_WRITE_INCOMPLETE;

cleanup:
    if ( rc )
        session->save = CUWA_SESSION_REMOVE;

    return rc;
}

/**
 * cuwa_session_write_request write bytes from the request file
 *
 * @param[in] session: the session.
 * @param[in] buf pointer to bytes to be written to the file
 * @param[in] count number of bytes to write.
 * @param[in] doEncryption encrypt data before written to disk or not
 * @return CUWA_OK, CUWA_ERR_SESSION_DB_ERR
 */
cuwa_err_t cuwa_session_write_request( cuwa_session_t *session, char *buf, int count, int doEncryption)
{
    cuwa_err_t rc = CUWA_OK;

    cuwa_assert(session);

    if ( session->maxSessionSize )
    {
        //check is request size exceed maximum session size
         if ( session->sessionSize + count > session->maxSessionSize )
        {
            rc = CUWA_ERR_SESSION_EXCEED_MAX_SESSION;
            goto cleanup;
        }
    }

    session->sessionSize += count;

    if ( doEncryption )
    {

        rc = cuwa_session_encryption_write( session, buf, count );
    }   
    else
    {
        rc = cuwa_session_do_write( session, buf, count);
        session->noneEncryptDataLen += count;
    }

cleanup:
    if ( rc )
        session->save = CUWA_SESSION_REMOVE;

    return rc;
}

/**
 * cuwa_session_close_request close the request file
 *
 * @param[in] session: the session.
 */
void cuwa_session_close_request( cuwa_session_t *session )
{
    apr_file_t *pFile = NULL;

    cuwa_trace("In cuwa_session_close_request");
    cuwa_assert(session);

    pFile = session->reqFH;
    if ( pFile )
    {
        apr_file_close( pFile );
    }
    session->reqFH = NULL;

    cuwa_trace("Done close request" );
}


/**
 * cuwa_session_release releases memory resources associated with a session, and flushed modified data
 *                      to the session database.
 *
 * @param[in] session: the session.
 * @return CUWA_OK, CUWA_ERR_MEM, CUWA_ERR_SESSION_DB_ERR
 *
 */
cuwa_err_t cuwa_session_release( cuwa_session_t *session )
{
    cuwa_err_t status = CUWA_OK;

    cuwa_trace("In cuwa_session_release");

    //If session has already been released, just return
    if ( (!session) || (!session->sessionID) )
        return status;

    cuwa_session_garbage_collect( session, 0);

    status = cuwa_session_flush( session );

    cuwa_session_clear( session );

    cuwa_trace("cuwa_session_release return status %d", status);
    return status;
}

static cuwa_err_t cuwa_session_save_primary( cuwa_session_t *session, char *file )
{
    apr_size_t nbytes;
    apr_status_t rv;
    cuwa_err_t rc = CUWA_OK;
    apr_file_t *pFile = NULL;

    cuwa_trace("About to save primary session data");
    rv = apr_file_open( &pFile, file, APR_WRITE|APR_CREATE, APR_UREAD|APR_UWRITE, session->pool );
    FAIL_IF_FILE_ERROR( rv );

    //flush data to file
    cuwa_trace("ready to flush the primary session data");

    //write a header
    nbytes = strlen(CUWA_SESSION_HEADER);
    rv = apr_file_write( pFile, CUWA_SESSION_HEADER, &nbytes);
    FAIL_IF_FILE_ERROR(rv);

    //write session version
    CUWA_SESSION_WRITE_STRING( pFile, CUWA_SESSION_VERSION);

    //write session state
    CUWA_SESSION_WRITE_NUM( pFile, session->state);

    //write session Key
    CUWA_SESSION_WRITE_NUM( pFile, session->sessionKey);

    //write endTime
    CUWA_SESSION_WRITE_NUM( pFile, session->endTime);

    if ( session->state & CUWA_SESSION_ACTIVE )
    {
        if ( session->state & CUWA_SESSION_HAS_PERMIT )
        {
            //write permit
            cuwa_trace("write permit");
            CUWA_SESSION_WRITE_STRING( pFile, session->permitList );
        }

        rc = cuwa_session_write_table( pFile, session->proxyTable );
        FAIL_IF(rc, rc);

        rc = cuwa_session_write_table( pFile, session->proxyCookiesTable );
        FAIL_IF(rc, rc);

        cuwa_assert(session->cred);
        rc = cuwa_cred_serialize( session->cred, pFile );
        FAIL_IF(rc,rc);

        CUWA_SESSION_WRITE_NUM( pFile, session->impersonated );
        CUWA_SESSION_WRITE_NUM( pFile, session->impersonate_verfiy_time );
    }
    cuwa_trace("Done saving primary session, status=%d", rc);

cleanup:
    if ( pFile )
        apr_file_close( pFile );

    cuwa_trace("cuwa_session_save_primary return status %d", rc);
    return rc;

}

static cuwa_err_t cuwa_session_update_use_file( cuwa_session_t *session )
{
    apr_time_t expireTime;
    cuwa_err_t rc = CUWA_OK;
    apr_file_t *pFile;
    apr_status_t rv;
    apr_time_t mtime;

    cuwa_trace("ready to update accessTime, path=%s", session->useFile);

    if ( cuwa_session_get_access_time(session->useFile,session->pool,&mtime) ==  CUWA_ERR_SESSION_NOT_FOUND )
    {
        rv = apr_file_open( &pFile, session->useFile, APR_WRITE|APR_CREATE, APR_UREAD|APR_UWRITE, session->pool );
        FAIL_IF_FILE_ERROR( rv );

        CUWA_SESSION_WRITE_NUM( pFile, session->sessionSize );
        CUWA_SESSION_WRITE_NUM( pFile, session->noneEncryptDataLen ); 
        CUWA_SESSION_WRITE_NUM( pFile, session->encryptedLen );
        apr_file_close(pFile);
    }

    //if inactivityTimeout is defined, use it to calculate when session is expired. Otherwise use endTime.
    //if inactivityTimeout is defined to 0, administrator means to force user login. In this case, we set
    //the expirationTime of the useFile to endTime. So their session won't be deleted by garbage collection.
    if ( session->inactivityTimeout > 0 )
    {
        //when inactivityTimeout has a low value, it may get deleted before user finish login. we'd keep it for 
        //at least 5 minutes
        if ( session->state == CUWA_SESSION_NEW && session->inactivityTimeout < CUWA_SESSION_MINIMUM_EXIST_TIME )
            expireTime = apr_time_from_sec(CUWA_SESSION_MINIMUM_EXIST_TIME) + apr_time_now();
        else
            expireTime = apr_time_from_sec(session->inactivityTimeout) + apr_time_now();
    }
    else
        expireTime = apr_time_from_sec(session->endTime);

    apr_file_mtime_set( session->useFile,expireTime, session->pool );

    cuwa_trace("update accessTime to %u,inactivityTimeout=%d",(int)expireTime,session->inactivityTimeout);
cleanup:
    return rc;
}

/**
 * cuwa_session_flush flushes changes made to the session to permanent storage.
 *
 * @param[in] session: the session.
 * @return CUWA_OK, CUWA_ERR_MEM, CUWA_ERR_SESSION_DB_ERR
 *
 */
static cuwa_err_t cuwa_session_flush( cuwa_session_t *session )
{
    cuwa_err_t rc = CUWA_OK;

    cuwa_trace("In cuwa_session_flush");
    cuwa_assert( session );

    cuwa_session_dump( session );

    if ( session->save == CUWA_SESSION_REMOVE )
    {
        //there is error condition occur, remove this session
        cuwa_session_delete( session );
    }

    //create primary session file and flush data to the file if savePrimary is true
    if ( session->save & CUWA_SESSION_SAVE_PRIMARY )
    {
        rc = cuwa_session_save_primary( session, session->sessionFile );
        while (rc == CUWA_ERR_SESSION_NO_DISK_SPACE)
        {
            if (cuwa_session_garbage_collect( session, 1 ))
                break;
            rc = cuwa_session_save_primary( session, session->sessionFile );
        }

        //update the modifed timestamp on req session file using endTime,then at the time for garbage collection,
        //we only need to check the time stamp on the session file
        apr_file_mtime_set( session->reqFile,apr_time_from_sec(session->endTime), session->pool);
    }

    //update the time stamp of primay session file so it indicate when the session was last accessed
    apr_file_mtime_set( session->sessionFile, apr_time_now(), session->pool );

    //update access time. The modified timestamp on the useFile indicate when session should expired.
    if ( (rc == CUWA_OK) && ( session->save & CUWA_SESSION_SAVE_ACCESS ) )
    {
        rc = cuwa_session_update_use_file( session );

    }

    cuwa_trace("cuwa_session_flush return status %d", rc);
    return rc;

}


/**
 * cuwa_session_from_credentials given a session cookie and/or a URL credential, will
 * find the associated session record, and
 * the loads the session. cuwa_session_from_credentials validates that the SessionKey in
 * session the session cookie before acceptance.
 *
 * @param[in] pool handle to pool.
 * @param[in] cfg configuration context
 * @param[in] host the URL of this virtual host.
 * @param[in] urlCred(WA) credential string, NULL if one was not attached to the request
 * @param[in] urlCredLen length of the credential string.
 * @param[in] cookie (WA) credential string. NULL if one was not attached to the request
 * @param[in] cookieLen length of the credential string.
 * @param[in] serviceID
 * @param[in] keytab
 * @param[out] session the newly loaded session.  Caller must call cuwa_session_release to release session if function succeed.
 * @return CUWA_OK, CUWA_ERR_MEM, CUWA_ERR_SESSION_NOT_FOUND, CUWA_ERR_SESSION_DB_ERR, CUWA_ERR_BAD_CRED,
 *         CUWA_ERR_KRB, CUWA_ERR_GSS, CUWA_ERR_SESSION_DB_ERR
 */
cuwa_err_t cuwa_session_from_credential( void *request, apr_pool_t *pool, CUWACfg_t *cfg, char *host, char *urlCred, int urlCredLen, char *cookie,
                                         int cookieLen, char *serviceName, char *keytab, cuwa_session_t **sessionOut)
{
    cuwa_err_t status = CUWA_OK;
    cuwa_session_t *session = NULL;
    int checkCookie = 1;
    int needDual = -1;
    char *dualAuthUser = NULL, *dualAuthMethod=NULL;
    int dualAuthTime = 0;

    cuwa_trace("In cuwa_session_from_credential");

    *sessionOut = NULL;

    if ( (!urlCredLen && !cookieLen) ||
         (!urlCred && !cookie) )
        return CUWA_ERR_BAD_CRED;

    //create session
    session = (cuwa_session_t *)apr_pcalloc( pool, sizeof(cuwa_session_t) );
    if ( !session )
        return CUWA_ERR_MEM;

    session->pool = pool;
    session->cfg = cfg;

    // if a URL credential is present,it is checked first
    if ( urlCred && urlCredLen )
    {
        cuwa_trace(" use login credential");

        status = cuwa_cred_parse( pool, &session->cred, urlCred, urlCredLen, serviceName, keytab, host, NULL );

        if ( status == CUWA_OK )
        {
            status = cuwa_cred_get_sessionid( session->cred ,&session->sessionID);
            cuwa_wal_note_set( request, CUWA_SESSION_SID, apr_psprintf(pool,"%qX",session->sessionID ));

            cuwa_trace("cuwa_cred_get_sessionid return status: %d,sessionID=0x%llX", status, session->sessionID);
            status = cuwa_session_setup( session, CUWA_SESSION_FILE_UNKNOWN );

            if ( status == CUWA_OK )
                status = cuwa_session_restore_from_file( session );

            if ( status == CUWA_OK )
            {

                if ( session->state == CUWA_SESSION_NEW )
                {
                    cuwa_trace("session is in new state, set up session data,%d", session->state);

                    session->save = CUWA_SESSION_SAVE_PRIMARY | CUWA_SESSION_SAVE_ACCESS;
                    session->state = CUWA_SESSION_ACTIVE;

                    session->endTime   = cuwa_cred_get_end_time( session->cred );

                    cuwa_session_dump( session );
                    checkCookie = 0;

                }
                else
                {
                    cuwa_trace("wa replay");
                    status = CUWA_ERR_SESSION_REPLAY;
                }
            }
        }
    }

    if ( checkCookie && cookie && (cookieLen > 0) )
    {
        cuwa_trace("use cookie credential");

        status = cuwa_cred_parse( pool, &session->cred, cookie, cookieLen, serviceName, keytab, host, NULL );

        if ( status == CUWA_OK )
        {
            status = cuwa_cred_get_sessionid( session->cred , &session->sessionID);
            cuwa_wal_note_set( request, CUWA_SESSION_SID, apr_psprintf(pool,"%qX",session->sessionID ));
            cuwa_trace("cuwa_cred_get_sessionid return status: %d", status);

            status = cuwa_session_setup( session, CUWA_SESSION_FILE_UNKNOWN );

            if ( status == CUWA_OK )
                status = cuwa_session_restore_from_file( session );

            if ( status == CUWA_OK )
            {

                uint64 key;

                status  = cuwa_cred_get_sessionkey(session->cred, &key);
                cuwa_trace("cuwa_cred_get_sessionkey return status: %d", status);

                if ( status == CUWA_OK )
                    status = cuwa_session_validate( session, key );

                if ( status == CUWA_OK )
                {
                    session->save = CUWA_SESSION_SAVE_ACCESS;
                    status = sspiutil_restore_sec_context(session->cred);
                }
            }
        }
    }

    //check if dualAuth is requested, if yes, check if user has been authenticated with dualAuth
    if ( status == CUWA_OK )
    {
        char *dualAuth = NULL;
        char *permits = CUWA_TWO_FACTOR_OPT_IN;

        cuwa_cred_get_dual_auth(session->cred, &dualAuthUser, &dualAuthMethod, &dualAuthTime );

        //check if user already authenticated with DUO. If yes and dualMethod is the same, we do not need to verify if site require DUO
        if ( dualAuthUser && dualAuthMethod && dualAuthTime > 0 )
        {
            cuwa_trace("User %s authenticated with %s", dualAuthUser,dualAuthMethod); 
            needDual = 0;

            if (CFG_CUWA2FAMethod(cfg) )
            {
                char *method, *state = NULL;
                char *methodList = apr_pstrdup(pool, CFG_CUWA2FAMethod(cfg));
                int good = 0;

                method = apr_strtok( methodList, " ", &state);
                while ( method )
                {
                    if (!apr_strnatcasecmp(method, dualAuthMethod) )
                    {
                        good = 1;
                        break;
                    }
                    method = apr_strtok( NULL, " ", &state);
                }

                //if dualMethod is defined and user logged on with different method
                //user has to relogin
                if ( good == 0 )
                {
                    cuwa_trace("user authenticated with %s, but app requires %s", dualAuthMethod,CFG_CUWA2FAMethod(cfg));
                    needDual = -1;
                }
             }  
        } 
        if (needDual < 0 && CFG_CUWA2FARequire(cfg) ) 
        { 
            dualAuth = apr_pstrdup(pool,CFG_CUWA2FARequire(cfg));

            //check if this user need two factor
           if ( !apr_strnatcasecmp( dualAuth, "all") )
               needDual = 1; 
           else if ( !apr_strnatcasecmp( dualAuth, "none") )
               needDual = 0; 
           else 
           {
               cuwa_util_replace_char_with(dualAuth,',',' ');
               permits = apr_pstrcat( pool, permits, " ", dualAuth, NULL);
           }
        }

        if ( needDual < 0 )
        {
            char *memberships;
            char *user = cuwa_cred_get_attribute( session->cred, "CUWA_FULL_USER",0);

            cuwa_trace("check if user %s is in permit %s", user, permits);
            cuwa_permit_cache_load( request, session, pool );
            status = cuwa_permit_lookup(request, pool, session, serviceName, keytab, user,permits, &memberships);

            if (status)  return status;
            else if (memberships) needDual = 1;
            else needDual = 0;
        }
  
        if ( status==CUWA_OK && needDual )
            status = CUWA_ERR_SESSION_NO_DUAL;
    }
 
    // Make sure credential meets CUWACredentialAge requirement...
    if ( (status == CUWA_OK) && CFG_CUWACredentialAge(cfg))
    {
        int authTime = cuwa_cred_get_auth_time(session->cred);

        if ( dualAuthTime > 0 ) authTime = dualAuthTime;

        if ((cuwa_cred_get_start_time(session->cred) - authTime) > *CFG_CUWACredentialAge(cfg))
        {
            // credential is too old, need to refresh
            status = CUWA_ERR_CRED_TOO_OLD;
            cuwa_trace("cuwa_session_from_credential, cred too old: %d - %d",cuwa_cred_get_auth_time(session->cred),cuwa_cred_get_auth_time(session->cred));
        }
        else cuwa_trace("cuwa_session_from_credential, cred is good");
    }

    *sessionOut = session;

    cuwa_session_dump(*sessionOut);

    if( status == CUWA_OK && CFG_CUWAImpersonation(cfg) && *CFG_CUWAImpersonation(cfg) == O_CFG_CUWAImpersonation_on)
    {
       int checkRate = CFG_CUWAImpersonationCheckRate(cfg) ? *CFG_CUWAImpersonationCheckRate(cfg) : CUWA_SESSION_CHECK_IMPERSONATE_RATE; 

       if ( urlCred && urlCredLen ) 
           status = cuwa_session_impersonate( request, session, serviceName, keytab );
       else if ( session->impersonated && (apr_time_sec(apr_time_now()) - session->impersonate_verfiy_time) > checkRate )
       {
          cuwa_trace("Recheck impersonation group %d - %d", apr_time_sec(apr_time_now()), session->impersonate_verfiy_time);
          status = cuwa_session_impersonate_verify( request, session, serviceName, keytab);
       }

       //if this is an impersonated session, set it in audit field
       if ( session->impersonated == 1 )
       { 
           char  *impersonator;
           cuwa_cred_get_impersonator_netid ( session->cred, &impersonator);
           cuwa_trace("set impersonate audit:%s - %s", CUWA_IMPERSONATE_AUDIT_IDENTIFIER, impersonator);
           cuwa_wal_note_set( request, CUWA_IMPERSONATE_AUDIT_IDENTIFIER,impersonator);
       }
    }

    if ( status != CUWA_OK)
    {
        session->save = CUWA_SESSION_REMOVE;
        cuwa_session_release( session );
    } 

    cuwa_trace("cuwa_session_from_credential return status %d", status);
    return status;
}


/**
 * cuwa_session_get_sessionid returns sessionid.
 *
 * @param[in] session the session.
 * @param[out] sessionid sessionid returned to caller.
 * @return CUWA_OK
 */
int cuwa_session_get_sessionid( cuwa_session_t *session, uint64 *sessionid )
{
    cuwa_err_t status = CUWA_OK;

    *sessionid = session->sessionID;

    return status;
}

/**
 * cuwa_session_to_cookie generates a cookie.  State of the session must be CUWA_SESSION_ACTIVE
 * or cuwa_session_to_cookie returns CUWA_ERR.
 * The cookie has the following format: [ SessionID SessionKey ]base16
 *
 * @param[in] session the session.
 * @param[out] cookie newly allocated buffer containing NULL terminated cookie string.  Caller must free.
 * @return CUWA_OK, CUWA_ERR
 */
cuwa_err_t cuwa_session_to_cookie( cuwa_session_t *session, char **cookie, int *cookieLen )
{
    cuwa_err_t rc, code;
    char *c0 = NULL;
    int c0Len;

    if (!session)
        return CUWA_ERR;

    code = cuwa_cred_make_c0( session->sessionID, session->sessionKey, &c0, &c0Len );
    FAIL_IF(code,code);

    rc = cuwa_base64_make_wa(cookie, cookieLen, c0Len, 1, c0, c0Len);
    FAIL_IF(code,code);

cleanup:

    if (c0) cuwa_free(c0);

    return rc;
}

/*
 * cuwa_session_get_req_size returns the size of request file
 *
 * @param[in] session the session.
 * @param[out] size file size.
 * @return CUWA_OK, CUWA_ERR
 */
cuwa_err_t cuwa_session_get_req_size(cuwa_session_t *session, apr_off_t *size)
{
    apr_status_t code;
    cuwa_err_t rc = CUWA_OK;
    apr_file_t *pFile;
    
    code = apr_file_open( &pFile, session->useFile, APR_READ, APR_UREAD|APR_UWRITE, session->pool);
    FAIL_IF_FILE_ERROR( code );

    CUWA_SESSION_READ_NUM( pFile, session->sessionSize );
    cuwa_trace("request size is %d", session->sessionSize);

    CUWA_SESSION_READ_NUM( pFile, session->noneEncryptDataLen );
    cuwa_trace("none encrypted data len is:%d", session->noneEncryptDataLen );

    CUWA_SESSION_READ_NUM( pFile, session->encryptedLen );
    cuwa_trace("encrypted data len is:%d", session->encryptedLen );

    *size = session->sessionSize;

    apr_file_close(pFile);
cleanup:
   if ( rc == CUWA_ERR_SESSION_NOT_FOUND )
   {
       cuwa_warning("session not found:%s", session->useFile);
       CUWA_SHOW_APR_ERROR(code);
   }
    return rc;
}

/*
 * cuwa_session_from_sessionid returns session, give sessionid
 *
 * @param[in] pool to allocate the session from.
 * @param[in] cfg configuration, used to get the session file path.
 * @param[in] sessionid the sessionid.
 * @param[out] sessionOut session retured.
 * @return CUWA_OK, CUWA_ERR
 */
cuwa_err_t cuwa_session_from_sessionid( void *request, apr_pool_t *pool, CUWACfg_t *cfg, uint64 sessionid, cuwa_session_t **sessionOut)
{
    cuwa_session_t *session;
    cuwa_err_t status = CUWA_OK;

    cuwa_trace("session_from_sessionid:%llX", sessionid);
    cuwa_wal_note_set( request, CUWA_SESSION_SID, apr_psprintf(pool,"%qX",sessionid ));

    session = (cuwa_session_t *)apr_pcalloc( pool, sizeof(cuwa_session_t) );

    if ( !session ) return CUWA_ERR_MEM;

    session->pool      = pool;
    session->cfg       = cfg;
    session->sessionID = sessionid;

    status = cuwa_session_setup( session, CUWA_SESSION_FILE_UNKNOWN );
    if ( status == CUWA_OK )
    {
        *sessionOut        = session;
    }
    return status;
}

void  cuwa_session_update_permit_cache( void *req, apr_pool_t *pool, void *s, CUWACfg_t *cfg, char *cachePermits )
{
    uint64 sid;
    cuwa_session_t *session = (cuwa_session_t *)s;
    cuwa_err_t status = CUWA_OK;
    char *sidStr = cuwa_wal_note_get( req, CUWA_SESSION_SID );

    cuwa_trace("in cuwa_session_update_permit_cache");

    if (!session)
    {
        if ( !sidStr ) return;

        sscanf( sidStr, "%llX", &sid);

        status = cuwa_session_from_sessionid(req, pool, cfg, sid, &session);
        if ( !status )
            status = cuwa_session_restore_from_file( session ); 
     } 
     if ( status == CUWA_OK && session )
     {
         cuwa_trace("Permit cache %s", cachePermits);
         session->permitList = cachePermits;

         cuwa_trace("permit_cashe:state is 0x%x", session->state);
         session->state |= CUWA_SESSION_HAS_PERMIT;
         cuwa_trace("permit_cashe:state now is 0x%x", session->state);

         //if function is called in authorization phase, update session file. Otherwise session will be saved in session_release
         if (!s)
         {
             char *fileName = apr_psprintf(pool,"%s.%lu", session->sessionFile,(unsigned long)getpid());
             cuwa_trace("save permit cache to temporary file:%s", fileName );

             cuwa_session_save_primary( session, fileName );
             apr_file_rename( fileName, session->sessionFile, pool );

             cuwa_session_update_use_file( session );

             cuwa_session_clear( session );
         }
     }
}

const char *cuwa_session_get_proxy_cookie(cuwa_session_t *session, const char *proxy)
{
    const char *proxyCred = NULL;

    if ( session && session->proxyTable )
    {
        proxyCred = apr_table_get( session->proxyTable, proxy );
    }
    return proxyCred;
}

void cuwa_session_save_proxy_cookie(cuwa_session_t *session, const char *proxy, const char *val)
{
    if ( !session )
        return;

    cuwa_trace("save proxy cookie:proxy=%s",proxy);
    if (!session->proxyTable)
        session->proxyTable = apr_table_make(session->pool,1);

    if ( session->proxyTable)
        apr_table_set( session->proxyTable, proxy, val );

    session->save |= CUWA_SESSION_SAVE_PRIMARY;

}

const char *cuwa_session_get_proxy_cookies(cuwa_session_t *session, const char *proxy)
{
    const char *proxyCred = NULL;

    if ( session && session->proxyCookiesTable )
    {
        proxyCred = apr_table_get( session->proxyCookiesTable, proxy );
    }
    return proxyCred;
}

void cuwa_session_save_proxy_cookies(cuwa_session_t *session, const char *proxy, const char *val)
{
    if ( !session )
        return;

    if (!session->proxyCookiesTable)
        session->proxyCookiesTable = apr_table_make(session->pool,1);

    if ( session->proxyCookiesTable)
        apr_table_set( session->proxyCookiesTable, proxy, val );

    session->save |= CUWA_SESSION_SAVE_PRIMARY;

}

//internal function. Caller make sure CUWA has defined CUWAImpersonation on 
////check if user can impersonate
static cuwa_err_t cuwa_session_impersonate( void *request, cuwa_session_t *session, char *serviceName, char *keytab )
{
    cuwa_err_t status = CUWA_OK;
    char *member,*nonmember;
    char *authenticatedUser, *authenticatedUserFullID;
    int code = 0;
    char *msg;
    char *impersonateNetID = NULL;

     cuwa_cred_get_impersonate_fullid( session->cred, &impersonateNetID);

    //user doesn't wish to impersonate, just return 
    if ( impersonateNetID == NULL )  return status;

    cuwa_cred_get_login_fulluser( session->cred, &authenticatedUserFullID);
    cuwa_cred_get_remote_user( session->cred, &authenticatedUser);

    cuwa_trace("check if user=%s is allowed to impersonate as %s",authenticatedUserFullID, impersonateNetID);

    code = cuwa_permit_ha_check_IPSN(session->pool,serviceName, keytab,impersonateNetID, authenticatedUserFullID, &member,&nonmember);
    if ( !code ) {
        if ( member && !strcasecmp(member,cuwa_get_impersonate_group_name( session->pool, serviceName, authenticatedUser ))) 
        {
            cuwa_cred_impersonate( session->cred );

            cuwa_info("%s start impersonate as %s", authenticatedUser, impersonateNetID);

            session->impersonate_verfiy_time = apr_time_sec(apr_time_now());
            session->impersonated = 1;
        } else {
            //this path shouldn't happen unless hack 2fa token 
            msg = apr_psprintf(session->pool, "%s is not authorized to impersonate as %s", authenticatedUser, impersonateNetID);

            cuwa_warning("%s", msg );
            cuwa_wal_save_error(request, HTTP_AUTHZ_DENY, CUWA_ERR_AUTHZ_DENY, msg);
            status = CUWA_ERR;
       }
   } else {
       msg = apr_psprintf(session->pool,"Permit verification failed with error %d.", code );

       cuwa_wal_save_error(request, HTTP_SERVER_ERROR, code, msg);
       status = CUWA_ERR;
  }
  return status;

}

static cuwa_err_t cuwa_session_impersonate_verify( void *request, cuwa_session_t *session, char *serviceName, char *keytab )
{
    cuwa_err_t status = CUWA_OK;
    char *member,*nonmember;
    char *impersonator;
    int code = 0;
    char *msg;
    char *impersonateNetID = NULL;

    cuwa_cred_get_impersonator_netid( session->cred, &impersonator);
    cuwa_cred_get_login_fulluser( session->cred, &impersonateNetID );

    cuwa_trace("check if user=%s is still allowed to impersonate as %s",impersonator, impersonateNetID);
      
    code = cuwa_permit_ha_check_IPSN(session->pool,serviceName, keytab,impersonateNetID, impersonator, &member,&nonmember);
    if ( !code ) {
        if ( member && !strcasecmp(member,apr_psprintf(session->pool,"%s-%s",IMPERSONATE_GROUP_PREFIX ,impersonator)))
        {
            session->impersonate_verfiy_time = apr_time_sec(apr_time_now());
            session->save |= CUWA_SESSION_SAVE_PRIMARY;
        } 
        else  
        {
            //delegator has removed user's impersonation privilege. throw an error let user know
            msg = apr_psprintf(session->pool, "Your impersonation to %s has been removed.",impersonateNetID);
 
            cuwa_warning("%s", msg );
            cuwa_wal_save_error(request, HTTP_AUTHZ_DENY,CUWA_ERR_AUTHZ_DENY, msg);
            status = CUWA_ERR_IMPERSONATE_REMOVED;
        } 
  }else {
       msg = apr_psprintf(session->pool,"Permit verification failed with error %d.", code );

       cuwa_wal_save_error(request, HTTP_SERVER_ERROR, code, msg);
       status = CUWA_ERR;
  }

  return status;
}
