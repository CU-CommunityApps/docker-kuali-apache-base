/************************************************************************

 * session.h -- Session Manager for cuwebauth
 *
 * Copyright 2007 Cornell University.
 * All Rights Reserved.
 *
 ************************************************************************
 */

#ifndef _SESSION_H

#define _SESSION_H

#include <apr_file_io.h>

#include <cuwa_types.h>
#include <cuwa_err.h>
#include <cred.h>
#include <apr_pools.h>
#include <cfg.h>
#include <list.h>
#include <session_file.h>
#include <openssl/evp.h>

#define CUWA_SESSION_DEFAULT_TIMEOUT     10*60*60  //session timeout default is 10 hours
#define CUWA_SESSION_DEFAULT_PATH        "/tmp"

#define CUWA_SESSION_SAVE_PRIMARY     0x0001
#define CUWA_SESSION_SAVE_ACCESS      0x0010
#define CUWA_SESSION_REMOVE           0x1000

#define CUWA_SESSION_NONE             0x0000
#define CUWA_SESSION_NEW              0x0001
#define CUWA_SESSION_ACTIVE           0x0010
#define CUWA_SESSION_HAS_PERMIT       0x0100

#define CUWA_SESSION_ENCRYPTION_UNKNOWN    1 
#define CUWA_SESSION_ENCRYPTION_YES        2
#define CUWA_SESSION_ENCRYPTION_NO         3

#define CUWA_SESSION_FILE_UNKNOWN         1
#define CUWA_SESSION_FILE_SESSION_ID      2
#define CUWA_SESSION_FILE_ENCRYPTED_ID    3

#define CUWA_SESSION_BUF_SIZE       1024 
 
typedef struct cuwa_session
{
    uint64 sessionID;               /** 64-bit nonce. Created to maintain the session */
    uint64 sessionKey;              /** 64-bit nonce. */
    int state;                      /** The state of the session.  and CUWA_SESSION_ACTIVE */
    apr_time_t endTime;                    /** The time that the user's credentials expire */
    apr_table_t *proxyTable;        /** store delegation credentials */
    apr_table_t *proxyCookiesTable; /** store cookie batch, including delegation credentials*/
    cuwa_cred_t *cred;              /** the credentials */

    /* Internal to session manager */
    int save;                       /** value can be CUWA_SESSION_SAVE_PRIMARY or/and CUWA_SESSION_SAVE_ACCESS*/
    apr_file_t *reqFH;              /** file handler of request file */
    apr_pool_t *pool;               /** handle to the pool used in allocation */
    CUWACfg_t *cfg;                 /** config context */
    int sessionSize;                // size of request we have saved so far
    int inactivityTimeout;          // session inactivity timeout value
    int maxSessionSize;             // maximum session size
    char *sessionFile;              // primary session file name
    char *reqFile;                  // request file name
    char *useFile;                  // use file name
    char *permitList;               //for cache permit.Format: /|/permit1==val/|/permit2==val2/|/

    //session encrypted?
    int encrypt;                   //indicate encryption state  
    EVP_CIPHER_CTX *encryptionCtx;   //context used for encryption
    char *buf;                      //store data that needs to be encrypted
    char *readBuf;                 //store data read from disk
    int bufLen;                   //total length of data waiting for encryption
    int noneEncryptDataLen;
    int encryptedLen;
    int bufAllocLen;               //allocated buffer len  
   
    //impersonation support
    int impersonated;             //1 - user impersonated as other user in this session.
    apr_time_t impersonate_verfiy_time;      //time webauth verify the authorization
} cuwa_session_t;

cuwa_err_t cuwa_session_new( void *req, apr_pool_t *pool,  CUWACfg_t *cfg, cuwa_session_t **session);
cuwa_err_t cuwa_session_open_request( cuwa_session_t *session, int write);
cuwa_err_t cuwa_session_read_request( cuwa_session_t *session, char *buf, apr_size_t *count);
cuwa_err_t cuwa_session_write_request( cuwa_session_t *session, char *buf, int count,int encryption);
void cuwa_session_close_request( cuwa_session_t *session );
cuwa_err_t cuwa_session_release( cuwa_session_t *session );
cuwa_err_t cuwa_session_from_credential( void *req, apr_pool_t *pool,  CUWACfg_t *cfg, char *host, char *urlCred, int urlCredLen,
                                         char *cookie, int cookieLen, char *serviceName, char *keytab,
                                         cuwa_session_t **sessionOut);
int cuwa_session_get_sessionid( cuwa_session_t *session, uint64 *sessionid );
cuwa_err_t cuwa_session_to_cookie( cuwa_session_t *session, char **cookie, int *cookieLen );
cuwa_err_t cuwa_session_get_req_size(cuwa_session_t *session, apr_off_t *size);
void cuwa_session_get_use_file_name( apr_pool_t *pool, char *path, char **fileName );
void cuwa_session_get_req_file_name( apr_pool_t *pool, char *path, char **fileName );
void cuwa_session_get_primary_file_name( apr_pool_t *pool, char *path, char **fileName );
cuwa_err_t cuwa_session_get_access_time( char *file, apr_pool_t *pool, apr_time_t *mtime );
int cuwa_session_garbage_collect( cuwa_session_t *session,int force);
cuwa_err_t cuwa_session_from_sessionid( void *req, apr_pool_t *pool, CUWACfg_t *cfg, uint64 sessionid, cuwa_session_t **sessionOut);
cuwa_err_t cuwa_session_check_session_path( char *, apr_pool_t * );
void  cuwa_session_update_permit_cache( void *r, apr_pool_t *pool, void *s, CUWACfg_t *cfg, char *cachePermits );
const char *cuwa_session_get_proxy_cookie(cuwa_session_t *session, const char *proxy);
void cuwa_session_save_proxy_cookie(cuwa_session_t *session, const char *proxy, const char *val);
const char *cuwa_session_get_proxy_cookies(cuwa_session_t *session, const char *proxy);
void cuwa_session_save_proxy_cookies(cuwa_session_t *session, const char *proxy, const char *val);

#define cuwa_session_get_permit_cache( session ) session->permitList
#define cuwa_session_get_attributes( session ) session->cred?cuwa_cred_get_attributes(session->cred):NULL
#define cuwa_session_get_attribute(session,key,idx) (session)->cred?cuwa_cred_get_attribute((session)->cred,(key),(idx)):NULL;

cuwa_err_t cuwa_session_do_write( cuwa_session_t *session, char *buf, int count);
cuwa_err_t cuwa_session_get_session_file_path(char **pathOut, cuwa_session_t *session, int idToUse);

cuwa_err_t cuwa_session_encryption_write( cuwa_session_t *session, char *buf, int count );
cuwa_err_t cuwa_session_encryption_read( cuwa_session_t *session, char *buf, apr_size_t *count );
cuwa_err_t cuwa_session_encryption_done( cuwa_session_t *session );
cuwa_err_t cuwa_session_encryption_set( cuwa_session_t *session );

cuwa_err_t cuwa_session_get_access_time_uid( char *file, apr_pool_t *pool, apr_time_t *mtime, apr_uid_t *uid );

#endif
