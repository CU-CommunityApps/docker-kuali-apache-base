/************************************************************************

 * session_encryption.c -- encrypt/decrypt post data
 *
 * Copyright 2007 Cornell University.
 * All Rights Reserved.
 *
 ************************************************************************
 */
#include <session.h>
#include <log.h>

#define CUWA2_LOG_DOMAIN cuwa.session

/*
 * cuwa_session_encryption_prepare initializes encryption context and buffer for encryption/decryption
 *
 * @param[in] session The session.
 * @param[in] do_encrypt 1 is encryption, 0 is decryption.
 * @return CUWA_OK, CUWA_ERR
 */
static cuwa_err_t cuwa_session_encryption_prepare( cuwa_session_t *session, int do_encrypt )
{
    cuwa_err_t rc = CUWA_OK;
    unsigned char iv[] = {0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15};
    int result = 0;
    char *key;

    cuwa_trace("prepare %s",do_encrypt?"encryption":"decryption");

    session->encryptionCtx = EVP_CIPHER_CTX_new();
    FAIL_IF( !session->encryptionCtx, CUWA_ERR );

    cuwa_trace("cipherInit_ex:set type");
    result = EVP_CipherInit_ex(session->encryptionCtx, EVP_aes_128_cbc(), NULL, NULL, NULL, do_encrypt);
    FAIL_IF( !result, CUWA_ERR_SESSION_ENCRYPTION);

    key = apr_psprintf(session->pool, "%16qX", session->sessionID);
    cuwa_trace("cipherInit_ex: set key %s", key);

    result = EVP_CipherInit_ex(session->encryptionCtx, NULL, NULL, (unsigned char *)key, iv, do_encrypt);
    FAIL_IF( !result, CUWA_ERR_SESSION_ENCRYPTION);

    session->bufAllocLen = CUWA_SESSION_BUF_SIZE;

    session->buf = apr_pcalloc( session->pool, session->bufAllocLen+EVP_MAX_BLOCK_LENGTH+1 );
    FAIL_IF( !session->buf, CUWA_ERR );

    if ( !do_encrypt )
    {
        session->readBuf = apr_pcalloc( session->pool, session->bufAllocLen+1 );
        FAIL_IF( !session->readBuf, CUWA_ERR );
    }
    session->bufLen = 0;

cleanup:
    return rc;

}

/*
 * cuwa_session_encryption_set prepare session file names using hashed sessionID. 
 *
 * @param[in] session The session.
 * @return CUWA_OK, CUWA_ERR
 */
cuwa_err_t cuwa_session_encryption_set( cuwa_session_t *session )
{
    char *path;
    cuwa_err_t status = CUWA_OK;

    status = cuwa_session_get_session_file_path( &path, session , CUWA_SESSION_FILE_ENCRYPTED_ID);

    cuwa_session_get_primary_file_name( session->pool, path, &session->sessionFile );
    cuwa_session_get_use_file_name( session->pool, path, &session->useFile );
    cuwa_session_get_req_file_name( session->pool, path, &session->reqFile );

    return status;
}

/*
 * cuwa_session_encryption_done When all the post data haven been encrypted, this function should  
 * When all the post data have been encrypted, this function should be called                              
 * so that the final block can be encrypted and written to disk
 * @param[in] session The session.
 * @return CUWA_OK, CUWA_ERR
 */
cuwa_err_t cuwa_session_encryption_done( cuwa_session_t *session )
{
    int result = 0;
    cuwa_err_t rc = CUWA_OK;
    int finalLen = 0;

    if ( session->encryptionCtx )
    {
        result = EVP_CipherFinal_ex(session->encryptionCtx, (unsigned char*)session->buf, &finalLen);
        cuwa_trace("cipherfinal return result %d, finalLen=%d",result, finalLen);
        FAIL_IF(!result, CUWA_ERR_SESSION_ENCRYPTION);

        if ( finalLen > 0 )
        {
            session->encryptedLen += finalLen;
            cuwa_trace("write %d bytes of final data", finalLen);
            rc = cuwa_session_do_write( session, session->buf, finalLen );
            if ( rc ) goto cleanup;
        }

cleanup:
        EVP_CIPHER_CTX_free(session->encryptionCtx);
        cuwa_trace("ctx cleaned up");
        session->encryptionCtx = NULL;

    }
    return rc;
}

/*
 * cuwa_session_encryption_read Read encrypted data from disk,decrypt it. Copy requested amount of decrypted data to caller's buffer
 *
 * @param[in] session The session.
 * @param[out] buf Buffer for decrypted data.
 * @param[in/out] count The amount of decrypted data requested
 * @return CUWA_OK, CUWA_ERR
 */
cuwa_err_t cuwa_session_encryption_read( cuwa_session_t *session, char *buf, apr_size_t *count )
{
    apr_file_t *pFile = NULL;
    apr_status_t rv;
    cuwa_err_t rc = CUWA_OK;
    int dataReturned = 0, dataToRead;
    int dataRequested = *count;
    int dataToCopy = 0;
    apr_size_t dataFromFile;
    int result;
    cuwa_assert(session);

    pFile = session->reqFH;
    cuwa_assert( pFile );

    if ( !session->encryptionCtx )
    {
         rc = cuwa_session_encryption_prepare( session, 0 );
         if ( rc ) return rc;
    }

    cuwa_trace("Requested %d bytes, encryptedLen=%d", dataRequested, session->encryptedLen); 
    while ( dataReturned < dataRequested )
    {
        //if we have left over decrypted data in buffer, copy it to output buffer
        if ( session->bufLen > 0 )
        {
            dataToCopy = ( dataRequested-dataReturned > session->bufLen )? session->bufLen : dataRequested-dataReturned;

            cuwa_trace("copy %d of data to outBuf", dataToCopy);
            memcpy( buf, session->buf, dataToCopy);

            buf += dataToCopy;

            session->bufLen = session->bufLen - dataToCopy;
            dataReturned += dataToCopy;

            if ( session->bufLen > 0 )
            {
                //we have remaining data in buffer, move data tO the beginning of the buffer
                cuwa_trace("We have %d bytes of data remaining, move them to the beginning of buffer",session->bufLen);
                memmove(session->buf, session->buf+dataToCopy, session->bufLen);
            }
            cuwa_trace("dataReturned=%d, dataRequested=%d", dataReturned, dataRequested);
        }
        else
        {
            dataToRead = session->encryptedLen;
            if ( dataToRead > session->bufAllocLen )
                dataToRead = session->bufAllocLen;

            cuwa_trace("Need to Read %d bytes from disk", dataToRead);

            //we need to read more
            rv = apr_file_read_full( pFile, session->readBuf, dataToRead, &dataFromFile );
            FAIL_IF_FILE_ERROR( rv );
            FAIL_IF( dataToRead != dataFromFile, CUWA_ERR);
 
            session->encryptedLen -= dataFromFile;

            cuwa_trace("encryptedLen=%d", session->encryptedLen);

            //decrypt data
            session->bufLen = session->bufAllocLen;

            memset( session->readBuf+dataFromFile,0, session->bufAllocLen-dataFromFile);
            
            result = EVP_CipherUpdate(session->encryptionCtx, (unsigned char *)session->buf, &session->bufLen, (unsigned char*)session->readBuf, dataToRead);

            cuwa_trace("cipherUpdate return result %d,dataDecrypted=%d", result, session->bufLen);
            FAIL_IF( !result, CUWA_ERR_SESSION_ENCRYPTION);
            
            if ( session->encryptedLen == 0 )
            {
               int finalLen;

                cuwa_trace("decrypt final block");
                result = EVP_CipherFinal_ex(session->encryptionCtx, (unsigned char*)session->buf+ session->bufLen, &finalLen);
                cuwa_trace("CipherFinal return result=%d, finalLen=%d", result,finalLen);

                FAIL_IF(!result, CUWA_ERR_SESSION_ENCRYPTION);
                session->bufLen += finalLen;

                EVP_CIPHER_CTX_free(session->encryptionCtx);
                session->encryptionCtx = NULL;
                cuwa_trace("ctx cleaned up");
            }

        }
    }
cleanup:

    if ( rc )
    {
        EVP_CIPHER_CTX_free(session->encryptionCtx);
        session->encryptionCtx = NULL;
    }   
    return rc;
}

/*
 * cuwa_session_encryption_write Encrypts data and write to disk
 *
 * @param[in] session The session.
 * @param[in] buf Data to be encrypted and written to disk.
 * @param[in] count Number of bytes of data to be encrypted
 * @return CUWA_OK, CUWA_ERR
 */
cuwa_err_t cuwa_session_encryption_write( cuwa_session_t *session, char *buf, int count )
{
    cuwa_err_t rc = CUWA_OK;
    int result = 0;
    int bytesToEncrypt = 0;
    char *p = buf;
 
    if ( session->encrypt != CUWA_SESSION_ENCRYPTION_YES )
    {
        cuwa_warning("Try to write encryption data to a file named with sessionID");
        return CUWA_ERR;
    }
    if ( !session->encryptionCtx )
    {
         rc = cuwa_session_encryption_prepare( session, 1 );
         if ( rc ) return rc;
    }
 
    while ( count )
    {
        if ( count > session->bufAllocLen )
            bytesToEncrypt = session->bufAllocLen;
        else
            bytesToEncrypt = count;

        cuwa_trace("Encrypt %d bytes of data", bytesToEncrypt);
        result = EVP_CipherUpdate(session->encryptionCtx, (unsigned char *)session->buf, &session->bufLen, (unsigned char*)p, bytesToEncrypt);

        FAIL_IF(!result, CUWA_ERR_SESSION_ENCRYPTION);
        p += bytesToEncrypt;
        count -= bytesToEncrypt;
        session->encryptedLen += session->bufLen;

        cuwa_trace("%d bytes encrypted", session->bufLen);
        if ( session->bufLen > 0 )
            rc = cuwa_session_do_write( session, session->buf, session->bufLen );

        if ( rc ) goto cleanup;
   }    

cleanup:
    if ( rc )
    {
        EVP_CIPHER_CTX_free(session->encryptionCtx);
        session->encryptionCtx = NULL;
    }
    return rc;
}

const char id_session_session_encryption_c[] = "$Id$";

