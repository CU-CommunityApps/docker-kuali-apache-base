/************************************************************************
 * session_file.c -- session manager's file primitives
 *
 * Copyright 2007 Cornell University.
 * All Rights Reserved.
 *
 ************************************************************************
 *  $Log$
 *  Revision 1.2  2008/08/15 14:42:22  hy93
 *  remove line feed
 *
 *  Revision 1.1  2008/08/15 04:49:26  pb10
 *  Added table based attribute support to session code.
 *  Still need to put support into auth.c and lastly need to remove old code from everywhere.
 *
 *
 ************************************************************************
 */

#include <session_file.h>
#include <apr_tables.h>
#include <apr_strings.h>
#include <cuwa_malloc.h>
#include <log.h>

#define CUWA2_LOG_DOMAIN cuwa.session

cuwa_err_t cuwa_session_write_table( apr_file_t *file, apr_table_t *table )
{
    cuwa_err_t rc = CUWA_OK;
    int total = 0;
    const apr_array_header_t *arr=NULL;
    const apr_table_entry_t *elts=NULL;

    cuwa_assert(file);

    if ( table )
    {
        arr = apr_table_elts( table );
        elts = (const apr_table_entry_t *)arr->elts;
        total = arr->nelts;
    }

    // write number of entries

    cuwa_trace("write table %d elements...",total);
    CUWA_SESSION_WRITE_NUM(file,total);

    // write the entries
    if ( total )
    {
        int i;

        for (i=0; i < arr->nelts; i++ )
        {
            cuwa_trace("write table element: %s=%s",elts[i].key,elts[i].val);
            CUWA_SESSION_WRITE_STRING( file, elts[i].key);
            CUWA_SESSION_WRITE_STRING( file, elts[i].val);
        }
    }

cleanup:

    return rc;
}


cuwa_err_t cuwa_session_read_table( apr_pool_t *pool, apr_file_t *file, apr_table_t **table )
{
    cuwa_err_t rc = CUWA_OK;
    int total = 0;

    cuwa_assert(file);
    cuwa_assert(table);

    if (!*table)
    {
        *table = apr_table_make( pool, total );
        FAIL_IF( !*table,CUWA_ERR);
    }

    // read number of entries
    CUWA_SESSION_READ_NUM(file,total);
    cuwa_trace("read table %d elements...",total);

    // read the entries
    if ( total > 0 )
    {
        int i = 0;
        char *key, *val;

        for ( i=0; i<total;i++)
        {
           CUWA_SESSION_READ_STRING( file, &key );
           CUWA_SESSION_READ_STRING( file, &val );

           cuwa_trace("read table element: %s=%s",key,val);
           apr_table_set( *table, key, val );
        }
    }

cleanup:

    return rc;
}


const char id_session_session_file_c[] = "$Id$";
