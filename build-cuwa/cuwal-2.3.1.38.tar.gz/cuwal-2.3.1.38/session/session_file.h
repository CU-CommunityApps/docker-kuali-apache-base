/************************************************************************
 * session_file.h -- Session Manager file support
 *
 * Copyright 2007 Cornell University.
 * All Rights Reserved.
 *
 ************************************************************************
 *  $Log$
 *  Revision 1.4  2008/08/19 20:00:56  hy93
 *  garbage collection enhancement
 *
 *  Revision 1.3  2008/08/15 15:33:46  pb10
 *  64-bit fix.
 *
 *  Revision 1.2  2008/08/15 14:43:42  hy93
 *  remove line feed
 *
 *  Revision 1.1  2008/08/15 04:49:26  pb10
 *  Added table based attribute support to session code.
 *  Still need to put support into auth.c and lastly need to remove old code from everywhere.
 *
 *
 ************************************************************************
 */

#ifndef _SESSION_FILE_H
#define _SESSION_FILE_H

#include <apr_file_io.h>
#include <apr_tables.h>
#include <apr_strings.h>
#include <apr_pools.h>
#include <cuwa_err.h>

/**

 * CUWA_SESSION_WRITE_STRING macro write the length of string to file, then write string to file
 * a "cleanup" label and an int called rc which is returned by the function.
 * @param[in] pFile file handler
 * @param[in] buf  string to write
 *
 */
#define CUWA_SESSION_WRITE_STRING(pFile, buf) do {                     \
 apr_size_t len = 0;                                                   \
 apr_size_t numBytes = sizeof(apr_size_t);                                    \
 apr_status_t rv;                                                      \
 if (buf) len = strlen(buf);                                           \
 rv = apr_file_write( pFile, &len, &numBytes );                      \
 FAIL_IF_FILE_ERROR( rv );                                             \
 if (len > 0 )                                                         \
 {                                                                     \
     rv = apr_file_write( pFile, buf, &len );                          \
     FAIL_IF_FILE_ERROR( rv );                                         \
 }                                                                     \
 }while(0)

 /**
 * CUWA_SESSION_READ_STRING macro read the length of string from file, then allocate memory for buffer, then read string from \\
 * file
 * a "cleanup" label and an int called rc which is returned by the function.
 * @param[in] pFile file handler
 * @param[in] buf  buffer for string that read from file
 *
 */
#define CUWA_SESSION_READ_STRING(pFile, buf) do {                      \
 apr_size_t len=0;                                                       \
 apr_size_t numBytes = sizeof(apr_size_t);                                    \
 apr_status_t rv;                                                      \
 char *newBuf = NULL;                                                  \
 rv = apr_file_read( pFile, &len, &numBytes );                         \
 FAIL_IF_FILE_ERROR( rv );                                             \
 if ( len > 0)  {                                                      \
     newBuf = cuwa_malloc(len+1);                                      \
     if (!newBuf)   {                                                  \
         rc = CUWA_ERR_MEM;                                            \
         goto cleanup;                                                 \
     }                                                                 \
     rv = apr_file_read( pFile, newBuf, &len );                        \
     FAIL_IF_FILE_ERROR( rv );                                         \
     newBuf[len] = '\0';                                               \
     *buf = newBuf;                                                    \
 }                                                                     \
 else                                                                  \
     *buf = NULL;                                                      \
 }while(0)


#define CUWA_SESSION_WRITE_NUM(pFile, val)                                              \
do {                                                                                    \
    int _write_num_rc_;                                                                 \
    apr_size_t _write_num_cnt_ = sizeof((val));                                         \
    _write_num_rc_ = apr_file_write( (pFile), (const void *)&(val), &_write_num_cnt_ ); \
    FAIL_IF_FILE_ERROR( _write_num_rc_ );                                               \
}while(0)


#define CUWA_SESSION_READ_NUM(pFile, val)                                               \
do {                                                                                    \
    int _write_num_rc_;                                                                 \
    apr_size_t _write_num_cnt_ = sizeof((val));                                         \
    _write_num_rc_ = apr_file_read( (pFile), (void *)&(val), &_write_num_cnt_ );        \
    FAIL_IF_FILE_ERROR( _write_num_rc_ );                                               \
}while(0)


cuwa_err_t cuwa_session_write_table( apr_file_t *file, apr_table_t *table );
cuwa_err_t cuwa_session_read_table( apr_pool_t *pool, apr_file_t *file, apr_table_t **table );

#endif
