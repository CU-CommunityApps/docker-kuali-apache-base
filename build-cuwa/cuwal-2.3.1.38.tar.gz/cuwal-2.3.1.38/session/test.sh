#!/bin/sh
./test_session ns10-demo "\$tester" "web-agent/bosanko@CIT.CORNELL.EDU" bosanko.keytab
