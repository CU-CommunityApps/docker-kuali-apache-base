#!/bin/sh

cp -r $HOME/cuwal2 $HOME/cuwal2-build
. $HOME/cuwal2-build/build_server/hudson_build.sh
