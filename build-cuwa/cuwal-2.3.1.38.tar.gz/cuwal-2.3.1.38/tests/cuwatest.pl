#supporting functions for the CUWebAuth test harness
#tests should require this file
#and should use the assorted cuwat_ functions
package main;
use strict;
use Apache::Test;
use Apache::TestUtil;
use Apache::TestRequest;
use Apache::TestTrace;
use HTML::Form;
use HTTP::Cookies;
use LWP::UserAgent;
use HTTP::Response;
use HTTP::Request;
use Carp qw(cluck);
use File::Basename qw(dirname basename);
use File::Spec::Functions;

#^ and $ don't work well with mixed line endings
#define versions that tolerate windows/unix mixed strings
$::SOS = '(?<![^\012\015])';  #"not preceeded by something other than CR or LF"
				#double negative to catch start of string
$::EOS = '(?![^\012\015])'; #"not succeeded by something other than CR or LF"
my $IISMODE = -e "IISMODE";

#Apache::TestUtil->import(qw(struct_as_string));
#

our $cuwatc_ID='cuwa-test';
our $cuwatc_PASSWORD='CUWebAuth2';
our $cuwatc_REALM='DEV.CORNELL.EDU';
our $cuwatc_WEBLOGIN='https://web[1-4].login.((dev|test).idm.cit.)?cornell.edu(:443)?';
our $cuwatc_ECHO='http(s)?://localhost[^/]*/TestCUWA__echo';

our $cuwatc_dual_ID='cuwa-test-dual';
our $cuwatc_dual_optin_ID='cuwa-test-dual-optin';
our $cuwatc_delegate_ID='cuwa-test-dlgt';
our $cuwatc_notdelegate_ID='cuwa-test-notdelegate';

#stuff to facilitate running in semiquiet semiverbose mode
#where -v output is captured but discarded if the tests pass
my $dbg_script=basename((caller(0))[1]); #name of calling script
my $dbg_vars=Apache::Test::config()->{vars};
my $dbg_log=catfile($dbg_vars->{serverroot},"logs","$dbg_script.log");
my $dbg_buffer="";
my $status=1;

#pseudoglobal
#last header that we sent to webauth
our $cuwat_lastheader=$dbg_script;

our $jar=HTTP::Cookies->new();
our $redir=[qw(GET HEAD POST)];
our $agent=Apache::TestRequest::user_agent(reset =>1, cookie_jar => $jar, requests_redirectable=>$redir );

# dump all cookies for debugging purposes
#out: value
sub cuwat_dump_cookies{
    cuwat_write_errorlog( "\ncuwat_dump_cookies(): " . $jar->as_string . "\n\n" );
}	

# Retrieve a cookie from the jar
#in: cookie name
#in: cookie domain
#out: value
sub cuwat_set_cookie{
    my ($name, $value, $domain)= @_;
    $jar->set_cookie( 0 , $name , $value , '/' , $domain , '443' , 1 , 1 , 1000 , 1 );
}	

# Add a cookie to the jar
#in: cookie name
#in: cookie value
#in: cookie domain
#out: void
sub cuwat_get_cookie{
    my ( $name , $domain ) = @_;
    my $value;    
    $jar->scan(sub { $value = $_[2] if ($_[1] eq $name && (!$domain || $_[4] eq $domain)); });
    return $value;
}	

#reset the user agent, turn on redirects
#in: void
#out: void
sub cuwat_reset{
	$agent=Apache::TestRequest::user_agent(reset =>1, cookie_jar => $jar, requests_redirectable=>$redir);
}

sub cuwat_get_agent{
	return $agent;
}

#reset the user agent, delete all cookies too
#in: void
#out: void
sub cuwat_full_reset{
	$jar=HTTP::Cookies->new();
	cuwat_reset();
}	

#delete any cookies for localhost
#in: void
#out: void
sub cuwat_clear_site{
	$jar->clear("localhost.localdomain");
	$jar->clear("localhost.local");
	$jar->clear("localhost.cornell.edu");
	$jar->clear("localhost.cit.cornell.edu");
	$jar->clear("localhost.idm.cit.cornell.edu");
	$jar->clear("localhost");
	$jar->clear("127.0.0.1");
}
	
#turn off redirect following
#in: void
#out: void
sub cuwat_redir_off{
	$agent=Apache::TestRequest::user_agent(reset =>1, cookie_jar => $jar, requests_redirectable=>0);
}

#is the argument a response from weblogin (login form)
#in: HTTP::Response to be tested
#out: true if it is weblogin and status 200 undef otherwise
sub cuwat_is_weblogin{
	my $response = shift;
	return unless cuwat_cmp($response->code,200, "status code");
	return unless cuwat_cmp($response->base,qr/$cuwatc_WEBLOGIN/i,"base url");
	return 1;
}

#is the argument a response from weblogin (login form)
#in: HTTP::Response to be tested
#out: true if it is weblogin and status 200 undef otherwise
sub cuwat_is_weblogin_error_page{
	my $response = shift;
	return unless cuwat_cmp($response->code,400, "status code");
	return unless cuwat_cmp($response->base,qr/$cuwatc_WEBLOGIN/i,"base url");
	return unless cuwat_cmp($response->content,qr/Your request contained errors/i,"error page header");
	return 1;
}

#is the argument a response from weblogin (TEST method dual login form)
#in: HTTP::Response to be tested
#out: true if it is weblogin and status 200 undef otherwise
sub cuwat_is_dual_login{
        my $response = shift;
        return unless cuwat_cmp($response->code,200, "status code");
        return unless cuwat_cmp($response->base,qr/$cuwatc_WEBLOGIN\/TEST/i,"base url");
        return 1;
}

#is the argument a response from weblogin (DUO method dual login form)
#in: HTTP::Response to be tested
#out: true if it is weblogin and status 200 undef otherwise
sub cuwat_is_dual_login_duo{
        my $response = shift;
        return unless cuwat_cmp($response->code,200, "status code");
        return unless cuwat_cmp($response->base,qr/$cuwatc_WEBLOGIN\/DUO/i,"base url");
        return 1;
}

#is the argument a the first-factor login prompt
#in: HTTP::Response to be checked
#out: true if it is the cuweblogin login form
#	false otherwise
sub cuwat_is_login_form{
	my $response = shift;
	return unless cuwat_is_weblogin $response;
        return unless cuwat_cmp($response->content,qr/<input name="netid"/,"found netid field of login form");
	return 1;
}


#is the argument the impersonation form?
#in: HTTP::Response to be checked
#out: true if it is the cuweblogin impersonation form
#	false otherwise
sub cuwat_is_impersonation_login_form{
	my $response = shift;
	return unless cuwat_is_weblogin $response;
    return unless cuwat_cmp($response->content,qr/<SELECT ID="impersonateNetID" NAME="impersonateNetID"/,"found impersonate netid field of delegation login form");
	return 1;
}

#is the argument a redirect to weblogin
#in: HTTP::Response containing a redirect 
#(i.e. result with redirects disabled)
#out: true if it is a weblogin redirect undef otherwise
sub cuwat_is_login_redirect{
	my $response = shift;
	unless(cuwat_cmp($response->is_redirect,1, "is this a redirect")){
		cuwat_debug($response->as_string);
		return 0;
	}
	unless(cuwat_cmp($response->header('Location'),qr/$cuwatc_WEBLOGIN/i, "location header")){
		cuwat_debug($response->as_string);
		return 0;
	}
	return 1;
}

#is the argument a response from webauth from echo.pm on a logged in session
#in: HTTP::Response to be tested
#out: true if the CUWA* and other variables are set, undef otherwise
sub cuwat_is_logged_in_echo{
	my $response=shift;
	my $method=shift;
	my $uri=shift;
	my $expected_remote_user=$cuwatc_ID;

	#if the testid is not in the same realm as the keytab ... fixme should detect keytab realm
	if($cuwatc_REALM ne "DEV.CORNELL.EDU"){
		$expected_remote_user .= "\@$cuwatc_REALM";
	}
	return unless cuwat_cmp(defined($response), 1, "have a response");
	unless(t_cmp($response->code,200, "response status code")){
		return t_cmp(cuwat_filter_css($response->content), "error text","printing error text");
	}			

	return cuwat_echo_check_values($response, $method=>$uri,
			{	(not $IISMODE)?(REMOTE_USER=>$expected_remote_user):(),
			 	CUWA_REMOTE_USER=>$cuwatc_ID,
				HTTP_CUWA_REMOTE_USER=>$cuwatc_ID,
			 	(not $IISMODE)?(APACHE2_REQUESTREC_USER=>$expected_remote_user):(),
			 	HTTP_REMOTE_USER=>$expected_remote_user,
			 	CUWA_FULL_USER=>"$cuwatc_ID\@$cuwatc_REALM",
			 	HTTP_CUWA_FULL_USER=>"$cuwatc_ID\@$cuwatc_REALM",
			 	CUWA_REALM=>$cuwatc_REALM,
			 	HTTP_CUWA_REALM=>$cuwatc_REALM});
	return 1;
}

#verify user is logged in two factor
sub cuwat_is_logged_in_onefactor_dual_ID{
        my $response=shift;
        my $method=shift;
        my $uri=shift;
        my $expected_remote_user=$cuwatc_dual_ID;

        #if the testid is not in the same realm as the keytab ... fixme should detect keytab realm
        if($cuwatc_REALM ne "DEV.CORNELL.EDU"){
                $expected_remote_user .= "\@$cuwatc_REALM";
        }
        return unless cuwat_cmp(defined($response), 1, "have a response");
        unless(t_cmp($response->code,200, "response status code")){
                return t_cmp(cuwat_filter_css($response->content), "error text","printing error text");
        }

        return cuwat_echo_check_values($response, $method=>$uri,
                        {       (not $IISMODE)?(REMOTE_USER=>$expected_remote_user):(),
                                CUWA_REMOTE_USER=>$cuwatc_dual_ID,
                                HTTP_CUWA_REMOTE_USER=>$cuwatc_dual_ID,
                                (not $IISMODE)?(APACHE2_REQUESTREC_USER=>$expected_remote_user):(),
                                HTTP_REMOTE_USER=>$expected_remote_user,
                                CUWA_FULL_USER=>"$cuwatc_dual_ID\@$cuwatc_REALM",
                                HTTP_CUWA_FULL_USER=>"$cuwatc_dual_ID\@$cuwatc_REALM",
                                CUWA_2FA_USER=>undef, # since we are logged in with only one factor so far
                                CUWA_2FA_METHOD=>undef,
                                CUWA_REALM=>$cuwatc_REALM,
                                HTTP_CUWA_REALM=>$cuwatc_REALM});
        return 1;
}

# verify user is not logged in as a two-factor user.
sub cuwat_verify_not_logged_in_dual{
        my $response=shift;
        my $method=shift;
        my $uri=shift;
        my $expected_remote_user=$cuwatc_dual_ID;

        return unless cuwat_cmp(defined($response), 1, "have a response");
        unless(t_cmp($response->code,200, "response status code")){
                return t_cmp(cuwat_filter_css($response->content), "error text","printing error text");
        }

        return cuwat_echo_check_values($response, $method=>$uri,
                        {       CUWA_2FA_USER=>undef, # since we are logged in with only one factor so far
                                CUWA_2FA_METHOD=>undef,
                                });
        return 1;
}

#verify user is logged in two factor
sub cuwat_is_logged_in_dual{
        my $response=shift;
        my $method=shift;
        my $uri=shift;
        my $expected_remote_user=$cuwatc_dual_ID;

        #if the testid is not in the same realm as the keytab ... fixme should detect keytab realm
        if($cuwatc_REALM ne "DEV.CORNELL.EDU"){
                $expected_remote_user .= "\@$cuwatc_REALM";
        }
        return unless cuwat_cmp(defined($response), 1, "have a response");
        unless(t_cmp($response->code,200, "response status code")){
                return t_cmp(cuwat_filter_css($response->content), "error text","printing error text");
        }

        return cuwat_echo_check_values($response, $method=>$uri,
                        {       (not $IISMODE)?(REMOTE_USER=>$expected_remote_user):(),
                                CUWA_REMOTE_USER=>$cuwatc_dual_ID,
                                HTTP_CUWA_REMOTE_USER=>$cuwatc_dual_ID,
                                (not $IISMODE)?(APACHE2_REQUESTREC_USER=>$expected_remote_user):(),
                                HTTP_REMOTE_USER=>$expected_remote_user,
                                CUWA_FULL_USER=>"$cuwatc_dual_ID\@$cuwatc_REALM",
                                HTTP_CUWA_FULL_USER=>"$cuwatc_dual_ID\@$cuwatc_REALM",
                                CUWA_2FA_USER=>"$cuwatc_dual_ID\@$cuwatc_REALM",
                                CUWA_2FA_METHOD=>"TEST",
                                CUWA_REALM=>$cuwatc_REALM,
                                HTTP_CUWA_REALM=>$cuwatc_REALM});
        return 1;
}

#verify the 2f-optin user is logged in two factor
sub cuwat_is_logged_in_dual_optinID{
        my $response=shift;
        my $method=shift;
        my $uri=shift;
        my $expected_remote_user=$cuwatc_dual_optin_ID;

        #if the testid is not in the same realm as the keytab ... fixme should detect keytab realm
        if($cuwatc_REALM ne "DEV.CORNELL.EDU"){
                $expected_remote_user .= "\@$cuwatc_REALM";
        }
        return unless cuwat_cmp(defined($response), 1, "have a response");
        unless(t_cmp($response->code,200, "response status code")){
                return t_cmp(cuwat_filter_css($response->content), "error text","printing error text");
        }

        return cuwat_echo_check_values($response, $method=>$uri,
                        {       (not $IISMODE)?(REMOTE_USER=>$expected_remote_user):(),
                                CUWA_REMOTE_USER=>$cuwatc_dual_optin_ID,
                                HTTP_CUWA_REMOTE_USER=>$cuwatc_dual_optin_ID,
                                (not $IISMODE)?(APACHE2_REQUESTREC_USER=>$expected_remote_user):(),
                                HTTP_REMOTE_USER=>$expected_remote_user,
                                CUWA_FULL_USER=>"$cuwatc_dual_optin_ID\@$cuwatc_REALM",
                                HTTP_CUWA_FULL_USER=>"$cuwatc_dual_optin_ID\@$cuwatc_REALM",
                                CUWA_2FA_USER=>"$cuwatc_dual_optin_ID\@$cuwatc_REALM",
                                CUWA_2FA_METHOD=>"TEST",
                                CUWA_REALM=>$cuwatc_REALM,
                                HTTP_CUWA_REALM=>$cuwatc_REALM});
        return 1;
}

#verify the 2f-optin user is logged in two factor
sub cuwat_is_logged_in_delegate_as_self{
        my $response=shift;
        my $method=shift;
        my $uri=shift;
        my $expected_remote_user=$cuwatc_delegate_ID;

        #if the testid is not in the same realm as the keytab ... fixme should detect keytab realm
        if($cuwatc_REALM ne "DEV.CORNELL.EDU"){
                $expected_remote_user .= "\@$cuwatc_REALM";
        }
        return unless cuwat_cmp(defined($response), 1, "have a response");
        unless(t_cmp($response->code,200, "response status code")){
                return t_cmp(cuwat_filter_css($response->content), "error text","printing error text");
        }

        return cuwat_echo_check_values($response, $method=>$uri,
                        {       (not $IISMODE)?(REMOTE_USER=>$expected_remote_user):(),
                                CUWA_REMOTE_USER=>$expected_remote_user,
                                HTTP_CUWA_REMOTE_USER=>$expected_remote_user,
                                (not $IISMODE)?(APACHE2_REQUESTREC_USER=>$expected_remote_user):(),
                                HTTP_REMOTE_USER=>$expected_remote_user,
                                CUWA_FULL_USER=>"$expected_remote_user\@$cuwatc_REALM",
                                HTTP_CUWA_FULL_USER=>"$expected_remote_user\@$cuwatc_REALM",
                                CUWA_2FA_USER=>"$expected_remote_user\@$cuwatc_REALM",
                                CUWA_2FA_METHOD=>"TEST",
                                CUWA_REALM=>$cuwatc_REALM,
                                HTTP_CUWA_REALM=>$cuwatc_REALM});
        return 1;
}

#verify the 2f-optin user is logged in two factor
sub cuwat_is_logged_in_delegate_as_self_1f{
        my $response=shift;
        my $method=shift;
        my $uri=shift;
        my $expected_remote_user=$cuwatc_delegate_ID;

        #if the testid is not in the same realm as the keytab ... fixme should detect keytab realm
        if($cuwatc_REALM ne "DEV.CORNELL.EDU"){
                $expected_remote_user .= "\@$cuwatc_REALM";
        }
        return unless cuwat_cmp(defined($response), 1, "have a response");
        unless(t_cmp($response->code,200, "response status code")){
                return t_cmp(cuwat_filter_css($response->content), "error text","printing error text");
        }

	    my @lines = grep(!/=""/,split(/(\012|\015)+/,$response->content));
        return unless cuwat_cmp(scalar grep(/CUWA_2FA_USER/, @lines),0,"CUWA_2FA_USER must not exist");
        return unless cuwat_cmp(scalar grep(/CUWA_2FA_METHOD/, @lines),0,"CUWA_2FA_METHOD must not exist");

        return cuwat_echo_check_values($response, $method=>$uri,
                        {       (not $IISMODE)?(REMOTE_USER=>$expected_remote_user):(),
                                CUWA_REMOTE_USER=>$expected_remote_user,
                                HTTP_CUWA_REMOTE_USER=>$expected_remote_user,
                                (not $IISMODE)?(APACHE2_REQUESTREC_USER=>$expected_remote_user):(),
                                HTTP_REMOTE_USER=>$expected_remote_user,
                                CUWA_FULL_USER=>"$expected_remote_user\@$cuwatc_REALM",
                                HTTP_CUWA_FULL_USER=>"$expected_remote_user\@$cuwatc_REALM",
                                CUWA_REALM=>$cuwatc_REALM,
                                HTTP_CUWA_REALM=>$cuwatc_REALM});
        return 1;
}

#verify the delegate is logged in as the cuwa-test user
sub cuwat_is_logged_in_delegate_impersonating_other{
        my $response=shift;
        my $method=shift;
        my $uri=shift;
        my $expected_remote_user=$cuwatc_ID;

        #if the testid is not in the same realm as the keytab ... fixme should detect keytab realm
        if($cuwatc_REALM ne "DEV.CORNELL.EDU"){
                $expected_remote_user .= "\@$cuwatc_REALM";
        }
        return unless cuwat_cmp(defined($response), 1, "have a response");
        unless(t_cmp($response->code,200, "response status code")){
                return t_cmp(cuwat_filter_css($response->content), "error text","printing error text");
        }

        return cuwat_echo_check_values($response, $method=>$uri,
                        {       (not $IISMODE)?(REMOTE_USER=>$expected_remote_user):(),
                                CUWA_REMOTE_USER=>$expected_remote_user,
                                HTTP_CUWA_REMOTE_USER=>$expected_remote_user,
                                (not $IISMODE)?(APACHE2_REQUESTREC_USER=>$expected_remote_user):(),
                                HTTP_REMOTE_USER=>$expected_remote_user,
                                CUWA_FULL_USER=>"$expected_remote_user\@$cuwatc_REALM",
                                HTTP_CUWA_FULL_USER=>"$expected_remote_user\@$cuwatc_REALM",
                                CUWA_2FA_USER=>"$expected_remote_user\@$cuwatc_REALM",
                                CUWA_2FA_METHOD=>"TEST",
                                CUWA_IMPERSONATOR_NETID=>"$cuwatc_delegate_ID\@$cuwatc_REALM",
                                HTTP_CUWA_IMPERSONATOR_NETID=>"$cuwatc_delegate_ID\@$cuwatc_REALM",
                                CUWA_REALM=>$cuwatc_REALM,
                                HTTP_CUWA_REALM=>$cuwatc_REALM});
        return 1;
}

# does the response NOT contain any CUWA_ lines or REMOTE_USER_ linses
#in: HTTP::Response to be tested
#out: undef if the session is logged in and the page contains REMOTE_USER or CUWA_*. true otherwise
sub cuwat_has_no_login_vars{
	my $response=shift;
	my @lines = grep(!/=""/,split(/(\012|\015)+/,$response->content));
	cuwat_debug($response->as_string);
	return unless cuwat_cmp(scalar grep(/REMOTE_USER/, @lines),0,"REMOTE_USER must not exist");
	return unless cuwat_cmp(scalar grep(/HTTP_REMOTE_USER/, @lines),0,"HTTP_REMOTE_USER must not exist");
	return unless cuwat_cmp(scalar grep(/^CUWA_/, @lines),0,"CUWA_ variables must not exist");
	return unless cuwat_cmp(scalar grep(/^HTTP_CUWA_/, @lines),0,"CUWA_ variables must not exist");
	return 1;
}


#is the response missing the REMOTE_USER and CUWA_* headers
#i.e. is this NOT a logged in session
#in: HTTP::Response to be tested
#out: undef if the session is logged in and the page contains REMOTE_USER or CUWA_*. true otherwise
sub cuwat_is_logged_out_echo{
	my $response=shift;
	return unless t_cmp($response->as_string,qr/${main::SOS}TestCUWA::echo${main::EOS}/,"should be from TestCUWA::echo");
	return unless t_cmp($response->code,200,"should be status 200");
	return unless $IISMODE or t_cmp($response->content,qr/APACHE2_REQUESTREC_USER=""/,"request rec user should be empty");
	return unless cuwat_has_no_login_vars($response);
	return 1;
}

#get the value of a variable from echo.pm
#in: ($want, $content) where $want is the string key and $content is the response body from echo.pm
#out: value such that a line of the form: ^want="value"$ exists
sub cuwat_echo_get{
	my $want = shift;
	my $content = shift;
	my @lines = split(/(\012|\015)+/,$content);
	my $got=(grep(/^$want=/,@lines))[0];
	$got =~ m/^$want="([^"]*)"$/ms;
	return $1;
}

#logs in the configured user
#in: HTTP::Response containing weblogin form
#out: HTTP::Response of submitting form 
#depending on whether redirects are on or off this will
#be either a 303 from weblogin or a 200 from webauth (or an error)
sub cuwat_do_login{
	my $response = shift;
	my $form=HTML::Form->parse($response->decoded_content,$response->base);
	return unless $form;
	$form->value(netid=>"$cuwatc_ID\@$cuwatc_REALM");
	$form->value(password=>$cuwatc_PASSWORD);
	return $agent->request($form->click);
}

sub cuwat_do_login_with_dualID{
        my $response = shift;
        my $form=HTML::Form->parse($response->decoded_content,$response->base);
        return unless $form;
        $form->value(netid=>"$cuwatc_dual_ID\@$cuwatc_REALM");
        $form->value(password=>$cuwatc_PASSWORD);
        return $agent->request($form->click);
}

sub cuwat_do_login_with_optinID{
        my $response = shift;
        my $form=HTML::Form->parse($response->decoded_content,$response->base);
        return unless $form;
        $form->value(netid=>"$cuwatc_dual_optin_ID\@$cuwatc_REALM");
        $form->value(password=>$cuwatc_PASSWORD);
        return $agent->request($form->click);
}

sub cuwat_do_dual_login{
        my $response = shift;
        my $form=HTML::Form->parse($response->decoded_content,$response->base);
        return unless $form;
        return $agent->request($form->click);
}

sub cuwat_do_login_with_delegateID{
	my $response = shift;
	my $form=HTML::Form->parse($response->decoded_content,$response->base);
	return unless $form;
	$form->value(netid=>"$cuwatc_delegate_ID\@$cuwatc_REALM");
	$form->value(password=>$cuwatc_PASSWORD);
	return $agent->request($form->click);
}

sub cuwat_do_login_with_delegateID_default_realm{
	my $response = shift;
	my $form=HTML::Form->parse($response->decoded_content,$response->base);
	return unless $form;
	$form->value(netid=>"$cuwatc_delegate_ID");
	$form->value(password=>$cuwatc_PASSWORD);
	return $agent->request($form->click);
}

#FIXME to work around a test harness issue -- when you log in 1F, then impersonate, it will
#prompt for Duo. But in that prompt, there is no way to substitute TEST as the 2fa method instead of DUO.
#So the test harness case can't get past that point.
#To work around that, i'll log in 2f first, so it's already 2f when it gets to the delegation form.
sub cuwat_replace_1f_prompt_with_2f_prompt{
	my $response = shift;
    my $next_url;
    $next_url = $response->base;
    $next_url =~ s/&WAreason=1&/&WAreason=2&DualMethod=TEST&/g;
    cuwat_debug($next_url);
    return $agent->request(HTTP::Request->new(GET=>$next_url));
}

# to spoof the impersonation setting and just make sure that doesn't work
sub cuwat_replace_sImper0_with_sImper1{
	my $response = shift;
    my $next_url;
    $next_url = $response->base;
    $next_url =~ s/&sImper=0/&sImper=1/g;
    cuwat_debug($next_url);
    return $agent->request(HTTP::Request->new(GET=>$next_url));
}

sub cuwat_do_impersonate_self{
	my $response = shift;
	my $form=HTML::Form->parse($response->decoded_content,$response->base);
	return unless $form;
	$form->value(impersonateNetID=>"$cuwatc_delegate_ID");
	return $agent->request($form->click);
}

sub cuwat_do_impersonate_other_allowed{
	my $response = shift;
	my $form=HTML::Form->parse($response->decoded_content,$response->base);
	return unless $form;
	$form->value(impersonateNetID=>"$cuwatc_ID\@$cuwatc_REALM");
	return $agent->request($form->click);
}

sub cuwat_do_impersonate_other_unallowed{
	my $response = shift;
	my $form=HTML::Form->parse($response->decoded_content,$response->base);
	return unless $form;
	$form->value(impersonateNetID=>"$cuwatc_notdelegate_ID\@$cuwatc_REALM");
	return $agent->request($form->click);
}

#submit a select form which choose "DUO" as second authenticaiton
#sub cuwat_do_dual_select{
#        my $response = shift;
#        my $form=HTML::Form->parse($response->decoded_content,$response->base);
#        return unless $form;
#        $form->value(dualChoice=>"TEST");
#        return $agent->request($form->click);
#}

#redirect to /TEST to bypass DUO login
sub cuwat_bypass_duo{
my $response = shift;
my $next_url;
my $find = "DUO";
my $replace = "TEST";
$next_url= $response->base;
$next_url =~ s/$find/$replace/g;
cuwat_debug($next_url);
return $agent->request(HTTP::Request->new(GET=>$next_url));

}

#in: HTTP::Response containing weblogin form
#out: HTTP::Response of submitting form 
#same as cuwat_do_login but no realm entered in iD line
sub cuwat_do_login_default_realm{
	my $response = shift;
	my $form=HTML::Form->parse($response->decoded_content,$response->base);
	return unless $form;
	$form->value(netid=>"$cuwatc_ID");
	$form->value(password=>$cuwatc_PASSWORD);
	return $agent->request($form->click);
}

#does the passed HTTP::Response contain a security warning?
#in: HTTP::Response to be tested for Security Warning
#out: 1 for warning, undef otherwise
sub cuwat_is_sec_warning{
	my $response = shift;
	return unless cuwat_is_weblogin $response;
	return unless cuwat_cmp(cuwat_filter_css($response->content), qr/Security Warning/m,"Security Warning");
	return 1;
}

#advances past the security warning clickthrough
#in: HTTP::Response for weblogin click-through
#out: HTTP::Response for the result of clicking the link
sub cuwat_clickthrough{
	my $response = shift;
	return unless cuwat_is_sec_warning $response;
	my $next_url;
	#temporary work around until all the weblogins are upgraded to the new form based clickthrough
	if($response->content =~ m/If you would still like to login, click here .*? (?:(?:action)|(?:href))="([^"]*).*? name="wa" value="([^"]*)"/ms){
		$next_url = "$1?wa=$2";
	}
	else{
		$response->content =~ m/If you would still like to login, click here .*? (?:(?:action)|(?:href))="([^"]*)"/ms;
		$next_url = $1;
	}
	cuwat_cmp($next_url,qr/wa=/,"clickthrough URL should have wa= in it");
	return unless $next_url;
	return $agent->request(HTTP::Request->new(GET=>$next_url));
}

#does the passed HTTP::Response contain the 'POSTing your credential' bigpost form?
#in: HTTP::Response to be tested for bigpost form
#out: 1 for bigpost, undef otherwise
sub cuwat_is_post_cred_form{
        my $response = shift;
        return unless cuwat_is_weblogin $response;
	return unless cuwat_cmp($response->code, 200, "HTTP code indicates success on 'POSTing your credential' form page");
        return unless cuwat_cmp(cuwat_filter_css($response->content), qr/Login OK.*<form name=.bigpost. /m,"POSTing credential form page contains bigpost form");
        return 1;
}

#advances past the 'POSTing your credentials' bigpost clickthrough
#in: HTTP::Response for bigpost form click-through
#out: HTTP::Response for the result of clicking the submit button
sub cuwat_bigpost_clickthrough{
        my $response = shift;
        return unless cuwat_is_post_cred_form $response;
	my $post_cred_form=HTML::Form->parse($response->decoded_content,$response->base);
	return $agent->request($post_cred_form->click);
}

#this function exists to invert the checks for CUWACRED=Y
#since GET requests aren't being restored a 2nd time
sub cuwat_MAGIC_ARG_GET{
	my $response = shift;
	return not $response;
}

#checks the provided response against the requested uri
#to make sure that the final response came from where it
#was supposed to
#in: string containing method, string containing URI, HTTP::Response that came from URI
#out: true iff it passes
#
#example
# $x=GET $uri;
# ok cuwat_check_final_url(GET=>$uri,$x);

sub cuwat_check_final_url{
	my $method=shift;
	my $uri=shift;
	my $response=shift;
	my $ignore_tag=shift;
	$ignore_tag=0 unless defined $ignore_tag;
	t_cmp($response->base,qr/\?[^?]*\?/, "NEG Final URL should not contain two ?'s") and return;
	
	if($method eq 'GET'){
		cuwat_cmp($response->base,qr/^(http(s)?:\/\/[^\/]*)?\Q$uri\E$/m,"GET request should end up where it started") or return;
	}
	elsif(!$ignore_tag){
		cuwat_cmp($response->base,qr/^(http(s)?:\/\/[^\/]*)?\Q$uri\E(\?|&)CUWACRED=Y$/m,"non-GET request should contain a CUWACRED=Y tag") or return;
	}
	else{
		cuwat_cmp($response->base,qr/^(http(s)?:\/\/[^\/]*)?\Q$uri\E/m,"request should end up where it started") or return;
	}
	return 1;
}


#checks that the given response has the desired echo variable value
#in: ($response, $variable, $value, $why)
# $response, an HTTP::Response from a request to TestCUWA::echo
# $variable, should match a line of $variable="$value"
# $why is optional and is a description of what the check is doing
# why is passed to t_cmp and printed in verbose mode
#out: true if the line $variable="$value" is found in cuwat_check_echo_value_eq
sub cuwat_echo_check_value{
	my $response=shift;
	my $variable=shift;
	my $value=shift;
	my $why=shift;
	$why = "Check that $variable=\"$value\"" unless defined $why;
	
	my $actual_value=cuwat_echo_get($variable,$response->content);
	return cuwat_cmp($actual_value,$value,$why)		
}

#checks that the given response has the desired echo variable value
#in: ($response, $method, $uri, %options)
# $response, an HTTP::Response from a request to TestCUWA::echo
# $method, the method used to request URI
# $uri, the requested URI
# %options a reference to a hash containing $variable=>$value pairs to be checked
#out: true if all %options pass and the $response->code is 200
sub cuwat_echo_check_values{
	my $response=shift;
	my $method=shift;
	my $uri=shift;
	my $optref=shift;
	my %opts = %$optref;
	my $k;

	return unless t_cmp($response->code,200, "is response HTTP_OK");
	my @lines = split(/(\012|\015)+/,$response->content);
	foreach $k (keys %opts){
		my $v=$opts{$k};
		if( defined($v) ) {
			my $got=(grep(/^$k=/,@lines))[0];
			unless(cuwat_cmp($got, qr/^\Q$k="$v"\E$/, "checking for $k")){
				cuwat_debug($response->as_string);
				return 0;
			}
		} else {
			my $got=(grep(/^$k=/,@lines))[0];
			unless( cuwat_cmp($got, undef , "checking for $k")){
				cuwat_debug($response->as_string);
				return 0;
			}
		}
	}
	return 1; 
}


#takes input which might be HTML
#if the HTML appears to be from either cuweblogin or a cuwebauth error page the CSS formatting
#is removed. This is useful so that TEST -v prints less garbage to filter through
#if the HTML doesn't appear to be from cuweblogin or a cuwebauth error then the input is returned
#input: contents of $response->content
#output: either input or decss'ed input
sub cuwat_filter_css{
	my $content=shift;
	if( $content =~ m/\Q<div id="content">\E(.*)\Q<\/div><!--content-->\E/is){
		return "<!-- WEBLOGIN CSS REMOVED -->\n$1";
	}
	if($content =~ m/\Q<!-- ++++++++++ -->\E(.*)\Q<!-- ++++++++++ -->\E/is){
		return "<!-- WEBAUTH CSS REMOVED -->\n$1";
	}
	return $content;
}

sub cuwat_CUWATest{
	my $method = shift;
	my $uri = shift;
	my $frame = shift;
	$frame=0 unless defined $frame;
	my $file=(caller($frame))[1];
	my $line=(caller($frame))[2];
	$file =~ s/^.*\///;
	return "$Test::ntest/$file:$line [$method $uri]";
}

#########################
## The wrapper section
## wrappers around various Apache::Test functions
##
## WARNING: this section replaces ::GET, ::ok and ::t_cmp
## with local wrappers.
##
## A lot of this is an ugly hack because
## there is no good way to get the output of
##
## t/TEST
## when the tests pass but
##
## t/TEST -v
## if anything goes wrong
##
##
## todo: investigate Test::Harness::Straps or TAP::Parser
## not clear how well they integrate with Apache::Test
##
#########################

#acts like GET but also saves
#the URL for future reference
#and adds a CUWATest header to the request
*usual_GET=\&GET;
sub cuwat_GET{
	my $file=(caller(0))[1];
	my $line=(caller(0))[2];
	$file =~ s/^.*\///;
	$cuwat_lastheader=cuwat_CUWATest(GET=>$_[0],1);
	cuwat_debug("cuwat_GET: $cuwat_lastheader");
	return (usual_GET(@_, CUWATest=>$cuwat_lastheader));
}
{	#ok, now replace the global GET with ours
no warnings 'redefine';
*GET=\&cuwat_GET;
}

#acts like ok but also keeps track of 
#where we are, annotates the error log,
#and dumps crap out on failure
*usual_ok=\&ok;
sub cuwat_ok($;$$){
	my $ntest = $Test::ntest;
	my $vok;
	my $msg="";
	my($package, $filename, $line) = caller;
	if(@_ > 1){
		my ($iarg1,$iarg2) = ($_[0],$_[1]);
		#make the test harness report the failure at the caller rather than in this function
		eval "#line $line $filename\n" . '$vok=usual_ok($iarg1,$iarg2);';
	}
	else{
		my $iarg=shift;
		#make the test harness report the failure at the caller rather than in this function
		eval "#line $line $filename\n" . '$vok=usual_ok($iarg);';
	}
	if($vok){
		$msg="ok $ntest";
	}
	else{
		if($Test::todo{$ntest}){
			$msg="TODO not ok $ntest";
		}
		else{	
			$status=0;
			$msg="not ok $ntest";
		}
	}
	$dbg_buffer.="$msg\n";
	my $dbg_call_line=basename((caller(0))[2]);

	cuwat_write_errorlog("#### $msg #$dbg_script:$dbg_call_line\n\n");
	if((not $status) or $ENV{CUWAT_VERBOSE}){
		open DBG, '>>', $dbg_log;
		print DBG $dbg_buffer;
		close DBG;
		$dbg_buffer="";
	}
	$vok;
}
{	#ok, now replace the global ok with ours
no warnings 'redefine';
*ok=\&cuwat_ok;
}

#wrapper around t_debug
#so that we can capture the output
sub cuwat_debug{
	t_debug @_;
	my $msg=shift;
	$msg=cuwat_filter_css($msg);
	$msg=~s/^/# /gm;
	$dbg_buffer.="$msg\n";
	cuwat_write_errorlog("$msg\n");
}

#wrapper around t_cmp
#prints additional debugging information
sub cuwat_cmp($$;$){
	my ($received, $expected, $why)= @_;

	#grab call context
	my $sub=(caller(1))[3];
	my $line=(caller(0))[2];
	my $file=(caller(0))[1];
	$sub = "" unless defined $sub;
	$sub =~ s/^main:://;
	$file =~ s/^.*\///;

	#extend reason to contain call context
	$why = "$sub: " . (defined($why)?$why:"") . " ($file:$line)";

	#indent the expected and received
	cuwat_debug("testing : $why");
	cuwat_debug("  expected: " . Apache::TestUtil::struct_as_string(0, $expected));
	my $result = t_is_equal($received, $expected);
	cuwat_debug(($result?"  received: ":"  RECEIVED: ") . cuwat_filter_css(Apache::TestUtil::struct_as_string(0, $received)));

	#if the test failed, print a stack trace
	unless($result){
		cuwat_debug("  CUWATest: $cuwat_lastheader") if defined $cuwat_lastheader;   	
		my $i=1;
		while( (my @call_details = caller($i++)) ){
			my $sub=$call_details[3];
			my $line=$call_details[2];
			my $file=$call_details[1];
			$sub =~ s/^main:://;
			$file =~ s/^.*\///;
			cuwat_debug("   * via $sub at $file:$line");	
		}
	}
	return $result;

}
{
no warnings 'redefine';
*t_cmp=\&cuwat_cmp;
}
    

#stolen from Apache::TestUtil t_client_log_is_expected
#writes its argument to t/logs/error_log
sub cuwat_write_errorlog{
	my $vars = Apache::Test::config()->{'vars'};
	my $log_file = catfile($vars->{'serverroot'}, "logs", "error_log");

	my $fh = Symbol::gensym();
	open $fh, ">>$log_file" or die "Can't open $log_file: $!";
	my $oldfh = select($fh); $| = 1; select($oldfh);
	print $fh shift;
	close $fh;
}

#puts a footprint in the error_log
sub cuwat_stamplog{
	return cuwat_write_errorlog("\n** cuwat_stamplog from " . cuwat_CUWATest(defined($_)?$_:"",$cuwat_lastheader,1) . " **\n");
}

cuwat_write_errorlog("####CUWAT start test $dbg_script####\n\n");
