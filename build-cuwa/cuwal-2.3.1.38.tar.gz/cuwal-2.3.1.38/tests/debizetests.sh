#!/bin/sh
#converts the tests to run against debian. Not sure why it chokes in the first place, but this fixes it.
find -name '*.t' -exec egrep 't_cmp\(.*,qr/\^.*\$/m' {} \; -exec sed -ie 's/\(t_cmp.*,qr\/\^.*\)\$\/m/\1\/m/g' {} \;
find -name '*.pl' -exec egrep 't_cmp\(.*,qr/\^.*\$/m' {} \; -exec sed -ie 's/\(t_cmp.*,qr\/\^.*\)\$\/m/\1\/m/g' {} \;
echo Your tests directory has been debianized. DO NOT COMMIT IT, there is no easy way to revert this change.

