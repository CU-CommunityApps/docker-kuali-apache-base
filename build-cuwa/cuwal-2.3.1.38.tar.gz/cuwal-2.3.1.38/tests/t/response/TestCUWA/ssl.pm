package TestCUWA::echo2;

my @ISA = TestCUWA::echo;

#sub handler{
#	my $r=shift
#	$r->subprocess_env;
#	ok $ENV{"CUWA_REMOTE_USER"};
#	
1;
__DATA__
<VirtualHost TestCUWA::ssl>

#ServerName localhost.idm.cit.cornell.edu
SSLEngine on
SSLCipherSuite HIGH
SSLCertificateFile "@ServerRoot@/conf/localhost.idm.cit.cornell.edu.pem"
SSLOptions +StdEnvVars
BrowserMatch ".*MSIE.*" \
         nokeepalive ssl-unclean-shutdown \
         downgrade-1.0 force-response-1.0


<Location /CUWAPortal/Proxy>
	SetHandler cuwa_proxy
</Location>

<Location /TestCUWA__echo.pl>
	SetHandler modperl
	PerlResponseHandler TestCUWA::echo
</Location>
<Location /TestCUWA__echo.pl/r>
	SetHandler modperl
	PerlResponseHandler TestCUWA::echo
	AuthName CORNELL
	AuthType all
	require valid-user
</Location>

<Location /TestCUWA__frontend>
	AuthName CORNELL
	AuthType all
	require valid-user
	CUWAWAK2Flags 1
	SetHandler TestCUWA::ssl
</Location>

</VirtualHost>




