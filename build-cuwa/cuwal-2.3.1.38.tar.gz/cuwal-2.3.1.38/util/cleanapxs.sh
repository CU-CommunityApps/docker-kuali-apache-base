#!/bin/sh

rm -f *.o
rm -f *.la
rm -f *.lo
rm -f *.loT
rm -f *.slo
rm -rf .libs

