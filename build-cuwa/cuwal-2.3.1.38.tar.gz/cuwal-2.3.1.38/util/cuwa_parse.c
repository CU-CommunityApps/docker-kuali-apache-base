/*
 * $Id$
 */
#include <log.h>
#include <string.h>
#include <apr_strings.h>
#include <apr_lib.h>

#define CUWA2_LOG_DOMAIN cuwa.parse

//replaces all instances of old with new in src_dest
void cuwa_decode_replace(char *src_dest, char *old, char *new){
	int old_len,new_len,i;
	char *tmp;
	old_len=strlen(old);
	new_len=strlen(new);
	if(src_dest){
		cuwa_assert(old_len>=new_len);
	}
	while((tmp=strstr(src_dest,old))){
		for(i=0; i<old_len && i<new_len; i++)
			tmp[i]=new[i];
		tmp+=i;
		while(*tmp && old_len > new_len){
			tmp[0]=tmp[old_len-new_len];
			tmp++;
		}
	}
}
		

void cuwa_decode_spaces(char *src_dest){
	cuwa_decode_replace(src_dest,"%20"," ");
	cuwa_decode_replace(src_dest,"+"," ");
	
}

/**searches a string that contains a list delimited by delim
 * for needle. needle must either be the first element, the last element, or surrounded by delim
 * @param[in] haystack the string to search
 * @param[in] needle the string to find
 * @param[in] delim the character that seperates strings
 */
char * cuwa_strlist_member(apr_pool_t *pool,char *haystack, char *needle, char delim){
        char *ptr = NULL, *state=NULL;
        const char sep[] = {delim,'\0'};
        char *buff = apr_pstrdup(pool, haystack);
 
        //apr_strtok function truncate haystack, so we should
        //use a different buffer before processing it.
        ptr = apr_strtok( buff,sep, &state );
        while ( ptr )
        {
            if ( !strcmp( ptr, needle))  break;
            ptr = apr_strtok( NULL, sep, &state );
	}
	return ptr;
}


/**
 * cuwa_build_ssl_domain Construct a full https URL including port for server, https://server:port
 * @param[in] server The server
 * @param[in] pool The pool to use for allocation memory
 * @param[out] The full URL
 */
char *cuwa_build_ssl_domain( char * server , apr_pool_t *pool )
{
    char *host;
    char *ptr;

    //remove the ending "/" if there is any
    if ( server[strlen(server)-1] == '/' )
        server[strlen(server)-1] = '\0';

   //if http is present, return NULL
   if ( !strncmp( server, "http://",7) )
       return NULL;

   //if https is not present, add it in
    if ( strncmp(server, "https://", 8) )
        host = apr_psprintf(pool,"https://%s",server);
    else
        host = server;

    //check if the port is present
    ptr = host + 8;
    if ( !strchr( ptr,':' ) )
        host = apr_psprintf(pool, "%s:443",host);

    return host;
}

/*This function is used to find the parameter value from query string
 *for example: src "session=hjknm0&a1=apple&beep=ok"
 *             name "beep="
 *This function should return "ok"
 */
char * cuwa_get_query_string_val( apr_pool_t *pool,char *src, char *name)
{
    char *p;
    char *val = NULL;

    //check if we have name in src
    p = strstr( src, name );
    if (!p || strlen(p) == strlen(name))
        return val;

    p += strlen(name);
    val = apr_pstrdup( pool, p );
    p = strchr( val, '&');
    if ( p )
        *p = '\0';
    cuwa_trace("got %s=%s", name,val);

    return val;
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Some utility functions lifted from Apache's util.c for portability
////////////////////////////////////////////////////////////////////////////////////////////////////////////
char * cuwa_getword(apr_pool_t *atrans, const char **line, char stop)
{
    const char *pos = *line;
    int len;
    char *res;

    while ((*pos != stop) && *pos) {
        ++pos;
    }

    len = pos - *line;
    res = (char *)apr_palloc(atrans, len + 1);
    memcpy(res, *line, len);
    res[len] = 0;

    if (stop) {
        while (*pos == stop) {
            ++pos;
        }
    }
    *line = pos;

    return res;
}

/* Get a word, (new) config-file style --- quoted strings and backslashes
 * all honored
 */
char *cuwa_substring_conf(apr_pool_t *p, const char *start, int len,
                            char quote)
{
    char *result = apr_palloc(p, len + 2);
    char *resp = result;
    int i;

    for (i = 0; i < len; ++i) {
        if (start[i] == '\\' && (start[i + 1] == '\\'
                                 || (quote && start[i + 1] == quote)))
            *resp++ = start[++i];
        else
            *resp++ = start[i];
    }

    *resp++ = '\0';
    return result;
}

char * cuwa_getword_conf(apr_pool_t *p, const char **line)
{
    const char *str = *line, *strend;
    char *res;
    char quote;

    while (*str && apr_isspace(*str))
        ++str;

    if (!*str) {
        *line = str;
        return "";
    }

    if ((quote = *str) == '"' || quote == '\'') {
        strend = str + 1;
        while (*strend && *strend != quote) {
            if (*strend == '\\' && strend[1] &&
                (strend[1] == quote || strend[1] == '\\')) {
                strend += 2;
            }
            else {
                ++strend;
            }
        }
        res = cuwa_substring_conf(p, str + 1, strend - str - 1, quote);

                                           if (*strend == quote)
            ++strend;
    }
    else {
        strend = str;
        while (*strend && !apr_isspace(*strend))
            ++strend;

        res = cuwa_substring_conf(p, str, strend - str, 0);
    }

    while (*strend && apr_isspace(*strend))
        ++strend;
    *line = strend;
    return res;
}

char *cuwa_make_full_path(apr_pool_t *a, const char *src1,
                          const char *src2)
{
    apr_size_t len1, len2;
    char *path;
    len1 = strlen(src1);
    len2 = strlen(src2);

    /* allocate +3 for '/' delimiter, trailing NULL and overallocate
     * one extra byte to allow the caller to add a trailing '/'
     */
    path = (char *)apr_palloc(a, len1 + len2 + 3);
    if (len1 == 0) {
        *path = '/';
        memcpy(path + 1, src2, len2 + 1);
    }
    else {
        char *next;
        memcpy(path, src1, len1);
        next = path + len1;
        if (next[-1] != '/') {
            *next++ = '/';
        }
        memcpy(next, src2, len2 + 1);
    }
    return path;
}


/*
 * Given a string, replace any bare " with \" .
 */
char * cuwa_escape_quotes(apr_pool_t *p, const char *instring)
{
    int newlen = 0;
    const char *inchr = instring;
    char *outchr, *outstring;
    /*
     * Look through the input string, jogging the length of the output
     * string up by an extra byte each time we find an unescaped ".
     */
    while (*inchr != '\0') {
        newlen++;
        if (*inchr == '"') {
            newlen++;
        }
        /*
         * If we find a slosh, and it's not the last byte in the string,
         * it's escaping something - advance past both bytes.
         */
        if ((*inchr == '\\') && (inchr[1] != '\0')) {
            inchr++;
            newlen++;
        }
        inchr++;
    }
    outstring = apr_palloc(p, newlen + 1);
    inchr = instring;
    outchr = outstring;
    /*
     * Now copy the input string to the output string, inserting a slosh
     * in front of every " that doesn't already have one.
     */
    while (*inchr != '\0') {
        if ((*inchr == '\\') && (inchr[1] != '\0')) {
            *outchr++ = *inchr++;
            *outchr++ = *inchr++;
        }
        if (*inchr == '"') {
            *outchr++ = '\\';
        }
        if (*inchr != '\0') {
            *outchr++ = *inchr++;
        }
    }
    *outchr = '\0';
    return outstring;
}
