#ifndef __CUWA2_UTIL_CUWA_PARSE_H
#define __CUWA2_UTIL_CUWA_PARSE_H

#include <apr_pools.h>

#define CUWA_HUGE_STRING_LEN 2048

#if !APR_CHARSET_EBCDIC
/** linefeed */
#define LF 10
/** carrige return */
#define CR 13
/** carrige return /Line Feed Combo */
#define CRLF "\015\012"
#else /* APR_CHARSET_EBCDIC */
/* For platforms using the EBCDIC charset, the transition ASCII->EBCDIC is done
 * in the buff package (bread/bputs/bwrite).  Everywhere else, we use
 * "native EBCDIC" CR and NL characters. These are therefore
 * defined as
 * '\r' and '\n'.
 */
#define CR '\r'
#define LF '\n'
#define CRLF "\r\n"
#endif /* APR_CHARSET_EBCDIC */    

char *cuwa_build_ssl_domain( char * server , apr_pool_t *pool );
void cuwa_decode_spaces(char *string);
char * cuwa_getword(apr_pool_t *atrans, const char **line, char stop);
char * cuwa_getword_conf(apr_pool_t *p, const char **line);
char * cuwa_get_query_string_val( apr_pool_t *pool,char *src, char *name);
char *cuwa_make_full_path(apr_pool_t *a, const char *src1,const char *src2);
char * cuwa_strlist_member(apr_pool_t *p,char *haystack, char *needle, char delim);
char * cuwa_escape_quotes(apr_pool_t *p, const char *instring);
#endif
