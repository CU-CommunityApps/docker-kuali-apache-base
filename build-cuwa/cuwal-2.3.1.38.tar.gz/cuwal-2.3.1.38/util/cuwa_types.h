/************************************************************************
 * cuwa_types.h -- Some general type definitions
 *
 * Copyright 2007 Cornell University.
 * All Rights Reserved.
 *
 ************************************************************************
 *  $Log$
 *  Revision 1.10  2008/06/30 20:19:00  gbr4
 *  fix warning in weblogin. revert windows types to before 64-bit linux fix
 *
 *  Revision 1.9  2008/06/30 20:00:33  gbr4
 *  typo
 *
 *  Revision 1.8  2008/06/30 19:58:50  gbr4
 *  hack together windows types
 *
 *  Revision 1.7  2008/06/30 16:45:32  pb10
 *  Fix 64 bit issue.
 *
 *  Revision 1.6  2008/04/02 14:12:24  gbr4
 *  Bring endianness under autoconf control
 *  Fix the build
 *
 *  Revision 1.5  2008/01/18 16:19:36  pb10
 *  Solaris build fixes.
 *
 *  Revision 1.4  2008/01/18 04:36:52  pb10
 *  temp change or endian
 *
 *  Revision 1.3  2008/01/18 04:05:53  pb10
 *  Fix 64bit endian issue.
 *
 *  Revision 1.2  2007/10/23 21:29:36  pb10
 *  Added support for cred manager.
 *
 *  Revision 1.1  2007/10/18 20:09:43  pb10
 *  initial
 *
 ************************************************************************
 */

#ifndef _CUWA_TYPES_H
#define _CUWA_TYPES_H

//fixme dirty hack to ignore clash between apache and us over autoheader names
//need a proper fix

#ifdef PACKAGE_BUGREPORT
    #undef PACKAGE_BUGREPORT
#endif
#ifdef PACKAGE_NAME
    #undef PACKAGE_NAME
#endif
#ifdef PACKAGE_STRING
    #undef PACKAGE_STRING
#endif
#ifdef PACKAGE_TARNAME
    #undef PACKAGE_TARNAME
#endif
#ifdef PACKAGE_VERSION
    #undef PACKAGE_VERSION
#endif

#include "../autoconfig.h"
    #undef PACKAGE_BUGREPORT
    #undef PACKAGE_NAME
    #undef PACKAGE_STRING
    #undef PACKAGE_TARNAME
    #undef PACKAGE_VERSION

#ifdef HAVE_INTTYPES_H
#include <inttypes.h>           // uint16_t might be here; PRId64 too.
#endif
#ifdef HAVE_STDINT_H
#include <stdint.h>             // to get uint16_t (ISO naming madness)
#endif
#include <sys/types.h>          // our last best hope for uint16_t

typedef signed char schar;

#define uint64 unsigned long long

#ifndef WIN32
typedef int8_t      int8;
typedef int16_t     int16;
typedef int32_t     int32;
typedef int64_t     int64;
typedef uint8_t     uint8;
typedef uint16_t    uint16;
typedef uint32_t    uint32;
#else
#define uint32 unsigned long
#define uint16 unsigned short
#define int64 long long
#define int32 long
#define int16 short
/*
typedef __int8 int8;
typedef __int16 int16;
typedef __int32 int32;
typedef __int64 int64;
typedef unsigned __int8 uint8;
typedef unsigned __int16 uint16;
typedef unsigned __int32 uint32;
typedef unsigned __int64 uint64;
*/
#endif
/*
 * 64-bit conversion macros
 */
#if WORDS_BIGENDIAN
#   define ntohll(x) (x)
#   define htonll(x) (x)
#else
#   define htonll(x) \
     ((((x) & 0xff00000000000000ull) >> 56)                                   \
      | (((x) & 0x00ff000000000000ull) >> 40)                                 \
      | (((x) & 0x0000ff0000000000ull) >> 24)                                 \
      | (((x) & 0x000000ff00000000ull) >> 8)                                  \
      | (((x) & 0x00000000ff000000ull) << 8)                                  \
      | (((x) & 0x0000000000ff0000ull) << 24)                                 \
      | (((x) & 0x000000000000ff00ull) << 40)                                 \
      | (((x) & 0x00000000000000ffull) << 56))
#   define ntohll(x) htonll(x)
#endif

#endif /* _CUWA_TYPES_H */
