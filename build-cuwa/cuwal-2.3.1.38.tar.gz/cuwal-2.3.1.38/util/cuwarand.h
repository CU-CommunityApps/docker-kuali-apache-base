/**
 * CUWAL2 random number generator
 * -- validate or replace before production
 * Copyright (c) 2007 Cornell University
 ************************************************************************
 *  $Log$
 *  Revision 1.8  2008/04/10 16:57:11  gbr4
 *  Line endings only. This set of files had mixed line endings which breaks visual studio (and looks ugly in vim). Each file was converted to the format that resulted in the fewest line changes (i.e. whichever format it was mostly in).
 *
 *  Revision 1.7  2008/01/15 08:22:47  gbr4
 *  some random fixes ... always wanted to say that. Get rid of interlocked (apr_atomic) code as the APR 0.9 version was wrong -- needed atomic increment and get previous. Now getting a threadid and ignoring the race condition -- two racing threads should have different thread ids.
 *
 *  Revision 1.6  2008/01/14 20:12:28  hy93
 *  fix file cvs block so it log check in correctly
 *
 *  Revision 1.5  2008/01/14 20:06:20  hy93
 *  Change code to use different apr based on apr version
 *
 ************************************************************************
 */



#ifndef __CUWA2_RAND_H
#define __CUWA2_RAND_H

#include <stdarg.h>
#include <apr_atomic.h>
#include <apr_version.h>

/*
#if (APR_MAJOR_VERSION == 0)
#define cuwa_counter apr_atomic_t
#define cuwa_counter_increase apr_atomic_inc
#else
#define cuwa_counter apr_int32_t
#define cuwa_counter_increase apr_atomic_inc32
#endif
*/

/**
 * A randomness context.
 */

typedef struct cuwa_rand{
	//FIXME 64-bit clean?
	
	//cryptographically secure entropy
	unsigned char r1[16];
	
	//cryptographically secure entropy
	unsigned char r2[16];
	
	//a counter
	apr_uint32_t c ;
} cuwa_rand_t;

// MUST CALL apr_atomic_init first
void cuwa_rand_init(cuwa_rand_t *r);


apr_uint32_t cuwa_next_rand(cuwa_rand_t *r);
apr_uint64_t cuwa_next_rand64(cuwa_rand_t *r);

// MUST CALL apr_atomic_init first
void cuwa_rand_init_g();

apr_uint32_t cuwa_rand_g();
apr_uint64_t cuwa_rand64_g();


#endif
