/** $Id$
*/

#include <stdlib.h>
#include <stdio.h>

#define BYTESPERLINE    (12)

void HexDump( char *label,void *ptr, int len)
{
	static char hexStr[64];
	static char ascStr[64];
	unsigned char *cp = (unsigned char*)ptr;
	unsigned char *hs = (unsigned char *)hexStr;
	unsigned char *as = (unsigned char *)ascStr;
	int i;
	int offset=0;

	printf("%s: HexDump....%d bytes\n",label,len);
	for (i=0;len || i;i++) {
		/* If a line is completed */
		if (i==BYTESPERLINE) {
			*hs = '\0';
			*as = '\0';
			printf("%04x: %s  %s\n",offset,hexStr,ascStr);
			hs = (unsigned char *)hexStr;
			as = (unsigned char *)ascStr;
			i = 0; offset += BYTESPERLINE;
		}

		/* If the buffer is exhausted */
		if (!len) {
			break;
		}
		*hs++ = "0123456789ABCDEF"[ *cp / 16];
		*hs++ = "0123456789ABCDEF"[ *cp % 16];
		
		if ((*cp>31 && *cp<58) || (*cp>60 && *cp<94) || (*cp>96 && *cp<127))
			*as = *cp;
		else *as = '.';
		
		*hs = ' ';
		hs++;
		as++;
		len--;
		cp++;
	}

	/* Pad out last line */
	if (i != 0) {
		for (;i < BYTESPERLINE; i++) {
			*hs++ = ' '; *hs++ = ' '; *hs++ = ' ';
			*as++ = ' '; *as++ = ' '; *as++ = ' ';
		}
		*hs = '\0'; *as = '\0';
		printf("%04x: %s   %s\n",offset, hexStr,ascStr);
	}
}

const char id_util_hexdump_c[] = "$Id$";
