/** $Id:
 */

#ifndef CUWA_HEXDUMP_INCL
#define CUWA_HEXDUMP_INCL
void HexDump( char *label, void *ptr, int len);
#endif
