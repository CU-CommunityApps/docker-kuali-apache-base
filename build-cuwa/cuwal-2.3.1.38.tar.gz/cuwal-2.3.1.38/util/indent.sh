for i in *; do indent -gnu -bad -bap -bli0 -ts4 -i4 -ci4 -ut $i/*.c $i/*.h; done
