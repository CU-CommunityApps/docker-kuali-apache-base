/************************************************************************
 * list.h -- list operation for CUWebAuth
 *
 * Copyright 2007 Cornell University.
 * All Rights Reserved.
 *
 ************************************************************************
 *  $Log$
 *  Revision 1.6  2007/12/20 20:26:01  hy93
 *  Add a function interface
 *
 *
 *  Revision 1.1  2007/10/22 16:48:14  gbr4
 *  Initial commit, to publish API.
 *
 *
 ************************************************************************
 */


#ifndef __CUWA2_LIST_H
#define __CUWA2_LIST_H

#include <stdarg.h>




/**
 * A linked list node. 
 */
typedef struct cuwa_node_t
{
	struct cuwa_node_t *prev; /**< previous list node or NULL if this is the head of list */
	struct cuwa_node_t *next; /**< next list node or NULL if this is the tail of the list */
	void *data;		/**< the dataum carried by this node */
} cuwa_node;

/**
 * A doubly linked list.
 * @invariant cuwa_list_valid should return TRUE on any linked list
 */
typedef struct cuwa_list_t
{
	cuwa_node *head; /**< list head or NULL for an empty list */
	cuwa_node *tail; /**< list tail or NULL for an empty list */
} cuwa_list;

/**
 * comparison predicate for comparing two void*'s
 */
typedef int (*cuwa_pred_eq) (void *, void *);

/**
 * application predicate that "processes" a void*
 */
typedef void (*cuwa_pfvpv) (void *);

typedef void *(*cuwa_combine2) (void *, void *);

cuwa_node *cuwa_list_find (cuwa_list * l, void *tar, cuwa_pred_eq peq);
void cuwa_list_append (cuwa_list ** l, void *add);
int cuwa_list_valid (cuwa_list * l);
void *cuwa_list_del (cuwa_list * l, cuwa_node * n);
void cuwa_list_apply (cuwa_list * l, cuwa_pfvpv f);
void cuwa_list_destroy (cuwa_list * l);
int cuwa_list_len(cuwa_list *l);


#endif
