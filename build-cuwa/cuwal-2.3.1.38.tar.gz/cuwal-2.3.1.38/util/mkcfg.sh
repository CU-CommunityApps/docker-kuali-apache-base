#!/bin/sh

echo \#!/bin/sh

echo OUT\=\`echo \$1 \| sed \{\"s\/\\\.\/ \/g\;\"\} \| wc \-w\`
echo OUT\=\`echo \$OUT\`
echo OUT\=\`echo \$1 \| cut \-d \\. \-f 1\-\$OUT\`
echo echo Making \$OUT

echo cat \$1 \|\\

for i in `cat $1`
do
echo sed \{\"s\/\#\#`echo $i | cut -d \= -f 1`\#\#\/`echo $i | cut -d \= -f 2 | sed s/\\\//\\\\\\\\\\\\\\\\\\\//g | xargs`\/g\;\"\} \|\\
done

echo cat \> \$OUT

