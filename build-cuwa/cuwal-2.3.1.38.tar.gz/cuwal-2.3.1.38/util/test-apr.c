#include <apr.h>
#include <apr_pools.h>
#include <stdio.h>

int
main (int argc, char **argv)
{
  int i;
  char *c;
  long long x = 0xdeadbeef01234567;

  apr_pool_t *pool;

  printf ("init...\n");

  apr_pool_initialize ();
  apr_pool_create (&pool, NULL);

  printf ("go...\n");
  c = apr_psprintf (pool, "foobar:%qX\n", x);
  printf ("%s", c);
  printf ("pf:%llX\n", x);

}
