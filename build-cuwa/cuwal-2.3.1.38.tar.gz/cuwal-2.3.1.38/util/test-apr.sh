#!/bin/sh
gcc test-apr.c -I/usr/include/apr-0/ -lapr-0 -o test-apr
./test-apr
