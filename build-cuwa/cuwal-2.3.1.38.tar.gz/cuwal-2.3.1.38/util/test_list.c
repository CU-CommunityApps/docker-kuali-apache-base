#include <stdio.h>
#include <stdlib.h>
#include <assert.h>

#include "list.h"

typedef struct my_data_t
{
	int value;
}my_data;

int matchFun(void *v, void *v1)
{
        int v2 = atoi(v);
        my_data *v3 = v1;

        return ( (v2 == v3->value) ? 0:1 );
}

int check_list( cuwa_list *l, int deletedVal ,int listLen)
{
	cuwa_node *p = l->head;
	my_data *data;
	int i =1;
        int len = 0;
	int rc = 0;

        printf("in check list\n");
 	while (p)
	{
		data = p->data;
		if ( i == deletedVal )
			i++;
		if ( data->value != i )
		{
			rc = -1;
			fprintf(stdout, "value %d is missing in this list\n", i);
			break;
		}
		i++;
		p = p->next;
		len++;
	}
	if ( len != listLen  )
	{
		rc = -1;
		fprintf(stdout, "list length is wrong, %d- %d\n",len, listLen);
	}
	return rc;
}


int main(int argc, char *argv[])
{
	char *delVal = argv[1];
	my_data dataSet[10];
	int i;
	cuwa_list *myList = NULL;
	cuwa_node *deleteNode;
	int rc = 0;
        int listLen=0;

	for (i=0; i< 10; i++)
	{
		dataSet[i].value = i+1;
		cuwa_list_append( &myList, &dataSet[i]);	
   	}
         listLen = cuwa_list_len( myList);

	if ( (rc=check_list( myList,-1 , listLen)) == -1)
	{	
	   goto cleanup;	
	}
	
	deleteNode = cuwa_list_find( myList, delVal, matchFun );

        printf("About to delete node, %s\n", delVal);
	cuwa_list_del( myList, deleteNode );

	if ( (rc=check_list( myList,atoi(delVal) , listLen-1)) == -1 )
		goto cleanup;

cleanup:
	cuwa_list_destroy( myList );

	if ( rc == -1 )
		printf("FAILED\n");
	else
		printf("Test list succeed\n");
	
	return 0;
}
	
const char id_util_test_list_c[] = "$Id$";
