#include <util.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdarg.h>
#include <assert.h>
#include <log.h>
#include <ctype.h>

#define CUWA2_LOG_DOMAIN cuwa.util

char * cuwa_nextword (char **str, char sep)
{
    char *cur=*str,*next;
    if (!*str) return NULL;
    next = strchr(*str,sep);
    if (!next) *str = NULL;
    else
    {
        *next++ = 0;
        *str = next;
    }
    return cur;
}

void cuwa_util_str_to_lower(char *str)
{
    int i;

    for (i=0; str[i]; i++)
        str[i] = tolower( str[i] ) ;

}

void cuwa_util_str_to_upper(char *str)
{
    int i;

    for (i=0; str[i]; i++)
        str[i] = toupper( str[i] ) ;

}

void cuwa_util_replace_char_with( char *buffer, char remove, char newChar )
{
    char *ptr;

    ptr = strchr( buffer, remove );
    while ( ptr )
    {
         *ptr = newChar;
         ptr = strchr( ptr+1, remove);
    }
}

/*
 * check if str2 is part of str1 - case insensitive
 */
char *strstr_case_insensitive(char *str1, char *str2)
{
    if ( !*str2 )
        return str1;

    for ( ; *str1; ++str1 )
    {
        if ( toupper(*str1) == toupper(*str2) )
        {
            /*
             * Matched starting char -- loop through remaining chars.
             */
             char *h, *n;
             for ( h = str1, n = str2; *h && *n; ++h, ++n )
             {
                 if ( toupper(*h) != toupper(*n) )
                     break;
             }
             if ( !*n ) /* matched all of 'str2' to null termination */
                 return str1; /* return the start of the match */
       }
   }
   return 0;
}

/**
 * cuwa_util_replace_char Replaced the remove character in input string with space
 * @param[in/out] buffer The input string.
 * @param[in] remove The character to be replaced
 */
void cuwa_util_replace_char( char *buffer, char remove )
{
    cuwa_util_replace_char_with( buffer, remove, ' ');
}
const char id_util_util_c[] = "$Id$";
