
#include <impersonate.h>
#include <apr_strings.h>
#include <log.h>
#include <openssl/sha.h>


#include <stdlib.h>
#include <stdio.h>

#define CUWA2_LOG_DOMAIN cuwa.auth

char *convertToHex( void *ptr, int len)
{
        static char hexStr[64];
        unsigned char *cp = (unsigned char*)ptr;
        unsigned char *hs = (unsigned char *)hexStr;
        int i;

        for (i=0;i<len;i++) {

                *hs++ = "0123456789ABCDEF"[ *cp / 16];
                *hs++ = "0123456789ABCDEF"[ *cp % 16];

                cp++;
        }
        if (i==SHA_DIGEST_LENGTH) {
            *hs = '\0';
        }
       return hexStr;
}

char *sha1Hash(char *data)
{
    unsigned char hash[SHA_DIGEST_LENGTH];
    SHA1((unsigned char *)data, strlen(data), hash);

    return convertToHex( hash, SHA_DIGEST_LENGTH);
}

char *cuwa_get_impersonate_group_name( apr_pool_t *p, char *siteServiceID, char *authenticatedNetid)
{
    char *ptr2;
    char *impersonateGroupName;
    char *netid = apr_pstrdup( p, authenticatedNetid );

    ptr2 = strchr(netid,'@');
    if ( ptr2 ) *ptr2 = '\0';

    impersonateGroupName = apr_psprintf( p, "%s-%s-%s",IMPERSONATE_GROUP_PREFIX, netid, sha1Hash(siteServiceID));

    cuwa_trace("impersonateGrpName for netid %s on siteID %s is %s", netid,siteServiceID,impersonateGroupName);

    return impersonateGroupName;
}
        
   
