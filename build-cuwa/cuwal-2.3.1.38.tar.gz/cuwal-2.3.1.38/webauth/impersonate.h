
#ifndef CUWA_IMPERSONATE_INCLUDED

#define CUWA_IMPERSONATE_INCLUDED

#include <apr_pools.h>
#include <ctype.h>

#define CUWA_IMPERSONATE_AUDIT_IDENTIFIER "CUWA-Impersonate-Audit"
#define IMPERSONATE_GROUP_PREFIX  "IDMIPSN"

char *cuwa_get_impersonate_group_name( apr_pool_t *p, char *siteServiceID, char *authenticatedNetid);

#endif
