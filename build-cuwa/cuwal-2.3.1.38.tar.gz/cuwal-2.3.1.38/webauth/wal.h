/************************************************************************
 * wal.h -- Web server abstraction layer
 *
 * Copyright 2007 Cornell University.
 * All Rights Reserved.
 *
 ************************************************************************
 *  $Log$
 *  Revision 1.25.2.6  2015/10/01 16:02:58  hy93
 *  add session in cuwa_permit_lookup
 *
 *  Revision 1.25.2.5  2015/06/30 13:01:49  hy93
 *  apache 2.4 support
 *
 *  Revision 1.25.2.4  2015/04/29 13:06:25  hy93
 *  Fix sometimes error page didn't show properly
 *
 *  Revision 1.25.2.3  2015/04/23 15:03:02  hy93
 *  remove parameter that is not being used
 *
 *  Revision 1.25.2.2  2015/01/29 18:25:16  hy93
 *  remove loginurl from request_save function
 *
 *  Revision 1.25.2.1  2014/10/22 20:01:06  hy93
 *  add two factor support
 *
 *  Revision 1.25  2014/10/22 16:45:51  hy93
 *  remove two factor,Apache 2.4 support
 *
 *  Revision 1.24  2014/07/25 17:44:05  hy93
 *  Apache 2.4 support
 *
 *  Revision 1.23  2014/07/25 16:59:21  hy93
 *  save weblogin server url to the request
 *
 *  Revision 1.22  2009/10/06 16:39:43  pb10
 *  Added support for webauth accepting a WA credential via POST in addition to URL based cred.
 *  This is to support large credentials that exceed 2K browser limit of IE.
 *
 *  Revision 1.21  2009/09/22 19:23:09  pb10
 *  Resolves multiple site cookies present in cookie header due to
 *  overlapping cookie domains (IE).
 *
 *  Revision 1.20  2009/09/11 17:14:33  hy93
 *  add validator function interfaces
 *
 *  Revision 1.19  2009/02/13 16:29:58  pb10
 *  CUWAReturnURL now accepts a %p that will be replaced with the
 *  original path of the URL (without the file).
 *
 *  Revision 1.18  2009/02/11 06:26:02  pb10
 *  Removal of cuwal2sid cookie.
 *
 *  Revision 1.17  2009/02/10 15:12:07  hy93
 *  print remote IP in IIS log
 *
 *  Revision 1.16  2009/01/08 18:24:33  pb10
 *  Support for ErrorDocument
 *
 *  Revision 1.15  2008/10/09 16:19:24  hy93
 *  move common code in cuwa_wal_set_cookie to auth.c
 *
 *  Revision 1.14  2008/10/07 19:35:49  hy93
 *  add function prototype cuwa_wal_get_pool
 *
 *  Revision 1.13  2008/09/13 13:23:53  pb10
 *  Add IIS code and cleanup apache dependency in cuwa_version.c.
 *  Fix naming and positioning of DAV functions in wal.h.
 *
 *  Revision 1.12  2008/09/08 16:34:42  hy93
 *  add function prototype cuwa_portal_davlogin_handler
 *
 *  Revision 1.11  2008/08/26 17:53:30  hy93
 *  remove apache dependency in auth.c and portal.c
 *
 *  Revision 1.10  2008/08/25 19:59:59  hy93
 *  move portal proxy code to a new file
 *
 *  Revision 1.9  2008/08/19 20:10:59  pb10
 *  Return a log on portal error.  Move permit portal code to auth.c.
 *
 *  Revision 1.8  2008/08/16 12:24:13  hy93
 *  add prototypes
 *
 *  Revision 1.7  2008/08/11 04:13:28  hy93
 *  delegation support
 *
 *  Revision 1.6  2008/07/30 00:01:45  hy93
 *  change prototype
 *
 *  Revision 1.5  2008/07/29 02:33:53  pb10
 *  remove ^M's.
 *
 *  Revision 1.4  2008/07/29 01:55:29  pb10
 *  Incomplete mod_cuwebauth surgery.
 *
 *  Revision 1.3  2008/07/25 18:56:35  hy93
 *  add prototype
 *
 *  Revision 1.1  2008/07/24 20:23:40  pb10
 *  Partially complete.
 *
 ************************************************************************
 */

#ifndef _WAL_H
#define _WAL_H

#include <ap_release.h>
#include <apr_pools.h>
#include <cfg.h>
#include <cuwa_types.h>
#include <apr_tables.h>

#define CUWA_WEB_LOGIN_TGT_COOKIE_NAME "cuwltgttime="
#define CUWA_SITE_COOKIE_NAME "cuweblogin2="

#define CUWA_HA_ENABLED(c) (CFG_CUWAhighAvailability((c))!=NULL)? (*CFG_CUWAhighAvailability((c))==O_CFG_CUWAhighAvailability_on) : 1
#define CUWA_MAGIC_FILE "cuwal2.c0ntinue"
#define CUWA_MAGIC_CRED "wa="

// URI flags

#define CUWA_URI_NORMAL 0    // Parsed URI of the current request
#define CUWA_URI_UNPARSED 1  // Unparsed URI
#define CUWA_URI_ORIGINAL 2  // The original request (differs from current on an internal redirect)

#define HTTP_SERVER_ERROR 500
#define HTTP_AUTHZ_DENY 403

#define TWO_FACTOR_REDIRECT_CODE 2
#define TWO_FACTOR_NOT_REQUIRED  3

// Webauth core functions called by WAL implementation...

int cuwa_core_authn(void * request, apr_pool_t *pool, char *credential, char *cookies, char *expectedSID);
int cuwa_core_authz(void * request, apr_pool_t *pool);
int cuwa_core_show_error(void *r, apr_pool_t *pool, short status, int code, const char *fmt, ... );
char *cuwa_core_find_cookie(void *r, apr_pool_t *pool, char *cookies, char *cookieName, char **state);
int cuwa_core_portal_proxy_handler(void *r, apr_pool_t *pool );
int cuwa_core_portal_permit_handler(void *r, apr_pool_t *pool );
int cuwa_core_portal_davlogin_handler(void *r, apr_pool_t *pool);
const char *cuwa_core_get_error_string(int code );
char *cuwa_core_set_cookie(void *r, CUWACfg_t *cfg, char *cookieName, char *cookieValue);
char *cuwa_core_strip_path(apr_pool_t *pool, char *url);
char *cuwa_core_make_return_url(apr_pool_t *pool, CUWACfg_t *cfg, char *host, int port, int isSSL, char *path);
int cuwa_permit_lookup(void *r, apr_pool_t *pool, void *s,char *localid, char *keytab, char *remoteuser,
                       char *permitlist, char **memberships);
// Functions must be supported by WAL...

CUWACfg_t *cuwa_wal_get_config(void * request);
char *cuwa_wal_get_authtype(void * request);
int cuwa_wal_send_page(void * request, int status, char *html);
char *cuwa_wal_get_virtual_host(void * request, CUWACfg_t *cfg, char *path);
const char *cuwa_wal_get_method(void * request);
void cuwa_wal_dont_cache(void * request);
void cuwa_wal_set_user(void * request, char *user);
char *cuwa_wal_get_uri(void * request, int uri_flags);
char *cuwa_wal_get_hostname(void * request);
const char *cuwa_wal_get_header_in(void * request, char *name);
void cuwa_wal_set_header_in(void * request, char *name, char *value);
void cuwa_wal_clear_header_in(void * request, char *name);
void cuwa_wal_set_header_out(void * request, char *name, char *value);
void cuwa_wal_set_env(void * request, char *name, char *value);
char * cuwa_wal_get_env(void * request, char *name);
const char *cuwa_wal_get_log_error(void * request);
void cuwa_wal_set_cookie(void * request, char *name, char *value);
int cuwa_wal_request_save(uint64 *sessionid, void *request);
char *cuwa_wal_note_get(void *request, char *name);                      //get notes field
void cuwa_wal_note_set( void *r, char *name, char *value);               //set notes field
void *cuwa_wal_get_cuwa_module();
const apr_array_header_t *cuwa_wal_get_requires(void *req);
char * cuwa_wal_get_require_line(void *r,void *requires, int index );
char * cuwa_get_cred_from_uri(apr_pool_t *pool, char *url);
char * cuwa_get_cred_from_args(apr_pool_t *pool, char *post);
char * cuwa_get_sid_from_uri(apr_pool_t *pool, char *url);
char * cuwa_get_sid_from_arg(apr_pool_t *pool, char *url);
void *cuwa_wal_get_next_server(void *server);
CUWACfg_t *cuwa_wal_get_config_from_server(void *server);
char * cuwa_wal_escape_uri(apr_pool_t *pool, char *url);
const char *cuwa_wal_get_server_signature( const char *str, void *r);
char *cuwa_get_login_server_from_config( CUWACfg_t *cfg );
int cuwa_wal_return_declined();
const char *cuwa_wal_get_server_version();
apr_pool_t *cuwa_wal_get_pool(void *req);
int cuwa_wal_is_ssl( void *req );
int cuwa_wal_handle_error(void * request, int error);
char *cuwa_wal_get_remote_IP(void * req );

char *cuwa_check_keytab(void *cmd, void *sInfo, const char *arg, CUWACfg_t* scfg, CUWACfg_t* cfg, apr_pool_t *pool, char *what);
char *cuwa_check_sessionfilepath(void *cmd, void *sInfo,const char *arg, CUWACfg_t* scfg, CUWACfg_t* cfg,  apr_pool_t *pool,char *what);
char *cuwa_check_kerberosprincipal(void * cmd, void *sInfo, const char *arg, CUWACfg_t* scfg, CUWACfg_t* cfg, apr_pool_t *pool,char *what);
char *cuwa_check_returnurl(void *cmd, void *sInfo,  const char *arg, CUWACfg_t* scfg, CUWACfg_t* cfg, apr_pool_t *pool,char *what);

void cuwa_wal_log_error(void *rec,int logLevel, char *file, int line, int severity, char *logdomain, char *msg );
void cuwa_wal_log_rerror(void *rec,int logLevel, char *file, int line, int severity, char *logdomain, char *msg,char *cuwaTest,char *sidStr );
void cuwa_wal_log_cerror(void *rec,int logLevel, char *file, int line, int severity, char *logdomain, char *msg );
void cuwa_wal_log_perror(apr_pool_t *p,int logLevel, char *file, int line, int severity, char *logdomain, char *msg );

void cuwa_wal_save_error(void *request, int status, int code, char *msg);
int cuwa_wal_show_error(void *request);

int cuwa_auth_type(void *r, apr_pool_t *pool);
#endif
